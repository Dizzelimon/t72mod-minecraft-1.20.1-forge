# Field audio credits

The Ogg Vorbis files listed below are adapted recordings. Edits include extracting the audio, selecting excerpts, mono downmixing, equalization, gain changes, fades, and looping where applicable. The attribution licenses apply to the audio files independently of the mod's source code license. Authors do not endorse this mod.

| Asset | Original recording and author | License |
| --- | --- | --- |
| `mi8_engine.ogg` | [Mi-8MTV take-off](https://commons.wikimedia.org/wiki/File:Mi-8MTV_take-off.ogv), Andrius.v | [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/) |
| `mi24_engine.ogg` | [Mi-24 Hind at ILA Berlin Air Show 2016](https://commons.wikimedia.org/wiki/File:Mi-24_Hind_at_ILA_Berlin_Air_Show_2016.ogv), LEJ.approach/dvldi | [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/) |
| `ka52_engine.ogg` | [Kamov Ka-52 helicopters sortie](https://commons.wikimedia.org/wiki/File:Kamov_Ka-52_helicopters_sortie.webm), Ministry of Defence of the Russian Federation. Audio from the external flyby at the end. | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `t72_engine.ogg` | [6th Tank Brigade's exercise at Mulino](https://commons.wikimedia.org/wiki/File:6th_Tank_Brigade%27s_exercise_at_the_Mulino_Training_Ground_(19-03-2021).webm), Ministry of Defence of the Russian Federation. T-72 family recording. | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `t90m_engine.ogg` | [T-90M tanks of the 27th Guards Motorized Rifle Brigade](https://commons.wikimedia.org/wiki/File:T-90M_tanks_of_the_27th_Guards_Motorized_Rifle_Brigade_(2021-03-10).webm), Ministry of Defence of the Russian Federation | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `bmp_engine.ogg` | [19th Motorized Rifle Brigade's exercise with BMP-3](https://commons.wikimedia.org/wiki/File:19th_Motorized_Rifle_Brigade%27s_exercise_with_BMP-3_at_the_Tarskoye_training_ground_(06-04-2020).webm), Ministry of Defence of the Russian Federation | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `leopard_engine.ogg` | [Zwei Leopard 2A5 beim durchqueren eines Gewässer](https://commons.wikimedia.org/wiki/File:Zwei_Leopard_2A5_beim_durchqueren_eines_Gew%C3%A4sser.ogv), Sonaz. Leopard 2A5 source for the in-game Leopard 2A6. | [CC BY-SA 3.0 Germany](https://creativecommons.org/licenses/by-sa/3.0/de/) |
| `abrams_engine.ogg` | [Tank Drive By](https://freesound.org/people/qubodup/sounds/169743/), qubodup | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| `scout_engine.ogg` | [Pickup Truck Engine - Start, Idle, Stop](https://freesound.org/people/micmussfilm/sounds/852666/), micmussfilm. Used as a light vehicle engine. | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `truck_engine.ogg` | [Car engine.wav](https://freesound.org/people/BeeProductive/sounds/395586/), BeeProductive. Diesel recording used for the workshop truck. | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| `hatch.ogg` | [hatch2.wav](https://freesound.org/people/Mihacappy/sounds/828125/), Mihacappy | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| `tank_fire.ogg` | [2-37 AR, 1ID M1A2 Abrams Gunnery](https://commons.wikimedia.org/wiki/File:2-37_AR,_1ID_Hones_Lethality_During_M1A2_Abrams_Gunnery_(1017452).webm), U.S. Army Reserve video by Sgt. Joseph Honce and Staff Sgt. Logan Ubaldo Lechuga. Shared by game's tanks and BMP. | USA public domain |
| `artillery_fire.ogg` | [M777 Howitzer live fire during Saber Strike](https://commons.wikimedia.org/wiki/File:M777_Howitzer_live_fire_during_Saber_Strike_(1006305).webm), U.S. Army Reserve video by Staff Sgt. Vontrae Hampton | USA public domain |
| `automatic_fire.ogg` | [Short burst from a light machine gun](https://freesound.org/people/barryshamir/sounds/834247/), barryshamir. Used for automatic fire. | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| `rocket.ogg` | [U.S. Army AH-64E Apache Guardian Launching a SPIKE NLOS Missile](https://commons.wikimedia.org/wiki/File:U.S._Army_AH-64E_Apache_Guardian_Launching_a_SPIKE_NLOS_Missile.webm), Sgt. Jamie Robinson. Used as a general rocket launch effect. | USA public domain |
| `blast.ogg` | [Explosion with debris - authentic](https://freesound.org/people/sidohzen/sounds/165808/), sidohzen | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
