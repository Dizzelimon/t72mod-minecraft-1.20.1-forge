# Field audio credits

The Ogg Vorbis files listed below are adapted recordings. Edits include extracting the audio, selecting excerpts, mono downmixing, equalization, gain changes, fades, and looping where applicable. The attribution licenses apply to the audio files independently of the mod's source code license. Authors do not endorse this mod.

| Asset | Original recording and author | License |
| --- | --- | --- |
| `mi8_engine.ogg` | [Mi-8MTV take-off](https://commons.wikimedia.org/wiki/File:Mi-8MTV_take-off.ogv), Andrius.v | [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/) |
