package com.example.t72mod.block;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.FpvDroneEntity;
import com.example.t72mod.item.FlightBattery;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public final class ChargingDock extends BaseEntityBlock {
    public ChargingDock(Properties properties) { super(properties); }
    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new Storage(pos,state); }

    public static final class Storage extends BlockEntity {
        private ItemStack battery = ItemStack.EMPTY;
        public Storage(BlockPos pos,BlockState state) { super(T72Mod.DOCK_STORAGE.get(),pos,state); }
        @Override protected void saveAdditional(CompoundTag tag) {
            super.saveAdditional(tag);
            if (!battery.isEmpty()) tag.put("Pack",battery.save(new CompoundTag()));
        }
        @Override public void load(CompoundTag tag) {
            super.load(tag);
            battery = ItemStack.of(tag.getCompound("Pack"));
        }
    }

    @Override public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                           InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof Storage dock)) return InteractionResult.PASS;
        ItemStack held = player.getItemInHand(hand);
        if (!held.isEmpty() && !(held.getItem() instanceof FlightBattery)) return InteractionResult.PASS;
        if (!level.isClientSide) {
            if (!held.isEmpty() && dock.battery.isEmpty()) {
                dock.battery = held.split(1);
                dock.setChanged();
                level.scheduleTick(pos,this,20);
            } else if (held.isEmpty() && !dock.battery.isEmpty()) {
                player.setItemInHand(hand,dock.battery);
                dock.battery = ItemStack.EMPTY;
                dock.setChanged();
            } else if (!dock.battery.isEmpty()) {
                player.displayClientMessage(Component.translatable("message.t72mod.dock_charge",
                        FlightBattery.charge(dock.battery)*100/FpvDroneEntity.BATTERY_CAPACITY),true);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override public void neighborChanged(BlockState state, Level level, BlockPos pos, Block block,
                                          BlockPos source, boolean moving) {
        if (!level.isClientSide && level.hasNeighborSignal(pos)) level.scheduleTick(pos,this,20);
    }

    @Override public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!(level.getBlockEntity(pos) instanceof Storage dock) || dock.battery.isEmpty() || !level.hasNeighborSignal(pos)) return;
        int energy = FlightBattery.charge(dock.battery);
        if (energy >= FpvDroneEntity.BATTERY_CAPACITY) return;
        FlightBattery.charge(dock.battery, energy+65);
        dock.setChanged();
        if (FlightBattery.charge(dock.battery)<FpvDroneEntity.BATTERY_CAPACITY) level.scheduleTick(pos,this,20);
    }

    @Override public void onRemove(BlockState state,Level level,BlockPos pos,BlockState next,boolean moving) {
        if (!next.is(this) && !level.isClientSide && level.getBlockEntity(pos) instanceof Storage dock && !dock.battery.isEmpty()) {
            Containers.dropItemStack(level,pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5,dock.battery);
            dock.battery=ItemStack.EMPTY;
        }
        super.onRemove(state,level,pos,next,moving);
    }
}
