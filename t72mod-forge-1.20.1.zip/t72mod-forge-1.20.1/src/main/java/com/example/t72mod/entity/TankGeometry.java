package com.example.t72mod.entity;

import net.minecraft.world.phys.Vec3;

/** Local footprint and turret pivots, in the same model units as the baked meshes. */
public final class TankGeometry {
    public static final int TRACK_PARTS = 4;
    public static final int HULL_ROWS = 3;
    public static final int HULL_COLUMNS = 2;
    public static final int FIRST_TURRET_PART = TRACK_PARTS + HULL_ROWS*HULL_COLUMNS;
    public static final int FIRST_BARREL_PART = FIRST_TURRET_PART+2;
    public static final int BARREL_PARTS = 3;
    public static final int BASE_PART_COUNT = FIRST_BARREL_PART + BARREL_PARTS;

    private TankGeometry() {}

    public static double modelLift(TankType type) { return type == TankType.BMP3 ? 1.42 : 0; }
    private static double unit(TankType type) { return type.modelScale()/16.0; }
    public static double trackLength(TankType type) {
        return type == TankType.BMP3 ? 6.24 : (type == TankType.T72B || type == TankType.T90M ? 68 : 72)*unit(type);
    }
    public static double trackTop(TankType type) { return type == TankType.BMP3 ? 1.34 : 10*unit(type); }
    public static double trackCenter(TankType type) {
        return type == TankType.BMP3 ? 1.615
                : (type == TankType.T72B || type == TankType.T90M ? 20 : 21.5)*unit(type);
    }
    public static double trackWidth(TankType type) {
        return type == TankType.BMP3 ? .42 : (type == TankType.T72B || type == TankType.T90M ? 6 : 7)*unit(type);
    }
    public static double hullTop(TankType type) {
        return type == TankType.BMP3 ? BmpCabin.ROOF+.16
                : (type == TankType.T72B || type == TankType.T90M ? 17 : 16)*unit(type);
    }
    public static double hullWidth(TankType type) {
        return type == TankType.BMP3 ? 3.16 : (type == TankType.T72B || type == TankType.T90M ? 36 : 40)*unit(type);
    }
    public static double turretTop(TankType type) {
        return modelLift(type) + (type == TankType.BMP3 ? 22 : type == TankType.T72B ? 25 : 26)*unit(type);
    }
    public static double turretWidth(TankType type) {
        return (type == TankType.BMP3 ? 23 : type == TankType.ABRAMS || type == TankType.LEOPARD2 ? 35 : 30)*unit(type);
    }

    public static double turretLength(TankType type) {
        return (type == TankType.BMP3 ? 24 : type == TankType.ABRAMS || type == TankType.LEOPARD2 ? 43 : 33)*unit(type);
    }

    public static Vec3 turretCenter(Vec3 origin,float hullYaw,TankType type) {
        return AirframeLayout.world(origin,hullYaw,0,modelLift(type),
                (type == TankType.ABRAMS || type == TankType.LEOPARD2 ? 1 : 2)*unit(type));
    }

    public static Vec3 barrelPivot(Vec3 origin,float hullYaw,float turretYaw,TankType type) {
        int z = switch (type) { case T72B,T90M -> 21; case BMP3 -> 15; case ABRAMS -> 26; case LEOPARD2 -> 25; };
        double y = switch (type) { case BMP3 -> 18; case T72B,T90M -> 20.5; default -> 21; };
        return AirframeLayout.world(turretCenter(origin,hullYaw,type),turretYaw,0,y*unit(type),z*unit(type));
    }

    public static double barrelLength(TankType type) {
        return switch (type) { case T72B,T90M -> 62; case BMP3 -> 43; case ABRAMS -> 64; case LEOPARD2 -> 72; } * unit(type);
    }
    public static double barrelRadius(TankType type) {
        return (type == TankType.ABRAMS ? 2 : type == TankType.LEOPARD2 ? 1.75 : 1.50)*unit(type);
    }

    public static Vec3 coaxOffset(TankType type) {
        return new Vec3(type == TankType.BMP3 ? -.41 : -.50,.015,.89);
    }

    public static Vec3 coaxMuzzle(Vec3 pivot,float yaw,float pitch,TankType type) {
        Vec3 offset = coaxOffset(type);
        return pivot.add(Vec3.directionFromRotation(pitch,yaw).scale(offset.z))
                .add(AirframeLayout.world(Vec3.ZERO,yaw,offset.x,offset.y,0));
    }
}
