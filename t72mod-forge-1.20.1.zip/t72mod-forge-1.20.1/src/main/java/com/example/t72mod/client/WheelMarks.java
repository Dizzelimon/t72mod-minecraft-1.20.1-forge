package com.example.t72mod.client;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.GroundTraction;
import com.example.t72mod.entity.T72TankEntity;
import java.util.ArrayDeque;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT)
public final class WheelMarks {
    private record Mark(Vec3 center, double yaw, double width, long tick) {}
    private static final ArrayDeque<Mark> marks = new ArrayDeque<>();
    private static final WeakHashMap<Entity,Vec3> previous = new WeakHashMap<>();
    private static ClientLevel world;

    private static void checkWorld(ClientLevel current) {
        if (world != current) {
            marks.clear();
            previous.clear();
            world = current;
        }
    }

    public static void observe(Entity e, double axleWidth) {
        var game = Minecraft.getInstance();
        checkWorld(game.level);
        if (world == null || !e.onGround() || e.isInWater() || game.gameRenderer.getMainCamera().getPosition().distanceToSqr(e.position()) > 48*48) {
            previous.remove(e);
            return;
        }
        var last = previous.get(e);
        if (last != null && last.distanceToSqr(e.position()) < .16) return;
        previous.put(e,e.position());
        if (last == null || last.distanceToSqr(e.position()) > 9) return;
        boolean tank = e instanceof T72TankEntity;
        double yaw = Math.toRadians(e.getYRot());
        for (int side = -1; side <= 1; side += 2) {
            double offset = side * axleWidth;
            var p = GroundTraction.contact(e,offset,0);
            if (GroundTraction.sample(e,p) < .38f) continue;
            var above = p.above();
            if (!world.getBlockState(above).getCollisionShape(world,above).isEmpty()) p = above;
            var shape = world.getBlockState(p).getCollisionShape(world,p);
            if (shape.isEmpty()) continue;
            double y = p.getY() + shape.max(Direction.Axis.Y) + .012;
            marks.addLast(new Mark(new Vec3(e.getX()+offset*Math.cos(yaw),y,e.getZ()+offset*Math.sin(yaw)),
                    yaw,tank ? .29 : .14,world.getGameTime()));
            if (marks.size() > 384) marks.removeFirst();
        }
    }

    @SubscribeEvent public static void draw(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        var game = Minecraft.getInstance();
        checkWorld(game.level);
        if (world == null) return;
        long now = world.getGameTime();
        while (!marks.isEmpty() && now - marks.peekFirst().tick >= 240) marks.removeFirst();
        if (marks.isEmpty()) return;
        var buffers = game.renderBuffers().bufferSource();
        var type = RenderType.debugQuads();
        var out = buffers.getBuffer(type);
        var matrix = e.getPoseStack().last().pose();
        Vec3 camera = e.getCamera().getPosition();
        for (var mark : marks) {
            var rel = mark.center.subtract(camera);
            if (rel.lengthSqr() > 52*52) continue;
            int alpha = (int)(105 * Math.min(1, (240 + mark.tick - now) / 60.0));
            for (int i = 0; i < 4; i++) {
                double side = (i < 2 ? -1 : 1) * mark.width;
                double along = (i == 0 || i == 3 ? -1 : 1) * .13;
                out.vertex(matrix,(float)(rel.x + side * Math.cos(mark.yaw) - along * Math.sin(mark.yaw)),
                        (float)rel.y,(float)(rel.z + side * Math.sin(mark.yaw) + along * Math.cos(mark.yaw)))
                        .color(48,42,37,alpha).endVertex();
            }
        }
        buffers.endBatch(type);
    }

    @SubscribeEvent public static void logout(net.minecraftforge.client.event.ClientPlayerNetworkEvent.LoggingOut e) {
        checkWorld(null);
    }
}
