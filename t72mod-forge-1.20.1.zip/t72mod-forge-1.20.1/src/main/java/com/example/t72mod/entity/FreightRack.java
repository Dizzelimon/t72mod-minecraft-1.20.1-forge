package com.example.t72mod.entity;

import com.example.t72mod.T72Mod;
import com.example.t72mod.scenario.CrewRoutes;
import com.example.t72mod.item.VehicleTools;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.phys.Vec3;

public final class FreightRack {
    public interface Carrier {
        FreightRack freight();
        boolean bayOpen();
        void syncFreight(int colors);
    }
    private final Entity vehicle;
    private final Carrier carrier;
    private final ItemStack[] boxes = {ItemStack.EMPTY, ItemStack.EMPTY};
    private final long[] revision = new long[2];

    public <T extends Entity & Carrier> FreightRack(T vehicle) {
        this.vehicle = vehicle;
        this.carrier = vehicle;
    }
    private static int appearance(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem item) || !(item.getBlock() instanceof ShulkerBoxBlock box)) return 0;
        return box.getColor() == null ? 17 : box.getColor().getId()+1;
    }
    private void put(int slot, ItemStack stack) {
        boxes[slot] = stack;
        revision[slot]++;
        carrier.syncFreight(appearance(boxes[0]) | appearance(boxes[1]) << 5);
    }
    public long revision(int slot) { return revision[slot]; }
    public int count() { return (boxes[0].isEmpty()?0:1)+(boxes[1].isEmpty()?0:1); }

    private boolean docked() {
        return vehicle.isAlive() && vehicle.onGround() && carrier.bayOpen()
                && vehicle.getDeltaMovement().horizontalDistanceSqr() < .0025;
    }
    private Vec3 rear() {
        return AirframeLayout.world(vehicle.position(),vehicle.getYRot(),0,1.4,
                vehicle instanceof HelicopterEntity ? -3.74 : -2.85);
    }
    private static void notice(Player p,String key) { p.displayClientMessage(Component.translatable("message.t72mod.freight_"+key),true); }

    public InteractionResult use(Player p,InteractionHand hand) {
        ItemStack held=p.getItemInHand(hand);
        boolean hook=held.is(T72Mod.FREIGHT_HOOK.get());
        if (!hook && appearance(held)==0) return InteractionResult.PASS;
        if (vehicle.level().isClientSide) return InteractionResult.SUCCESS;
        if (!docked() || p.isPassenger() || p.getEyePosition().distanceToSqr(rear())>18
                || !VehicleTools.mayHandleFreight(p,vehicle)) {
            notice(p,"locked");
            return InteractionResult.CONSUME;
        }
        int slot=AirframeLayout.local(vehicle.position(),vehicle.getYRot(),p.position()).x<0 ? 0 : 1;
        if (!hook) {
            if (!boxes[slot].isEmpty()) notice(p,"full");
            else {
                put(slot,held.split(1));
                CrewRoutes.loaded(p,vehicle,slot);
                notice(p,"loaded");
            }
        } else if (p.isShiftKeyDown()) {
            if (!boxes[slot].isEmpty() && p.getInventory().add(boxes[slot].copy())) {
                put(slot,ItemStack.EMPTY);
                held.removeTagKey("FreightSource");
                CrewRoutes.moved(p,vehicle,slot,null,0);
                notice(p,"unloaded");
            } else notice(p,"unload_failed");
        } else {
            CompoundTag state=held.getOrCreateTag();
            if (state.hasUUID("FreightSource") && !vehicle.getUUID().equals(state.getUUID("FreightSource"))) {
                Entity source=((ServerLevel)vehicle.level()).getEntity(state.getUUID("FreightSource"));
                if (source instanceof Carrier other && VehicleTools.mayHandleFreight(p,source)
                        && other.freight().transfer(this,state.getInt("FreightSlot"),slot,state.getLong("FreightRevision"))) {
                    CrewRoutes.moved(p,source,state.getInt("FreightSlot"),vehicle,slot);
                    state.remove("FreightSource");
                    notice(p,"transferred");
                } else notice(p,"transfer_failed");
            } else if (!boxes[slot].isEmpty()) {
                state.putUUID("FreightSource",vehicle.getUUID());
                state.putInt("FreightSlot",slot);
                state.putLong("FreightRevision",revision[slot]);
                notice(p,"selected");
            } else notice(p,"empty");
        }
        return InteractionResult.CONSUME;
    }
    private boolean transfer(FreightRack to,int from,int dest,long expected) {
        if (from<0 || from>=boxes.length || revision[from]!=expected || boxes[from].isEmpty() || !to.boxes[dest].isEmpty()
                || !docked() || !to.docked() || rear().distanceToSqr(to.rear())>64) return false;
        to.put(dest,boxes[from]);
        put(from,ItemStack.EMPTY);
        return true;
    }
    public void write(CompoundTag tag) {
        for (int i=0;i<boxes.length;i++) {
            if (!boxes[i].isEmpty()) tag.put("Freight"+i,boxes[i].save(new CompoundTag()));
            tag.putLong("FreightRevision"+i,revision[i]);
        }
    }
    public void read(CompoundTag tag) {
        for (int i=0;i<boxes.length;i++) {
            put(i,ItemStack.of(tag.getCompound("Freight"+i)));
            revision[i]=tag.getLong("FreightRevision"+i);
        }
    }
    public void drop() {
        for (int i=0;i<boxes.length;i++) {
            if (!boxes[i].isEmpty()) vehicle.spawnAtLocation(boxes[i]);
            put(i,ItemStack.EMPTY);
        }
    }
}
