package com.example.t72mod.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;
import java.util.UUID;

public interface ArtilleryTowVehicle {
    Mob towEntity();
    Optional<UUID> towedGun();
    void setTowedGun(UUID gun);
    Vec3 rearHitch(Vec3 position, float yaw);

    default Vec3 rearHitch() {
        return this.rearHitch(this.towEntity().position(), this.towEntity().getYRot());
    }

    default boolean couple(ArtilleryEntity gun) {
        Mob vehicle = this.towEntity();
        if (vehicle.level().isClientSide || !vehicle.isAlive() || !gun.isAlive() || gun.level() != vehicle.level()
                || this.towedGun().isPresent() || gun.towVehicle().isPresent() || gun.isVehicle()
                || !gun.hasGroundSupport() || vehicle.getDeltaMovement().horizontalDistanceSqr() > .012
                || this.rearHitch().distanceToSqr(gun.position()) > 42) return false;
        if (!vehicle.onGround() && !vehicle.level().getBlockCollisions(vehicle,
                vehicle.getBoundingBox().move(0, -.13, 0)).iterator().hasNext()) return false;
        this.setTowedGun(gun.getUUID());
        gun.attachToTowVehicle(vehicle);
        return true;
    }

    default void uncouple() {
        Mob vehicle = this.towEntity();
        if (!(vehicle.level() instanceof ServerLevel level)) return;
        UUID other = this.towedGun().orElse(null);
        this.setTowedGun(null);
        if (other != null && level.getEntity(other) instanceof ArtilleryEntity gun
                && gun.towVehicle().filter(vehicle.getUUID()::equals).isPresent()) gun.setTowVehicle(null);
    }
}
