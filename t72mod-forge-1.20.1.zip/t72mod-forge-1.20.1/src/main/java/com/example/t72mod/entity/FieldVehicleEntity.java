package com.example.t72mod.entity;

import com.example.t72mod.T72Mod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.server.level.ServerLevel;

public final class FieldVehicleEntity extends PathfinderMob implements ArtilleryTowVehicle, FreightRack.Carrier {
    private static final int CAPACITY = 800;
    private static final EntityDataAccessor<Integer> FUEL = data();
    private static final EntityDataAccessor<Integer> WHEELS = data();
    private static final EntityDataAccessor<Integer> EQUIPMENT = data();
    private static final EntityDataAccessor<Boolean> WORKSHOP_OPEN = SynchedEntityData.defineId(
            FieldVehicleEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Optional<UUID>> TOWED_GUN = SynchedEntityData.defineId(
            FieldVehicleEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Integer> RACK_COLORS = data();
    private final FreightRack rack = new FreightRack(this);
    @Override public FreightRack freight() { return rack; }
    @Override public boolean bayOpen() { return !this.scout() && this.workshopOpen(); }
    @Override public void syncFreight(int colors) { this.entityData.set(RACK_COLORS,colors); }
    public int freightColors() { return this.entityData.get(RACK_COLORS); }

    private final SimpleContainer cargo = new SimpleContainer(27) {
        @Override public boolean stillValid(Player p) {
            return isAlive() && (hasPassenger(p) || distanceToSqr(p) <= 36);
        }
    };
    private final GroundTraction terrain = new GroundTraction();
    private int driveTicks;
    private float wheelAngle;

    public FieldVehicleEntity(EntityType<? extends FieldVehicleEntity> type, Level level) {
        super(type, level);
        this.setMaxUpStep(0.9F);
        this.blocksBuilding = true;
    }

    private static EntityDataAccessor<Integer> data() {
        return SynchedEntityData.defineId(FieldVehicleEntity.class, EntityDataSerializers.INT);
    }

    public static AttributeSupplier.Builder attributes(boolean scout) {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, scout ? 120 : 100)
                .add(Attributes.ARMOR, scout ? 10 : 6).add(Attributes.KNOCKBACK_RESISTANCE, 0.8);
    }

    @Override protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(RACK_COLORS,0);
        this.entityData.define(FUEL, 0);
        this.entityData.define(WHEELS, 100);
        this.entityData.define(EQUIPMENT, 0);
        this.entityData.define(TOWED_GUN, Optional.empty());
        this.entityData.define(WORKSHOP_OPEN, false);
    }

    public void starterSupplies() {
        this.entityData.set(FUEL, 400);
        if (!this.scout()) this.cargo.setItem(0, new ItemStack(T72Mod.REPAIR_KIT.get(), 2));
    }

    public boolean workshopOpen() { return this.entityData.get(WORKSHOP_OPEN); }

    @Override public Mob towEntity() { return this; }

    @Override public Optional<UUID> towedGun() { return this.entityData.get(TOWED_GUN); }

    @Override public void setTowedGun(UUID gun) { this.entityData.set(TOWED_GUN, Optional.ofNullable(gun)); }

    @Override public Vec3 rearHitch(Vec3 position, float yaw) {
        return AirframeLayout.world(position, yaw, 0, .50, this.scout() ? -3.14 : -3.82);
    }

    private boolean hasGroundSupport() {
        return this.onGround() || this.level().getBlockCollisions(this, this.getBoundingBox().move(0, -.13, 0))
                .iterator().hasNext();
    }

    public boolean winch(T72TankEntity tank) {
        if (this.level().isClientSide || this.scout() || !this.isAlive() || !tank.isAlive()
                || tank.level() != this.level() || !(tank.isTracksBroken() || tank.isWreck()) || tank.isVehicle()
                || this.getDeltaMovement().horizontalDistanceSqr() > .01 || !this.hasGroundSupport()) return false;
        Vec3 cable = this.rearHitch().subtract(tank.position()).multiply(1, 0, 1);
        double length = cable.length();
        if (length < 3.1 || length > 11) return false;
        Vec3 before = tank.position();
        tank.move(net.minecraft.world.entity.MoverType.SELF, cable.normalize().scale(Math.min(.90, length - 3)));
        return tank.position().distanceToSqr(before) > .01;
    }


    public boolean scout() { return this.getType() == T72Mod.SCOUT_CAR.get(); }
    public int fuel() { return this.entityData.get(FUEL); }
    public int wheels() { return this.entityData.get(WHEELS); }
    public int equipment() { return this.entityData.get(EQUIPMENT); }
    public boolean scanning() { return this.scout() && this.equipment() > 160; }
    public float wheelAngle() { return this.wheelAngle; }

    @Override protected boolean canAddPassenger(Entity e) {
        return this.isAlive() && e instanceof Player && this.getPassengers().size() < (this.scout() ? 2 : 3);
    }

    @Override public LivingEntity getControllingPassenger() {
        return this.getFirstPassenger() instanceof LivingEntity driver ? driver : null;
    }

    @Override protected void positionRider(Entity passenger, Entity.MoveFunction move) {
        int seat = this.getPassengers().indexOf(passenger);
        if (seat < 0) return;
        Vec3 pos = this.position().add(Vec3.directionFromRotation(0, this.getYRot()).scale(seat < 2 ? 0.53 : -0.90))
                .add(Vec3.directionFromRotation(0, this.getYRot() + 90).scale(seat == 0 ? -0.51 : seat == 1 ? 0.51 : 0))
                .add(0, 0.84 + passenger.getMyRidingOffset(), 0);
        move.accept(passenger, pos.x, pos.y, pos.z);
    }

    @Override public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        for (int heading : new int[]{90, -90, 180}) {
            Vec3 point = this.position().add(Vec3.directionFromRotation(0, this.getYRot() + heading).scale(2.6));
            if (this.level().noCollision(passenger, passenger.getBoundingBox().move(point.subtract(passenger.position())))) return point;
        }
        return this.position().add(0, this.getBbHeight(), 0);
    }

    @Override public boolean canBeCollidedWith() { return this.isAlive(); }
    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double distance) { return false; }

    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.isAlive() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        ItemStack held = player.getItemInHand(hand);
        if (!this.scout()) {
            InteractionResult freight = rack.use(player,hand);
            if (freight.consumesAction()) return freight;
        }
        int amount = T72TankEntity.getFuelValue(held);
        if (amount > 0 && !held.is(Items.LAVA_BUCKET) && this.fuel() < CAPACITY) {
            if (!this.level().isClientSide) {
                this.entityData.set(FUEL, Math.min(CAPACITY, this.fuel() + amount));
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
        } else if (held.is(T72Mod.REPAIR_KIT.get()) && (this.wheels() < 100 || this.getHealth() < this.getMaxHealth())) {
            if (!this.level().isClientSide) {
                this.entityData.set(WHEELS, 100);
                this.heal(45);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
        } else if (player.isShiftKeyDown()) {
            if (!this.level().isClientSide) this.openCargo(player);
        } else if (this.canAddPassenger(player)) {
            if (!this.level().isClientSide && !player.startRiding(this)) return InteractionResult.FAIL;
        } else return InteractionResult.PASS;
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    private void openCargo(Player p) {
        p.openMenu(new SimpleMenuProvider((id, inventory, owner) -> ChestMenu.threeRows(id, inventory, this.cargo),
                Component.translatable("menu.t72mod.field_cargo")));
    }

    public void action(Player p, int action) {
        if (this.level().isClientSide || !this.isAlive() || !this.hasPassenger(p)) return;
        if (action == 0) this.openCargo(p);
        if (action == 2 && !this.scout() && this.getControllingPassenger() == p
                && this.onGround() && this.getDeltaMovement().horizontalDistanceSqr() < .003) {
            this.entityData.set(WORKSHOP_OPEN, !this.workshopOpen());
            this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.PLAYERS, .8F, 1);
            return;
        }
        if (action != 1 || this.getControllingPassenger() != p || this.equipment() > 0) return;
        if (this.scout()) {
            if (this.fuel() < 25) {
                this.notice(p, "scout_no_fuel");
                return;
            }
            this.entityData.set(FUEL, this.fuel() - 25);
            this.entityData.set(EQUIPMENT, 360);
            return;
        }
        if (this.getDeltaMovement().horizontalDistanceSqr() > 0.003) {
            this.notice(p, "workshop_stop");
            return;
        }
        int slot = -1;
        for (int i = 0; i < this.cargo.getContainerSize(); i++) {
            if (this.cargo.getItem(i).is(T72Mod.REPAIR_KIT.get())) {
                slot = i;
                break;
            }
        }
        if (slot < 0 && !p.getAbilities().instabuild) {
            this.notice(p, "workshop_no_kit");
            return;
        }
        var tanks = this.level().getEntitiesOfClass(T72TankEntity.class, this.getBoundingBox().inflate(6, 2, 6),
                tank -> tank.isAlive() && this.distanceToSqr(tank) <= 36 && this.hasLineOfSight(tank));
        tanks.sort(Comparator.comparingDouble(this::distanceToSqr));
        for (T72TankEntity tank : tanks) {
            if (!tank.serviceFromTruck()) continue;
            if (!p.getAbilities().instabuild) this.cargo.removeItem(slot, 1);
            this.entityData.set(EQUIPMENT, 160);
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1, 1.1F);
            this.notice(p, "workshop_done");
            return;
        }
        this.notice(p, "workshop_no_target");
    }

    private void notice(Player p, String key) {
        p.displayClientMessage(Component.translatable("message.t72mod." + key), true);
    }

    @Override public void travel(Vec3 ignored) {
        if (!(this.getControllingPassenger() instanceof Player driver) || this.fuel() == 0 || this.wheels() == 0 || this.workshopOpen()) {
            this.setDeltaMovement(this.getDeltaMovement().multiply(0.65, 1, 0.65));
            super.travel(Vec3.ZERO);
            return;
        }
        float factor = 0.45F + this.wheels() * 0.0055F;
        if (Math.abs(driver.zza) > 0.01F) this.setYRot(this.getYRot()
                - driver.xxa * (this.scout() ? 4.4F : 3.1F) * factor * Math.signum(driver.zza));
        this.yBodyRot = this.getYRot();
        this.yHeadRot = this.getYRot();
        if (this.towedGun().isPresent()) factor *= .68F;
        int colors = this.freightColors();
        int load = ((colors & 31)==0 ? 0 : 1) + (colors >> 5 ==0 ? 0 : 1);
        factor *= (1 - terrain.update(this) * (this.scout() ? .32F : .44F)) / (1 + .08F * load);
        this.setSpeed((this.scout() ? 0.41F : 0.33F) * factor);
        super.travel(new Vec3(0, 0, driver.zza * (driver.zza < 0 ? 0.48 : 1)));
    }

    @Override public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            this.wheelAngle = Mth.wrapDegrees(this.wheelAngle + (float) Math.hypot(this.getX() - this.xo, this.getZ() - this.zo) * 172);
        } else {
            if (terrain.wear(this)) this.entityData.set(WHEELS, Math.max(0, wheels() - 1));
            if (this.equipment() > 0) this.entityData.set(EQUIPMENT, this.equipment() - 1);
            if (this.getControllingPassenger() instanceof Player p && Math.abs(p.zza) > 0.01F
                    && !this.workshopOpen() && this.fuel() > 0 && this.wheels() > 0 && ++this.driveTicks >= Math.round(16 - 4 * terrain.update(this))) {
                this.driveTicks = 0;
                this.entityData.set(FUEL, this.fuel() - 1);
            }
        }
    }

    @Override public boolean hurt(DamageSource source, float amount) {
        boolean hit = super.hurt(source, amount);
        if (hit && !this.level().isClientSide && this.isAlive()) this.entityData.set(WHEELS,
                Math.max(0, this.wheels() - Math.round(Math.min(100, amount * 1.25F))));
        return hit;
    }

    @Override public void die(DamageSource source) {
        if (!this.level().isClientSide) {
            this.uncouple();
            this.ejectPassengers();
            rack.drop();
            Containers.dropContents(this.level(), this.blockPosition(), this.cargo);
        }
        super.die(source);
    }

    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putDouble("SurfaceWear",terrain.distance());
        rack.write(tag);
        tag.putInt("Fuel", this.fuel());
        tag.putInt("Wheels", this.wheels());
        this.towedGun().ifPresent(id -> tag.putUUID("TowedGun", id));
        ListTag contents = new ListTag();
        for (int i = 0; i < this.cargo.getContainerSize(); i++) {
            ItemStack stack = this.cargo.getItem(i);
            if (stack.isEmpty()) continue;
            CompoundTag entry = new CompoundTag();
            entry.putByte("Slot", (byte) i);
            contents.add(stack.save(entry));
        }
        tag.put("Cargo", contents);
    }

    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        terrain.restore(tag.getDouble("SurfaceWear"));
        rack.read(tag);
        this.entityData.set(FUEL, Mth.clamp(tag.getInt("Fuel"), 0, CAPACITY));
        this.entityData.set(TOWED_GUN, tag.hasUUID("TowedGun") ? Optional.of(tag.getUUID("TowedGun")) : Optional.empty());
        if (tag.contains("Wheels")) this.entityData.set(WHEELS, Mth.clamp(tag.getInt("Wheels"), 0, 100));
        this.cargo.clearContent();
        for (Tag item : tag.getList("Cargo", Tag.TAG_COMPOUND)) {
            CompoundTag entry = (CompoundTag) item;
            int slot = entry.getByte("Slot") & 255;
            if (slot < this.cargo.getContainerSize()) this.cargo.setItem(slot, ItemStack.of(entry));
        }
    }
}
