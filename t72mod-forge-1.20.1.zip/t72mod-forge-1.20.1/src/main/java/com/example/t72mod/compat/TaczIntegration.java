package com.example.t72mod.compat;

import com.example.t72mod.config.T72ServerConfig;
import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.FieldVehicleEntity;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.TaczGunStand;
import com.example.t72mod.entity.VehiclePart;
import com.tacz.guns.api.event.common.EntityHurtByGunEvent;
import com.tacz.guns.api.event.common.GunDamageSourcePart;
import com.tacz.guns.api.event.common.GunFireEvent;
import com.tacz.guns.api.item.IAmmo;
import com.tacz.guns.api.item.IAmmoBox;
import com.tacz.guns.api.item.IGun;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.EventPriority;

final class TaczIntegration {
    private static final String HIT_VEHICLES = "t72mod:TaczVehiclesHit";

    private TaczIntegration() {}

    static void register() {
        MinecraftForge.EVENT_BUS.addListener(EventPriority.LOWEST, TaczIntegration::onBulletHit);
        MinecraftForge.EVENT_BUS.addListener(TaczIntegration::onFire);
    }

    static boolean isGun(ItemStack stack) {
        return stack.getItem() instanceof IGun;
    }

    private static ResourceLocation ammoId(ItemStack stack) {
        if (stack.getItem() instanceof IAmmo loose) return loose.getAmmoId(stack);
        if (stack.getItem() instanceof IAmmoBox box && !box.isCreative(stack) && !box.isAllTypeCreative(stack))
            return box.getAmmoId(stack);
        return null;
    }

    static boolean acceptsAmmo(ItemStack stack) {
        ResourceLocation id = ammoId(stack);
        return id != null && T72ServerConfig.taczMachineGunAmmo().contains(id.toString());
    }

    static int loadAmmo(ItemStack stack, int freeSpace) {
        if (!acceptsAmmo(stack)) return 0;
        if (stack.getItem() instanceof IAmmoBox box) {
            int available = Math.max(0, box.getAmmoCount(stack));
            int take = Math.min(available, freeSpace);
            if (take > 0) box.setAmmoCount(stack, available - take);
            return take;
        }
        int take = Math.min(stack.getCount(), freeSpace);
        stack.shrink(take);
        return take;
    }

    private static void onFire(GunFireEvent event) {
        if (!event.getLogicalSide().isServer() || !(event.getShooter() instanceof Player player)) return;
        Vec3 eye = player.getEyePosition();
        Vec3 away = eye.add(player.getLookAngle().scale(12));
        if (player.getVehicle() instanceof HelicopterEntity air && !air.clearCabinFireLine(away, eye)
                || player.getVehicle() instanceof T72TankEntity tank && !tank.clearCrewFireLine(player, away)
                || player.getVehicle() instanceof TaczGunStand stand && !stand.canAim(player))
            event.setCanceled(true);
    }

    private static void onBulletHit(EntityHurtByGunEvent.Pre event) {
        if (!event.getLogicalSide().isServer()) return;
        Entity target = event.getHurtEntity();
        Entity bullet = event.getBullet();
        if (target == null || bullet == null) return;
        Vec3 origin = bullet.position();
        if (target instanceof Player occupant) {
            if (occupant.getVehicle() instanceof T72TankEntity tank) {
                if (tank.clearCrewFireLine(occupant, origin)) return;
                target = tank;
            } else if (occupant.getVehicle() instanceof HelicopterEntity air) {
                if (air.clearCabinFireLine(origin, occupant.getBoundingBox().getCenter())) return;
                target = air;
            } else return;
        }

        VehiclePart part = target instanceof VehiclePart vehiclePart ? vehiclePart : null;
        Entity parent = part == null ? target : part.getParent();
        if (!(parent instanceof T72TankEntity || parent instanceof HelicopterEntity
                || parent instanceof ArtilleryEntity || parent instanceof FieldVehicleEntity)) return;
        if (event.getAttacker() != null && parent.hasPassenger(event.getAttacker())) {
            event.setCanceled(true);
            return;
        }
        // Keep TaCZ's impact and explosion path running. The vehicle computes its own direct damage.
        float damage = event.getBaseAmount();
        event.setBaseAmount(0);
        event.setHeadshot(false);
        event.setHurtEntity(target);
        String key = parent.getStringUUID();
        CompoundTag data = bullet.getPersistentData();
        CompoundTag seen = data.getCompound(HIT_VEHICLES);
        if (seen.contains(key)) return;
        seen.putBoolean(key, true);
        data.put(HIT_VEHICLES, seen);

        double scale = T72ServerConfig.taczDamageScale(event.getGunId());
        damage = (float) (damage * scale);
        if (damage <= 0 || !Float.isFinite(damage)) return;
        var source = event.getDamageSource(GunDamageSourcePart.NON_ARMOR_PIERCING);
        if (part != null) part.hitBy(source, part.getBoundingBox().getCenter(), damage);
        else parent.hurt(source, damage);
    }
}
