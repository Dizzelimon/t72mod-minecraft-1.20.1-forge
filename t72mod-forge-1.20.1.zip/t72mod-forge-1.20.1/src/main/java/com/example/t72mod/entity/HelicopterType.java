package com.example.t72mod.entity;

public enum HelicopterType {
    MI8("Ми-8", 5, 0.62, 2.6F, 1500, 11, 170, true),
    MI24("Ми-24", 3, 0.85, 3.4F, 1100, 8, 220, true),
    KA52("Ка-52", 2, 0.94, 4.0F, 1250, 7, 205, true);

    public final String displayName;
    public final int seats;
    public final double speed;
    public final float turnRate;
    public final int fuelCapacity;
    public final int fuelInterval;
    public final double hullHealth;
    public final boolean armed;

    HelicopterType(String displayName, int seats, double speed, float turnRate, int fuelCapacity,
                   int fuelInterval, double hullHealth, boolean armed) {
        this.displayName = displayName;
        this.seats = seats;
        this.speed = speed;
        this.turnRate = turnRate;
        this.fuelCapacity = fuelCapacity;
        this.fuelInterval = fuelInterval;
        this.hullHealth = hullHealth;
        this.armed = armed;
    }
}
