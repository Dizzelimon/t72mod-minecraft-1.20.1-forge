package com.example.t72mod.network;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.ArtilleryMarkerStore;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.function.Supplier;

public record ArtilleryMarkerPacket(int action, int index, int x, int z) {
    public static final int ACTION_ADD = 0;
    public static final int ACTION_DELETE = 1;
    public static final int ACTION_REQUEST_SYNC = 2;

    public static void encode(ArtilleryMarkerPacket packet, FriendlyByteBuf buf) {
        buf.writeByte(packet.action);
        buf.writeByte(packet.index);
        buf.writeInt(packet.x);
        buf.writeInt(packet.z);
    }

    public static ArtilleryMarkerPacket decode(FriendlyByteBuf buf) {
        return new ArtilleryMarkerPacket(buf.readUnsignedByte(), buf.readUnsignedByte(), buf.readInt(), buf.readInt());
    }

    public static void handle(ArtilleryMarkerPacket packet, Supplier<NetworkEvent.Context> supplied) {
        NetworkEvent.Context context = supplied.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null) return;
            ResourceLocation dim = player.level().dimension().location();
            ArtilleryMarkerStore store = loadPlayerStore(player);
            if (packet.action == ACTION_ADD) {
                if (!store.addMarker(dim, packet.x, packet.z)) {
                    player.displayClientMessage(Component.translatable("message.t72mod.artillery_marker_full"), true);
                }
                savePlayerStore(player, store);
            } else if (packet.action == ACTION_DELETE) {
                if (store.deleteMarker(dim, packet.index)) {
                    savePlayerStore(player, store);
                }
            }
            syncToPlayer(player, store, dim);
        });
        context.setPacketHandled(true);
    }

    public static ArtilleryMarkerStore loadPlayerStore(ServerPlayer player) {
        ArtilleryMarkerStore store = new ArtilleryMarkerStore();
        CompoundTag persistent = player.getPersistentData();
        if (persistent.contains(ArtilleryMarkerStore.NBT_KEY)) {
            store.readNbt(persistent.getCompound(ArtilleryMarkerStore.NBT_KEY));
        }
        return store;
    }

    public static void savePlayerStore(ServerPlayer player, ArtilleryMarkerStore store) {
        player.getPersistentData().put(ArtilleryMarkerStore.NBT_KEY, store.writeNbt());
    }

    public static void syncToPlayer(ServerPlayer player) {
        if (player instanceof FakePlayer || player.connection == null
                || player.connection.connection == null || player.connection.connection.channel() == null
                || !player.connection.connection.isConnected()) {
            return;
        }
        syncToPlayer(player, loadPlayerStore(player), player.level().dimension().location());
    }

    private static void syncToPlayer(ServerPlayer player, ArtilleryMarkerStore store, ResourceLocation dim) {
        ModMessages.INSTANCE.send(
                PacketDistributor.PLAYER.with(() -> player),
                new ArtilleryMarkersSyncPacket(dim, store.list(dim))
        );
    }
}
