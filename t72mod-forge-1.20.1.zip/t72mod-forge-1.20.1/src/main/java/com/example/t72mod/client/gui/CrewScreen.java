package com.example.t72mod.client.gui;

import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.network.ModMessages;
import com.example.t72mod.network.TankActionPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;

public final class CrewScreen extends Screen {
    private final T72TankEntity tank;
    private final List<Button> seats = new ArrayList<>();

    public CrewScreen(T72TankEntity tank) {
        super(Component.translatable("screen.t72mod.crew"));
        this.tank = tank;
    }

    @Override protected void init() {
        seats.clear();
        for (int i=0; i<tank.crewCapacity(); i++) {
            int seat = i;
            seats.add(addRenderableWidget(Button.builder(Component.empty(), b ->
                    ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.SEAT_BASE + seat)))
                    .bounds(width/2-106, height/2-34+i*21, 212, 20).build()));
        }
        tick();
    }

    @Override public void tick() {
        if (minecraft.player == null || minecraft.player.getVehicle() != tank || !tank.isAlive()) {
            onClose();
            return;
        }
        for (int i=0; i<seats.size(); i++) {
            var occupant = tank.crewOccupant(i);
            seats.get(i).setMessage(Component.translatable("screen.t72mod.seat."+i,
                    occupant == null ? Component.translatable("screen.t72mod.free") : occupant.getDisplayName()));
            seats.get(i).active = occupant == null && tank.canChangeCrewSeat();
        }
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float pt) {
        renderBackground(g);
        int y = height/2;
        g.drawCenteredString(font,title,width/2,y-73,0xffffff);
        g.drawCenteredString(font, Component.translatable("screen.t72mod.modules",tank.getEngineHealth(),
                tank.getTracksHealth(),tank.getTurretHealth(),tank.getGunHealth()), width/2,y-57,0xe1d8ba);
        if (!tank.canChangeCrewSeat()) g.drawCenteredString(font,Component.translatable("message.t72mod.seat_unavailable"),
                width/2, y+57, 0xfbbb84);
        super.render(g,mouseX,mouseY,pt);
    }

    @Override public boolean isPauseScreen() { return false; }
}
