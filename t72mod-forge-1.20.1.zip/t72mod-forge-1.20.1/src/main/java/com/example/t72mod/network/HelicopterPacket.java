package com.example.t72mod.network;

import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.FieldVehicleEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record HelicopterPacket(int entityId, boolean controls, int value) {
    public static void encode(HelicopterPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.entityId);
        buffer.writeBoolean(message.controls);
        buffer.writeByte(message.value);
    }

    public static HelicopterPacket decode(FriendlyByteBuf buffer) {
        return new HelicopterPacket(buffer.readVarInt(), buffer.readBoolean(), buffer.readUnsignedByte());
    }

    public static void handle(HelicopterPacket message, Supplier<NetworkEvent.Context> supplied) {
        NetworkEvent.Context context = supplied.get();
        context.enqueueWork(() -> {
            ServerPlayer sender = context.getSender();
            if (sender != null && !message.controls && sender.getVehicle() instanceof FieldVehicleEntity field
                    && field.getId() == message.entityId) {
                field.action(sender, message.value);
                return;
            }
            if (sender == null || !(sender.level().getEntity(message.entityId) instanceof HelicopterEntity helicopter))
                return;
            if (!message.controls && (message.value>=HelicopterEntity.RELOAD_ROCKETS)) {
                helicopter.handleCrewAction(sender,message.value);
                return;
            }
            if (sender.getVehicle()!=helicopter) return;
            if (message.controls) helicopter.acceptInput(sender,message.value);
            else helicopter.handleAction(sender,message.value);
        });
        context.setPacketHandled(true);
    }
}
