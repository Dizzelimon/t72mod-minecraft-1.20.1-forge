package com.example.t72mod.client;

import com.example.t72mod.T72Mod;
import com.example.t72mod.client.gui.ArtilleryMapScreen;
import com.example.t72mod.client.gui.TankInventoryScreen;
import com.example.t72mod.client.model.AbramsTankModel;
import com.example.t72mod.client.model.Leopard2TankModel;
import com.example.t72mod.client.model.T72TankModel;
import com.example.t72mod.client.model.Bmp3Model;
import com.example.t72mod.client.model.T90mModel;
import com.example.t72mod.client.renderer.ArtilleryRenderer;
import com.example.t72mod.client.renderer.HelicopterRenderer;
import com.example.t72mod.client.renderer.FieldVehicleRenderer;
import com.example.t72mod.client.renderer.T72TankRenderer;
import com.example.t72mod.client.renderer.TankShellRenderer;
import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.VehiclePart;
import net.minecraft.world.phys.EntityHitResult;
import com.example.t72mod.entity.FieldVehicleEntity;
import com.example.t72mod.entity.HelicopterType;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.TankType;
import com.example.t72mod.network.HelicopterPacket;
import com.example.t72mod.network.ModMessages;
import com.example.t72mod.network.TankActionPacket;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.CameraType;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientTankEvents {

    private static final String FLIGHT_KEYS = "key.categories.t72mod.flight";
    private static final KeyMapping START_ENGINE = flightKey("engine", GLFW.GLFW_KEY_H);
    private static final KeyMapping DESCEND = flightKey("collective_down", GLFW.GLFW_KEY_LEFT_CONTROL);
    private static final KeyMapping BMP_HATCH = flightKey("bmp_hatch", GLFW.GLFW_KEY_B);
    private static final KeyMapping STRAFE_LEFT = flightKey("yaw_left", GLFW.GLFW_KEY_J);
    private static final KeyMapping STRAFE_RIGHT = flightKey("yaw_right", GLFW.GLFW_KEY_L);
    private static final KeyMapping ROCKET_RELOAD=flightKey("rocket_reload",GLFW.GLFW_KEY_R);
    private static final KeyMapping RAMP=flightKey("rear_ramp",GLFW.GLFW_KEY_U);
    private static final KeyMapping CARGO = flightKey("cargo", GLFW.GLFW_KEY_I);

    private static KeyMapping flightKey(String id, int code) {
        return new KeyMapping("key.t72mod." + id, InputConstants.Type.KEYSYM, code, FLIGHT_KEYS);
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(START_ENGINE);
        event.register(DESCEND);
        event.register(BMP_HATCH);
        event.register(STRAFE_LEFT);
        event.register(STRAFE_RIGHT);
        event.register(CARGO);
        event.register(ROCKET_RELOAD);
        event.register(RAMP);
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            MenuScreens.register(T72Mod.TANK_MENU.get(), TankInventoryScreen::new);
        });
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(ArtilleryRenderer.LAYER, ArtilleryRenderer::createLayer);
        event.registerLayerDefinition(T72TankModel.LAYER_LOCATION, T72TankModel::createBodyLayer);
        event.registerLayerDefinition(Bmp3Model.LAYER_LOCATION, Bmp3Model::createBodyLayer);
        event.registerLayerDefinition(T90mModel.LAYER_LOCATION, T90mModel::createBodyLayer);
        event.registerLayerDefinition(AbramsTankModel.LAYER_LOCATION, AbramsTankModel::createBodyLayer);
        event.registerLayerDefinition(Leopard2TankModel.LAYER_LOCATION, Leopard2TankModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(T72Mod.ARTILLERY.get(), ArtilleryRenderer::new);
        event.registerEntityRenderer(T72Mod.MI8.get(), ctx -> new HelicopterRenderer(ctx, HelicopterType.MI8));
        event.registerEntityRenderer(T72Mod.KA52.get(), ctx -> new HelicopterRenderer(ctx, HelicopterType.KA52));
        event.registerEntityRenderer(T72Mod.SCOUT_CAR.get(), ctx -> new FieldVehicleRenderer(ctx, true));
        event.registerEntityRenderer(T72Mod.WORKSHOP_TRUCK.get(), ctx -> new FieldVehicleRenderer(ctx, false));
        event.registerEntityRenderer(T72Mod.MI24.get(), ctx -> new HelicopterRenderer(ctx, HelicopterType.MI24));
        event.registerEntityRenderer(T72Mod.T72_TANK.get(), T72TankRenderer::new);
        event.registerEntityRenderer(T72Mod.T90M_TANK.get(), T72TankRenderer::new);
        event.registerEntityRenderer(T72Mod.BMP3.get(), T72TankRenderer::new);
        event.registerEntityRenderer(T72Mod.ABRAMS_TANK.get(), T72TankRenderer::new);
        event.registerEntityRenderer(T72Mod.LEOPARD2_TANK.get(), T72TankRenderer::new);
        event.registerEntityRenderer(T72Mod.TANK_PART.get(), NoopRenderer::new);
        event.registerEntityRenderer(T72Mod.TANK_SHELL.get(), TankShellRenderer::new);
    }

    @SubscribeEvent
    public static void registerGuiOverlay(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "t72_sight_hud", (gui, graphics, partialTick, width, height) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.screen != null) return;
            if (mc.player.getVehicle() instanceof T72TankEntity tank) {
                if (tank.getControllingPassenger() == mc.player) renderTankPeriscopeOverlay(graphics, mc, tank, partialTick, width, height);
            } else if (mc.player.getVehicle() instanceof FieldVehicleEntity field) {
                renderFieldHud(graphics, mc, field, width);
            } else if (mc.player.getVehicle() instanceof HelicopterEntity flight) {
                renderFlightHud(graphics, mc, flight, width);
            } else if (mc.player.getVehicle() instanceof ArtilleryEntity) {
                graphics.drawCenteredString(mc.font, Component.translatable("message.t72mod.artillery_map_hint"),
                        width / 2, height - 65, 0xFFE3D899);
            }
        });
    }

    private static void renderTankPeriscopeOverlay(GuiGraphics g, Minecraft mc, T72TankEntity tank, float partialTick, int w, int h) {
        boolean isZooming = GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        TankType type = tank.getTankType();

        int maskColor = 0xF2080A08;
        int topBottomBorder = isZooming ? (int) (h * 0.20F) : (int) (h * 0.24F);
        int sideBorder = isZooming ? (int) (w * 0.24F) : (int) (w * 0.13F);

        g.fill(0, 0, w, topBottomBorder, maskColor);
        g.fill(0, h - topBottomBorder, w, h, maskColor);
        g.fill(0, topBottomBorder, sideBorder, h - topBottomBorder, maskColor);
        g.fill(w - sideBorder, topBottomBorder, w, h - topBottomBorder, maskColor);

        int borderColor = switch (type) {
            case ABRAMS -> 0xAA327A6D;
            case LEOPARD2 -> 0xAA4D7A32;
            default -> 0xAA2E5C32;
        };
        g.renderOutline(sideBorder, topBottomBorder, w - sideBorder * 2, h - topBottomBorder * 2, borderColor);

        int cx = w / 2;
        int cy = h / 2;
        int reticleColor = tank.getReloadTicks() == 0 && !tank.isGunBroken()
                ? (type == TankType.ABRAMS ? 0xCC33FFCC : 0xCC22FF44)
                : 0xCCFF5522;

        // Main cursor reticle
        g.fill(cx - 80, cy, cx - 8, cy + 1, reticleColor);
        g.fill(cx + 9, cy, cx + 81, cy + 1, reticleColor);
        g.fill(cx, cy + 4, cx + 1, cy + 55, reticleColor);

        for (int i = 1; i <= 3; i++) {
            int dropY = cy + i * 12;
            g.fill(cx - 10, dropY, cx + 11, dropY + 1, reticleColor);
        }

        float interpTurretYaw = tank.renderTurretYaw(partialTick);
        float interpBarrelPitch = tank.renderBarrelPitch(partialTick);
        var camera = mc.gameRenderer.getMainCamera();
        Vec3 direction = Vec3.directionFromRotation(interpBarrelPitch, interpTurretYaw);
        Vec3 look = Vec3.directionFromRotation(camera.getXRot(), camera.getYRot());
        double depth = direction.dot(look);
        if (depth > 0.025) {
            Vec3 right = Vec3.directionFromRotation(0, camera.getYRot() + 90);
            Vec3 up = right.cross(look);
            double verticalFov = mc.options.fov().get() * (isZooming ? type.zoomFovMultiplier : 1);
            double scale = (h * 0.5) / (Math.tan(Math.toRadians(verticalFov * 0.5)) * depth);
            int mx = cx + Mth.floor(direction.dot(right) * scale);
            int my = cy - Mth.floor(direction.dot(up) * scale);
            if (mx > sideBorder + 5 && mx < w - sideBorder - 5 && my > topBottomBorder + 5 && my < h - topBottomBorder - 5) {
                g.renderOutline(mx - 5, my - 5, 11, 11, tank.isTurretBroken() || tank.isGunBroken() ? 0xFFFF2222 : 0xDDFFFF44);
            }
        }

        // Reload status
        int reload = tank.getReloadTicks();
        String statusText = tank.isGunBroken() ? "ОРУДИЕ ВЫВЕДЕНО ИЗ СТРОЯ — R: ремонт" : reload == 0
                ? String.format("[ %s: ГОТОВ | Снарядов в укладке: %d ]", type.cannonTitle, tank.getShellCount())
                : String.format("[ ПЕРЕЗАРЯДКА: %.1f с ]", reload / 20.0F);
        int statusColor = tank.isGunBroken() ? 0xFF5544 : reload == 0 ? 0x55FF55 : 0xFFAA00;
        g.drawCenteredString(mc.font, statusText, cx, h - topBottomBorder + 6, statusColor);

        // Top line 1: Telemetry (Hull, Armor, Fuel, MG Ammo, Smoke)
        float relAngle = Mth.wrapDegrees(interpTurretYaw - Mth.rotLerp(partialTick, tank.yRotO, tank.getYRot()));
        String telemetryLine = String.format("%s | Броня: %d/%d | Топливо: %d/%d | Пулемёт: %d патр. | Азимут: %+.0f° | Дымы: %s",
                type.displayName,
                (int) tank.getHealth(),
                (int) tank.getMaxHealth(),
                tank.getFuel(),
                T72TankEntity.MAX_FUEL,
                tank.getMgAmmo(),
                relAngle,
                tank.getSmokeCooldown() == 0 ? "ОК" : (tank.getSmokeCooldown() / 20 + "с"));
        g.drawCenteredString(mc.font, telemetryLine, cx, topBottomBorder - 26, 0xA8E6A8);

        // Top line 2: Module status (Turret, Tracks, Engine)
        String turretStat = tank.isTurretBroken() ? "§cБАШНЯ: КЛИН!" : ("§aБашня: " + tank.getTurretHealth() + "%");
        String tracksStat = tank.isTracksBroken() ? "§cГУСЕНИЦЫ: СБИТЫ!" : ("§aГусеницы: " + tank.getTracksHealth() + "%");
        String engineStat = tank.isEngineBroken() ? "§cДВИГАТЕЛЬ: КРИТ!" : ("§aДвигатель: " + tank.getEngineHealth() + "%");
        String moduleLine = "Узлы танка:  " + turretStat + "  |  " + tracksStat + "  |  " + engineStat + "  |  " + (tank.isGunBroken() ? "§cОРУДИЕ: СЛОМАНО" : "§aОрудие: " + tank.getGunHealth() + "%");
        g.drawCenteredString(mc.font, moduleLine, cx, topBottomBorder - 13, 0xFFFFFF);

        // Bottom controls hint
        g.drawCenteredString(mc.font,
                type == TankType.BMP3 ? "B: Люк | H: Тормоз и корма | V: Пулемёт | I: Укладка"
                        : "ЛКМ: Выстрел | ПКМ: Прицел | V: Пулемёт | G: Дымы | I: Слоты и топливо | R: Полевой ремонт",
                cx, h - 15, 0x999999);
    }

    private static void renderFlightHud(GuiGraphics graphics, Minecraft mc, HelicopterEntity flight, int width) {
        graphics.drawCenteredString(mc.font, Component.translatable("hud.t72mod.flight_status",
                flight.model().displayName, flight.getBlockY(), flight.fuel(), flight.model().fuelCapacity,
                flight.rpm(), (int) flight.getHealth()), width / 2, 10, 0xE5F5E8);
        graphics.drawCenteredString(mc.font, Component.translatable("hud.t72mod.flight_parts",
                flight.engineHealth(), flight.rotorHealth(), flight.tailHealth()), width / 2, 22, 0xE5F5E8);
        if (flight.engineOn() && !flight.onGround() && flight.deckHold()) graphics.drawCenteredString(mc.font,
                Component.translatable("hud.t72mod.deck_hold"),width/2,59,0xFFE2C88A);
        if (flight.model().armed) {
            graphics.drawCenteredString(mc.font, Component.translatable("hud.t72mod.rockets",flight.rockets(),flight.rocketCapacity(),flight.launcherHealth()),
                    width / 2, 34, 0xF5CE88);
            graphics.drawCenteredString(mc.font,
                    Component.translatable("hud.t72mod.air_cannon", flight.cannonAmmo()),
                    width / 2, 46, 0xF5CE88);
        }
    }

    private static void renderFieldHud(GuiGraphics g, Minecraft mc, FieldVehicleEntity v, int width) {
        g.drawCenteredString(mc.font, Component.translatable("hud.t72mod.field_status", v.fuel(), v.wheels()),
                width / 2, 9, 0xE1ECDD);
        g.drawCenteredString(mc.font, Component.translatable(v.scout() ? "hud.t72mod.scout" : "hud.t72mod.workshop"),
                width / 2, 21, 0xE1ECDD);
        if (!v.scanning() || mc.level == null) return;
        int x = width - 43, y = 74;
        g.fill(x - 35, y - 35, x + 35, y + 35, 0xD41C2926);
        g.renderOutline(x - 35, y - 35, 70, 70, 0xFFADD0B3);
        g.fill(x - 1, y - 1, x + 2, y + 2, 0xFFF2F9EE);
        for (LivingEntity target : mc.level.getEntitiesOfClass(LivingEntity.class, v.getBoundingBox().inflate(44),
                e -> e != v && (e instanceof FieldVehicleEntity || e instanceof HelicopterEntity
                        || e instanceof T72TankEntity || e instanceof ArtilleryEntity))) {
            double dx = target.getX() - v.getX(), dz = target.getZ() - v.getZ();
            if (dx * dx + dz * dz > 44 * 44) continue;
            int px = x + Mth.floor(dx * 0.72), py = y + Mth.floor(dz * 0.72);
            g.fill(px - 1, py - 1, px + 2, py + 2, target instanceof HelicopterEntity ? 0xFFADCADD : 0xFFE0A684);
        }
    }

    @Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeBusEvents {
        private static Entity lastVehicle;
        private static int lastFlightInput=-1;
        private static CameraType previousCamera;

        @SubscribeEvent
        public static void onOverlay(RenderGuiOverlayEvent.Pre event) {
            Minecraft mc = Minecraft.getInstance();
            if (event.getOverlay().id().equals(VanillaGuiOverlay.CROSSHAIR.id())
                    && mc.player != null && mc.player.getVehicle() instanceof T72TankEntity) {
                event.setCanceled(true);
            }
        }

        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            Entity vehicle = mc.player == null ? null : mc.player.getVehicle();
            if (vehicle != lastVehicle) {
                if (previousCamera != null) mc.options.setCameraType(previousCamera);
                previousCamera = null;
                if (vehicle instanceof T72TankEntity || vehicle instanceof HelicopterEntity || vehicle instanceof ArtilleryEntity || vehicle instanceof FieldVehicleEntity) {
                    previousCamera = mc.options.getCameraType();
                    boolean cockpit = vehicle instanceof T72TankEntity tank && tank.getControllingPassenger() == mc.player
                            || vehicle instanceof HelicopterEntity;
                    mc.options.setCameraType(cockpit ? CameraType.FIRST_PERSON : CameraType.THIRD_PERSON_BACK);
                }
                lastVehicle = vehicle;
                lastFlightInput=-1;
            }
            if (vehicle instanceof T72TankEntity tank && tank.getControllingPassenger() == mc.player) {
                if (tank.getTankType() != TankType.BMP3 && mc.options.getCameraType() != CameraType.FIRST_PERSON)
                    mc.options.setCameraType(CameraType.FIRST_PERSON);
                if (mc.screen == null && InputConstants.isKeyDown(mc.getWindow().getWindow(), GLFW.GLFW_KEY_V) && tank.tickCount % 3 == 0) {
                    ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_FIRE_MG));
                }
            }
            if (BMP_HATCH.consumeClick() && vehicle instanceof T72TankEntity tank && tank.getTankType() == TankType.BMP3
                    && mc.screen == null) {
                ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_BMP_HATCH));
            }
            boolean engine = START_ENGINE.consumeClick();
            boolean cargo = CARGO.consumeClick();
            if (engine && vehicle instanceof T72TankEntity tank && tank.getTankType() == TankType.BMP3 && mc.screen == null) {
                ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_BMP_BRAKE));
            }
            if (vehicle instanceof FieldVehicleEntity field && cargo && mc.screen == null) {
                ModMessages.INSTANCE.sendToServer(new HelicopterPacket(field.getId(), false, 0));
            }
            boolean reload=ROCKET_RELOAD.consumeClick(), ramp=RAMP.consumeClick();
            if (mc.player==null || mc.screen!=null) return;
            if (reload) {
                HelicopterEntity target = vehicle instanceof HelicopterEntity air ? air : nearbyAircraft(mc);
                if (target != null) sendFlightAction(target, HelicopterEntity.RELOAD_ROCKETS);
            }
            if (ramp && mc.level != null) {
                if (vehicle instanceof HelicopterEntity air && air.canOperateRearRamp(mc.player)) {
                    sendFlightAction(air, HelicopterEntity.TOGGLE_RAMP);
                } else if (vehicle == null) {
                    mc.level.getEntitiesOfClass(HelicopterEntity.class, mc.player.getBoundingBox().inflate(8),
                            air -> air.canOperateRearRamp(mc.player)).stream()
                            .min(java.util.Comparator.comparingDouble(air -> air.distanceToSqr(mc.player)))
                            .ifPresent(air -> sendFlightAction(air, HelicopterEntity.TOGGLE_RAMP));
                }
            }
            if (!(vehicle instanceof HelicopterEntity flight)) return;
            if (cargo) sendFlightAction(flight, HelicopterEntity.CARGO);
            if (!flight.isPilot(mc.player)) return;
            if (engine) sendFlightAction(flight, HelicopterEntity.TOGGLE_ENGINE);
            if (flight.model().armed && flight.tickCount % 4 == 0
                    && InputConstants.isKeyDown(mc.getWindow().getWindow(), GLFW.GLFW_KEY_V)) {
                sendFlightAction(flight, HelicopterEntity.CANNON);
            }
            int flags = pressed(mc.options.keyUp, HelicopterEntity.FORWARD) | pressed(mc.options.keyDown, HelicopterEntity.BACK)
                    | pressed(mc.options.keyLeft, HelicopterEntity.LEFT) | pressed(mc.options.keyRight, HelicopterEntity.RIGHT)
                    | pressed(mc.options.keyJump, HelicopterEntity.ASCEND) | (DESCEND.isDown() || DESCEND.isDefault()
                    && InputConstants.isKeyDown(mc.getWindow().getWindow(),GLFW.GLFW_KEY_LEFT_CONTROL) ? HelicopterEntity.DESCEND : 0)
                    | pressed(STRAFE_LEFT, HelicopterEntity.STRAFE_LEFT) | pressed(STRAFE_RIGHT, HelicopterEntity.STRAFE_RIGHT);
            if (flags!=lastFlightInput || flight.tickCount%5==0) {
                ModMessages.INSTANCE.sendToServer(new HelicopterPacket(flight.getId(),true,flags));
                lastFlightInput=flags;
            }
        }

        private static int pressed(KeyMapping key, int bit) {
            return key.isDown() ? bit : 0;
        }

        private static void sendFlightAction(HelicopterEntity flight, int action) {
            ModMessages.INSTANCE.sendToServer(new HelicopterPacket(flight.getId(), false, action));
        }

        private static HelicopterEntity nearbyAircraft(Minecraft game) {
            HelicopterEntity cabin=standingAircraft(game);
            if (cabin!=null) return cabin;
            if (!(game.hitResult instanceof EntityHitResult hit)) return null;
            Entity target=hit.getEntity();
            if (target instanceof VehiclePart part) target=part.getParent();
            return target instanceof HelicopterEntity aircraft?aircraft:null;
        }

        private static HelicopterEntity standingAircraft(Minecraft game) {
            if (game.player==null || game.level==null) return null;
            for (HelicopterEntity aircraft : game.level.getEntitiesOfClass(HelicopterEntity.class,
                    game.player.getBoundingBox().inflate(5),h->h.insideWalkableCabin(game.player))) return aircraft;
            return null;
        }

        @SubscribeEvent
        public static void onMouseClick(InputEvent.InteractionKeyMappingTriggered event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;
            if (event.isUseItem() && !mc.player.isPassenger() && !mc.player.isSpectator()
                    && event.getHand()==net.minecraft.world.InteractionHand.MAIN_HAND) {
                if (mc.player.getMainHandItem().isEmpty() && !mc.player.isShiftKeyDown()) {
                    HelicopterEntity cabin=standingAircraft(mc);
                    if (cabin!=null) {
                        int seat=cabin.aimSeat(mc.player);
                        if (seat>=0) {
                            sendFlightAction(cabin,seat);
                            event.setCanceled(true);
                            event.setSwingHand(false);
                            return;
                        }
                    }
                } else if (mc.player.getMainHandItem().is(T72Mod.AIR_ROCKET.get())) {
                    HelicopterEntity aircraft=nearbyAircraft(mc);
                    if (aircraft!=null) {
                        sendFlightAction(aircraft,HelicopterEntity.LOAD_HELD_ROCKETS);
                        event.setCanceled(true);
                        event.setSwingHand(false);
                        return;
                    }
                }

            }
            if (mc.player.getVehicle() instanceof T72TankEntity && (event.isAttack() || event.isUseItem())) {
                if (event.isAttack()) ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_FIRE_MAIN));
                event.setCanceled(true);
                event.setSwingHand(false);
            } else if (mc.player.getVehicle() instanceof ArtilleryEntity piece && (event.isAttack() || event.isUseItem())) {
                if (event.isUseItem() && mc.screen == null) mc.setScreen(new ArtilleryMapScreen(piece));
                event.setCanceled(true);
                event.setSwingHand(false);
            } else if (mc.player.getVehicle() instanceof HelicopterEntity flight && event.isAttack()) {
                if (flight.isPilot(mc.player) && flight.model().armed) sendFlightAction(flight, HelicopterEntity.FIRE);
                event.setCanceled(true);
                event.setSwingHand(false);
            }
        }

        @SubscribeEvent
        public static void onKeyInput(InputEvent.Key event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.screen == null && mc.player != null && mc.player.getVehicle() instanceof FieldVehicleEntity field
                    && event.getAction() == GLFW.GLFW_PRESS && event.getKey() == GLFW.GLFW_KEY_R) {
                ModMessages.INSTANCE.sendToServer(new HelicopterPacket(field.getId(), false, 1));
            }
            if (mc.screen == null && mc.player != null && mc.player.getVehicle() instanceof T72TankEntity tank) {
                if (event.getAction() == GLFW.GLFW_PRESS) {
                    if (event.getKey() == GLFW.GLFW_KEY_G) {
                        ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_SMOKE));
                    } else if (event.getKey() == GLFW.GLFW_KEY_I
                            || event.getKey() == GLFW.GLFW_KEY_B && tank.getTankType() != TankType.BMP3) {
                        ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_OPEN_INVENTORY));
                    } else if (event.getKey() == GLFW.GLFW_KEY_R) {
                        ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_REPAIR));
                    }
                }
            }
        }

        @SubscribeEvent
        public static void onComputeFov(ViewportEvent.ComputeFov event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.getVehicle() instanceof T72TankEntity tank && mc.screen == null) {
                if (GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS) {
                    event.setFOV(event.getFOV() * tank.getTankType().zoomFovMultiplier);
                }
            }
        }
    }
}
