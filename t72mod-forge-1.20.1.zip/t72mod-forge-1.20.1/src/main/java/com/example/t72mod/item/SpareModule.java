package com.example.t72mod.item;

import com.example.t72mod.entity.T72TankEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import java.util.List;
import java.util.function.ObjIntConsumer;
import java.util.function.ToIntFunction;

public final class SpareModule extends Item {
    public enum Kind {
        ENGINE(T72TankEntity::getEngineHealth,T72TankEntity::setEngineHealth),
        TRACK(T72TankEntity::getTracksHealth,T72TankEntity::setTracksHealth),
        TURRET(T72TankEntity::getTurretHealth,T72TankEntity::setTurretHealth),
        GUN(T72TankEntity::getGunHealth,T72TankEntity::setGunHealth);
        public final ToIntFunction<T72TankEntity> read;
        public final ObjIntConsumer<T72TankEntity> write;
        Kind(ToIntFunction<T72TankEntity> read,ObjIntConsumer<T72TankEntity> write) {
            this.read=read;
            this.write=write;
        }
    }
    public final Kind kind;
    public SpareModule(Kind kind) { super(new Properties().stacksTo(1)); this.kind=kind; }
    public static int condition(ItemStack item) {
        return item.hasTag() && item.getTag().contains("Condition") ? Mth.clamp(item.getTag().getInt("Condition"),0,100) : 100;
    }
    @Override public void appendHoverText(ItemStack item,Level level,List<Component> lines,TooltipFlag flag) {
        lines.add(Component.translatable("message.t72mod.module_condition",condition(item)));
    }
}
