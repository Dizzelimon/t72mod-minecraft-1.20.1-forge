package com.example.t72mod.entity;

import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Paint, seating and collision are placed against the same block-space datums. */
public final class AirframeLayout {
    public static final double MI8_FLOOR = 1.35;
    public static final double MI8_BULKHEAD_MIN_Z = 2.08;
    public static final double MI8_BULKHEAD_MAX_Z = 2.24;
    public static final double MI8_BULKHEAD_OPEN_HALF_WIDTH = .88;
    public static final double MI8_DOOR_Z = 1.23;
    public static final double MI8_PILOT_Z = 3.62;

    private AirframeLayout() {}

    public static Vec3 world(Vec3 origin, float yaw, double x, double y, double z) {
        return origin.add(new Vec3(x, y, z).yRot(-yaw * Mth.DEG_TO_RAD));
    }

    public static Vec3 local(Vec3 origin, float yaw, Vec3 point) {
        return point.subtract(origin).yRot(yaw * Mth.DEG_TO_RAD);
    }

    public static Vec3 store(HelicopterType type,int side) {
        return new Vec3(side*(type == HelicopterType.MI8 ? 2.42 : 2.18),
                type == HelicopterType.MI8 ? 1.39 : 1.53, type == HelicopterType.MI8 ? -1.95 : .04);
    }

    public static double rotorRadius(HelicopterType type) {
        return switch (type) { case MI8 -> 10.63; case MI24 -> 8.50; case KA52 -> 7.25; };
    }

    public static final double MAIN_ROTOR_Z = -.53;
    public static final double TAIL_ROTOR_Y = 3.65;
    public static final double TAIL_ROTOR_RADIUS = 1.12;

    public static double rotorY(HelicopterType type) {
        return switch (type) { case MI8 -> 4.86; case MI24 -> 4.25; case KA52 -> 4.72; };
    }

    public static double tailZ(HelicopterType type) {
        return switch (type) { case MI8 -> -11.15; case MI24 -> -10.05; case KA52 -> -8.25; };
    }
}
