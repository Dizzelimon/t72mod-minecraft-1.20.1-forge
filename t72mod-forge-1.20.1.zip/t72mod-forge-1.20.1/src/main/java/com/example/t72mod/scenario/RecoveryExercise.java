package com.example.t72mod.scenario;

import com.example.t72mod.entity.FieldVehicleEntity;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.TankType;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.*;

public final class RecoveryExercise extends SavedData {
    private static final String DATA_ID = "t72mod_recovery_exercise";
    private final Map<UUID, Goal> goals = new HashMap<>();

    private record Goal(UUID bmp, BlockPos garage) {}

    private static RecoveryExercise read(CompoundTag tag) {
        var state = new RecoveryExercise();
        for (var item : tag.getList("Exercises", 10)) {
            CompoundTag exercise = (CompoundTag) item;
            if (exercise.hasUUID("Player") && exercise.hasUUID("Bmp"))
                state.goals.put(exercise.getUUID("Player"), new Goal(exercise.getUUID("Bmp"),
                        NbtUtils.readBlockPos(exercise.getCompound("Garage"))));
        }
        return state;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag entries = new ListTag();
        this.goals.forEach((owner, goal) -> {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Player", owner);
            entry.putUUID("Bmp", goal.bmp());
            entry.put("Garage", NbtUtils.writeBlockPos(goal.garage()));
            entries.add(entry);
        });
        tag.put("Exercises", entries);
        return tag;
    }

    private static RecoveryExercise get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(RecoveryExercise::read, RecoveryExercise::new, DATA_ID);
    }

    @SubscribeEvent
    public static void commands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("t72recovery")
                .then(Commands.literal("start").executes(ctx -> start(ctx.getSource().getPlayerOrException())))
                .then(Commands.literal("stop").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    var state = get(p.serverLevel());
                    if (state.goals.remove(p.getUUID()) != null) state.setDirty();
                    tell(p, "exercise_ended");
                    return 1;
                })));
    }

    private static int start(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        var state = get(level);
        if (state.goals.containsKey(player.getUUID())) {
            tell(player, "exercise_active");
            return 0;
        }
        boolean workshop = !level.getEntitiesOfClass(FieldVehicleEntity.class, player.getBoundingBox().inflate(38),
                truck -> truck.isAlive() && !truck.scout()).isEmpty();
        var closest = level.getEntitiesOfClass(T72TankEntity.class, player.getBoundingBox().inflate(38),
                tank -> tank.isAlive() && tank.getTankType() == TankType.BMP3 && tank.isTracksBroken()
                        && tank.distanceToSqr(player) >= 81).stream()
                .min(Comparator.comparingDouble(player::distanceToSqr));
        if (!workshop || closest.isEmpty()) {
            tell(player, "exercise_needs_equipment");
            return 0;
        }
        var tank = closest.get();
        state.goals.put(player.getUUID(), new Goal(tank.getUUID(), player.blockPosition()));
        state.setDirty();
        tell(player, "exercise_start", tank.getBlockX(), tank.getBlockZ());
        return 1;
    }

    @SubscribeEvent
    public static void tick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)
                || level.getGameTime() % 20 != 0) return;
        var state = get(level);
        var iterator = state.goals.entrySet().iterator();
        while (iterator.hasNext()) {
            var entry = iterator.next();
            if (!(level.getPlayerByUUID(entry.getKey()) instanceof ServerPlayer owner)) continue;
            Goal goal = entry.getValue();
            if (!(level.getEntity(goal.bmp()) instanceof T72TankEntity tank)) continue;
            boolean success = !tank.isTracksBroken() && tank.position().distanceToSqr(Vec3.atCenterOf(goal.garage())) < 36;
            if (success || !tank.isAlive()) {
                tell(owner, success ? "exercise_done" : "exercise_destroyed");
                iterator.remove();
                state.setDirty();
            } else {
                tell(owner, tank.isTracksBroken() ? "exercise_repair" : "exercise_return",
                        goal.garage().getX(), goal.garage().getZ());
            }
        }
    }

    private static void tell(ServerPlayer player, String key, Object... args) {
        player.displayClientMessage(Component.translatable("message.t72mod." + key, args), true);
    }
}
