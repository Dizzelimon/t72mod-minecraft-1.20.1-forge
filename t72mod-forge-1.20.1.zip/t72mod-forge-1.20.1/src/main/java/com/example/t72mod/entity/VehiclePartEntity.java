package com.example.t72mod.entity;

import com.example.t72mod.T72Mod;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

public final class VehiclePartEntity extends Entity {
    public interface Parent {
        Vec3 partPosition(int index);
        boolean partIsActive(int index);
        boolean partIsSolid(int index);
        boolean hurtPart(int index, DamageSource source, Vec3 contact, float amount);
        InteractionResult interactPart(int index, Player player, InteractionHand hand);
    }

    private static final EntityDataAccessor<Integer> PARENT =
            SynchedEntityData.defineId(VehiclePartEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> INDEX =
            SynchedEntityData.defineId(VehiclePartEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> WIDTH =
            SynchedEntityData.defineId(VehiclePartEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> HEIGHT =
            SynchedEntityData.defineId(VehiclePartEntity.class, EntityDataSerializers.FLOAT);

    public VehiclePartEntity(EntityType<? extends VehiclePartEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public static <T extends LivingEntity & Parent> void updateParts(T parent, VehiclePartEntity[] parts, EntityDimensions[] dimensions) {
        for (int i = 0; i < parts.length; i++) {
            if (dimensions[i] == null) continue;
            VehiclePartEntity part = parts[i];
            if (part == null || part.isRemoved()) {
                Vec3 pos = parent.partPosition(i);
                if (!parent.level().hasChunkAt(BlockPos.containing(pos))) continue;
                part = new VehiclePartEntity(T72Mod.TANK_PART.get(), parent.level());
                part.entityData.set(PARENT, parent.getId());
                part.entityData.set(INDEX, i);
                part.entityData.set(WIDTH, dimensions[i].width);
                part.entityData.set(HEIGHT, dimensions[i].height);
                part.follow(parent);
                if (parent.level().addFreshEntity(part)) parts[i] = part;
            } else {
                part.follow(parent);
            }
        }
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(PARENT, -1);
        this.entityData.define(INDEX, 0);
        this.entityData.define(WIDTH, 1.05F);
        this.entityData.define(HEIGHT, 0.78F);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (WIDTH.equals(key) || HEIGHT.equals(key)) this.refreshDimensions();
    }

    public LivingEntity parent() {
        Entity entity = this.level().getEntity(this.entityData.get(PARENT));
        return entity instanceof LivingEntity living && living instanceof Parent ? living : null;
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return EntityDimensions.fixed(this.entityData.get(WIDTH), this.entityData.get(HEIGHT));
    }

    @Override
    public void tick() {
        super.tick();
        LivingEntity parent = this.parent();
        if (parent != null && parent.isAlive()) this.follow(parent);
        else if (!this.level().isClientSide) this.discard();
    }

    private void follow(LivingEntity parent) {
        Parent vehicle = (Parent) parent;
        Vec3 position = vehicle.partPosition(this.entityData.get(INDEX));
        this.blocksBuilding = vehicle.partIsSolid(this.entityData.get(INDEX));
        this.setPos(position);
    }

    @Override
    public boolean isPickable() {
        LivingEntity parent = this.parent();
        return parent != null && parent.isAlive() && ((Parent) parent).partIsActive(this.entityData.get(INDEX));
    }

    @Override
    public boolean canBeCollidedWith() {
        LivingEntity parent = this.parent();
        return parent != null && parent.isAlive() && ((Parent) parent).partIsSolid(this.entityData.get(INDEX));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isInvulnerableTo(source)) return false;
        return this.hitBy(source, this.position().add(0, this.getBbHeight() / 2, 0), amount);
    }

    public boolean hitBy(DamageSource source, Vec3 contact, float amount) {
        LivingEntity parent = this.parent();
        return parent != null && parent.isAlive() && ((Parent) parent).partIsActive(this.entityData.get(INDEX))
                && ((Parent) parent).hurtPart(this.entityData.get(INDEX), source, contact, amount);
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        LivingEntity parent = this.parent();
        return parent != null && parent.isAlive() && ((Parent) parent).partIsActive(this.entityData.get(INDEX))
                ? ((Parent) parent).interactPart(this.entityData.get(INDEX), player, hand) : InteractionResult.PASS;
    }

    @Override
    public InteractionResult interactAt(Player player, Vec3 hit, InteractionHand hand) {
        return this.interact(player, hand);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public boolean shouldBeSaved() { return false; }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
