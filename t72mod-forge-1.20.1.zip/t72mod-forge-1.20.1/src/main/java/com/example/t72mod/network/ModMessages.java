package com.example.t72mod.network;

import com.example.t72mod.T72Mod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;

public class ModMessages {
    private static final String PROTOCOL_VERSION = "11";
    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(T72Mod.MODID, "messages"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    public static void register() {
        INSTANCE.registerMessage(0,
                TankActionPacket.class,
                TankActionPacket::encode,
                TankActionPacket::decode,
                TankActionPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));

        INSTANCE.registerMessage(1,
                HelicopterPacket.class,
                HelicopterPacket::encode,
                HelicopterPacket::decode,
                HelicopterPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        INSTANCE.registerMessage(2,
                ArtilleryFirePacket.class,
                ArtilleryFirePacket::encode,
                ArtilleryFirePacket::decode,
                ArtilleryFirePacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        INSTANCE.registerMessage(3,
                ArtilleryAimPacket.class,
                ArtilleryAimPacket::encode,
                ArtilleryAimPacket::decode,
                ArtilleryAimPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        INSTANCE.registerMessage(4,
                ArtilleryMarkerPacket.class,
                ArtilleryMarkerPacket::encode,
                ArtilleryMarkerPacket::decode,
                ArtilleryMarkerPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        INSTANCE.registerMessage(5,
                ArtilleryMarkersSyncPacket.class,
                ArtilleryMarkersSyncPacket::encode,
                ArtilleryMarkersSyncPacket::decode,
                ArtilleryMarkersSyncPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        INSTANCE.registerMessage(6, FpvInputPacket.class, FpvInputPacket::encode,
                FpvInputPacket::decode, FpvInputPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        INSTANCE.registerMessage(7, FpvViewPacket.class, FpvViewPacket::encode,
                FpvViewPacket::decode, FpvViewPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }
}
