package com.example.t72mod.entity;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Shared artillery ballistics and trajectory chunk sampling helpers used on server and client. */
public final class ArtilleryBallistics {
    public static final int MIN_RANGE = 16;
    public static final int DEFAULT_MAX_RANGE = 300;
    public static final float GRAVITY = 0.085F;
    public static final float AIR_DRAG = 0.99F;
    public static final double PIVOT_Y_OFFSET = 1.35D;
    public static final double MUZZLE_LENGTH = 3.25D;

    public record Solution(Vec3 velocity, float yawDeg, int elevationDeg, double range, boolean valid) {}

    public record SamplePoint(int blockX, int blockZ) {}

    private ArtilleryBallistics() {}

    public static boolean isRangeAllowed(double range, int maxRange) {
        return Double.isFinite(range) && range >= MIN_RANGE && range <= maxRange;
    }

    public static int flightTicks(double range) {
        if (range <= 96.0D) {
            return Mth.ceil(32.0D + range * 0.25D);
        }
        return Mth.ceil(56.0D + (range - 96.0D) * 0.15D);
    }

    public static double dispersionRadius(double range) {
        double reach = Math.max(0, (range - 72) / (DEFAULT_MAX_RANGE - 72));
        return Math.min(32, 14 * reach * reach);
    }

    public static SamplePoint dispersedTarget(int x, int z, double range, RandomSource random) {
        double radius = dispersionRadius(range);
        double angle = random.nextDouble() * Math.PI * 2;
        double offset = radius * Math.sqrt(random.nextDouble());
        return new SamplePoint(x + (int) Math.round(Math.cos(angle) * offset),
                z + (int) Math.round(Math.sin(angle) * offset));
    }

    public static float yawTo(double fromX, double fromZ, double toX, double toZ) {
        return (float) Math.toDegrees(Math.atan2(-(toX - fromX), toZ - fromZ));
    }

    public static Solution solve(Vec3 pivot, double targetX, double targetY, double targetZ) {
        double dx = targetX - pivot.x;
        double dz = targetZ - pivot.z;
        double range = Math.hypot(dx, dz);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        if (range < 0.001D) {
            return new Solution(Vec3.ZERO, yaw, 45, range, false);
        }

        int ticks = flightTicks(range);
        double displacementScale = (1.0D - Math.pow(AIR_DRAG, ticks)) / (1.0D - AIR_DRAG);
        double gravityDrop = GRAVITY * (ticks - displacementScale) / (1.0D - AIR_DRAG);
        Vec3 velocity = new Vec3(dx, targetY - 0.12D - pivot.y + gravityDrop, dz).scale(1.0D / displacementScale);
        int elevation = Mth.clamp(Mth.floor(Math.toDegrees(Math.atan2(velocity.y, velocity.horizontalDistance()))), 5, 82);
        boolean valid = velocity.y >= 0.20D && velocity.y <= 9.0D && Double.isFinite(velocity.lengthSqr());
        return new Solution(velocity, yaw, elevation, range, valid);
    }

    /** Returns chunk-dense checkpoints (every <= 12 blocks plus endpoint) between start and target. */
    public static List<SamplePoint> trajectorySamples(double startX, double startZ, int targetBlockX, int targetBlockZ) {
        double targetCenterX = targetBlockX + 0.5D;
        double targetCenterZ = targetBlockZ + 0.5D;
        double dx = targetCenterX - startX;
        double dz = targetCenterZ - startZ;
        double range = Math.hypot(dx, dz);
        int steps = Math.max(8, Mth.ceil(range / 12.0D));
        List<SamplePoint> points = new ArrayList<>(steps + 1);
        for (int i = 0; i <= steps; i++) {
            double t = (double) i / steps;
            int bx = Mth.floor(startX + dx * t);
            int bz = Mth.floor(startZ + dz * t);
            if (points.isEmpty() || points.get(points.size() - 1).blockX != bx || points.get(points.size() - 1).blockZ != bz) {
                points.add(new SamplePoint(bx, bz));
            }
        }
        return points;
    }
}
