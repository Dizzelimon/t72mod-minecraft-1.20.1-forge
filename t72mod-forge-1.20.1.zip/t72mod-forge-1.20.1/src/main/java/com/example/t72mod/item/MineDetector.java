package com.example.t72mod.item;

import com.example.t72mod.T72Mod;
import com.example.t72mod.block.AntiTankMineBlock;
import com.example.t72mod.block.InfantryMine;
import com.example.t72mod.config.T72ServerConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public final class MineDetector extends Item {
    public MineDetector(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            BlockPos center = player.blockPosition();
            int nearest = 65;
            for (BlockPos check : BlockPos.betweenClosed(center.offset(-8, -2, -8), center.offset(8, 2, 8))) {
                double distance = check.distSqr(center);
                if (distance >= nearest || !level.hasChunkAt(check)) continue;
                var state = level.getBlockState(check);
                if (state.is(T72Mod.ANTI_TANK_MINE.get()) && state.getValue(AntiTankMineBlock.ARMED)
                        || state.is(T72Mod.INFANTRY_MINE.get()) && state.getValue(InfantryMine.ARMED)
                        && T72ServerConfig.infantryMinesEnabled()) nearest = (int) distance;
            }
            if (nearest < 65) level.playSound(null, center, SoundEvents.NOTE_BLOCK_BIT.value(), SoundSource.PLAYERS, .6F, 1.6F);
            player.displayClientMessage(nearest < 65
                    ? Component.translatable("message.t72mod.detector_found", Math.round(Math.sqrt(nearest)))
                    : Component.translatable("message.t72mod.detector_clear"), true);
            player.getCooldowns().addCooldown(this, 20);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
