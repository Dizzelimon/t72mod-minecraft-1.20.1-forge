package com.example.t72mod.entity;

import net.minecraft.world.phys.Vec3;

public final class BmpCabin {
    public static final double FLOOR = .79;
    public static final double ROOF = 2.77;
    public static final Vec3 DRIVER = new Vec3(-.67, 1.09, 2.24);
    public static final Vec3[] SEATS = {DRIVER, new Vec3(-1.02,1.09,-1.58),
            new Vec3(1.02,1.09,-1.58), new Vec3(1.02,1.09,-2.40)};
    private BmpCabin() {}

    public static CabinSection[] collision() {
        var sections = new java.util.ArrayList<CabinSection>();
        sections.add(new CabinSection(DRIVER.x, FLOOR, DRIVER.z, .58, .81, .60));
        for (int i = 0; i < 7; i++) {
            double z = -2.81 + i * .84;
            sections.add(new CabinSection(0,.57,z,2.92,FLOOR-.57,.85));
            sections.add(new CabinSection(0,ROOF,z,2.64,.19,.85));
            for (double x : new double[]{-1.48, 1.48})
                sections.add(new CabinSection(x,FLOOR,z,.23,ROOF-FLOOR,.86));
        }
        sections.add(new CabinSection(0,FLOOR,2.78,2.9,ROOF-FLOOR,.34));
        sections.add(new CabinSection(0,.53,-3.45,1.60,.16,.58));
        sections.add(new CabinSection(0,.30,-3.89,1.60,.16,.55));
        sections.add(new CabinSection(0,.07,-4.26,1.60,.16,.51));
        return sections.toArray(CabinSection[]::new);
    }

    public static boolean contains(Vec3 p) {
        return Math.abs(p.x) < 1.38 && p.z > -3.17 && p.z < 2.69 && p.y > FLOOR - .08 && p.y < ROOF;
    }
}
