package com.example.t72mod.entity;

import net.minecraft.world.phys.Vec3;

public final class BmpCabin {
    public static final double FLOOR = .79;
    public static final double ROOF = 2.70;
    public static final double HALF_WIDTH = 1.50;
    public static final Vec3 DRIVER = new Vec3(-.67, 1.08, 2.16);
    public static final Vec3[] SEATS = {DRIVER,new Vec3(-1.06,1.09,-1.58),
            new Vec3(1.06,1.09,-1.58),new Vec3(1.06,1.09,-2.40)};
    private BmpCabin() {}

    public static CabinSection[] collision() {
        var sections = new java.util.ArrayList<CabinSection>();
        sections.add(new CabinSection(DRIVER.x,FLOOR,DRIVER.z,.56,.76,.61));
        for (int i=0;i<3;i++) {
            double z=-2.23+i*2.02;
            sections.add(new CabinSection(0,.60,z,2*HALF_WIDTH,FLOOR-.60,2.03));
            for (double side : new double[]{-1,1})
                sections.add(new CabinSection(side*HALF_WIDTH,FLOOR,z,.13,ROOF-FLOOR,2.01));
        }
        sections.add(new CabinSection(0,ROOF,-.26,2.64,.14,6.0));
        sections.add(new CabinSection(0,FLOOR,2.81,2.98,ROOF-FLOOR,.14));
        sections.add(new CabinSection(0,.53,-3.45,1.60,.16,.58));
        sections.add(new CabinSection(0,.30,-3.89,1.60,.16,.55));
        sections.add(new CabinSection(0,.07,-4.26,1.60,.16,.51));
        return sections.toArray(CabinSection[]::new);
    }

    public static boolean contains(Vec3 p) {
        return Math.abs(p.x) < HALF_WIDTH && p.z > -3.22 && p.z < 2.78 && p.y > FLOOR-.09 && p.y < ROOF;
    }
}
