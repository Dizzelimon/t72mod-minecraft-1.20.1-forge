package com.example.t72mod.network;

import com.example.t72mod.entity.ArtilleryEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record ArtilleryAimPacket(int pieceId, int x, int z) {
    public static void encode(ArtilleryAimPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.pieceId);
        buf.writeInt(packet.x);
        buf.writeInt(packet.z);
    }

    public static ArtilleryAimPacket decode(FriendlyByteBuf buf) {
        return new ArtilleryAimPacket(buf.readVarInt(), buf.readInt(), buf.readInt());
    }

    public static void handle(ArtilleryAimPacket packet, Supplier<NetworkEvent.Context> supplied) {
        NetworkEvent.Context context = supplied.get();
        context.enqueueWork(() -> {
            ServerPlayer operator = context.getSender();
            if (operator != null && operator.getVehicle() instanceof ArtilleryEntity piece
                    && piece.getId() == packet.pieceId) {
                piece.aimAt(operator, packet.x, packet.z);
            }
        });
        context.setPacketHandled(true);
    }
}
