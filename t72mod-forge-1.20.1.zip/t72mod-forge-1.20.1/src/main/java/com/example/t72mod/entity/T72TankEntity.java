package com.example.t72mod.entity;

import com.example.t72mod.block.FieldObstacleBlock;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.core.Direction;
import com.example.t72mod.T72Mod;
import com.example.t72mod.block.AntiTankMineBlock;
import com.example.t72mod.inventory.TankInventoryMenu;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class T72TankEntity extends PathfinderMob implements MenuProvider, VehiclePartEntity.Parent {
    public static final int MODULE_HULL_FRONT = 0;
    public static final int MODULE_TRACKS = 1;
    public static final int MODULE_TURRET = 2;
    public static final int MODULE_ENGINE = 3;
    public static final int MODULE_GUN = 4;
    private static final EntityDataAccessor<Float> DATA_TURRET_YAW =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_BARREL_PITCH =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> DATA_HATCH_OPEN =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_RELOAD_TICKS =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_RECOIL_TICKS =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SMOKE_COOLDOWN =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);

    // New synched fields: TankType, Fuel, MG Ammo, Shell Count, Module Healths, AI Mode
    private static final EntityDataAccessor<Integer> DATA_TANK_TYPE =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_FUEL =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_MG_AMMO =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SHELL_COUNT =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TURRET_HEALTH =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TRACKS_HEALTH =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ENGINE_HEALTH =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_ENEMY_AI =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.BOOLEAN);

    private static final EntityDataAccessor<Integer> DATA_GUN_HEALTH =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);

    private static final EntityDataAccessor<Boolean> DATA_BMP_PARKED =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.BOOLEAN);

    public static final int MAX_FUEL = 1000;
    public static final int MAX_MG_AMMO = 1000;
    public static final int MAX_MODULE_HEALTH = 100;

    private float renderedYaw;
    private float previousRenderedYaw;
    private float renderedPitch;
    private float previousRenderedPitch;
    private boolean renderAimInitialized;
    public float wheelRotation;

    private int mgCooldown;
    private int fuelBurnTicker = 0;
    private boolean starterLoadoutInitialized = false;

    // 9-slot tank inventory (0..3: Cannon shells, 4..5: MG ammo boxes, 6..7: Fuel, 8: Repair kit)
    private final SimpleContainer tankInventory = new SimpleContainer(TankInventoryMenu.TANK_SLOT_COUNT);

    private static final EntityDimensions[] PART_DIMENSIONS = createPartDimensions();
    private static final int BMP_INTERIOR_START = PART_DIMENSIONS.length;
    private static final CabinSection[] BMP_INTERIOR = BmpCabin.collision();
    private static final EntityDimensions[] BMP_PARTS = createBmpParts();
    private final VehiclePartEntity[] subParts = new VehiclePartEntity[BMP_PARTS.length];

    private static EntityDimensions[] createBmpParts() {
        var parts = java.util.Arrays.copyOf(PART_DIMENSIONS, BMP_INTERIOR_START + BMP_INTERIOR.length);
        for (int i = 0; i < BMP_INTERIOR.length; i++) parts[i + BMP_INTERIOR_START] = BMP_INTERIOR[i].dimensions();
        return parts;
    }

    private static EntityDimensions[] createPartDimensions() {
        EntityDimensions[] dimensions = new EntityDimensions[TankGeometry.BASE_PART_COUNT];
        java.util.Arrays.fill(dimensions,0,TankGeometry.TRACK_PARTS,EntityDimensions.fixed(.65F,.80F));
        java.util.Arrays.fill(dimensions,TankGeometry.TRACK_PARTS,TankGeometry.FIRST_TURRET_PART,EntityDimensions.fixed(.84F,1.50F));
        java.util.Arrays.fill(dimensions,TankGeometry.FIRST_TURRET_PART,TankGeometry.FIRST_BARREL_PART,EntityDimensions.fixed(.94F,.76F));
        java.util.Arrays.fill(dimensions, TankGeometry.FIRST_BARREL_PART, dimensions.length, EntityDimensions.fixed(.54F, .31F));
        return dimensions;
    }

    public T72TankEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setMaxUpStep(1.5F);
        this.blocksBuilding = true;

        if (type == T72Mod.BMP3.get()) {
            this.setTankType(TankType.BMP3);
        } else if (type == T72Mod.T90M_TANK.get()) {
            this.setTankType(TankType.T90M);
        } else if (type == T72Mod.ABRAMS_TANK.get()) {
            this.setTankType(TankType.ABRAMS);
        } else if (type == T72Mod.LEOPARD2_TANK.get()) {
            this.setTankType(TankType.LEOPARD2);
        } else {
            this.setTankType(TankType.T72B);
        }

    }

    private void updateSubPartPositions() {
        VehiclePartEntity.updateParts(this, this.subParts, this.getTankType() == TankType.BMP3 ? BMP_PARTS : PART_DIMENSIONS);
    }

    @Override
    public boolean partIsActive(int index) {
        if (index >= BMP_INTERIOR_START) return this.bmpCabinOpen();
        return index < TankGeometry.FIRST_BARREL_PART || !this.isGunBroken()
                || this.barrelDistance(index) < .95 * this.getTankType().modelScale();
    }

    @Override
    public boolean partIsSolid(int index) {
        if (index >= BMP_INTERIOR_START) return index != BMP_INTERIOR_START && this.bmpCabinOpen();
        if (index >= TankGeometry.FIRST_BARREL_PART) return this.partIsActive(index);
        return !this.bmpCabinOpen() || index >= TankGeometry.FIRST_TURRET_PART;
    }

    @Override
    public boolean partShouldExist(int index) { return index < BMP_INTERIOR_START || this.bmpCabinOpen(); }

    @Override
    public AABB partBounds(int index, AABB fallback) {
        TankType type = this.getTankType();
        if (index >= BMP_INTERIOR_START) return BMP_INTERIOR[index-BMP_INTERIOR_START].bounds(this);
        if (index < TankGeometry.FIRST_TURRET_PART) return this.hullSection(index).bounds(this);
        if (index < TankGeometry.FIRST_BARREL_PART) {
            Vec3 pivot = TankGeometry.turretCenter(this.position(),this.getYRot(),type);
            return this.turretSection(index).bounds(new Vec3(pivot.x,this.getY(),pivot.z),this.getTurretYaw());
        }
        float yaw = this.getTurretYaw(), pitch = this.getBarrelPitch();
        Vec3 direction = Vec3.directionFromRotation(pitch,yaw);
        Vec3 center = this.barrelCenter(index);
        Vec3 half = direction.scale(TankGeometry.barrelLength(type)/TankGeometry.BARREL_PARTS*.50);
        double radius = TankGeometry.barrelRadius(type) * (index - TankGeometry.FIRST_BARREL_PART < 4 ? 1.22 : 1);
        return new AABB(center.subtract(half),center.add(half)).inflate(radius);
    }

    private CabinSection hullSection(int index) {
        TankType type = this.getTankType();
        double length = TankGeometry.trackLength(type);
        if (index < TankGeometry.TRACK_PARTS) {
            int segments=TankGeometry.TRACK_PARTS/2;
            double side=index<segments ? -1 : 1;
            return new CabinSection(side*TankGeometry.trackCenter(type),0,(index%segments+.5-segments/2.0)*length/segments,
                    TankGeometry.trackWidth(type),TankGeometry.trackTop(type),length/segments+.015);
        }
        int panel=index-TankGeometry.TRACK_PARTS;
        double tileWidth=TankGeometry.hullWidth(type)/TankGeometry.HULL_COLUMNS;
        double tileLength=(length+.27)/TankGeometry.HULL_ROWS;
        int row=panel/TankGeometry.HULL_COLUMNS, column=panel%TankGeometry.HULL_COLUMNS;
        return new CabinSection((column+.5-TankGeometry.HULL_COLUMNS/2.0)*tileWidth,0,
                (row+.5-TankGeometry.HULL_ROWS/2.0)*tileLength,tileWidth+.012,
                TankGeometry.hullTop(type)-(row==0 || row==TankGeometry.HULL_ROWS-1 ? .07 : 0),tileLength+.014);
    }

    private CabinSection turretSection(int index) {
        TankType type = this.getTankType();
        int segment=index-TankGeometry.FIRST_TURRET_PART;
        double width = TankGeometry.turretWidth(type)/2;
        double length = TankGeometry.turretLength(type)/2;
        return new CabinSection((segment%2-.5)*width,TankGeometry.hullTop(type),
                (segment/2-.5)*length,width+.022,TankGeometry.turretTop(type)-TankGeometry.hullTop(type),length+.021);
    }

    private double barrelDistance(int index) {
        return (index-TankGeometry.FIRST_BARREL_PART+.5)*TankGeometry.barrelLength(this.getTankType())/TankGeometry.BARREL_PARTS;
    }

    private Vec3 barrelCenter(int index) {
        return this.cannonPivot().add(Vec3.directionFromRotation(this.getBarrelPitch(),this.getTurretYaw())
                .scale(this.barrelDistance(index)));
    }

    public boolean bmpCabinOpen() {
        return this.getTankType() == TankType.BMP3 && this.entityData.get(DATA_BMP_PARKED);
    }

    private boolean insideBmp(Player player) {
        return BmpCabin.contains(AirframeLayout.local(this.position(), this.getYRot(), player.position()));
    }

    public void toggleBmpBrake(Player driver) {
        if (this.getTankType() != TankType.BMP3 || this.getControllingPassenger() != driver) return;
        if (!this.onGround() || this.getDeltaMovement().horizontalDistanceSqr() >= .003) {
            driver.displayClientMessage(Component.translatable("message.t72mod.bmp_stop"), true);
            return;
        }
        if (this.bmpCabinOpen()) {
            var occupants = this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(3,1,3),
                    p -> !p.isPassenger() && !p.isSpectator() && p.isAlive() && this.insideBmp(p));
            if (occupants.size() + this.getPassengers().size() > 4 || occupants.stream().anyMatch(Player::isShiftKeyDown)) {
                driver.displayClientMessage(Component.translatable("message.t72mod.cabin_seats_needed"), true);
                return;
            }
            for (Player occupant : occupants) if (!occupant.startRiding(this, true)) return;
        }
        this.entityData.set(DATA_BMP_PARKED, !this.bmpCabinOpen());
        this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.NEUTRAL, .75F, .97F);
        driver.displayClientMessage(Component.translatable(this.bmpCabinOpen()
                ? "message.t72mod.bmp_parked" : "message.t72mod.bmp_ready"), true);
    }

    @Override
    public Vec3 partPosition(int index) {
        if (index >= BMP_INTERIOR_START) return BMP_INTERIOR[index-BMP_INTERIOR_START].position(this);
        if (index < TankGeometry.FIRST_TURRET_PART) return this.hullSection(index).position(this);
        if (index < TankGeometry.FIRST_BARREL_PART) {
            Vec3 pivot=TankGeometry.turretCenter(this.position(),this.getYRot(),this.getTankType());
            CabinSection tile=this.turretSection(index);
            return AirframeLayout.world(new Vec3(pivot.x,this.getY(),pivot.z),this.getTurretYaw(),tile.x(),tile.y(),tile.z());
        }
        return this.barrelCenter(index).add(0,-TankGeometry.barrelRadius(this.getTankType()),0);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.ARMOR, 24.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 16.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.35D);
    }

    public static AttributeSupplier.Builder createAbramsAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 380.0D)
                .add(Attributes.ARMOR, 28.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 18.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.36D);
    }

    public static AttributeSupplier.Builder createLeopard2Attributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 320.0D)
                .add(Attributes.ARMOR, 25.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 17.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.38D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_TURRET_YAW, 0.0F);
        this.entityData.define(DATA_BARREL_PITCH, 0.0F);
        this.entityData.define(DATA_HATCH_OPEN, true);
        this.entityData.define(DATA_RELOAD_TICKS, 0);
        this.entityData.define(DATA_RECOIL_TICKS, 0);
        this.entityData.define(DATA_SMOKE_COOLDOWN, 0);
        this.entityData.define(DATA_TANK_TYPE, 0);
        this.entityData.define(DATA_FUEL, 500);
        this.entityData.define(DATA_MG_AMMO, 250);
        this.entityData.define(DATA_SHELL_COUNT, 0);
        this.entityData.define(DATA_TURRET_HEALTH, MAX_MODULE_HEALTH);
        this.entityData.define(DATA_TRACKS_HEALTH, MAX_MODULE_HEALTH);
        this.entityData.define(DATA_ENGINE_HEALTH, MAX_MODULE_HEALTH);
        this.entityData.define(DATA_ENEMY_AI, false);
        this.entityData.define(DATA_GUN_HEALTH, MAX_MODULE_HEALTH);
        this.entityData.define(DATA_BMP_PARKED, false);
    }

    public void initStarterSupplies() {
        if (this.starterLoadoutInitialized) return;
        this.starterLoadoutInitialized = true;
        TankType type = this.getTankType();
        if (type == TankType.BMP3) {
            this.tankInventory.setItem(0, new ItemStack(T72Mod.SHELL_100MM.get(), 4));
        } else if (type == TankType.T72B || type == TankType.T90M) {
            this.tankInventory.setItem(0, new ItemStack(T72Mod.SHELL_125MM.get(), 8));
        } else {
            this.tankInventory.setItem(0, new ItemStack(T72Mod.SHELL_120MM.get(), 8));
        }
        this.tankInventory.setItem(4, new ItemStack(T72Mod.MG_AMMO_BOX.get(), 2));
        this.tankInventory.setItem(6, new ItemStack(T72Mod.FUEL_CANISTER.get(), 1));
        this.tankInventory.setItem(8, new ItemStack(T72Mod.REPAIR_KIT.get(), 2));
        this.updateShellCountData();
    }

    @Override
    protected void registerGoals() {
    }

    @Override
    protected float tickHeadTurn(float bodyRot, float animStep) {
        // Keep hull rotation strictly independent from turret rotation so LivingEntity never twists the body
        this.yBodyRot = this.getYRot();
        this.yBodyRotO = this.yRotO;
        return 0.0F;
    }

    @Override
    public boolean canBeCollidedWith() {
        return this.isAlive() && !this.bmpCabinOpen();
    }

    @Override
    public boolean canCollideWith(Entity other) {
        if (other instanceof VehiclePartEntity part && part.parent() == this) return false;
        return (other.canBeCollidedWith() || other.isPushable()) && !this.isPassengerOfSameVehicle(other);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    public SimpleContainer getTankInventory() {
        return this.tankInventory;
    }

    public static boolean isMainShellItem(ItemStack stack) {
        return stack.is(T72Mod.SHELL_100MM.get()) || stack.is(T72Mod.SHELL_125MM.get())
                || stack.is(T72Mod.SHELL_120MM.get());
    }

    private static boolean isCompatibleShell(ItemStack stack, TankType type) {
        return switch (type) {
            case BMP3 -> stack.is(T72Mod.SHELL_100MM.get());
            case T72B, T90M -> stack.is(T72Mod.SHELL_125MM.get());
            case ABRAMS, LEOPARD2 -> stack.is(T72Mod.SHELL_120MM.get());
        };
    }

    public static int getFuelValue(ItemStack stack) {
        if (stack.is(T72Mod.FUEL_CANISTER.get())) return 500;
        if (stack.is(Items.COAL_BLOCK)) return 400;
        if (stack.is(Items.LAVA_BUCKET)) return 800;
        if (stack.is(Items.COAL) || stack.is(Items.CHARCOAL)) return 60;
        return 0;
    }

    public static boolean isRepairItem(ItemStack stack) {
        return stack.is(T72Mod.REPAIR_KIT.get()) || stack.is(Items.IRON_BLOCK) || stack.is(Items.IRON_INGOT);
    }

    @Override
    public InteractionResult interactPart(int index, Player player, InteractionHand hand) {
        return index < TankGeometry.FIRST_BARREL_PART || index >= BMP_INTERIOR_START
                ? this.handleTankInteraction(player,hand,index >= TankGeometry.FIRST_TURRET_PART && index < TankGeometry.FIRST_BARREL_PART)
                : InteractionResult.PASS;
    }

    @Override
    public InteractionResult interactAt(Player player, Vec3 clickVec, InteractionHand hand) {
        boolean clickedUpperArea = clickVec.y >= 0.95D;
        return this.handleTankInteraction(player, hand, clickedUpperArea);
    }

    private InteractionResult handleTankInteraction(Player player, InteractionHand hand, boolean clickedUpperArea) {
        if (!this.isAlive() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;

        ItemStack stack = player.getItemInHand(hand);

        // 1. Toggle Enemy AI Crew mode if clicked with AI Crew Chip
        if (stack.is(T72Mod.AI_CREW_CHIP.get())) {
            if (!this.level().isClientSide) {
                boolean nextAi = !this.isEnemyAI();
                this.setEnemyAI(nextAi);
                this.setHatchOpen(!nextAi);
                if (nextAi && !this.starterLoadoutInitialized) {
                    this.initStarterSupplies();
                }
                this.level().playSound(null, this.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1.0F, nextAi ? 0.7F : 1.3F);
                player.displayClientMessage(Component.literal(nextAi
                                ? "⚠ Активирован вражеский ИИ-экипаж (" + this.getTankType().displayName + ")! Танк будет атаковать цели."
                                : "ИИ-экипаж отключён. Танк переведён в ручной режим.")
                        .withStyle(nextAi ? ChatFormatting.RED : ChatFormatting.GREEN), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // 2. Quick external repair with Repair Kit, Iron Block, or Iron Ingot
        if (isRepairItem(stack) && (this.getHealth() < this.getMaxHealth() || this.hasBrokenModules())) {
            if (!this.level().isClientSide) {
                this.applyRepairItem(stack, player);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // 3. Quick external refuel with Fuel Canister or Coal
        int fuelAdd = getFuelValue(stack);
        if (fuelAdd > 0 && this.getFuel() < MAX_FUEL) {
            if (!this.level().isClientSide) {
                this.setFuel(Math.min(MAX_FUEL, this.getFuel() + fuelAdd));
                if (!player.getAbilities().instabuild) stack.shrink(1);
                this.level().playSound(null, this.blockPosition(), SoundEvents.BUCKET_FILL, SoundSource.PLAYERS, 1.0F, 1.0F);
                player.displayClientMessage(Component.literal("Топливный бак заправлен: " + this.getFuel() + "/" + MAX_FUEL)
                        .withStyle(ChatFormatting.GOLD), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // 4. Quick external ammo load if holding shells or MG ammo box
        if (isMainShellItem(stack) || stack.is(T72Mod.MG_AMMO_BOX.get())) {
            if (!this.level().isClientSide && player instanceof ServerPlayer sp) {
                this.openTankInventory(sp);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        if (this.getTankType() == TankType.BMP3 && !this.isEnemyAI() && !player.isShiftKeyDown() && stack.isEmpty()) {
            if (this.bmpCabinOpen() && this.insideBmp(player)) {
                Vec3 local = AirframeLayout.local(this.position(), this.getYRot(), player.position());
                if (this.getFirstPassenger() == null && local.z < 1.11) {
                    if (!this.level().isClientSide)
                        player.displayClientMessage(Component.translatable("message.t72mod.bmp_board"), true);
                    return InteractionResult.FAIL;
                }
                if (!this.level().isClientSide && !player.startRiding(this)) return InteractionResult.FAIL;
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
            if (this.isVehicle() && this.onGround() && this.getDeltaMovement().horizontalDistanceSqr() < .003) {
                if (!this.level().isClientSide && !player.startRiding(this)) return InteractionResult.FAIL;
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
            return InteractionResult.PASS;
        }

        double playerHeightAboveGround = player.getY() - this.getY();
        double horizontalDist = Math.hypot(player.getX() - this.getX(), player.getZ() - this.getZ());
        boolean isOnTankOrStep = playerHeightAboveGround >= 0.65D && horizontalDist <= 3.0D;

        if (player.isShiftKeyDown()) {
            // If standing on ground and Shift+Right-Clicking hull, open Tank Inventory unless clicking upper hatch
            if (!isOnTankOrStep && !clickedUpperArea) {
                if (!this.level().isClientSide && player instanceof ServerPlayer sp) {
                    this.openTankInventory(sp);
                }
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }

            // Toggle Hatch
            if (!this.level().isClientSide) {
                boolean nextState = !this.isHatchOpen();
                this.setHatchOpen(nextState);
                this.level().playSound(null, this.blockPosition(),
                        SoundEvents.IRON_TRAPDOOR_CLOSE,
                        SoundSource.BLOCKS, 1.0F, 0.75F);
                player.displayClientMessage(Component.literal(nextState ? "Люк башни открыт" : "Люк башни задраен")
                        .withStyle(ChatFormatting.YELLOW), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        if (this.isEnemyAI()) {
            if (!this.level().isClientSide) {
                player.displayClientMessage(Component.literal("Внутри вражеский ИИ-экипаж! Отключите его чипом ИИ-экипажа.")
                        .withStyle(ChatFormatting.RED), true);
            }
            return InteractionResult.FAIL;
        }

        if (!this.isVehicle()) {
            if (!isOnTankOrStep && !clickedUpperArea) {
                if (!this.level().isClientSide) {
                    player.displayClientMessage(Component.literal("Запрыгните на гусеницу, нос или корму танка, чтобы забраться в люк! (Shift+ПКМ с земли — боеукладка)")
                            .withStyle(ChatFormatting.GOLD), true);
                }
                return InteractionResult.FAIL;
            }

            if (!this.isHatchOpen()) {
                if (!this.level().isClientSide) {
                    player.displayClientMessage(Component.literal("Люк башни закрыт! Нажмите Shift + ПКМ по башне, чтобы открыть его.")
                            .withStyle(ChatFormatting.RED), true);
                }
                return InteractionResult.FAIL;
            }

            if (!this.level().isClientSide) {
                if (!this.starterLoadoutInitialized) {
                    this.initStarterSupplies();
                }
                if (!player.startRiding(this)) return InteractionResult.FAIL;
                this.setHatchOpen(false);
                this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 1.0F, 0.7F);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        return InteractionResult.PASS;
    }

    public void openTankInventory(ServerPlayer player) {
        if (!this.starterLoadoutInitialized) {
            this.initStarterSupplies();
        }
        NetworkHooks.openScreen(player, this, buf -> buf.writeInt(this.getId()));
    }

    @Override
    public Component getDisplayName() {
        return Component.literal("Укладка: " + this.getTankType().displayName);
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInv, Player player) {
        return new TankInventoryMenu(containerId, playerInv, this.tankInventory, this);
    }

    public boolean hasBrokenModules() {
        return this.getTurretHealth() < MAX_MODULE_HEALTH
                || this.getTracksHealth() < MAX_MODULE_HEALTH
                || this.getEngineHealth() < MAX_MODULE_HEALTH || this.getGunHealth() < MAX_MODULE_HEALTH;
    }

    public void performFieldRepair(Player player) {
        if (this.level().isClientSide) return;
        if (this.getHealth() >= this.getMaxHealth() && !this.hasBrokenModules()) {
            player.displayClientMessage(Component.literal("Все узлы и броня танка исправны!")
                    .withStyle(ChatFormatting.GREEN), true);
            return;
        }

        // Check slot 8 in tank inventory first, then player's inventory
        ItemStack repairStack = this.tankInventory.getItem(8);
        if (repairStack.isEmpty() || !isRepairItem(repairStack)) {
            repairStack = ItemStack.EMPTY;
            for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                ItemStack s = player.getInventory().getItem(i);
                if (isRepairItem(s)) {
                    repairStack = s;
                    break;
                }
            }
        }

        if (repairStack.isEmpty() && !player.getAbilities().instabuild) {
            player.displayClientMessage(Component.literal("Нет ремкомплекта (ЗИП) или железа в слоте ремонта / инвентаре!")
                    .withStyle(ChatFormatting.RED), true);
            this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 1.0F, 0.8F);
            return;
        }

        if (player.getAbilities().instabuild && repairStack.isEmpty()) {
            this.setTurretHealth(MAX_MODULE_HEALTH);
            this.setTracksHealth(MAX_MODULE_HEALTH);
            this.setEngineHealth(MAX_MODULE_HEALTH);
            this.setGunHealth(MAX_MODULE_HEALTH);
            this.heal(120.0F);
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1.0F, 1.1F);
            player.displayClientMessage(Component.literal("Все модули (башня, гусеницы, двигатель) и броня отремонтированы!")
                    .withStyle(ChatFormatting.GREEN), true);
            return;
        }

        this.applyRepairItem(repairStack, player);
    }

    private void applyRepairItem(ItemStack stack, Player player) {
        boolean isFullKit = stack.is(T72Mod.REPAIR_KIT.get());
        boolean isBlock = stack.is(Items.IRON_BLOCK);

        float healAmount = isFullKit ? 110.0F : (isBlock ? 55.0F : 15.0F);
        int moduleRestore = isFullKit ? 100 : (isBlock ? 70 : 35);

        this.heal(healAmount);
        this.setTurretHealth(Math.min(MAX_MODULE_HEALTH, this.getTurretHealth() + moduleRestore));
        this.setTracksHealth(Math.min(MAX_MODULE_HEALTH, this.getTracksHealth() + moduleRestore));
        this.setEngineHealth(this.getEngineHealth() + moduleRestore);
        this.setGunHealth(this.getGunHealth() + moduleRestore);

        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1.0F, 1.15F);
        player.displayClientMessage(Component.literal(String.format(
                        "Ремонт выполнен! Броня: %d/%d | Башня: %d%% | Гусеницы: %d%% | Двигатель: %d%% | Орудие: %d%%",
                        (int) this.getHealth(), (int) this.getMaxHealth(),
                        this.getTurretHealth(), this.getTracksHealth(), this.getEngineHealth(), this.getGunHealth()))
                .withStyle(ChatFormatting.GREEN), true);
    }

    public boolean serviceFromTruck() {
        if (this.level().isClientSide || !this.isAlive()
                || this.getHealth() >= this.getMaxHealth() && !this.hasBrokenModules()) return false;
        this.setGunHealth(MAX_MODULE_HEALTH);
        this.setTracksHealth(MAX_MODULE_HEALTH);
        this.setTurretHealth(MAX_MODULE_HEALTH);
        this.setEngineHealth(MAX_MODULE_HEALTH);
        this.heal(65);
        return true;
    }

    @Override protected boolean canAddPassenger(Entity e) {
        return e instanceof Player && this.isAlive() && this.getPassengers().size()
                < (this.getTankType() == TankType.BMP3 ? 4 : 1);
    }

    @Override protected void positionRider(Entity passenger, Entity.MoveFunction move) {
        int seat = this.getPassengers().indexOf(passenger);
        if (this.getTankType() != TankType.BMP3 || seat < 0) {
            super.positionRider(passenger, move);
            return;
        }
        Vec3 offset = BmpCabin.SEATS[seat];
        Vec3 pos = AirframeLayout.world(this.position(), this.getYRot(), offset.x,
                offset.y + passenger.getMyRidingOffset() + (seat == 0 && this.isHatchOpen() ? .66 : 0), offset.z);
        move.accept(passenger, pos.x, pos.y, pos.z);
    }

    @Override
    protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (!this.level().isClientSide && passenger instanceof Player && this.getTankType() != TankType.BMP3) {
            this.setHatchOpen(true);
            this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 1.0F, 0.75F);
        }
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        if (this.bmpCabinOpen()) {
            Vec3 aisle = AirframeLayout.world(this.position(), this.getYRot(), 0, BmpCabin.FLOOR + .02, -.41);
            if (this.level().noCollision(passenger, passenger.getBoundingBox().move(aisle.subtract(passenger.position()))))
                return aisle;
        }
        for (float side : new float[]{90.0F, -90.0F, 180.0F, 0.0F}) {
            Vec3 point = this.position().add(Vec3.directionFromRotation(0, this.getYRot() + side).scale(this.getTankType() == TankType.BMP3 ? 3.0 : 3.45));
            if (this.level().noCollision(passenger, passenger.getBoundingBox().move(point.subtract(passenger.position())))) {
                return point;
            }
        }
        return this.position().add(0, 1.75, 0);
    }

    @Override
    public double getPassengersRidingOffset() {
        return 0.45D;
    }

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        return this.getFirstPassenger() instanceof LivingEntity living ? living : null;
    }

    private void updateAim(LivingEntity driver) {
        if (this.isTurretBroken()) return;
        TankType type = this.getTankType();
        float remainingYaw = Mth.wrapDegrees(driver.getYRot() - this.getTurretYaw());
        this.setTurretYaw(Mth.wrapDegrees(this.getTurretYaw() +
                Mth.clamp(remainingYaw, -type.turretTurnSpeed, type.turretTurnSpeed)));
        float targetPitch = Mth.clamp(driver.getXRot(), type.minBarrelPitch, type.maxBarrelPitch);
        this.setBarrelPitch(Mth.approach(this.getBarrelPitch(), targetPitch, 2.8F));
    }

    public float renderTurretYaw(float partialTick) {
        return this.renderAimInitialized ? Mth.rotLerp(partialTick, this.previousRenderedYaw, this.renderedYaw) : this.getTurretYaw();
    }

    public float renderBarrelPitch(float partialTick) {
        return this.renderAimInitialized ? Mth.lerp(partialTick, this.previousRenderedPitch, this.renderedPitch) : this.getBarrelPitch();
    }

    private void sampleRenderAim() {
        if (!this.renderAimInitialized) {
            this.renderedYaw = this.getTurretYaw();
            this.renderedPitch = this.getBarrelPitch();
            this.renderAimInitialized = true;
        }
        this.previousRenderedYaw = this.renderedYaw;
        this.previousRenderedPitch = this.renderedPitch;
        this.renderedYaw = this.getTurretYaw();
        this.renderedPitch = this.getBarrelPitch();
    }

    @Override
    public void tick() {
        super.tick();

        // Keep body rotation strictly locked to hull YRot so vanilla LivingEntity never twists the hull
        this.yBodyRot = this.getYRot();
        this.yBodyRotO = this.yRotO;
        this.yHeadRot = this.getYRot();
        this.yHeadRotO = this.yRotO;

        if (this.level().isClientSide) this.sampleRenderAim();
        else if (this.isAlive()) {
            if (this.getTankType() == TankType.BMP3 && !this.isVehicle()) {
                this.entityData.set(DATA_BMP_PARKED, !this.isEnemyAI() && this.onGround() && !this.isInWater()
                        && this.getDeltaMovement().horizontalDistanceSqr() < .003);
            }
            this.updateSubPartPositions();
        }
        if (this.mgCooldown > 0) this.mgCooldown--;

        if (this.getReloadTicks() > 0) this.setReloadTicks(this.getReloadTicks() - 1);
        if (this.getRecoilTicks() > 0) this.setRecoilTicks(this.getRecoilTicks() - 1);
        if (this.getSmokeCooldown() > 0) this.setSmokeCooldown(this.getSmokeCooldown() - 1);

        if (!this.level().isClientSide) {
            if (!this.starterLoadoutInitialized) {
                this.initStarterSupplies();
            }
            if (this.getReloadTicks() == 1) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.PLAYERS, .8F, 1.36F);
            }
            this.tickSupplyAutoLoad();
        }

        // Emit damage smoke/sparks if modules are broken
        if (this.level().isClientSide) {
            if (this.isEngineBroken() && this.tickCount % 2 == 0) {
                double rad = Math.toRadians(this.getYRot());
                double backX = this.getX() + Math.sin(rad) * 1.6D;
                double backZ = this.getZ() - Math.cos(rad) * 1.6D;
                this.level().addParticle(ParticleTypes.LARGE_SMOKE, backX, this.getY() + 1.1D, backZ, 0.0D, 0.06D, 0.0D);
                this.level().addParticle(ParticleTypes.LAVA, backX, this.getY() + 1.0D, backZ, 0.0D, 0.02D, 0.0D);
            }
            if (this.isGunBroken() && this.tickCount % 4 == 0) {
                Vec3 breach = this.cannonPivot();
                this.level().addParticle(ParticleTypes.SMOKE, breach.x, breach.y, breach.z, 0, 0.06, 0);
            }
            if (this.isTurretBroken() && this.tickCount % 4 == 0) {
                this.level().addParticle(ParticleTypes.CRIT, this.getX(), this.getY() + 1.55D, this.getZ(), 0.0D, 0.05D, 0.0D);
            }
        }

        LivingEntity driver = this.getControllingPassenger();
        if (driver != null) {
            // Keep passenger safe from fire, drowning, and fall damage inside the armored hull
            driver.clearFire();
            driver.setAirSupply(driver.getMaxAirSupply());
            driver.resetFallDistance();

            TankType type = this.getTankType();

            if (!this.level().isClientSide) {
                this.updateAim(driver);
                if (driver instanceof Player player && !player.getAbilities().instabuild
                        && (Math.abs(player.xxa) > 0.01F || Math.abs(player.zza) > 0.01F)) {
                    this.burnFuel();
                }
            }

            if (this.getFuel() > 0 && !this.isEngineBroken()) {
                if (this.level().isClientSide && this.tickCount % 3 == 0) {
                    double rad = Math.toRadians(this.getYRot());
                    double backX = this.getX() + Math.sin(rad) * 1.9D - Math.cos(rad) * 1.1D;
                    double backZ = this.getZ() - Math.cos(rad) * 1.9D - Math.sin(rad) * 1.1D;
                    this.level().addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                            backX, this.getY() + 0.95D, backZ,
                            Math.sin(rad) * 0.04D, 0.03D, -Math.cos(rad) * 0.04D);
                }

            }
        } else if (!this.level().isClientSide && this.isEnemyAI()) {
            this.tickEnemyAI();
        }

        double speedSq = this.getDeltaMovement().horizontalDistanceSqr();
        if (speedSq > 0.0004D) {
            this.wheelRotation += (float) Math.sqrt(speedSq) * 1.8F;
            if (!this.level().isClientSide) {
                if (speedSq > 0.02D) {
                    AABB ramBox = this.getBoundingBox().inflate(0.95D, 0.2D, 0.95D);
                    List<Entity> hitEntities = this.level().getEntities(this, ramBox,
                            e -> e instanceof LivingEntity && !(e instanceof T72TankEntity) && !this.isPassengerOfSameVehicle(e));
                    for (Entity victim : hitEntities) {
                        victim.hurt(this.damageSources().mobAttack(this), 12.0F);
                        Vec3 knock = this.getDeltaMovement().normalize().scale(1.25D);
                        victim.push(knock.x, 0.35D, knock.z);
                    }
                }
            }
        }
    }

    @Override
    public void move(MoverType type, Vec3 movement) {
        if (!this.level().isClientSide && this.isAlive() && !this.isTracksBroken()
                && this.getFuel() > 0 && (this.isVehicle() || this.isEnemyAI()) && movement.horizontalDistanceSqr() > 0.0004
                && this.level().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            Vec3 advance = movement.multiply(1,0,1);
            AABB path=this.getBoundingBox();
            for (int i=0;i<TankGeometry.FIRST_TURRET_PART;i++) path=path.minmax(this.hullSection(i).bounds(this));
            this.crushVegetation(path.expandTowards(advance).inflate(0,.22,0));
        }
        if (this.subParts != null && movement.horizontalDistanceSqr() > .000001
                && (this.isVehicle() || this.isEnemyAI())) {
            movement = this.clipAgainstFieldObstacles(movement);
        }
        super.move(type, movement);
        if (this.level() instanceof ServerLevel server && this.subParts != null && this.isAlive()
                && movement.horizontalDistanceSqr() > .0001) this.checkMines(server);
    }

    private Vec3 clipAgainstFieldObstacles(Vec3 movement) {
        AABB[] footprint = new AABB[TankGeometry.FIRST_TURRET_PART];
        AABB sweep = this.getBoundingBox();
        for (int i = 0; i < footprint.length; i++) {
            footprint[i] = this.hullSection(i).bounds(this).deflate(.01);
            sweep = sweep.minmax(footprint[i]);
        }
        sweep = sweep.expandTowards(movement.x,0,movement.z);
        List<VoxelShape> obstacles = new java.util.ArrayList<>();
        for (BlockPos pos : BlockPos.betweenClosed(Mth.floor(sweep.minX),Mth.floor(sweep.minY)-1,Mth.floor(sweep.minZ),
                Mth.floor(sweep.maxX),Mth.floor(sweep.maxY),Mth.floor(sweep.maxZ))) {
            BlockState state = this.level().getBlockState(pos);
            if (state.getBlock() instanceof FieldObstacleBlock)
                obstacles.add(state.getCollisionShape(this.level(),pos,CollisionContext.of(this)).move(pos.getX(),pos.getY(),pos.getZ()));
        }
        if (obstacles.isEmpty()) return movement;
        double x = movement.x, z = movement.z;
        for (AABB part : footprint) x = Shapes.collide(Direction.Axis.X,part,obstacles,x);
        for (AABB part : footprint) z = Shapes.collide(Direction.Axis.Z,part.move(x,0,0),obstacles,z);
        return new Vec3(x,movement.y,z);
    }

    public void toggleBmpHatch(Player driver) {
        if (this.getTankType() != TankType.BMP3 || this.getControllingPassenger() != driver) return;
        this.setHatchOpen(!this.isHatchOpen());
        this.level().playSound(null,this.blockPosition(),
                this.isHatchOpen() ? SoundEvents.IRON_TRAPDOOR_OPEN : SoundEvents.IRON_TRAPDOOR_CLOSE,SoundSource.NEUTRAL,1,.9F);
    }

    public void damageTracksFromMine() {
        if (!this.level().isClientSide) this.damageSpecificModule(MODULE_TRACKS, MAX_MODULE_HEALTH);
    }

    public boolean overlapsMine(BlockPos pos) {
        Vec3 center = Vec3.atBottomCenterOf(pos);
        AABB fuse = new AABB(center.x - 0.37, center.y, center.z - 0.37,
                center.x + 0.37, center.y + 0.24, center.z + 0.37);
        for (int i=0;i<TankGeometry.FIRST_TURRET_PART;i++) {
            if (this.hullSection(i).bounds(this).intersects(fuse)) return true;
        }
        return this.getBoundingBox().intersects(fuse);
    }

    private void checkMines(ServerLevel level) {
        AABB area = this.getBoundingBox().inflate(2.4, 0.16, 2.4);
        for (BlockPos pos : BlockPos.betweenClosed(Mth.floor(area.minX), Mth.floor(this.getY() - 0.2),
                Mth.floor(area.minZ), Mth.floor(area.maxX), Mth.floor(this.getY() + 0.16), Mth.floor(area.maxZ))) {
            if (level.hasChunkAt(pos) && level.getBlockState(pos).getBlock() instanceof AntiTankMineBlock mine
                    && this.overlapsMine(pos)) mine.trigger(level, pos, this);
        }
    }

    private void crushVegetation(AABB area) {
        for (BlockPos pos : BlockPos.betweenClosed(
                Mth.floor(area.minX), Mth.floor(area.minY), Mth.floor(area.minZ),
                Mth.floor(area.maxX), Mth.floor(area.maxY), Mth.floor(area.maxZ))) {
            if (!this.level().hasChunkAt(pos)) continue;
            BlockState state = this.level().getBlockState(pos);
            if (state.is(Blocks.FARMLAND) && pos.getY() < this.getY()) {
                FarmBlock.turnToDirt(this, state, this.level(), pos);
            } else if (state.is(T72Mod.TANK_CRUSHABLE)) {
                this.level().destroyBlock(pos, true, this);
            }
        }
    }

    private void tickSupplyAutoLoad() {
        // 1. Auto-refill Coaxial MG Ammo from Slots 4..5
        if (this.getMgAmmo() <= MAX_MG_AMMO - 250) {
            for (int i = 4; i <= 5; i++) {
                ItemStack s = this.tankInventory.getItem(i);
                if (s.is(T72Mod.MG_AMMO_BOX.get())) {
                    s.shrink(1);
                    this.setMgAmmo(Math.min(MAX_MG_AMMO, this.getMgAmmo() + 250));
                    this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, 0.8F, 1.2F);
                    break;
                } else if (s.is(Items.IRON_NUGGET) && s.getCount() >= 8) {
                    s.shrink(8);
                    this.setMgAmmo(Math.min(MAX_MG_AMMO, this.getMgAmmo() + 40));
                    break;
                }
            }
        }

        // 2. Auto-refill Fuel from Slots 6..7
        if (this.getFuel() <= MAX_FUEL - 60) {
            for (int i = 6; i <= 7; i++) {
                ItemStack s = this.tankInventory.getItem(i);
                int fuelVal = getFuelValue(s);
                if (fuelVal > 0 && this.getFuel() + fuelVal <= MAX_FUEL) {
                    if (s.is(Items.LAVA_BUCKET)) {
                        this.tankInventory.setItem(i, new ItemStack(Items.BUCKET));
                    } else {
                        s.shrink(1);
                    }
                    this.setFuel(Math.min(MAX_FUEL, this.getFuel() + fuelVal));
                    this.level().playSound(null, this.blockPosition(), SoundEvents.BUCKET_FILL, SoundSource.PLAYERS, 0.7F, 1.1F);
                    break;
                }
            }
        }

        // 3. Sync total main cannon shells count in Slots 0..3
        if (this.tickCount % 5 == 0) {
            this.updateShellCountData();
        }
    }

    public void updateShellCountData() {
        int total = 0;
        for (int i = 0; i < 4; i++) {
            ItemStack s = this.tankInventory.getItem(i);
            if (isMainShellItem(s)) {
                total += s.getCount();
            }
        }
        this.entityData.set(DATA_SHELL_COUNT, total);
    }

    private void tickEnemyAI() {
        // Find nearest target: another tank with a player driver, a player, or a Warden/Monster
        LivingEntity target = null;
        double bestDistSq = 48.0D * 48.0D;

        List<T72TankEntity> tanks = this.level().getEntitiesOfClass(T72TankEntity.class, this.getBoundingBox().inflate(48.0D),
                t -> t != this && t.isAlive() && (t.getControllingPassenger() instanceof Player || !t.isEnemyAI()));
        for (T72TankEntity t : tanks) {
            double d = this.distanceToSqr(t);
            if (d < bestDistSq) {
                bestDistSq = d;
                target = t;
            }
        }

        if (target == null) {
            List<Player> players = this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(42.0D),
                    p -> p.isAlive() && !p.isCreative() && !p.isSpectator());
            for (Player p : players) {
                double d = this.distanceToSqr(p);
                if (d < bestDistSq) {
                    bestDistSq = d;
                    target = p;
                }
            }
        }

        if (target == null) {
            List<Warden> wardens = this.level().getEntitiesOfClass(Warden.class, this.getBoundingBox().inflate(42.0D), LivingEntity::isAlive);
            if (!wardens.isEmpty()) target = wardens.get(0);
        }

        if (target == null) return;

        double dx = target.getX() - this.getX();
        double dy = (target.getY() + target.getBbHeight() * 0.5D) - (this.getY() + 1.4D);
        double dz = target.getZ() - this.getZ();
        double horizDist = Math.hypot(dx, dz);

        float desiredYaw = (float) (Mth.atan2(-dx, dz) * (180.0D / Math.PI));
        float desiredPitch = (float) (-Mth.atan2(dy, horizDist) * (180.0D / Math.PI));

        TankType type = this.getTankType();

        // Rotate turret if not broken
        if (!this.isTurretBroken()) {
            float diffYaw = Mth.wrapDegrees(desiredYaw - this.getTurretYaw());
            float step = Mth.clamp(diffYaw, -type.turretTurnSpeed * 0.65F, type.turretTurnSpeed * 0.65F);
            this.setTurretYaw(Mth.wrapDegrees(this.getTurretYaw() + step));
            this.setBarrelPitch(Mth.clamp(desiredPitch, type.minBarrelPitch, type.maxBarrelPitch));
        }

        // Maneuver hull if tracks & fuel are available
        if (!this.isTracksBroken() && this.getFuel() > 0) {
            float hullDiff = Mth.wrapDegrees(desiredYaw - this.getYRot());
            this.burnFuel();
            this.setYRot(this.getYRot() + Mth.clamp(hullDiff, -type.hullTurnSpeed * 0.7F, type.hullTurnSpeed * 0.7F));
            if (horizDist > 16.0D) {
                double rad = Math.toRadians(this.getYRot());
                float moveSpd = this.isEngineBroken() ? 0.04F : type.driveSpeed * 0.45F;
                this.setDeltaMovement(this.getDeltaMovement().add(-Math.sin(rad) * moveSpd * 0.2D, 0.0D, Math.cos(rad) * moveSpd * 0.2D));
            }
        }

        // Fire main cannon if aimed within 8 degrees
        if (Math.abs(Mth.wrapDegrees(desiredYaw - this.getTurretYaw())) < 8.0F && this.getReloadTicks() == 0) {
            this.fireMainCannon(null);
        }
    }

    @Override
    public void travel(Vec3 travelVector) {
        if (this.isAlive() && this.isVehicle() && this.getControllingPassenger() instanceof Player player) {
            TankType type = this.getTankType();

            boolean hasInput = Math.abs(player.xxa) > 0.01F || Math.abs(player.zza) > 0.01F;

            if (this.bmpCabinOpen()) {
                this.setDeltaMovement(this.getDeltaMovement().multiply(0,1,0));
                super.travel(new Vec3(0,travelVector.y,0));
                return;
            }

            // Check broken tracks
            if (this.isTracksBroken()) {
                if (hasInput && !this.level().isClientSide && this.tickCount % 20 == 0) {
                    player.displayClientMessage(Component.literal("⚠ Гусеница сбита! Танк обездвижен (нажмите R для ремонта ЗИП).")
                            .withStyle(ChatFormatting.RED), true);
                }
                this.setDeltaMovement(this.getDeltaMovement().multiply(0, 1, 0));
                super.travel(new Vec3(0.0D, travelVector.y, 0.0D));
                return;
            }

            // Check fuel
            if (this.getFuel() <= 0 && !player.getAbilities().instabuild) {
                if (hasInput && !this.level().isClientSide && this.tickCount % 20 == 0) {
                    player.displayClientMessage(Component.literal("⛽ Топливный бак пуст! Загрузите канистру или уголь в инвентарь танка (клавиша I).")
                            .withStyle(ChatFormatting.GOLD), true);
                }
                this.setDeltaMovement(this.getDeltaMovement().multiply(0, 1, 0));
                super.travel(new Vec3(0.0D, travelVector.y, 0.0D));
                return;
            }

            float enginePenalty = this.isEngineBroken() ? 0.22F : 1.0F;

            float turnInput = -player.xxa;
            this.setYRot(this.getYRot() + turnInput * type.hullTurnSpeed * enginePenalty);
            this.yBodyRot = this.getYRot();
            this.yHeadRot = this.getYRot();

            float forwardInput = player.zza;
            if (forwardInput < 0.0F) {
                forwardInput *= type.reverseFactor;
            }

            // BMP-3 amphibious mode: modest water propulsion and buoyancy.
            // Use the same driver controls; damaged tracks/engine still restrict motion.
            if (type == TankType.BMP3 && this.isInWater()) {
                float waterSpeed = type.driveSpeed * 0.40F * enginePenalty;
                this.setSpeed(waterSpeed);
                double heading = Math.toRadians(this.getYRot());
                double thrust = forwardInput * waterSpeed * 0.12D;
                Vec3 velocity = this.getDeltaMovement();
                double buoyancy = Mth.clamp((this.getFluidHeight(net.minecraft.tags.FluidTags.WATER) - 0.75D) * 0.06D,
                        -0.035D, 0.045D);
                this.setDeltaMovement(velocity.x * 0.86D - Math.sin(heading) * thrust,
                        Mth.clamp(velocity.y * 0.82D + buoyancy, -0.08D, 0.08D),
                        velocity.z * 0.86D + Math.cos(heading) * thrust);
                this.move(MoverType.SELF, this.getDeltaMovement());
                return;
            }
            this.setSpeed(type.driveSpeed * enginePenalty);
            super.travel(new Vec3(0.0D, travelVector.y, forwardInput));
            return;
        }
        super.travel(travelVector);
    }

    private void burnFuel() {
        if (this.isTracksBroken() || this.getFuel() <= 0) return;
        int interval = Math.max(4, Math.round(14.0F / this.getTankType().fuelConsumptionMult));
        if (this.isEngineBroken()) interval /= 2;
        if (++this.fuelBurnTicker >= interval) {
            this.fuelBurnTicker = 0;
            this.setFuel(this.getFuel() - 1);
        }
    }

    private Vec3 cannonPivot() {
        return TankGeometry.barrelPivot(this.position(),this.getYRot(),this.getTurretYaw(),this.getTankType());
    }

    public void fireMainCannon(@Nullable Player shooter) {
        if (this.level().isClientSide || !this.isAlive() || this.getReloadTicks() > 0) return;
        if (this.isGunBroken()) {
            if (shooter != null) shooter.displayClientMessage(Component.translatable("message.t72mod.gun_broken"), true);
            return;
        }

        TankType type = this.getTankType();

        if (shooter != null && !shooter.getAbilities().instabuild) {
            ItemStack foundAmmo = ItemStack.EMPTY;
            // 1. Check Tank Inventory Slots 0..3 first
            for (int i = 0; i < 4; i++) {
                ItemStack s = this.tankInventory.getItem(i);
                if (isCompatibleShell(s, type)) {
                    foundAmmo = s;
                    break;
                }
            }
            // 2. Fallback to shooter's inventory
            if (foundAmmo.isEmpty()) {
                for (int i = 0; i < shooter.getInventory().getContainerSize(); i++) {
                    ItemStack s = shooter.getInventory().getItem(i);
                    if (isCompatibleShell(s, type)) {
                        foundAmmo = s;
                        break;
                    }
                }
            }
            if (foundAmmo.isEmpty()) {
                shooter.displayClientMessage(Component.literal("Нет подходящих снарядов для " + type.cannonTitle + ". Загрузите боеприпасы в танк (I).")
                        .withStyle(ChatFormatting.RED), true);
                this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 1.0F, 0.8F);
                return;
            }
            foundAmmo.shrink(1);
            this.updateShellCountData();
        }

        Vec3 barrelDir = Vec3.directionFromRotation(this.getBarrelPitch(), this.getTurretYaw());
        Vec3 origin = this.cannonPivot();
        Vec3 end = origin.add(barrelDir.scale(TankGeometry.barrelLength(type)+.12));
        Vec3 turretCenter = this.position().add(0, origin.y - this.getY(), 0);
        HitResult clearance = this.level().clip(new ClipContext(turretCenter, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        Vec3 muzzlePos = clearance.getType() == HitResult.Type.MISS ? end : turretCenter;

        TankShellEntity shell = new TankShellEntity(T72Mod.TANK_SHELL.get(), this.level());
        if (shooter != null) {
            shell.setOwner(shooter);
        } else {
            shell.setOwner(this);
        }
        shell.configureShell(this, type.shellDirectDamage, type.shellExplosionRadius, type.shellGravity);
        shell.setPos(muzzlePos.x, muzzlePos.y, muzzlePos.z);
        shell.shoot(barrelDir.x, barrelDir.y, barrelDir.z, type.shellSpeed, 0.0F);
        this.level().addFreshEntity(shell);
        if (clearance.getType() != HitResult.Type.MISS) shell.onHit(clearance);

        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.FLASH, muzzlePos.x, muzzlePos.y, muzzlePos.z, 2, 0, 0, 0, 0);
            serverLevel.sendParticles(ParticleTypes.EXPLOSION, muzzlePos.x, muzzlePos.y, muzzlePos.z, 4, 0.2, 0.2, 0.2, 0.05);
            serverLevel.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, muzzlePos.x, muzzlePos.y, muzzlePos.z, 18, 0.35, 0.35, 0.35, 0.04);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 3.2F,
                type == TankType.BMP3 ? 1.24F : 1.0F);

        this.push(-barrelDir.x * 0.32D, 0.04D, -barrelDir.z * 0.32D);

        this.setRecoilTicks(10);
        int reload = this.isTurretBroken() ? (int) (type.reloadTicks * 1.5F) : type.reloadTicks;
        this.setReloadTicks(reload);
    }

    public void fireCoaxialMG(Player shooter) {
        if (this.level().isClientSide || !this.isAlive() || this.mgCooldown > 0) return;
        this.mgCooldown = 3;
        if (this.isGunBroken()) {
            if (this.tickCount % 12 < 3) shooter.displayClientMessage(Component.translatable("message.t72mod.gun_broken"), true);
            return;
        }

        // Check MG ammo limit
        if (!shooter.getAbilities().instabuild) {
            if (this.getMgAmmo() <= 0) {
                this.tickSupplyAutoLoad();
            }
            if (this.getMgAmmo() <= 0) {
                if (this.tickCount % 9 == 0) {
                    shooter.displayClientMessage(Component.literal("Пулемётная лента пуста! Положите короб 7.62мм в слот пулемёта (клавиша I).")
                            .withStyle(ChatFormatting.RED), true);
                    this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.9F, 1.2F);
                }
                return;
            }
            this.setMgAmmo(this.getMgAmmo() - 1);
        }

        Vec3 dir = Vec3.directionFromRotation(this.getBarrelPitch(), this.getTurretYaw());
        Vec3 start = TankGeometry.coaxMuzzle(this.cannonPivot(),this.getTurretYaw(),this.getBarrelPitch(),this.getTankType());
        Vec3 end = this.level().clip(new ClipContext(start, start.add(dir.scale(48)),
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this)).getLocation();
        var hit = ProjectileUtil.getEntityHitResult(this.level(), this, start, end,
                new AABB(start, end).inflate(1), entity -> entity instanceof LivingEntity
                        && entity != shooter && !this.hasPassenger(entity) && entity.isPickable());
        if (hit != null) {
            hit.getEntity().hurt(this.damageSources().mobProjectile(this, shooter), 6.5F);
            end = hit.getLocation();
        }
        if (this.level() instanceof ServerLevel serverLevel) {
            for (int i = 2; i < start.distanceTo(end); i += 4) {
                Vec3 particle = start.add(dir.scale(i));
                serverLevel.sendParticles(ParticleTypes.CRIT, particle.x, particle.y, particle.z, 1, 0, 0, 0, 0);
            }
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_LAUNCH, SoundSource.PLAYERS, .91F, 1.18F);
    }

    public void deploySmokeScreen() {
        if (this.level().isClientSide || this.getSmokeCooldown() > 0) return;

        float yawRad = (float) Math.toRadians(this.getTurretYaw());
        Vec3 forward = new Vec3(-Mth.sin(yawRad), 0.2D, Mth.cos(yawRad)).normalize();
        Vec3 smokeCenter = this.position().add(forward.scale(8.5D));

        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE,
                    smokeCenter.x, smokeCenter.y + 1.5D, smokeCenter.z,
                    120, 3.8D, 2.0D, 3.8D, 0.01D);
            serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE,
                    smokeCenter.x, smokeCenter.y + 1.0D, smokeCenter.z,
                    60, 3.0D, 1.5D, 3.0D, 0.02D);
        }

        List<Monster> monsters = this.level().getEntitiesOfClass(Monster.class, this.getBoundingBox().inflate(24.0D));
        for (Monster m : monsters) {
            m.setTarget(null);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_LAUNCH, SoundSource.PLAYERS, 2.0F, 0.7F);
        this.setSmokeCooldown(300);
    }

    public int resolveModuleAtPosition(@Nullable Vec3 hitPos) {
        if (hitPos == null) return MODULE_HULL_FRONT;
        double relY = hitPos.y - this.getY();
        if (relY >= TankGeometry.hullTop(this.getTankType())-.08) return MODULE_TURRET;

        double rad = Math.toRadians(this.getYRot());
        double fx = -Math.sin(rad);
        double fz = Math.cos(rad);
        double dx = hitPos.x - this.getX();
        double dz = hitPos.z - this.getZ();
        double forwardProj = dx * fx + dz * fz;

        if (forwardProj < -0.85D) {
            return MODULE_ENGINE;
        } else if (forwardProj > 0.95D) {
            return MODULE_HULL_FRONT;
        }
        return MODULE_TRACKS;
    }

    public void onDirectShellHit(int moduleType, Vec3 hitPos, TankShellEntity shell, float rawShellDamage) {
        if (this.level().isClientSide || !this.isAlive()) return;
        DamageSource src = this.damageSources().thrown(shell, shell.getOwner());
        this.applyModularTankDamage(moduleType, src, rawShellDamage, true);
    }

    @Override
    public boolean hurtPart(int index, DamageSource source, Vec3 impact, float amount) {
        if (index >= BMP_INTERIOR_START) return this.hurt(source, amount);
        if (this.level().isClientSide || !this.isAlive()) return false;
        int module;
        if (index < TankGeometry.TRACK_PARTS) module = MODULE_TRACKS;
        else if (index < TankGeometry.FIRST_TURRET_PART) module = this.hullSection(index).z() < 0 ? MODULE_ENGINE : MODULE_HULL_FRONT;
        else if (index < TankGeometry.FIRST_BARREL_PART) module = MODULE_TURRET;
        else module = MODULE_GUN;
        return this.applyModularTankDamage(module, source, amount,
                source.getDirectEntity() instanceof TankShellEntity && !source.is(DamageTypeTags.IS_EXPLOSION));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide || !this.isAlive()) return false;
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurt(source, amount);
        }
        int module = this.resolveModuleAtPosition(source.getSourcePosition());
        return this.applyModularTankDamage(module, source, amount, false);
    }

    private boolean applyModularTankDamage(int moduleType, DamageSource source, float amount, boolean isDirectTankShell) {
        if (amount <= 0 || !Float.isFinite(amount)) return false;
        if (!isDirectTankShell && source.is(T72Mod.TACZ_BULLETS)) {
            // TaCZ sends armor-piercing and normal fractions separately. Both go through the same armor rules.
            if (moduleType != MODULE_HULL_FRONT && this.isAlive()) {
                int wear = (int) (Math.min(30, amount) * (moduleType == MODULE_GUN ? 0.5F : 0.23F));
                if (wear > 0) this.damageSpecificModule(moduleType, wear);
            }
            return super.hurt(source, Math.min(amount, 35) * (moduleType == MODULE_HULL_FRONT ? 0.025F : 0.085F));
        }

        // Ignore self-damage from own cannon muzzle blast
        if (source.getDirectEntity() instanceof TankShellEntity shell && shell.getOwner() != null
                && this.isPassengerOfSameVehicle(shell.getOwner())) {
            return false;
        }

        // Complete immunity to small arms, arrows, fire, fall, drowning, cactus
        if (!isDirectTankShell && (source.getDirectEntity() instanceof AbstractArrow
                || source.is(DamageTypeTags.IS_FIRE)
                || source.is(DamageTypeTags.IS_FALL)
                || source.is(DamageTypeTags.IS_DROWNING)
                || source.is(DamageTypes.CACTUS)
                || source.is(DamageTypes.SWEET_BERRY_BUSH)
                || source.is(DamageTypes.IN_WALL))) {
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.NEUTRAL, 0.5F, 1.8F);
            return false;
        }

        Entity attacker = source.getEntity();
        boolean isWarden = attacker instanceof Warden || source.is(DamageTypes.SONIC_BOOM);
        boolean isHeavyBossOrGolem = attacker instanceof WitherBoss
                || attacker instanceof EnderDragon
                || attacker instanceof Ravager
                || attacker instanceof IronGolem;
        boolean isExplosion = source.is(DamageTypeTags.IS_EXPLOSION);

        // Weak attacks from ordinary mobs bounce off tank armor
        if (!isDirectTankShell && !isWarden && !isHeavyBossOrGolem && !isExplosion && amount < 14.0F) {
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.NEUTRAL, 0.5F, 1.75F);
            return false;
        }

        float effectiveHullDamage = amount;
        int moduleDamage = 0;

        if (isDirectTankShell) {
            effectiveHullDamage = amount < 16 ? amount * 0.18F : amount;
            moduleDamage = (int) Mth.clamp(amount < 16 ? amount * 0.3F : amount * 1.35F, 0, 100);
        } else if (isWarden) {
            effectiveHullDamage = Math.max(amount * 2.2F, 65.0F);
            moduleDamage = 85;
            // Warden Sonic Boom or melee hits turret or tracks heavily
            if (source.is(DamageTypes.SONIC_BOOM)) {
                moduleType = MODULE_TURRET;
            }
        } else if (isExplosion) {
            // Avoid double-counting vanilla explosion after onDirectShellHit
            if (source.getDirectEntity() instanceof TankShellEntity shell && shell.excludeFromBlast(this)) return false;
            effectiveHullDamage = amount * 0.85F;
            moduleDamage = (int) Math.min(100, amount * 1.8F);
        } else {
            effectiveHullDamage = amount * 0.55F;
            moduleDamage = (int) Math.min(75, amount * 1.4F);
        }

        // Frontal armor & Leopard 2A6 wedge turret armor reduction
        if (moduleType == MODULE_HULL_FRONT) {
            effectiveHullDamage *= 0.70F;
        } else if (moduleType == MODULE_TURRET && this.getTankType() == TankType.LEOPARD2) {
            effectiveHullDamage *= 0.78F;
        }

        if (isDirectTankShell) this.invulnerableTime = 0;
        boolean hurtResult = super.hurt(source, effectiveHullDamage);
        if (hurtResult && this.isAlive() && moduleDamage > 0) {
            this.damageSpecificModule(moduleType, moduleDamage);
        }
        this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_GOLEM_HURT, SoundSource.NEUTRAL, 1.4F, 0.65F);
        return hurtResult;
    }

    private void damageSpecificModule(int moduleType, int dmg) {
        Player driver = this.getControllingPassenger() instanceof Player p ? p : null;

        if (moduleType == MODULE_GUN) {
            int previous = this.getGunHealth();
            this.setGunHealth(previous - dmg);
            if (previous > 0 && this.isGunBroken()) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.PLAYERS, 1.4F, 0.83F);
                if (driver != null) driver.displayClientMessage(Component.translatable("message.t72mod.gun_broken"), true);
            }
        } else if (moduleType == MODULE_TURRET) {
            int prev = this.getTurretHealth();
            int next = Math.max(0, prev - dmg);
            this.setTurretHealth(next);
            if (prev > 0 && next == 0) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.PLAYERS, 1.5F, 0.75F);
                if (driver != null) {
                    driver.displayClientMessage(Component.literal("💥 КРИТ БАШНИ: Привод наведения выбит! Башня заклинена (нажмите R для ремонта)!")
                            .withStyle(ChatFormatting.RED, ChatFormatting.BOLD), true);
                }
            }
        } else if (moduleType == MODULE_TRACKS) {
            int prev = this.getTracksHealth();
            int next = Math.max(0, prev - dmg);
            this.setTracksHealth(next);
            if (prev > 0 && next == 0) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.PLAYERS, 1.5F, 0.6F);
                if (driver != null) {
                    driver.displayClientMessage(Component.literal("💥 СБИТА ГУСЕНИЦА: Ходовая часть разрушена! Танк обездвижен (нажмите R для ремонта)!")
                            .withStyle(ChatFormatting.RED, ChatFormatting.BOLD), true);
                }
            }
        } else if (moduleType == MODULE_ENGINE) {
            int prev = this.getEngineHealth();
            int next = Math.max(0, prev - dmg);
            this.setEngineHealth(next);
            if (prev > 0 && next == 0) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.2F, 0.9F);
                if (driver != null) {
                    driver.displayClientMessage(Component.literal("💥 ПОЖАР МТО: Двигатель пробит! Критическая потеря тяги (нажмите R для ремонта)!")
                            .withStyle(ChatFormatting.RED, ChatFormatting.BOLD), true);
                }
            }
        } else if (moduleType == MODULE_HULL_FRONT && dmg >= 85) {
            // Heavy hit to lower glacis can also damage tracks
            int prev = this.getTracksHealth();
            int next = Math.max(0, prev - dmg / 2);
            this.setTracksHealth(next);
        }
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide) {
            // Eject passengers before explosion and drop tank inventory
            this.ejectPassengers();
            Containers.dropContents(this.level(), this.blockPosition(), this.tankInventory);
            if (this.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.EXPLOSION_EMITTER, this.getX(), this.getY() + 1.0D, this.getZ(), 3, 0.5, 0.5, 0.5, 0.0);
                serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.2D, this.getZ(), 45, 1.2, 0.8, 1.2, 0.05);
            }
            this.level().playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.NEUTRAL, 3.0F, 0.6F);
        }
        for (VehiclePartEntity part : this.subParts) {
            if (part != null) part.discard();
        }
        super.die(source);
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }

    public TankType getTankType() {
        return TankType.byOrdinal(this.entityData.get(DATA_TANK_TYPE));
    }

    public void setTankType(TankType type) {
        this.entityData.set(DATA_TANK_TYPE, type.ordinal());
    }

    public float getTurretYaw() { return this.entityData.get(DATA_TURRET_YAW); }
    public void setTurretYaw(float yaw) { this.entityData.set(DATA_TURRET_YAW, yaw); }

    public float getBarrelPitch() { return this.entityData.get(DATA_BARREL_PITCH); }
    public void setBarrelPitch(float pitch) { this.entityData.set(DATA_BARREL_PITCH, pitch); }

    public boolean isHatchOpen() { return this.entityData.get(DATA_HATCH_OPEN); }
    public void setHatchOpen(boolean open) { this.entityData.set(DATA_HATCH_OPEN, open); }

    public int getReloadTicks() { return this.entityData.get(DATA_RELOAD_TICKS); }
    public void setReloadTicks(int ticks) { this.entityData.set(DATA_RELOAD_TICKS, ticks); }

    public int getRecoilTicks() { return this.entityData.get(DATA_RECOIL_TICKS); }
    public void setRecoilTicks(int ticks) { this.entityData.set(DATA_RECOIL_TICKS, ticks); }

    public int getSmokeCooldown() { return this.entityData.get(DATA_SMOKE_COOLDOWN); }
    public void setSmokeCooldown(int ticks) { this.entityData.set(DATA_SMOKE_COOLDOWN, ticks); }

    public int getFuel() { return this.entityData.get(DATA_FUEL); }
    public void setFuel(int fuel) { this.entityData.set(DATA_FUEL, Mth.clamp(fuel, 0, MAX_FUEL)); }

    public int getMgAmmo() { return this.entityData.get(DATA_MG_AMMO); }
    public void setMgAmmo(int ammo) { this.entityData.set(DATA_MG_AMMO, Mth.clamp(ammo, 0, MAX_MG_AMMO)); }

    public int getShellCount() { return this.entityData.get(DATA_SHELL_COUNT); }

    public int getTurretHealth() { return this.entityData.get(DATA_TURRET_HEALTH); }
    public void setTurretHealth(int hp) { this.entityData.set(DATA_TURRET_HEALTH, Mth.clamp(hp, 0, MAX_MODULE_HEALTH)); }
    public boolean isTurretBroken() { return this.getTurretHealth() <= 0; }

    public int getTracksHealth() { return this.entityData.get(DATA_TRACKS_HEALTH); }
    public void setTracksHealth(int hp) { this.entityData.set(DATA_TRACKS_HEALTH, Mth.clamp(hp, 0, MAX_MODULE_HEALTH)); }
    public boolean isTracksBroken() { return this.getTracksHealth() <= 0; }

    public int getEngineHealth() { return this.entityData.get(DATA_ENGINE_HEALTH); }
    public void setEngineHealth(int hp) { this.entityData.set(DATA_ENGINE_HEALTH, Mth.clamp(hp, 0, MAX_MODULE_HEALTH)); }
    public boolean isEngineBroken() { return this.getEngineHealth() <= 0; }

    public int getGunHealth() { return this.entityData.get(DATA_GUN_HEALTH); }
    public void setGunHealth(int hp) { this.entityData.set(DATA_GUN_HEALTH, Mth.clamp(hp, 0, MAX_MODULE_HEALTH)); }
    public boolean isGunBroken() { return this.getGunHealth() == 0; }

    public boolean isEnemyAI() { return this.entityData.get(DATA_ENEMY_AI); }
    public void setEnemyAI(boolean ai) { this.entityData.set(DATA_ENEMY_AI, ai); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("TurretYaw", getTurretYaw());
        tag.putFloat("BarrelPitch", getBarrelPitch());
        tag.putBoolean("HatchOpen", isHatchOpen());
        tag.putInt("TankType", getTankType().ordinal());
        tag.putInt("Fuel", getFuel());
        tag.putInt("MgAmmo", getMgAmmo());
        tag.putInt("TurretHealth", getTurretHealth());
        tag.putInt("TracksHealth", getTracksHealth());
        tag.putInt("EngineHealth", getEngineHealth());
        tag.putInt("GunHealth", getGunHealth());
        tag.putBoolean("EnemyAI", isEnemyAI());
        tag.putBoolean("StarterLoaded", this.starterLoadoutInitialized);

        ListTag itemsTag = new ListTag();
        for (int i = 0; i < this.tankInventory.getContainerSize(); i++) {
            ItemStack stack = this.tankInventory.getItem(i);
            if (!stack.isEmpty()) {
                CompoundTag slotTag = new CompoundTag();
                slotTag.putByte("Slot", (byte) i);
                stack.save(slotTag);
                itemsTag.add(slotTag);
            }
        }
        tag.put("TankItems", itemsTag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("TurretYaw")) setTurretYaw(tag.getFloat("TurretYaw"));
        if (tag.contains("BarrelPitch")) setBarrelPitch(tag.getFloat("BarrelPitch"));
        if (tag.contains("HatchOpen")) setHatchOpen(tag.getBoolean("HatchOpen"));
        if (tag.contains("TankType")) setTankType(TankType.byOrdinal(tag.getInt("TankType")));
        if (tag.contains("Fuel")) setFuel(tag.getInt("Fuel"));
        if (tag.contains("MgAmmo")) setMgAmmo(tag.getInt("MgAmmo"));
        if (tag.contains("TurretHealth")) setTurretHealth(tag.getInt("TurretHealth"));
        if (tag.contains("TracksHealth")) setTracksHealth(tag.getInt("TracksHealth"));
        if (tag.contains("EngineHealth")) setEngineHealth(tag.getInt("EngineHealth"));
        if (tag.contains("GunHealth")) setGunHealth(tag.getInt("GunHealth"));
        if (tag.contains("EnemyAI")) setEnemyAI(tag.getBoolean("EnemyAI"));
        if (tag.contains("StarterLoaded")) this.starterLoadoutInitialized = tag.getBoolean("StarterLoaded");

        if (tag.contains("TankItems", Tag.TAG_LIST)) {
            this.tankInventory.clearContent();
            ListTag itemsTag = tag.getList("TankItems", Tag.TAG_COMPOUND);
            for (int i = 0; i < itemsTag.size(); i++) {
                CompoundTag slotTag = itemsTag.getCompound(i);
                int slot = slotTag.getByte("Slot") & 255;
                if (slot < this.tankInventory.getContainerSize()) {
                    this.tankInventory.setItem(slot, ItemStack.of(slotTag));
                }
            }
            this.updateShellCountData();
        }
    }
}
