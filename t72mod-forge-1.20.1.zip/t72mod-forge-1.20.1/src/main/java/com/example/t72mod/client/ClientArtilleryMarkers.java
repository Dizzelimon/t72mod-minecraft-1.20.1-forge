package com.example.t72mod.client;

import com.example.t72mod.entity.ArtilleryMarkerStore;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/** Client-side mirror of the current player's saved artillery markers per dimension. */
public final class ClientArtilleryMarkers {
    private static final ArtilleryMarkerStore STORE = new ArtilleryMarkerStore();

    private ClientArtilleryMarkers() {}

    public static void update(ResourceLocation dimension, List<ArtilleryMarkerStore.Marker> markers) {
        STORE.setMarkers(dimension, markers);
    }

    public static List<ArtilleryMarkerStore.Marker> list(ResourceLocation dimension) {
        return STORE.list(dimension);
    }

    public static void clear() {
        STORE.readNbt(null);
    }
}
