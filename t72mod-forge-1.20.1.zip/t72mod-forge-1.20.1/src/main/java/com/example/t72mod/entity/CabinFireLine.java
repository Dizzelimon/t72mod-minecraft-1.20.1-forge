package com.example.t72mod.entity;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

final class CabinFireLine {
    private CabinFireLine() {}

    static boolean throughOpening(AABB shell, Vec3 outside, Vec3 inside, int axis, double plane,
                                  double spanStart, double spanEnd, double minY, double maxY) {
        if (shell.contains(outside)) return false;
        var hit = shell.clip(outside, inside);
        if (hit.isEmpty()) return false;
        Vec3 entry = hit.get();
        double direction = axis == 0 ? entry.x : entry.z;
        double across = axis == 0 ? entry.z : entry.x;
        return Math.abs(direction - plane) < .001 && across >= spanStart && across <= spanEnd
                && entry.y >= minY && entry.y <= maxY;
    }
}
