package com.example.t72mod.item;

import com.example.t72mod.T72Mod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public final class GunStandKit extends Item {
    public GunStandKit(Properties properties) { super(properties); }

    @Override public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        Player player = ctx.getPlayer();
        if (player == null || !player.mayBuild()) return InteractionResult.FAIL;
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        var stand = T72Mod.GUN_STAND.get().create(level);
        if (stand == null) return InteractionResult.FAIL;
        stand.moveTo(pos.getX() + .5, pos.getY(), pos.getZ() + .5, player.getYRot(), 0F);
        stand.setOwner(player);
        if (!level.noCollision(stand, stand.getBoundingBox()) || !level.addFreshEntity(stand)) return InteractionResult.FAIL;
        if (!player.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }
}
