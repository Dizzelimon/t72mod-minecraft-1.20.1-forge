package com.example.t72mod.client.model;

import com.example.t72mod.entity.TankGeometry;
import com.example.t72mod.entity.TankType;
import net.minecraft.world.phys.Vec3;

public final class TankDetailsModel {
    private static final int STEEL=0x333a36, HIGHLIGHT=0x515b54, DARK=0x252b27;
    public final VehicleMesh coax = new VehicleMesh();
    public final VehicleMesh roofGun = new VehicleMesh();
    public final VehicleMesh tracks = new VehicleMesh();
    public final VehicleMesh engine = new VehicleMesh();
    public final VehicleMesh turret = new VehicleMesh();

    public TankDetailsModel(TankType type) {
        this.coax.box(-.084,-.072,-.12,.084,.074,.25,STEEL);
        this.coax.tube(new Vec3(0,0,.20),new Vec3(0,0,.77),.058,.043,10,HIGHLIGHT);
        this.coax.tube(new Vec3(0,0,.70),new Vec3(0,0,.89),.062,.058,10,STEEL);
        this.coax.tube(new Vec3(0,0,.891),new Vec3(0,0,.9),.035,.035,8,DARK);
        double x = type == TankType.ABRAMS ? -.76 : .76;
        double y=TankGeometry.turretTop(type);
        double z=type==TankType.LEOPARD2 ? .47 : .23;
        roofGun.tube(new Vec3(x,y-.05,z),new Vec3(x,y+.27,z),.10,.064,10,STEEL);
        roofGun.box(x-.111,y+.21,z-.42,x+.111,y+.40,z+.29,HIGHLIGHT);
        roofGun.box(x+.087,y+.15,z-.17,x+.315,y+.36,z+.24,0x495247);
        roofGun.box(x-.061,y+.214,z-.65,x+.061,y+.343,z-.40,STEEL);
        roofGun.tube(new Vec3(x,y+.305,z+.18),new Vec3(x,y+.305,z+1.005),.053,.039,10,STEEL);
        roofGun.tube(new Vec3(x,y+.305,z+.95),new Vec3(x,y+.305,z+1.10),.071,.058,10,HIGHLIGHT);
        roofGun.box(x-.02,y+.356,z+.84,x+.02,y+.432,z+.895,DARK);

        for (int side : new int[]{-1,1}) {
            double edge=side*(TankGeometry.trackCenter(type)+TankGeometry.trackWidth(type)*.49);
            double length=TankGeometry.trackLength(type);
            for(int i=0;i<4;i++) {
                double zz=length*(-.47+i*.14);
                tracks.tube(new Vec3(edge+side*.07,.36,zz),new Vec3(edge+side*.15,.17,zz+.30),.093,.075,6,0x605849);
                tracks.tube(new Vec3(edge+side*.13,.20,zz+.20),new Vec3(edge+side*.14,.26,zz+.42),.093,.073,6,DARK);
            }
        }
        double zRear = -TankGeometry.trackLength(type)*.40;
        double yHull = TankGeometry.hullTop(type);
        double engineY = type == TankType.BMP3 ? .95 : yHull;
        double engineZ = type == TankType.BMP3 ? 2.56 : zRear;
        engine.box(-.79,engineY-.04,engineZ-.28,.79,engineY+.073,engineZ+.39,0x272722);
        for(int i=0;i<7;i++) {
            double stripe=-.63+i*.21;
            engine.box(stripe,engineY+.071,engineZ-.27,stripe+.071,engineY+.091,engineZ+.37,0x655445);
        }
        double face=TankGeometry.turretWidth(type)*.51;
        double turretY=TankGeometry.turretTop(type);
        turret.tube(new Vec3(face,turretY-.33,-.14),new Vec3(face+.07,turretY-.25,.48),.116,.082,6,0x292d27);
        turret.tube(new Vec3(face+.08,turretY-.28,.11),new Vec3(face+.12,turretY-.14,.39),.031,.013,5,0x9e6b49);
    }
}
