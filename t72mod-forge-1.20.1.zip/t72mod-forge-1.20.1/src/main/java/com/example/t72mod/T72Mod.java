package com.example.t72mod;

import com.example.t72mod.sound.VehicleSounds;
import com.example.t72mod.block.AntiTankMineBlock;
import com.example.t72mod.block.FieldObstacleBlock;
import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.FieldVehicleEntity;
import com.example.t72mod.entity.HelicopterType;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.VehiclePartEntity;
import com.example.t72mod.entity.TankShellEntity;
import com.example.t72mod.entity.TankType;
import com.example.t72mod.inventory.TankInventoryMenu;
import com.example.t72mod.network.ModMessages;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Consumer;
import java.util.function.Supplier;

@Mod(T72Mod.MODID)
public class T72Mod {
    public static final String MODID = "t72mod";
    public static final net.minecraft.tags.TagKey<net.minecraft.world.level.block.Block> TANK_CRUSHABLE =
            net.minecraft.tags.BlockTags.create(new net.minecraft.resources.ResourceLocation(MODID, "tank_crushable"));

    public static final TagKey<DamageType> TACZ_BULLETS =
            TagKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(MODID, "tacz_bullets"));

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final RegistryObject<Block> ANTI_TANK_MINE = BLOCKS.register("anti_tank_mine",
            () -> new AntiTankMineBlock(BlockBehaviour.Properties.of()
                    .strength(1.25F).noCollission().noOcclusion().sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(AntiTankMineBlock.ARMED) ? 2 : 0)));

    public static final RegistryObject<Block> DRAGON_TOOTH = BLOCKS.register("dragon_tooth",
            () -> new FieldObstacleBlock(BlockBehaviour.Properties.of().strength(4, 9).requiresCorrectToolForDrops()
                    .sound(net.minecraft.world.level.block.SoundType.STONE).noOcclusion(), FieldObstacleBlock.TOOTH));
    public static final RegistryObject<Block> SANDBAGS = BLOCKS.register("sandbag_barricade",
            () -> new FieldObstacleBlock(BlockBehaviour.Properties.of().strength(1.2F, 2.5F)
                    .sound(net.minecraft.world.level.block.SoundType.WOOL).noOcclusion(), FieldObstacleBlock.SANDBAGS));
    public static final RegistryObject<Block> ROAD_BARRIER = BLOCKS.register("road_barrier",
            () -> new FieldObstacleBlock(BlockBehaviour.Properties.of().strength(3, 7).requiresCorrectToolForDrops()
                    .sound(net.minecraft.world.level.block.SoundType.STONE).noOcclusion(), FieldObstacleBlock.BARRIER));

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    // 3 Tank Entity Types (central hull sized 1.75x1.40 so surrounding 0.85-high track/front/rear parts act as steps)
    public static final RegistryObject<EntityType<T72TankEntity>> T72_TANK = ENTITIES.register("t72_tank",
            () -> EntityType.Builder.<T72TankEntity>of(T72TankEntity::new, MobCategory.MISC)
                    .sized(2.04F, 1.28F)
                    .clientTrackingRange(12)
                    .updateInterval(1)
                    .fireImmune()
                    .build("t72_tank"));

    public static final RegistryObject<EntityType<T72TankEntity>> T90M_TANK = ENTITIES.register("t90m_tank",
            () -> EntityType.Builder.<T72TankEntity>of(T72TankEntity::new, MobCategory.MISC)
                    .sized(2.12F, 1.28F).clientTrackingRange(12).updateInterval(1)
                    .fireImmune().build("t90m_tank"));

    public static final RegistryObject<EntityType<T72TankEntity>> BMP3 = ENTITIES.register("bmp3",
            () -> EntityType.Builder.<T72TankEntity>of(T72TankEntity::new, MobCategory.MISC)
                    .sized(2.26F, 1.35F).clientTrackingRange(12).updateInterval(1)
                    .build("bmp3"));

    public static final RegistryObject<EntityType<T72TankEntity>> ABRAMS_TANK = ENTITIES.register("abrams_tank",
            () -> EntityType.Builder.<T72TankEntity>of(T72TankEntity::new, MobCategory.MISC)
                    .sized(2.18F, 1.28F)
                    .clientTrackingRange(12)
                    .updateInterval(1)
                    .fireImmune()
                    .build("abrams_tank"));

    public static final RegistryObject<EntityType<T72TankEntity>> LEOPARD2_TANK = ENTITIES.register("leopard2_tank",
            () -> EntityType.Builder.<T72TankEntity>of(T72TankEntity::new, MobCategory.MISC)
                    .sized(2.16F, 1.28F)
                    .clientTrackingRange(12)
                    .updateInterval(1)
                    .fireImmune()
                    .build("leopard2_tank"));

    public static final RegistryObject<EntityType<VehiclePartEntity>> TANK_PART = ENTITIES.register("tank_part",
            () -> EntityType.Builder.<VehiclePartEntity>of(VehiclePartEntity::new, MobCategory.MISC)
                    .sized(1.05F, 0.78F).noSave().noSummon().clientTrackingRange(12).updateInterval(10)
                    .build("tank_part"));

    public static final RegistryObject<EntityType<ArtilleryEntity>> ARTILLERY = ENTITIES.register("artillery",
            () -> EntityType.Builder.<ArtilleryEntity>of(ArtilleryEntity::new, MobCategory.MISC)
                    .sized(2.65F, 1.85F).clientTrackingRange(12).updateInterval(1).build("artillery"));

    public static final RegistryObject<EntityType<HelicopterEntity>> MI8 = registerHelicopter("mi8", 4.25F);
    public static final RegistryObject<EntityType<HelicopterEntity>> MI24 = registerHelicopter("mi24", 3.85F);

    public static final RegistryObject<EntityType<HelicopterEntity>> KA52 = registerHelicopter("ka52", 3.65F);
    public static final RegistryObject<EntityType<FieldVehicleEntity>> SCOUT_CAR = fieldVehicle("scout_car", 2.49F);
    public static final RegistryObject<EntityType<FieldVehicleEntity>> WORKSHOP_TRUCK = fieldVehicle("workshop_truck", 2.54F);

    private static RegistryObject<EntityType<FieldVehicleEntity>> fieldVehicle(String id, float width) {
        return ENTITIES.register(id, () -> EntityType.Builder.<FieldVehicleEntity>of(FieldVehicleEntity::new, MobCategory.MISC)
                .sized(width, 1.95F).clientTrackingRange(12).updateInterval(1).build(id));
    }

    private static RegistryObject<EntityType<HelicopterEntity>> registerHelicopter(String id, float width) {
        return ENTITIES.register(id, () -> EntityType.Builder.<HelicopterEntity>of(HelicopterEntity::new, MobCategory.MISC)
                .sized(width, 3.15F).clientTrackingRange(12).updateInterval(1).build(id));
    }

    public static final RegistryObject<EntityType<TankShellEntity>> TANK_SHELL = ENTITIES.register("tank_shell",
            () -> EntityType.Builder.<TankShellEntity>of(TankShellEntity::new, MobCategory.MISC)
                    .sized(0.35F, 0.35F)
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build("tank_shell"));

    public static final RegistryObject<MenuType<TankInventoryMenu>> TANK_MENU = MENUS.register("tank_inventory_menu",
            () -> IForgeMenuType.create(TankInventoryMenu::new));

    // Helper for tank spawner items
    private static Item createTankSpawnerItem(Supplier<EntityType<T72TankEntity>> entityTypeSupplier, TankType tankType) {
        return new Item(new Item.Properties().stacksTo(1)) {
            @Override
            public InteractionResult useOn(UseOnContext ctx) {
                Level level = ctx.getLevel();
                if (!level.isClientSide) {
                    BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
                    T72TankEntity tank = entityTypeSupplier.get().create(level);
                    if (tank != null) {
                        tank.setTankType(tankType);
                        tank.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ctx.getRotation(), 0.0F);
                        tank.setTurretYaw(ctx.getRotation());
                        tank.initStarterSupplies();
                        level.addFreshEntity(tank);
                        if (ctx.getPlayer() != null && !ctx.getPlayer().getAbilities().instabuild) {
                            ctx.getItemInHand().shrink(1);
                        }
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        };
    }

    private static <T extends PathfinderMob> Item createEquipmentKit(Supplier<EntityType<T>> type, Consumer<T> prepare) {
        return new Item(new Item.Properties().stacksTo(1)) {
            @Override
            public InteractionResult useOn(UseOnContext ctx) {
                Level level = ctx.getLevel();
                if (level.isClientSide) return InteractionResult.SUCCESS;
                BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
                T equipment = type.get().create(level);
                if (equipment == null) return InteractionResult.FAIL;
                equipment.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ctx.getRotation(), 0);
                if (!level.noCollision(equipment, equipment.getBoundingBox().inflate(0.1, 0, 0.1))) {
                    return InteractionResult.FAIL;
                }
                prepare.accept(equipment);
                if (!level.addFreshEntity(equipment)) return InteractionResult.FAIL;
                if (ctx.getPlayer() == null || !ctx.getPlayer().getAbilities().instabuild) ctx.getItemInHand().shrink(1);
                return InteractionResult.CONSUME;
            }
        };
    }

    public static final RegistryObject<Item> MI8_SPAWNER = ITEMS.register("mi8_spawner", () -> createEquipmentKit(MI8, HelicopterEntity::giveStarterFuel));
    public static final RegistryObject<Item> MI24_SPAWNER = ITEMS.register("mi24_spawner", () -> createEquipmentKit(MI24, HelicopterEntity::giveStarterFuel));
    public static final RegistryObject<Item> KA52_SPAWNER = ITEMS.register("ka52_spawner",
            () -> createEquipmentKit(KA52, HelicopterEntity::giveStarterFuel));
    public static final RegistryObject<Item> SCOUT_KIT = ITEMS.register("scout_kit",
            () -> createEquipmentKit(SCOUT_CAR, FieldVehicleEntity::starterSupplies));
    public static final RegistryObject<Item> WORKSHOP_KIT = ITEMS.register("workshop_kit",
            () -> createEquipmentKit(WORKSHOP_TRUCK, FieldVehicleEntity::starterSupplies));
    public static final RegistryObject<Item> AIR_ROCKET = ITEMS.register("air_rocket",
            () -> new Item(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> ARTILLERY_KIT = ITEMS.register("artillery_kit",
            () -> createEquipmentKit(ARTILLERY, ArtilleryEntity::loadStarterAmmo));
    public static final RegistryObject<Item> ARTILLERY_SHELL = ITEMS.register("artillery_shell",
            () -> new Item(new Item.Properties().stacksTo(32)));
    public static final RegistryObject<Item> ANTI_TANK_MINE_ITEM = ITEMS.register("anti_tank_mine",
            () -> new BlockItem(ANTI_TANK_MINE.get(), new Item.Properties().stacksTo(16)));

    // Tank Spawner Items
    public static final RegistryObject<Item> T72_SPAWN_ITEM = ITEMS.register("t72_spawner",
            () -> createTankSpawnerItem(T72_TANK, TankType.T72B));
    public static final RegistryObject<Item> T90M_SPAWN_ITEM = ITEMS.register("t90m_spawner",
            () -> createTankSpawnerItem(T90M_TANK, TankType.T90M));
    public static final RegistryObject<Item> BMP3_SPAWN_ITEM = ITEMS.register("bmp3_spawner",
            () -> createTankSpawnerItem(BMP3, TankType.BMP3));
    public static final RegistryObject<Item> ABRAMS_SPAWN_ITEM = ITEMS.register("abrams_spawner",
            () -> createTankSpawnerItem(ABRAMS_TANK, TankType.ABRAMS));
    public static final RegistryObject<Item> LEOPARD2_SPAWN_ITEM = ITEMS.register("leopard2_spawner",
            () -> createTankSpawnerItem(LEOPARD2_TANK, TankType.LEOPARD2));

    // Ammo, Fuel, Repair & AI Crew Items
    public static final RegistryObject<Item> SHELL_125MM = ITEMS.register("shell_125mm",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> SHELL_100MM = ITEMS.register("shell_100mm",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> SHELL_120MM = ITEMS.register("shell_120mm",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> MG_AMMO_BOX = ITEMS.register("mg_ammo_box",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> FUEL_CANISTER = ITEMS.register("fuel_canister",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> REPAIR_KIT = ITEMS.register("repair_kit",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> AI_CREW_CHIP = ITEMS.register("ai_crew_chip",
            () -> new Item(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> DRAGON_TOOTH_ITEM = blockItem(DRAGON_TOOTH);
    public static final RegistryObject<Item> SANDBAGS_ITEM = blockItem(SANDBAGS);
    public static final RegistryObject<Item> ROAD_BARRIER_ITEM = blockItem(ROAD_BARRIER);

    private static RegistryObject<Item> blockItem(RegistryObject<Block> block) {
        return ITEMS.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
    }

    public static final RegistryObject<CreativeModeTab> TANK_TAB = TABS.register("tank_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.t72mod"))
                    .icon(() -> new ItemStack(T72_SPAWN_ITEM.get()))
                    .displayItems((params, output) -> {
                        output.accept(T72_SPAWN_ITEM.get());
                        output.accept(MI8_SPAWNER.get());
                        output.accept(MI24_SPAWNER.get());
                        output.accept(KA52_SPAWNER.get());
                        output.accept(SCOUT_KIT.get());
                        output.accept(WORKSHOP_KIT.get());
                        output.accept(AIR_ROCKET.get());
                        output.accept(ARTILLERY_KIT.get());
                        output.accept(ARTILLERY_SHELL.get());
                        output.accept(ANTI_TANK_MINE_ITEM.get());
                        output.accept(DRAGON_TOOTH_ITEM.get());
                        output.accept(SANDBAGS_ITEM.get());
                        output.accept(ROAD_BARRIER_ITEM.get());
                        output.accept(T90M_SPAWN_ITEM.get());
                        output.accept(BMP3_SPAWN_ITEM.get());
                        output.accept(ABRAMS_SPAWN_ITEM.get());
                        output.accept(LEOPARD2_SPAWN_ITEM.get());
                        output.accept(SHELL_100MM.get());
                        output.accept(SHELL_125MM.get());
                        output.accept(SHELL_120MM.get());
                        output.accept(MG_AMMO_BOX.get());
                        output.accept(FUEL_CANISTER.get());
                        output.accept(REPAIR_KIT.get());
                        output.accept(AI_CREW_CHIP.get());
                    })
                    .build());

    public T72Mod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(modEventBus);
        VehicleSounds.EVENTS.register(modEventBus);
        ENTITIES.register(modEventBus);
        ITEMS.register(modEventBus);
        MENUS.register(modEventBus);
        TABS.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::registerAttributes);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModMessages::register);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ARTILLERY.get(), ArtilleryEntity.attributes().build());
        event.put(MI8.get(), HelicopterEntity.attributes(HelicopterType.MI8).build());
        event.put(MI24.get(), HelicopterEntity.attributes(HelicopterType.MI24).build());
        event.put(KA52.get(), HelicopterEntity.attributes(HelicopterType.KA52).build());
        event.put(SCOUT_CAR.get(), FieldVehicleEntity.attributes(true).build());
        event.put(WORKSHOP_TRUCK.get(), FieldVehicleEntity.attributes(false).build());
        event.put(T72_TANK.get(), T72TankEntity.createAttributes().build());
        event.put(T90M_TANK.get(), T72TankEntity.createAttributes()
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, TankType.T90M.maxHealth)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR, TankType.T90M.armor).build());
        event.put(BMP3.get(), T72TankEntity.createAttributes()
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, TankType.BMP3.maxHealth)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR, TankType.BMP3.armor).build());
        event.put(ABRAMS_TANK.get(), T72TankEntity.createAbramsAttributes().build());
        event.put(LEOPARD2_TANK.get(), T72TankEntity.createLeopard2Attributes().build());
    }

    // Complete crew invulnerability while inside an intact tank; redirect heavy external hits to the tank itself
    @SubscribeEvent
    public void onLivingAttack(LivingAttackEvent event) {
        if (event.getEntity() instanceof Player player && player.getVehicle() instanceof T72TankEntity tank && tank.isAlive()) {
            if (!event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                event.setCanceled(true);
                // If a Warden or heavy enemy attacks the player directly (e.g. Sonic Boom), redirect damage to the tank
                if (!player.level().isClientSide && (event.getSource().is(net.minecraft.world.damagesource.DamageTypes.SONIC_BOOM) || event.getSource().getEntity() instanceof Warden)) {
                    tank.hurt(event.getSource(), event.getAmount());
                }
            }
        }
    }

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        if (event.getEntity() instanceof Player player && player.getVehicle() instanceof T72TankEntity tank && tank.isAlive()) {
            if (!event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                event.setCanceled(true);
            }
        }
    }
}
