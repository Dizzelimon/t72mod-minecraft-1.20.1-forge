package com.example.t72mod.entity;

import com.example.t72mod.config.T72ServerConfig;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

final class VehicleContactDamage {
    private VehicleContactDamage() {}

    static boolean enabled() { return T72ServerConfig.contactDamageEnabled(); }

    static boolean canHit(LivingEntity vehicle, LivingEntity operator, LivingEntity target) {
        if (vehicle == target || !target.isAlive() || target.invulnerableTime > 0 || target.isSpectator()
                || vehicle.hasPassenger(target) || vehicle.isAlliedTo(target)
                || target instanceof T72TankEntity || target instanceof HelicopterEntity
                || target instanceof ArtilleryEntity || target instanceof FieldVehicleEntity) return false;
        if (!(target instanceof Player player)) return true;
        if (player.isCreative() || !(vehicle.level() instanceof ServerLevel server) || !server.getServer().isPvpAllowed()) return false;
        return !(operator instanceof Player pilot) || pilot.canHarmPlayer(player);
    }

    static boolean discIntersects(AABB bounds, Vec3 center, Vec3 normal, double radius) {
        Vec3 delta = bounds.getCenter().subtract(center);
        double distance = delta.dot(normal);
        double halfExtent = .5 * (Math.abs(normal.x) * bounds.getXsize()
                + Math.abs(normal.y) * bounds.getYsize() + Math.abs(normal.z) * bounds.getZsize());
        if (Math.abs(distance) > halfExtent + .15) return false;
        double radial = delta.subtract(normal.scale(distance)).length();
        return radial <= radius + Math.max(bounds.getXsize(), bounds.getZsize()) * .5;
    }
}
