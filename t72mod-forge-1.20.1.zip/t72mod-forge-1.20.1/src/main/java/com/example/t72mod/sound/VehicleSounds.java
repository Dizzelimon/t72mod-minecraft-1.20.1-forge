package com.example.t72mod.sound;

import com.example.t72mod.T72Mod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class VehicleSounds {
    public static final DeferredRegister<SoundEvent> EVENTS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS,T72Mod.MODID);
    public static final RegistryObject<SoundEvent> MI8_ENGINE = EVENTS.register("mi8_engine",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(T72Mod.MODID,"mi8_engine")));

    private VehicleSounds() {}
}
