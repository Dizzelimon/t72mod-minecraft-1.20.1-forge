package com.example.t72mod.sound;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.HelicopterType;
import com.example.t72mod.entity.TankType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class VehicleSounds {
    public static final DeferredRegister<SoundEvent> EVENTS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, T72Mod.MODID);
    private static final RegistryObject<SoundEvent> MI8 = register("mi8_engine");
    private static final RegistryObject<SoundEvent> MI24 = register("mi24_engine");
    private static final RegistryObject<SoundEvent> KA52 = register("ka52_engine");
    private static final RegistryObject<SoundEvent> T72 = register("t72_engine");
    private static final RegistryObject<SoundEvent> T90 = register("t90m_engine");
    private static final RegistryObject<SoundEvent> BMP = register("bmp_engine");
    private static final RegistryObject<SoundEvent> ABRAMS = register("abrams_engine");
    private static final RegistryObject<SoundEvent> LEOPARD = register("leopard_engine");
    public static final RegistryObject<SoundEvent> SCOUT = register("scout_engine");
    public static final RegistryObject<SoundEvent> TRUCK = register("truck_engine");
    public static final RegistryObject<SoundEvent> HATCH = register("hatch");
    public static final RegistryObject<SoundEvent> TANK_FIRE = register("tank_fire");
    public static final RegistryObject<SoundEvent> ARTILLERY_FIRE = register("artillery_fire");
    public static final RegistryObject<SoundEvent> AUTOMATIC_FIRE = register("automatic_fire");
    public static final RegistryObject<SoundEvent> ROCKET = register("rocket");
    public static final RegistryObject<SoundEvent> BLAST = register("blast");

    private VehicleSounds() {}

    private static RegistryObject<SoundEvent> register(String path) {
        return EVENTS.register(path, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(T72Mod.MODID,path)));
    }

    public static SoundEvent engine(HelicopterType type) {
        return switch (type) {
            case MI8 -> MI8.get();
            case MI24 -> MI24.get();
            case KA52 -> KA52.get();
        };
    }

    public static SoundEvent engine(TankType type) {
        return switch (type) {
            case T72B -> T72.get();
            case T90M -> T90.get();
            case BMP3 -> BMP.get();
            case ABRAMS -> ABRAMS.get();
            case LEOPARD2 -> LEOPARD.get();
        };
    }
}
