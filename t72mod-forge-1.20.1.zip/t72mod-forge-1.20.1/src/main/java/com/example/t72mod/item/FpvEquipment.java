package com.example.t72mod.item;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.FpvDroneEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public final class FpvEquipment {
    private FpvEquipment() {}

    public static final class Kit extends Item {
        public Kit(Properties properties) { super(properties); }

        @Override public InteractionResult useOn(UseOnContext context) {
            Level level = context.getLevel();
            if (level.isClientSide) return InteractionResult.SUCCESS;
            Player player = context.getPlayer();
            if (player == null || !player.mayBuild()) return InteractionResult.FAIL;
            BlockPos point = context.getClickedPos().relative(context.getClickedFace());
            FpvDroneEntity drone = T72Mod.FPV_DRONE.get().create(level);
            if (drone == null) return InteractionResult.FAIL;
            drone.moveTo(point.getX() + .5, point.getY() + .025, point.getZ() + .5, context.getRotation(), 0);
            if (!level.noCollision(drone, drone.getBoundingBox())) return InteractionResult.FAIL;
            ItemStack item = context.getItemInHand();
            drone.prepare(player, item);
            if (!level.addFreshEntity(drone)) return InteractionResult.FAIL;
            player.getPersistentData().putUUID(FpvDroneEntity.LINKED, drone.getUUID());
            if (!player.getAbilities().instabuild || item.getOrCreateTag().contains(FpvDroneEntity.STORED_CHARGE)) item.shrink(1);
            return InteractionResult.CONSUME;
        }
    }

    public static final class Controller extends Item {
        public Controller(Properties properties) { super(properties); }

        @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (player instanceof ServerPlayer pilot) {
                var saved = pilot.getPersistentData();
                if (saved.hasUUID(FpvDroneEntity.LINKED) && pilot.serverLevel().getEntity(saved.getUUID(FpvDroneEntity.LINKED))
                        instanceof FpvDroneEntity drone && drone.isOwnedBy(pilot)) drone.toggle(pilot);
                else pilot.displayClientMessage(Component.translatable("message.t72mod.fpv_unlinked"), true);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
    }
}
