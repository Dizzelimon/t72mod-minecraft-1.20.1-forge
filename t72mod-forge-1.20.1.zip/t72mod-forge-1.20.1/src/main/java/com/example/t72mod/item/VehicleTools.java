package com.example.t72mod.item;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.ArtilleryTowVehicle;
import com.example.t72mod.entity.FieldVehicleEntity;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.VehiclePart;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class VehicleTools {
    private static final String OWNER = "t72mod:VehicleOwner";
    private static final String PACKED = "T72PackedVehicle";
    private static final String SELECTED_TRUCK = "T72TowSelection";

    private VehicleTools() {}

    @SubscribeEvent
    public static void interact(PlayerInteractEvent.EntityInteract event) {
        interact(event, event.getTarget());
    }

    @SubscribeEvent
    public static void interactSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        interact(event, event.getTarget());
    }

    private static void interact(PlayerInteractEvent event, Entity target) {
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        if (target instanceof VehiclePart part) target = part.getParent();
        Player player = event.getEntity();
        ItemStack held = event.getItemStack();
        Item kit = kitOf(target);
        if (kit == null) return;
        boolean wrench = held.is(T72Mod.RECOVERY_WRENCH.get());
        boolean hitch = held.is(Items.CHAIN) && (target instanceof ArtilleryEntity || target instanceof ArtilleryTowVehicle);
        if (!wrench && !hitch) return;
        event.setCancellationResult(InteractionResult.sidedSuccess(target.level().isClientSide));
        event.setCanceled(true);
        if (target.level().isClientSide) return;
        if (wrench) {
            if (!pack(player, target, kit)) notice(player, "recovery_denied");
        } else {
            couple(player, target, held);
        }
    }

    private static void couple(Player player, Entity target, ItemStack chain) {
        if (!target.isAlive() || player.isPassenger() || !(target.level() instanceof ServerLevel level)) return;
        CompoundTag data = chain.getOrCreateTag();
        if (target instanceof ArtilleryTowVehicle tow) {
            if (player.isShiftKeyDown() && tow.towedGun().isPresent()) {
                tow.uncouple();
                notice(player, "hitch_detached");
            } else if (player.isShiftKeyDown() && target instanceof T72TankEntity tank
                    && data.hasUUID(SELECTED_TRUCK) && level.getEntity(data.getUUID(SELECTED_TRUCK)) instanceof FieldVehicleEntity truck) {
                if (!player.getCooldowns().isOnCooldown(Items.CHAIN) && truck.winch(tank)) {
                    player.getCooldowns().addCooldown(Items.CHAIN, 8);
                    notice(player, "winch_pulled");
                } else notice(player, "winch_failed");
            } else {
                data.putUUID(SELECTED_TRUCK, target.getUUID());
                notice(player, "hitch_selected");
            }
        } else if (target instanceof ArtilleryEntity gun) {
            if (player.isShiftKeyDown() && gun.towVehicle().isPresent()) {
                gun.unhitch();
                notice(player, "hitch_detached");
                return;
            }
            if (data.hasUUID(SELECTED_TRUCK) && level.getEntity(data.getUUID(SELECTED_TRUCK)) instanceof ArtilleryTowVehicle tow
                    && tow.couple(gun)) {
                data.remove(SELECTED_TRUCK);
                notice(player, "hitch_attached");
            } else notice(player, "hitch_failed");
        }
    }

    private static boolean pack(Player player, Entity target, Item kit) {
        CompoundTag data = target.getPersistentData();
        if (!target.isAlive() || target.isVehicle() || target.isPassenger() || !target.onGround()
                || target.getDeltaMovement().horizontalDistanceSqr() > .01
                || target instanceof HelicopterEntity aircraft && aircraft.engineOn()
                || target instanceof ArtilleryEntity gun && gun.towVehicle().isPresent()
                || target instanceof ArtilleryTowVehicle tow && tow.towedGun().isPresent()
                || !player.hasPermissions(2) && (!data.hasUUID(OWNER) || !data.getUUID(OWNER).equals(player.getUUID()))) return false;

        CompoundTag state = target.saveWithoutId(new CompoundTag());
        for (String key : new String[]{"UUID", "Pos", "Motion", "Rotation", "Passengers", "Leash",
                "FallDistance", "PortalCooldown"}) state.remove(key);
        ItemStack packed = new ItemStack(kit);
        packed.addTagElement(PACKED, state);
        if (!player.getInventory().add(packed)) return false;
        target.discard();
        notice(player, "recovery_packed");
        return true;
    }

    public static boolean restore(Entity target, ItemStack kit, Player player) {
        CompoundTag saved = kit.getTagElement(PACKED);
        if (saved != null) {
            // The vehicle identity stays unique even on a creative server.
            var uuid = target.getUUID();
            target.load(saved.copy());
            target.setUUID(uuid);
        }
        if (player != null) target.getPersistentData().putUUID(OWNER, player.getUUID());
        return saved != null;
    }

    private static void notice(Player player, String key) {
        player.displayClientMessage(Component.translatable("message.t72mod." + key), true);
    }

    private static Item kitOf(Entity entity) {
        if (entity instanceof T72TankEntity tank) return switch (tank.getTankType()) {
            case T72B -> T72Mod.T72_SPAWN_ITEM.get();
            case T90M -> T72Mod.T90M_SPAWN_ITEM.get();
            case BMP3 -> T72Mod.BMP3_SPAWN_ITEM.get();
            case ABRAMS -> T72Mod.ABRAMS_SPAWN_ITEM.get();
            case LEOPARD2 -> T72Mod.LEOPARD2_SPAWN_ITEM.get();
        };
        if (entity instanceof HelicopterEntity aircraft) return switch (aircraft.model()) {
            case MI8 -> T72Mod.MI8_SPAWNER.get();
            case MI24 -> T72Mod.MI24_SPAWNER.get();
            case KA52 -> T72Mod.KA52_SPAWNER.get();
        };
        if (entity instanceof FieldVehicleEntity truck)
            return (truck.scout() ? T72Mod.SCOUT_KIT : T72Mod.WORKSHOP_KIT).get();
        if (entity instanceof ArtilleryEntity) return T72Mod.ARTILLERY_KIT.get();
        return null;
    }
}
