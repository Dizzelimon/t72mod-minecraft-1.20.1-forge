package com.example.t72mod.client.renderer;

import com.example.t72mod.client.model.VehicleMesh;
import com.example.t72mod.entity.TaczGunStand;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class GunStandRenderer extends EntityRenderer<TaczGunStand> {
    private final VehicleMesh base = new VehicleMesh();
    private final VehicleMesh cradle = new VehicleMesh();

    public GunStandRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = .52F;
        for (Vec3 foot : new Vec3[]{new Vec3(-.62,.06,.40),new Vec3(.62,.06,.40),new Vec3(0,.06,-.67)}) {
            this.base.tube(foot,new Vec3(0,.76,0),.056,.044,7,0x596150);
            this.base.box(foot.x-.095,.012,foot.z-.075,foot.x+.095,.075,foot.z+.075,0x343935);
        }
        this.base.box(-.18,.74,-.19,.18,.88,.194,0x404a39);
        this.base.box(-.19,.22,-.69,.19,.28,-.32,0x5c6453);
        this.cradle.box(-.16,-.11,-.31,.16,0,.51,0x505d4c);
        this.cradle.box(-.204,-.082,.08,-.14,.11,.40,0x363f38);
        this.cradle.box(.14,-.082,.08,.204,.11,.40,0x363f38);
    }

    @Override public ResourceLocation getTextureLocation(TaczGunStand stand) { return HelicopterRenderer.SURFACE; }

    @Override public void render(TaczGunStand stand, float yaw, float partial, PoseStack poses,
                                 MultiBufferSource buffers, int light) {
        poses.pushPose();
        poses.mulPose(Axis.YP.rotationDegrees(-stand.getYRot()));
        var out = buffers.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(stand)));
        this.base.draw(poses.last(), out, light);
        poses.translate(0, .98, 0);
        if (stand.getFirstPassenger() != null) {
            var gunner = stand.getFirstPassenger();
            float turn = Mth.clamp(Mth.wrapDegrees(gunner.getViewYRot(partial) - stand.getYRot()),
                    -TaczGunStand.TRAVERSE, TaczGunStand.TRAVERSE);
            poses.mulPose(Axis.YP.rotationDegrees(-turn));
            poses.mulPose(Axis.XP.rotationDegrees(Mth.clamp(gunner.getViewXRot(partial), -52, 38)));
        }
        this.cradle.draw(poses.last(), out, light);
        poses.popPose();
        super.render(stand, yaw, partial, poses, buffers, light);
    }
}
