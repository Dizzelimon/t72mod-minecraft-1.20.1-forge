package com.example.t72mod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.level.GameRules;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;


public class TankShellEntity extends ThrowableProjectile {
    private static final EntityDataAccessor<Float> DATA_GRAVITY =
            SynchedEntityData.defineId(TankShellEntity.class, EntityDataSerializers.FLOAT);

    private float directDamage = 115.0F;
    private float explosionRadius = 5.5F;
    private UUID firingVehicle;
    private LivingEntity directVictim;


    public TankShellEntity(EntityType<? extends ThrowableProjectile> type, Level level) {
        super(type, level);
    }

    public void configureShell(Entity vehicle, float directDamage, float explosionRadius, float gravity) {
        this.firingVehicle = vehicle.getUUID();
        this.directDamage = directDamage;
        this.explosionRadius = explosionRadius;
        this.entityData.set(DATA_GRAVITY, gravity);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_GRAVITY, 0.010F);
    }

    @Override
    protected float getGravity() {
        return this.entityData.get(DATA_GRAVITY);
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        if (target.getUUID().equals(this.firingVehicle)) return false;
        if (target instanceof VehiclePart part) {
            return part.isPickable() && !part.getParent().getUUID().equals(this.firingVehicle);
        }
        if (target instanceof VehiclePartEntity part) {
            return part.isPickable() && part.parent() != null && !part.parent().getUUID().equals(this.firingVehicle);
        }
        if (this.getOwner() != null && target.isPassengerOfSameVehicle(this.getOwner())) return false;
        return super.canHitEntity(target);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            Vec3 pos = this.position();
            this.level().addParticle(ParticleTypes.SMOKE, pos.x, pos.y, pos.z, 0, 0, 0);
            this.level().addParticle(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 0, 0, 0);
        }
        if (this.tickCount > 200) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (this.level().isClientSide) return;

        Entity target = result.getEntity();
        Vec3 hitPos = this.contact(result);
        DamageSource source = this.damageSources().thrown(this, this.getOwner());
        if (target instanceof VehiclePart part) {
            this.directVictim=part.getParent();
            part.hitBy(source,hitPos,this.directDamage);
        } else if (target instanceof VehiclePartEntity part) {
            this.directVictim = part.parent();
            part.hitBy(source, hitPos, this.directDamage);
        } else if (target instanceof T72TankEntity tank) {
            this.directVictim = tank;
            tank.onDirectShellHit(tank.resolveModuleAtPosition(hitPos), hitPos, this, this.directDamage);
        } else if (target instanceof HelicopterEntity helicopter) {
            this.directVictim = helicopter;
            helicopter.hitAirframe(source, hitPos, this.directDamage);
        } else if (target instanceof ArtilleryEntity artillery) {
            this.directVictim = artillery;
            artillery.hitAssembly(source, hitPos, this.directDamage);
        } else if (target instanceof LivingEntity living) {
            living.hurt(source, this.directDamage);
        }
    }

    private Vec3 contact(EntityHitResult result) {
        Vec3 start = this.position();
        Vec3 end = start.add(this.getDeltaMovement());
        var bounds = result.getEntity().getBoundingBox();
        return bounds.clip(start, end).or(() -> bounds.inflate(0.3F).clip(start, end)).orElse(start);
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide) {
            this.detonateAt(result instanceof EntityHitResult entityHit ? this.contact(entityHit) : result.getLocation());
        }
    }

    public boolean excludeFromBlast(LivingEntity vehicle) {
        return this.directVictim == vehicle || vehicle.getUUID().equals(this.firingVehicle);
    }

    private void detonateAt(Vec3 hit) {
        if (this.isRemoved()) return;
        if (this.explosionRadius <= 0) {
            this.discard();
            return;
        }

        this.level().explode(
                this,
                hit.x, hit.y, hit.z,
                this.explosionRadius,
                this.level().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)
                        ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE
        );

        this.discard();
    }
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (this.firingVehicle != null) tag.putUUID("FiringVehicle", this.firingVehicle);
        tag.putFloat("DirectDamage", this.directDamage);
        tag.putFloat("ExplosionRadius", this.explosionRadius);
        tag.putFloat("ShellGravity", this.getGravity());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("FiringVehicle")) this.firingVehicle = tag.getUUID("FiringVehicle");
        if (tag.contains("DirectDamage")) this.directDamage = tag.getFloat("DirectDamage");
        if (tag.contains("ExplosionRadius")) this.explosionRadius = tag.getFloat("ExplosionRadius");
        if (tag.contains("ShellGravity")) this.entityData.set(DATA_GRAVITY, tag.getFloat("ShellGravity"));
    }
}
