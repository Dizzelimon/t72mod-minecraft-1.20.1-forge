package com.example.t72mod.client.sound;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.FieldVehicleEntity;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.sound.VehicleSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import com.example.t72mod.entity.HelicopterType;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT)
public final class VehicleAudio {
    private static final Map<Entity, EngineLoop> LOOPS = new HashMap<>();
    private static ClientLevel world;
    private static int ticks;

    private VehicleAudio() {}

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft game = Minecraft.getInstance();
        if (world != game.level) {
            LOOPS.values().forEach(game.getSoundManager()::stop);
            LOOPS.clear();
            world = game.level;
        }
        if (world == null || game.player == null || ++ticks % 8 != 0) return;
        var viewer = game.player;
        LOOPS.entrySet().removeIf(entry -> {
            if (entry.getValue().isStopped()) return true;
            if (entry.getKey().distanceToSqr(viewer) <= 100 * 100) return false;
            game.getSoundManager().stop(entry.getValue());
            return true;
        });
        for (Entity vehicle : world.entitiesForRendering()) {
            if (vehicle.distanceToSqr(viewer) > 84 * 84 || LOOPS.containsKey(vehicle) || !running(vehicle)) continue;
            SoundEvent engine = sound(vehicle);
            EngineLoop loop = new EngineLoop(vehicle,engine);
            LOOPS.put(vehicle,loop);
            game.getSoundManager().play(loop);
        }
    }

    private static SoundEvent sound(Entity vehicle) {
        if (vehicle instanceof HelicopterEntity helicopter) {
            return helicopter.model() == HelicopterType.MI8 ? VehicleSounds.MI8_ENGINE.get() : SoundEvents.ELYTRA_FLYING;
        }
        return SoundEvents.MINECART_RIDING;
    }

    private static boolean running(Entity vehicle) {
        if (!(vehicle instanceof LivingEntity living) || !living.isAlive() || vehicle.isRemoved()) return false;
        if (vehicle instanceof HelicopterEntity air) return air.rpm() > 2;
        if (vehicle instanceof T72TankEntity tank)
            return tank.getFuel() > 0 && !tank.isEngineBroken() && (tank.isVehicle() || tank.isEnemyAI());
        return vehicle instanceof FieldVehicleEntity ground && vehicle.isVehicle() && ground.fuel() > 0;
    }

    private static final class EngineLoop extends AbstractTickableSoundInstance {
        private final Entity vehicle;
        private int quietTicks;
        private double previousX, previousZ;
        private float groundLoad;

        private EngineLoop(Entity vehicle, SoundEvent sound) {
            super(sound,SoundSource.NEUTRAL,SoundInstance.createUnseededRandom());
            this.vehicle = vehicle;
            this.looping = true;
            this.volume = .1F;
            this.x = this.previousX = vehicle.getX();
            this.y = vehicle.getY() + vehicle.getBbHeight() / 2;
            this.z = this.previousZ = vehicle.getZ();
        }

        @Override public void tick() {
            float targetVolume, targetPitch;
            if (this.vehicle instanceof HelicopterEntity air) {
                float rpm = air.rpm() / 100F;
                boolean mi8 = air.model() == HelicopterType.MI8;
                targetVolume = (mi8 ? .86F : .32F) * rpm;
                targetPitch = (mi8 ? .81F : .61F) + .20F * rpm;
            } else {
                double speed = Math.hypot(vehicle.getX() - this.previousX,vehicle.getZ() - this.previousZ);
                this.groundLoad = Mth.lerp(.18F,this.groundLoad, Mth.clamp((float) speed * 5F,0,1));
                targetVolume = .11F + .28F * this.groundLoad;
                targetPitch = .61F + .26F * this.groundLoad;
            }
            if (!running(this.vehicle)) {
                targetVolume = 0;
                if (++this.quietTicks > 12 || vehicle.isRemoved()) {
                    this.stop();
                    return;
                }
            } else this.quietTicks = 0;
            this.volume = Mth.lerp(.2F,this.volume,targetVolume);
            this.pitch = Mth.lerp(.21F,this.pitch,targetPitch);
            this.x = this.previousX = this.vehicle.getX();
            this.y = this.vehicle.getY() + vehicle.getBbHeight() / 2;
            this.z = this.previousZ = this.vehicle.getZ();
        }
    }
}
