package com.example.t72mod.network;

import com.example.t72mod.entity.FpvDroneEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record FpvInputPacket(int droneId, int keys, float yaw, float pitch, int action) {
    static void encode(FpvInputPacket packet, FriendlyByteBuf out) {
        out.writeVarInt(packet.droneId).writeByte(packet.keys).writeFloat(packet.yaw).writeFloat(packet.pitch).writeByte(packet.action);
    }

    static FpvInputPacket decode(FriendlyByteBuf in) {
        return new FpvInputPacket(in.readVarInt(), in.readUnsignedByte(), in.readFloat(), in.readFloat(), in.readUnsignedByte());
    }

    static void handle(FpvInputPacket packet, Supplier<NetworkEvent.Context> supplier) {
        var context = supplier.get();
        context.enqueueWork(() -> {
            var pilot = context.getSender();
            if (pilot != null && pilot.serverLevel().getEntity(packet.droneId) instanceof FpvDroneEntity drone)
                drone.accept(pilot, packet.keys, packet.yaw, packet.pitch, packet.action);
        });
        context.setPacketHandled(true);
    }
}
