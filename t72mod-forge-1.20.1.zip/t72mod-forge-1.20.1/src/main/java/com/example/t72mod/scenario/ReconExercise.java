package com.example.t72mod.scenario;

import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.ArtilleryMarkerStore;
import com.example.t72mod.network.ArtilleryMarkerPacket;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Comparator;

/** Small repeatable exercises that reuse the actual map pins, FPV feed and tow links. */
public final class ReconExercise {
    private static final String RECON = "t72mod:recon_exercise";
    private static final String TOW = "t72mod:tow_exercise";

    private ReconExercise() {}

    @SubscribeEvent public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("t72recon")
                .then(Commands.literal("start").executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    CompoundTag job = new CompoundTag();
                    job.putString("Dimension", player.level().dimension().location().toString());
                    job.putLong("Start", player.level().getGameTime());
                    job.put("Pins", new ListTag());
                    player.getPersistentData().put(RECON, job);
                    notice(player, "recon_start");
                    return 1;
                })).then(Commands.literal("stop").executes(ctx -> stop(ctx.getSource().getPlayerOrException(), RECON))));
        event.getDispatcher().register(Commands.literal("t72tow")
                .then(Commands.literal("start").executes(ctx -> beginTow(ctx.getSource().getPlayerOrException())))
                .then(Commands.literal("stop").executes(ctx -> stop(ctx.getSource().getPlayerOrException(), TOW))));
    }

    private static int stop(ServerPlayer p, String job) {
        p.getPersistentData().remove(job);
        notice(p, "exercise_ended");
        return 1;
    }

    public static void markFromDrone(ServerPlayer player, BlockPos marker) {
        var data = player.getPersistentData();
        if (!data.contains(RECON)) return;
        CompoundTag job = data.getCompound(RECON);
        if (!sameDimension(job, player.serverLevel())) return;
        ListTag pins = job.getList("Pins", 10);
        for (var entry : pins) {
            BlockPos old = NbtUtils.readBlockPos((CompoundTag) entry);
            double dx = old.getX() - marker.getX(), dz = old.getZ() - marker.getZ();
            if (dx * dx + dz * dz < 16 * 16) {
                notice(player, "recon_too_close");
                return;
            }
        }
        pins.add(NbtUtils.writeBlockPos(marker));
        if (pins.size() >= 3) {
            data.remove(RECON);
            notice(player, "recon_done");
        } else {
            job.put("Pins", pins);
            notice(player, "recon_progress", pins.size());
        }
    }

    private static int beginTow(ServerPlayer player) {
        var dimension = player.level().dimension().location();
        var marks = ArtilleryMarkerPacket.loadPlayerStore(player).list(dimension);
        ArtilleryMarkerStore.Marker destination = marks.isEmpty() ? null : marks.get(marks.size() - 1);
        var nearby = player.level().getEntitiesOfClass(ArtilleryEntity.class, player.getBoundingBox().inflate(10, 3, 10),
                gun -> gun.isAlive() && !gun.isVehicle()).stream().min(Comparator.comparingDouble(player::distanceToSqr));
        if (destination == null || nearby.isEmpty()) {
            notice(player, "tow_mission_needs");
            return 0;
        }
        ArtilleryEntity gun = nearby.get();
        int dx = destination.x() - gun.getBlockX(), dz = destination.z() - gun.getBlockZ();
        if (Math.hypot(dx, dz) < 12 || Math.hypot(dx, dz) > 170) {
            notice(player, "tow_mission_distance");
            return 0;
        }
        CompoundTag job = new CompoundTag();
        job.putString("Dimension", dimension.toString());
        job.putUUID("Gun", gun.getUUID());
        job.putInt("X", destination.x());
        job.putInt("Z", destination.z());
        player.getPersistentData().put(TOW, job);
        notice(player, "tow_mission_start", destination.x(), destination.z());
        return 1;
    }

    @SubscribeEvent public static void tick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)
                || player.tickCount % 20 != 0) return;
        ServerLevel level = player.serverLevel();
        var data = player.getPersistentData();
        if (data.contains(RECON) && sameDimension(data.getCompound(RECON), level)
                && level.getGameTime() - data.getCompound(RECON).getLong("Start") > 4000) {
            data.remove(RECON);
            notice(player, "recon_timeout");
        }
        if (!data.contains(TOW)) return;
        CompoundTag job = data.getCompound(TOW);
        if (!sameDimension(job, level) || !job.hasUUID("Gun") || !(level.getEntity(job.getUUID("Gun")) instanceof ArtilleryEntity gun)) return;
        if (gun.towVehicle().isPresent()) job.putBoolean("Towed", true);
        if (!job.getBoolean("Towed") || gun.towVehicle().isPresent() || !gun.hasGroundSupport()) return;
        int x = job.getInt("X"), z = job.getInt("Z");
        if (Math.hypot(gun.getX() - x - .5, gun.getZ() - z - .5) <= 5) {
            data.remove(TOW);
            notice(player, "tow_mission_done");
        }
    }

    private static boolean sameDimension(CompoundTag job, ServerLevel level) {
        return job.getString("Dimension").equals(level.dimension().location().toString());
    }

    private static void notice(ServerPlayer player, String key, Object... values) {
        player.displayClientMessage(Component.translatable("message.t72mod." + key, values), true);
    }
}
