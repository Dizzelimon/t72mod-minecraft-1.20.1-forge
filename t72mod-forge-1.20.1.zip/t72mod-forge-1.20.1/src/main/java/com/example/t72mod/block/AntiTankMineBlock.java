package com.example.t72mod.block;

import com.example.t72mod.entity.T72TankEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class AntiTankMineBlock extends Block {
    public static final BooleanProperty ARMED = BooleanProperty.create("armed");
    private static final VoxelShape SHAPE = Block.box(2, 0, 2, 14, 2, 14);

    public AntiTankMineBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(ARMED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ARMED);
    }

    @Override
    public VoxelShape getShape(BlockState state, net.minecraft.world.level.BlockGetter level,
                               BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighbor, LevelAccessor level,
                                  BlockPos pos, BlockPos neighborPos) {
        return direction == Direction.DOWN && !this.canSurvive(state, level, pos) ? Blocks.AIR.defaultBlockState() : state;
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moved) {
        if (!level.isClientSide && !oldState.is(this)) level.scheduleTick(pos, this, 35);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.getValue(ARMED)) level.setBlock(pos, state.setValue(ARMED, true), UPDATE_CLIENTS);
        var tanks = level.getEntitiesOfClass(T72TankEntity.class, new AABB(pos).inflate(2.4, 0.3, 2.4),
                tank -> tank.isAlive() && tank.overlapsMine(pos));
        if (!tanks.isEmpty()) this.trigger(level, pos, tanks.get(0));
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (entity instanceof T72TankEntity tank && level instanceof ServerLevel server && tank.overlapsMine(pos)) {
            this.trigger(server, pos, tank);
        }
    }

    public void trigger(ServerLevel level, BlockPos pos, T72TankEntity tank) {
        BlockState state = level.getBlockState(pos);
        if (!tank.isAlive() || !state.is(this) || !state.getValue(ARMED)) return;
        level.removeBlock(pos, false);
        tank.damageTracksFromMine();
        Vec3 center = Vec3.atBottomCenterOf(pos).add(0, 0.15, 0);
        level.explode(null, center.x, center.y, center.z, 3.0F,
                level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)
                        ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (!player.isShiftKeyDown() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level.isClientSide) {
            level.removeBlock(pos, false);
            if (!player.getAbilities().instabuild) {
                ItemStack mine = new ItemStack(this);
                if (!player.addItem(mine)) popResource(level, pos, mine);
            }
            player.displayClientMessage(Component.translatable("message.t72mod.mine_disarmed"), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
