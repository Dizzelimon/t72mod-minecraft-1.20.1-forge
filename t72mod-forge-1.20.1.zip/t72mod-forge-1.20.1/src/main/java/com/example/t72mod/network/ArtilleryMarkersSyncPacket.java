package com.example.t72mod.network;

import com.example.t72mod.client.ClientArtilleryMarkers;
import com.example.t72mod.entity.ArtilleryMarkerStore;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public record ArtilleryMarkersSyncPacket(ResourceLocation dimension, List<ArtilleryMarkerStore.Marker> markers) {
    public static void encode(ArtilleryMarkersSyncPacket packet, FriendlyByteBuf buf) {
        buf.writeResourceLocation(packet.dimension);
        int count = Math.min(packet.markers.size(), ArtilleryMarkerStore.MAX_MARKERS);
        buf.writeByte(count);
        for (int i = 0; i < count; i++) {
            ArtilleryMarkerStore.Marker m = packet.markers.get(i);
            buf.writeInt(m.x());
            buf.writeInt(m.z());
        }
    }

    public static ArtilleryMarkersSyncPacket decode(FriendlyByteBuf buf) {
        ResourceLocation dim = buf.readResourceLocation();
        int count = Math.min(buf.readUnsignedByte(), ArtilleryMarkerStore.MAX_MARKERS);
        List<ArtilleryMarkerStore.Marker> markers = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            markers.add(new ArtilleryMarkerStore.Marker(buf.readInt(), buf.readInt()));
        }
        return new ArtilleryMarkersSyncPacket(dim, markers);
    }

    public static void handle(ArtilleryMarkersSyncPacket packet, Supplier<NetworkEvent.Context> supplied) {
        NetworkEvent.Context context = supplied.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientArtilleryMarkers.update(packet.dimension, packet.markers)));
        context.setPacketHandled(true);
    }
}
