package com.example.t72mod.client.gui;

import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.network.ArtilleryFirePacket;
import com.example.t72mod.network.ModMessages;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

public final class ArtilleryMapScreen extends Screen {
    private static final int UNLOADED = 0xFF22282A;
    private final ArtilleryEntity piece;
    private int viewX;
    private int viewZ;
    private BlockPos target;
    private int columns;
    private int rows;
    private int originX;
    private int originZ;
    private int top;
    private int left;
    private int cellPixels = 4;
    private int sampleStep = 3;
    private int[] colors;
    private Button fire;

    public ArtilleryMapScreen(ArtilleryEntity piece) {
        super(Component.translatable("screen.t72mod.artillery"));
        this.piece = piece;
        Vec3 initialView = piece.position().add(Vec3.directionFromRotation(0, piece.getYRot()).scale(32));
        this.viewX = Mth.floor(initialView.x);
        this.viewZ = Mth.floor(initialView.z);
    }

    @Override
    protected void init() {
        this.cellPixels = this.height < 215 ? 3 : 4;
        this.columns = Mth.clamp((this.width - 20) / this.cellPixels, 26, 51);
        this.rows = Mth.clamp((this.height - 83) / this.cellPixels, 12, 39);
        this.top = 31;
        this.left = (this.width - this.columns * this.cellPixels) / 2;
        int bottom = this.top + this.rows * this.cellPixels;
        this.fire = this.addRenderableWidget(Button.builder(Component.translatable("screen.t72mod.fire"), button -> {
            if (this.target != null) {
                ModMessages.INSTANCE.sendToServer(new ArtilleryFirePacket(this.piece.getId(), this.target.getX(), this.target.getZ()));
                this.onClose();
            }
        }).bounds((this.width - 104) / 2, bottom + 14, 104, 20).build());
        this.sampleTerrain();
    }

    private void sampleTerrain() {
        if (this.minecraft == null || this.minecraft.level == null) return;
        Level level = this.minecraft.level;
        this.colors = new int[this.rows * this.columns];
        this.originX = this.viewX - this.columns / 2 * this.sampleStep;
        this.originZ = this.viewZ - this.rows / 2 * this.sampleStep;
        for (int cellZ = 0; cellZ < this.rows; cellZ++) {
            int z = this.originZ + cellZ * this.sampleStep;
            for (int cellX = 0; cellX < this.columns; cellX++) {
                int x = this.originX + cellX * this.sampleStep;
                BlockPos column = new BlockPos(x, 0, z);
                int color = UNLOADED;
                if (level.hasChunkAt(column)) {
                    int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z) - 1;
                    BlockPos surface = column.atY(y);
                    int rgb = level.getBlockState(surface).getMapColor(level, surface).col;
                    if (rgb == 0) rgb = 0x394552;
                    int shade = 215 + Mth.clamp(y - 60, -42, 40);
                    color = 0xFF000000 | (((rgb >> 16 & 255) * shade / 255) << 16)
                            | (((rgb >> 8 & 255) * shade / 255) << 8) | ((rgb & 255) * shade / 255);
                    if (!this.inRange(x, z)) color = 0xFF000000 | ((color & 0x00FEFEFE) >> 1);
                }
                this.colors[cellZ * this.columns + cellX] = color;
            }
        }
    }

    private boolean inRange(int x, int z) {
        double distance = Math.hypot(x + 0.5 - this.piece.getX(), z + 0.5 - this.piece.getZ());
        return distance >= ArtilleryEntity.MIN_RANGE && distance <= ArtilleryEntity.MAX_RANGE;
    }

    @Override
    public void tick() {
        if (this.minecraft == null || this.minecraft.player == null || this.minecraft.player.getVehicle() != this.piece) {
            this.onClose();
            return;
        }
        this.fire.active = this.target != null && this.inRange(this.target.getX(), this.target.getZ())
                && this.piece.gunHealth() > 0 && this.piece.traverseHealth() > 0 && this.piece.reloadTicks() == 0
                && (this.piece.ammunition() > 0 || this.minecraft.player.getAbilities().instabuild);
        if (this.piece.tickCount % 10 == 0) this.sampleTerrain();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        int right = this.left + this.columns * this.cellPixels;
        int bottom = this.top + this.rows * this.cellPixels;
        if (this.colors != null) {
            for (int row = 0; row < this.rows; row++) {
                int y = this.top + row * this.cellPixels;
                for (int col = 0; col < this.columns; col++) {
                    int x = this.left + col * this.cellPixels;
                    graphics.fill(x, y, x + this.cellPixels, y + this.cellPixels, this.colors[row * this.columns + col]);
                }
            }
        }
        graphics.renderOutline(this.left - 1, this.top - 1, right - this.left + 2, bottom - this.top + 2, 0xFFB5BFA9);
        if (this.minecraft != null && this.minecraft.level != null) {
            for (LivingEntity vehicle : this.minecraft.level.getEntitiesOfClass(LivingEntity.class,
                    this.piece.getBoundingBox().inflate(ArtilleryEntity.MAX_RANGE, 128, ArtilleryEntity.MAX_RANGE),
                    entity -> entity != this.piece && entity.isAlive() && (entity instanceof T72TankEntity
                            || entity instanceof HelicopterEntity || entity instanceof ArtilleryEntity))) {
                this.marker(graphics, vehicle.getBlockX(), vehicle.getBlockZ(),
                        vehicle instanceof HelicopterEntity ? 0xFFCBE7F4 : 0xFFDB8A75);
            }
        }
        this.marker(graphics, this.piece.getBlockX(), this.piece.getBlockZ(), 0xFFB1D4FF);
        if (this.target != null) this.marker(graphics, this.target.getX(), this.target.getZ(), 0xFFFFCD79);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 6, 0xFFFFFF);
        graphics.drawCenteredString(this.font, Component.translatable("screen.t72mod.artillery_status",
                this.piece.ammunition(), this.piece.gunHealth(), this.piece.traverseHealth()), this.width / 2, 18, 0xE1E5D7);
        graphics.drawCenteredString(this.font, this.hint(), this.width / 2, bottom + 3, 0xE1E5D7);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private Component hint() {
        if (this.piece.reloadTicks() > 0) {
            return Component.translatable("screen.t72mod.artillery_reload", (this.piece.reloadTicks() + 19) / 20);
        }
        if (this.target == null) return Component.translatable("screen.t72mod.artillery_controls");
        return Component.translatable("screen.t72mod.artillery_target", this.target.getX(), this.target.getZ(),
                (int) Math.hypot(this.target.getX() + 0.5 - this.piece.getX(), this.target.getZ() + 0.5 - this.piece.getZ()));
    }

    private void marker(GuiGraphics graphics, int x, int z, int color) {
        int col = Math.floorDiv(x - this.originX, this.sampleStep);
        int row = Math.floorDiv(z - this.originZ, this.sampleStep);
        if (col < 0 || col >= this.columns || row < 0 || row >= this.rows) return;
        int px = this.left + col * this.cellPixels;
        int py = this.top + row * this.cellPixels;
        graphics.renderOutline(px - 2, py - 2, this.cellPixels + 4, this.cellPixels + 4, color);
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button == 0 && this.mouseOverMap(x, y)) {
            int col = ((int) x - this.left) / this.cellPixels;
            int row = ((int) y - this.top) / this.cellPixels;
            int targetX = this.originX + col * this.sampleStep;
            int targetZ = this.originZ + row * this.sampleStep;
            if (this.inRange(targetX, targetZ) && this.colors != null && this.colors[row * this.columns + col] != UNLOADED) {
                this.target = new BlockPos(targetX, 0, targetZ);
            }
            return true;
        }
        return super.mouseClicked(x, y, button);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double delta) {
        if (!this.mouseOverMap(x, y)) return super.mouseScrolled(x, y, delta);
        this.sampleStep = Mth.clamp(this.sampleStep + (delta > 0 ? -1 : 1), 1, 5);
        this.sampleTerrain();
        return true;
    }

    private boolean mouseOverMap(double x, double y) {
        return x >= this.left && x < this.left + this.columns * this.cellPixels
                && y >= this.top && y < this.top + this.rows * this.cellPixels;
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        int dx = key == GLFW.GLFW_KEY_LEFT ? -12 : key == GLFW.GLFW_KEY_RIGHT ? 12 : 0;
        int dz = key == GLFW.GLFW_KEY_UP ? -12 : key == GLFW.GLFW_KEY_DOWN ? 12 : 0;
        if (dx == 0 && dz == 0) return super.keyPressed(key, scanCode, modifiers);
        int edge = ArtilleryEntity.MAX_RANGE + 12;
        this.viewX = Mth.clamp(this.viewX + dx, this.piece.getBlockX() - edge, this.piece.getBlockX() + edge);
        this.viewZ = Mth.clamp(this.viewZ + dz, this.piece.getBlockZ() - edge, this.piece.getBlockZ() + edge);
        this.sampleTerrain();
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
