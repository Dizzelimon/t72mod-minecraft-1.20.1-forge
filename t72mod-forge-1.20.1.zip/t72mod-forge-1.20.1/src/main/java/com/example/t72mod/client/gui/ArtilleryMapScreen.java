package com.example.t72mod.client.gui;

import com.example.t72mod.client.ClientArtilleryMarkers;
import com.example.t72mod.entity.ArtilleryBallistics;
import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.ArtilleryMarkerStore;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.network.ArtilleryAimPacket;
import com.example.t72mod.network.ArtilleryFirePacket;
import com.example.t72mod.network.ArtilleryMarkerPacket;
import com.example.t72mod.network.ModMessages;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public final class ArtilleryMapScreen extends Screen {
    private static final int UNLOADED = 0xFF1F2428;
    private static final int RELOAD_MAX_TICKS = 95;
    private final ArtilleryEntity piece;
    private int viewX;
    private int viewZ;
    private BlockPos target;
    private int columns;
    private int rows;
    private int originX;
    private int originZ;
    private int top;
    private int left;
    private int panelX;
    private int panelWidth;
    private int cellPixels = 4;
    private int sampleStep = 6;
    private int[] colors;
    private boolean draggingMap;
    private double dragAccumX;
    private double dragAccumY;

    private Button fireButton;
    private Button saveMarkerButton;
    private final Button[] selectMarkerButtons = new Button[ArtilleryMarkerStore.MAX_MARKERS];
    private final Button[] deleteMarkerButtons = new Button[ArtilleryMarkerStore.MAX_MARKERS];

    public ArtilleryMapScreen(ArtilleryEntity piece) {
        super(Component.translatable("screen.t72mod.artillery"));
        this.piece = piece;
        Vec3 initialView = piece.position().add(Vec3.directionFromRotation(0, piece.getYRot()).scale(48));
        this.viewX = Mth.floor(initialView.x);
        this.viewZ = Mth.floor(initialView.z);
    }

    @Override
    protected void init() {
        this.panelWidth = this.width < 390 ? 104 : 124;
        this.cellPixels = (this.height < 230 || this.width < 360) ? 3 : 4;
        int availMapW = Math.max(84, this.width - this.panelWidth - 26);
        int availMapH = Math.max(60, this.height - 86);
        this.columns = Mth.clamp(availMapW / this.cellPixels, 24, 68);
        this.rows = Mth.clamp(availMapH / this.cellPixels, 15, 56);

        int mapW = this.columns * this.cellPixels;
        int totalW = mapW + 8 + this.panelWidth;
        this.left = Math.max(8, (this.width - totalW) / 2);
        this.top = 30;
        this.panelX = this.left + mapW + 8;
        int bottom = this.top + this.rows * this.cellPixels;
        int mapCenterX = this.left + mapW / 2;

        this.fireButton = this.addRenderableWidget(Button.builder(Component.translatable("screen.t72mod.fire"), button -> {
            if (this.target != null) {
                ModMessages.INSTANCE.sendToServer(new ArtilleryFirePacket(this.piece.getId(), this.target.getX(), this.target.getZ()));
                this.onClose();
            }
        }).bounds(mapCenterX - 54, bottom + 28, 108, 19).build());

        int btnY = this.top + 14;
        for (int i = 0; i < ArtilleryMarkerStore.MAX_MARKERS; i++) {
            final int slot = i;
            this.selectMarkerButtons[i] = this.addRenderableWidget(Button.builder(Component.literal("-"), b -> this.selectSavedMarker(slot))
                    .bounds(this.panelX, btnY + i * 21, this.panelWidth - 22, 18).build());
            this.deleteMarkerButtons[i] = this.addRenderableWidget(Button.builder(Component.literal("×"), b -> this.deleteSavedMarker(slot))
                    .bounds(this.panelX + this.panelWidth - 20, btnY + i * 21, 20, 18).build());
        }

        int controlsY = btnY + ArtilleryMarkerStore.MAX_MARKERS * 21 + 4;
        this.saveMarkerButton = this.addRenderableWidget(Button.builder(Component.translatable("screen.t72mod.marker_save"), b -> {
            if (this.target != null) {
                ModMessages.INSTANCE.sendToServer(new ArtilleryMarkerPacket(
                        ArtilleryMarkerPacket.ACTION_ADD, 0, this.target.getX(), this.target.getZ()));
            }
        }).bounds(this.panelX, controlsY, this.panelWidth, 18).build());

        int zoomY = controlsY + 24;
        int halfW = (this.panelWidth - 4) / 2;
        this.addRenderableWidget(Button.builder(Component.literal("+"), b -> this.adjustZoom(-1))
                .bounds(this.panelX, zoomY, halfW, 18).build());
        this.addRenderableWidget(Button.builder(Component.literal("-"), b -> this.adjustZoom(1))
                .bounds(this.panelX + halfW + 4, zoomY, this.panelWidth - halfW - 4, 18).build());
        this.addRenderableWidget(Button.builder(Component.translatable("screen.t72mod.center"), b -> {
            this.viewX = this.piece.getBlockX();
            this.viewZ = this.piece.getBlockZ();
            this.sampleTerrain();
        }).bounds(this.panelX, zoomY + 21, this.panelWidth, 18).build());

        this.refreshMarkerWidgets();
        this.sampleTerrain();
        ModMessages.INSTANCE.sendToServer(new ArtilleryMarkerPacket(ArtilleryMarkerPacket.ACTION_REQUEST_SYNC, 0, 0, 0));
    }

    private void adjustZoom(int delta) {
        this.sampleStep = Mth.clamp(this.sampleStep + delta, 1, 12);
        this.sampleTerrain();
    }

    private ResourceLocation currentDimension() {
        return this.minecraft != null && this.minecraft.level != null
                ? this.minecraft.level.dimension().location()
                : Level.OVERWORLD.location();
    }

    private List<ArtilleryMarkerStore.Marker> markers() {
        return ClientArtilleryMarkers.list(this.currentDimension());
    }

    private void refreshMarkerWidgets() {
        List<ArtilleryMarkerStore.Marker> list = this.markers();
        for (int i = 0; i < ArtilleryMarkerStore.MAX_MARKERS; i++) {
            boolean present = i < list.size();
            Button sel = this.selectMarkerButtons[i];
            Button del = this.deleteMarkerButtons[i];
            if (sel != null) {
                if (present) {
                    ArtilleryMarkerStore.Marker m = list.get(i);
                    sel.setMessage(Component.literal((i + 1) + ": " + m.x() + "," + m.z()));
                    sel.active = true;
                } else {
                    sel.setMessage(Component.translatable("screen.t72mod.marker_empty", i + 1));
                    sel.active = false;
                }
            }
            if (del != null) {
                del.active = present;
            }
        }
        if (this.saveMarkerButton != null) {
            this.saveMarkerButton.active = this.target != null && list.size() < ArtilleryMarkerStore.MAX_MARKERS;
        }
    }

    private void selectSavedMarker(int index) {
        List<ArtilleryMarkerStore.Marker> list = this.markers();
        if (index < 0 || index >= list.size()) return;
        ArtilleryMarkerStore.Marker marker = list.get(index);
        this.setTargetAndAim(marker.x(), marker.z(), true);
    }

    private void deleteSavedMarker(int index) {
        ModMessages.INSTANCE.sendToServer(new ArtilleryMarkerPacket(ArtilleryMarkerPacket.ACTION_DELETE, index, 0, 0));
    }

    private void setTargetAndAim(int x, int z, boolean centerView) {
        this.target = new BlockPos(x, 0, z);
        if (centerView) {
            int maxPan = ArtilleryEntity.maxRange() + 96;
            this.viewX = Mth.clamp(x, this.piece.getBlockX() - maxPan, this.piece.getBlockX() + maxPan);
            this.viewZ = Mth.clamp(z, this.piece.getBlockZ() - maxPan, this.piece.getBlockZ() + maxPan);
            this.sampleTerrain();
        }
        ModMessages.INSTANCE.sendToServer(new ArtilleryAimPacket(this.piece.getId(), x, z));
    }

    private void sampleTerrain() {
        if (this.minecraft == null || this.minecraft.level == null) return;
        Level level = this.minecraft.level;
        int maxRange = ArtilleryEntity.maxRange();
        double maxBand = Math.max(1.25D, this.sampleStep * 0.65D);
        double minBand = Math.max(1.0D, this.sampleStep * 0.55D);
        this.colors = new int[this.rows * this.columns];
        this.originX = this.viewX - (this.columns / 2) * this.sampleStep;
        this.originZ = this.viewZ - (this.rows / 2) * this.sampleStep;
        for (int cellZ = 0; cellZ < this.rows; cellZ++) {
            int z = this.originZ + cellZ * this.sampleStep;
            for (int cellX = 0; cellX < this.columns; cellX++) {
                int x = this.originX + cellX * this.sampleStep;
                double dist = Math.hypot(x + 0.5D - this.piece.getX(), z + 0.5D - this.piece.getZ());
                int color = UNLOADED;
                BlockPos column = new BlockPos(x, 0, z);
                if (level.hasChunkAt(column)) {
                    int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z) - 1;
                    BlockPos surface = column.atY(y);
                    int rgb = level.getBlockState(surface).getMapColor(level, surface).col;
                    if (rgb == 0) rgb = 0x394552;
                    int shade = 215 + Mth.clamp(y - 60, -42, 40);
                    color = 0xFF000000 | (((rgb >> 16 & 255) * shade / 255) << 16)
                            | (((rgb >> 8 & 255) * shade / 255) << 8) | ((rgb & 255) * shade / 255);
                    if (!ArtilleryBallistics.isRangeAllowed(dist, maxRange)) {
                        color = 0xFF000000 | ((color & 0x00FEFEFE) >> 1);
                    }
                }
                if (Math.abs(dist - maxRange) <= maxBand) {
                    color = blendColor(color, 0xFFD95B43, 0.72F);
                } else if (Math.abs(dist - ArtilleryBallistics.MIN_RANGE) <= minBand) {
                    color = blendColor(color, 0xFFE3A648, 0.58F);
                }
                this.colors[cellZ * this.columns + cellX] = color;
            }
        }
    }

    private static int blendColor(int bg, int fg, float alpha) {
        int r = (int) Mth.lerp(alpha, (bg >> 16) & 255, (fg >> 16) & 255);
        int g = (int) Mth.lerp(alpha, (bg >> 8) & 255, (fg >> 8) & 255);
        int b = (int) Mth.lerp(alpha, bg & 255, fg & 255);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private boolean isTargetLoadedAndInPath(int targetX, int targetZ) {
        if (this.minecraft == null || this.minecraft.level == null) return false;
        Level level = this.minecraft.level;
        for (ArtilleryBallistics.SamplePoint p : ArtilleryBallistics.trajectorySamples(
                this.piece.getX(), this.piece.getZ(), targetX, targetZ)) {
            if (!level.hasChunkAt(new BlockPos(p.blockX(), 0, p.blockZ()))) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void tick() {
        if (this.minecraft == null || this.minecraft.player == null || this.minecraft.player.getVehicle() != this.piece) {
            this.onClose();
            return;
        }
        this.refreshMarkerWidgets();
        this.fireButton.active = this.target != null
                && this.piece.gunHealth() > 0 && this.piece.traverseHealth() > 0 && this.piece.reloadTicks() == 0
                && (this.piece.ammunition() > 0 || this.minecraft.player.getAbilities().instabuild);
        if (this.piece.tickCount % 10 == 0) this.sampleTerrain();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        int right = this.left + this.columns * this.cellPixels;
        int bottom = this.top + this.rows * this.cellPixels;
        int mapCenterX = (this.left + right) / 2;

        if (this.colors != null) {
            for (int row = 0; row < this.rows; row++) {
                int y = this.top + row * this.cellPixels;
                for (int col = 0; col < this.columns; col++) {
                    int x = this.left + col * this.cellPixels;
                    graphics.fill(x, y, x + this.cellPixels, y + this.cellPixels, this.colors[row * this.columns + col]);
                }
            }
        }
        graphics.renderOutline(this.left - 1, this.top - 1, right - this.left + 2, bottom - this.top + 2, 0xFFB5BFA9);

        int maxRange = ArtilleryEntity.maxRange();
        if (this.minecraft != null && this.minecraft.level != null) {
            for (LivingEntity vehicle : this.minecraft.level.getEntitiesOfClass(LivingEntity.class,
                    this.piece.getBoundingBox().inflate(maxRange, 128, maxRange),
                    entity -> entity != this.piece && entity.isAlive() && (entity instanceof T72TankEntity
                            || entity instanceof HelicopterEntity || entity instanceof ArtilleryEntity))) {
                this.marker(graphics, vehicle.getBlockX(), vehicle.getBlockZ(),
                        vehicle instanceof HelicopterEntity ? 0xFFCBE7F4 : 0xFFDB8A75, null);
            }
        }

        // Draw saved markers on the map
        List<ArtilleryMarkerStore.Marker> saved = this.markers();
        for (int i = 0; i < saved.size(); i++) {
            ArtilleryMarkerStore.Marker m = saved.get(i);
            this.marker(graphics, m.x(), m.z(), 0xFF55E0FF, String.valueOf(i + 1));
        }

        // Artillery icon & target aim line + target box
        this.marker(graphics, this.piece.getBlockX(), this.piece.getBlockZ(), 0xFFB1D4FF, null);
        if (this.target != null) {
            this.drawAimLine(graphics, this.piece.getBlockX(), this.piece.getBlockZ(), this.target.getX(), this.target.getZ());
            double dist = Math.hypot(this.target.getX() + 0.5 - this.piece.getX(), this.target.getZ() + 0.5 - this.piece.getZ());
            boolean inRange = ArtilleryBallistics.isRangeAllowed(dist, maxRange);
            if (inRange) this.drawDispersion(graphics, this.target.getX(), this.target.getZ(),
                    ArtilleryBallistics.dispersionRadius(dist));
            this.marker(graphics, this.target.getX(), this.target.getZ(), inRange ? 0xFFFFCD79 : 0xFFFF5A5A, null);
        }

        // Header & status
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 5, 0xFFFFFF);
        graphics.drawCenteredString(this.font, Component.translatable("screen.t72mod.artillery_status",
                this.piece.ammunition(), this.piece.gunHealth(), this.piece.traverseHealth(),
                ArtilleryBallistics.MIN_RANGE, maxRange), this.width / 2, 16, 0xE1E5D7);

        // Right marker panel label + zoom info
        graphics.drawString(this.font, Component.translatable("screen.t72mod.markers_header", saved.size(), ArtilleryMarkerStore.MAX_MARKERS),
                this.panelX, this.top + 2, 0xFFE3D899);
        graphics.drawString(this.font, Component.translatable("screen.t72mod.zoom_label", this.sampleStep),
                this.panelX, this.top + 14 + ArtilleryMarkerStore.MAX_MARKERS * 21 + 74, 0xFFB8C4B0);

        // Target & Range summary + Reload bar below map
        this.renderTargetAndReload(graphics, mapCenterX, bottom, maxRange);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private void drawDispersion(GuiGraphics graphics, int x, int z, double radius) {
        if (radius < .5) return;
        int previousX = Integer.MIN_VALUE;
        int previousZ = Integer.MIN_VALUE;
        for (int i = 0; i < 64; i++) {
            double angle = i * Math.PI / 32;
            int col = Math.floorDiv(x + (int) Math.round(Math.cos(angle) * radius) - this.originX, this.sampleStep);
            int row = Math.floorDiv(z + (int) Math.round(Math.sin(angle) * radius) - this.originZ, this.sampleStep);
            if (col < 0 || row < 0 || col >= this.columns || row >= this.rows
                    || col == previousX && row == previousZ) continue;
            int px = this.left + col * this.cellPixels + this.cellPixels / 2;
            int py = this.top + row * this.cellPixels + this.cellPixels / 2;
            graphics.fill(px, py, px + 2, py + 2, 0xC6FFC46C);
            previousX = col;
            previousZ = row;
        }
    }

    private void renderTargetAndReload(GuiGraphics graphics, int centerX, int bottom, int maxRange) {
        if (this.target == null) {
            graphics.drawCenteredString(this.font, Component.translatable("screen.t72mod.artillery_controls", maxRange),
                    centerX, bottom + 3, 0xE1E5D7);
        } else {
            double dist = Math.hypot(this.target.getX() + 0.5 - this.piece.getX(), this.target.getZ() + 0.5 - this.piece.getZ());
            int d = Mth.floor(dist + 0.5);
            Component status;
            int color;
            if (!ArtilleryBallistics.isRangeAllowed(dist, maxRange)) {
                status = Component.translatable("screen.t72mod.artillery_target_out", this.target.getX(), this.target.getZ(), d, maxRange);
                color = 0xFFFF6E6E;
            } else if (!this.isTargetLoadedAndInPath(this.target.getX(), this.target.getZ())) {
                status = Component.translatable("screen.t72mod.artillery_target_unloaded", this.target.getX(), this.target.getZ(), d);
                color = 0xFFFFB74D;
            } else {
                status = Component.translatable("screen.t72mod.artillery_target_spread", this.target.getX(), this.target.getZ(),
                        d, maxRange, Math.round(ArtilleryBallistics.dispersionRadius(dist)));
                color = 0xFF98F598;
            }
            graphics.drawCenteredString(this.font, status, centerX, bottom + 3, color);
        }

        // Reload progress bar & explicit text always visible
        int reload = this.piece.reloadTicks();
        int barW = 148;
        int barX = centerX - barW / 2;
        int barY = bottom + 15;
        graphics.fill(barX, barY, barX + barW, barY + 9, 0xCC1E2420);
        if (reload > 0) {
            float progress = Mth.clamp(1.0F - (float) reload / RELOAD_MAX_TICKS, 0.0F, 1.0F);
            int fillW = Math.round((barW - 2) * progress);
            graphics.fill(barX + 1, barY + 1, barX + 1 + fillW, barY + 8, 0xFFDD8A2E);
            graphics.drawCenteredString(this.font,
                    Component.translatable("screen.t72mod.artillery_reload_precise", String.format("%.1f", reload / 20.0F)),
                    centerX, barY + 1, 0xFFFFFFFF);
        } else {
            graphics.fill(barX + 1, barY + 1, barX + barW - 1, barY + 8, 0xFF3E8C47);
            graphics.drawCenteredString(this.font, Component.translatable("screen.t72mod.artillery_ready"),
                    centerX, barY + 1, 0xFFFFFFFF);
        }
        graphics.renderOutline(barX, barY, barW, 9, 0xFF7B8778);
    }

    private void drawAimLine(GuiGraphics graphics, int x0, int z0, int x1, int z1) {
        int col0 = Math.floorDiv(x0 - this.originX, this.sampleStep);
        int row0 = Math.floorDiv(z0 - this.originZ, this.sampleStep);
        int col1 = Math.floorDiv(x1 - this.originX, this.sampleStep);
        int row1 = Math.floorDiv(z1 - this.originZ, this.sampleStep);
        int steps = Math.max(1, Math.max(Math.abs(col1 - col0), Math.abs(row1 - row0)));
        for (int s = 1; s < steps; s += 2) {
            double t = (double) s / steps;
            int col = Mth.floor(Mth.lerp(t, col0, col1));
            int row = Mth.floor(Mth.lerp(t, row0, row1));
            if (col < 0 || col >= this.columns || row < 0 || row >= this.rows) continue;
            int px = this.left + col * this.cellPixels + this.cellPixels / 2;
            int py = this.top + row * this.cellPixels + this.cellPixels / 2;
            graphics.fill(px, py, px + 1, py + 1, 0xAAFFE382);
        }
    }

    private void marker(GuiGraphics graphics, int x, int z, int color, String label) {
        int col = Math.floorDiv(x - this.originX, this.sampleStep);
        int row = Math.floorDiv(z - this.originZ, this.sampleStep);
        if (col < 0 || col >= this.columns || row < 0 || row >= this.rows) return;
        int px = this.left + col * this.cellPixels;
        int py = this.top + row * this.cellPixels;
        graphics.renderOutline(px - 2, py - 2, this.cellPixels + 4, this.cellPixels + 4, color);
        if (label != null) {
            graphics.drawString(this.font, label, px + this.cellPixels + 3, py - 2, color);
        }
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (this.mouseOverMap(x, y)) {
            if (button == 0) {
                int col = ((int) x - this.left) / this.cellPixels;
                int row = ((int) y - this.top) / this.cellPixels;
                int targetX = this.originX + col * this.sampleStep;
                int targetZ = this.originZ + row * this.sampleStep;
                this.setTargetAndAim(targetX, targetZ, false);
                return true;
            } else if (button == 1 || button == 2) {
                this.draggingMap = true;
                this.dragAccumX = 0;
                this.dragAccumY = 0;
                return true;
            }
        }
        return super.mouseClicked(x, y, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (this.draggingMap && (button == 1 || button == 2)) {
            this.dragAccumX += dragX;
            this.dragAccumY += dragY;
            int stepPx = Math.max(1, this.cellPixels);
            int shiftCols = (int) (this.dragAccumX / stepPx);
            int shiftRows = (int) (this.dragAccumY / stepPx);
            if (shiftCols != 0 || shiftRows != 0) {
                this.dragAccumX -= shiftCols * stepPx;
                this.dragAccumY -= shiftRows * stepPx;
                this.panBy(-shiftCols * this.sampleStep, -shiftRows * this.sampleStep);
            }
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 1 || button == 2) {
            this.draggingMap = false;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double delta) {
        if (!this.mouseOverMap(x, y)) return super.mouseScrolled(x, y, delta);
        this.adjustZoom(delta > 0 ? -1 : 1);
        return true;
    }

    private boolean mouseOverMap(double x, double y) {
        return x >= this.left && x < this.left + this.columns * this.cellPixels
                && y >= this.top && y < this.top + this.rows * this.cellPixels;
    }

    private void panBy(int dx, int dz) {
        int edge = ArtilleryEntity.maxRange() + 96;
        this.viewX = Mth.clamp(this.viewX + dx, this.piece.getBlockX() - edge, this.piece.getBlockX() + edge);
        this.viewZ = Mth.clamp(this.viewZ + dz, this.piece.getBlockZ() - edge, this.piece.getBlockZ() + edge);
        this.sampleTerrain();
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == GLFW.GLFW_KEY_1) { this.selectSavedMarker(0); return true; }
        if (key == GLFW.GLFW_KEY_2) { this.selectSavedMarker(1); return true; }
        if (key == GLFW.GLFW_KEY_3) { this.selectSavedMarker(2); return true; }

        int step = Math.max(8, this.sampleStep * 4);
        int dx = (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_A) ? -step
                : (key == GLFW.GLFW_KEY_RIGHT || key == GLFW.GLFW_KEY_D) ? step : 0;
        int dz = (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_W) ? -step
                : (key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_S) ? step : 0;
        if (dx != 0 || dz != 0) {
            this.panBy(dx, dz);
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
