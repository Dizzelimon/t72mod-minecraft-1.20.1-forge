package com.example.t72mod.entity;

import com.example.t72mod.T72Mod;
import com.example.t72mod.compat.TaczCompat;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

public final class TaczGunStand extends Entity {
    public static final float TRAVERSE = 85F;
    private UUID owner;
    private int stability = 20;

    public TaczGunStand(EntityType<? extends TaczGunStand> type, Level level) { super(type, level); }

    public void setOwner(Player player) { this.owner = player == null ? null : player.getUUID(); }

    @Override protected void defineSynchedData() {}
    @Override public boolean isPickable() { return this.isAlive(); }
    @Override public boolean canBeCollidedWith() { return this.isAlive(); }

    @Override protected boolean canAddPassenger(Entity entity) {
        return entity instanceof Player && this.getPassengers().isEmpty();
    }

    @Override protected void positionRider(Entity rider, MoveFunction move) {
        Vec3 seat = AirframeLayout.world(this.position(), this.getYRot(), 0, .25 + rider.getMyRidingOffset(), -.49);
        move.accept(rider, seat.x, seat.y, seat.z);
    }

    @Override public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        Vec3 seat = AirframeLayout.world(this.position(), this.getYRot(), 0, 0, -1.1);
        return this.level().noCollision(passenger, passenger.getBoundingBox().move(seat.subtract(passenger.position())))
                ? seat : super.getDismountLocationForPassenger(passenger);
    }

    public boolean canAim(Player player) {
        return this.hasPassenger(player) && TaczCompat.isGun(player.getMainHandItem())
                && Math.abs(Mth.wrapDegrees(player.getYRot() - this.getYRot())) <= TRAVERSE
                && player.getXRot() > -52 && player.getXRot() < 38;
    }

    @Override public InteractionResult interact(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND || player.isPassenger()) return InteractionResult.PASS;
        ItemStack held = player.getItemInHand(hand);
        if (player.isShiftKeyDown() && held.isEmpty() && !this.isVehicle()
                && (player.getUUID().equals(this.owner) || player.hasPermissions(2))) {
            if (!this.level().isClientSide) {
                ItemStack item = new ItemStack(T72Mod.GUN_STAND_KIT.get());
                if (!player.getInventory().add(item)) return InteractionResult.FAIL;
                this.discard();
            }
        } else if (!player.isShiftKeyDown() && !this.isVehicle() && (held.isEmpty() || TaczCompat.isGun(held))) {
            if (!this.level().isClientSide && player.startRiding(this, true)) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, .7F, 1.1F);
                player.displayClientMessage(Component.translatable("message.t72mod.stand_ready"), true);
            }
        } else return InteractionResult.PASS;
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    @Override public void tick() {
        super.tick();
        if (!this.level().isClientSide && !this.onGround()) {
            double down = Math.max(-.5, this.getDeltaMovement().y - .08);
            this.move(MoverType.SELF, new Vec3(0, down, 0));
            this.setDeltaMovement(0, this.verticalCollision ? 0 : down, 0);
        }
    }

    @Override public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide || !this.isAlive() || !Float.isFinite(amount) || amount <= 0) return false;
        this.stability -= Math.max(1, (int) amount);
        if (this.stability <= 0) {
            this.ejectPassengers();
            this.discard();
        }
        return true;
    }

    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }

    @Override protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.hasUUID("Owner")) this.owner = tag.getUUID("Owner");
        if (tag.contains("Stability")) this.stability = Mth.clamp(tag.getInt("Stability"), 1, 20);
    }

    @Override protected void addAdditionalSaveData(CompoundTag tag) {
        if (this.owner != null) tag.putUUID("Owner", this.owner);
        tag.putInt("Stability", this.stability);
    }
}
