package com.example.t72mod.client.renderer;

import com.example.t72mod.client.model.VehicleMesh;
import com.example.t72mod.entity.FieldVehicleEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import static com.example.t72mod.client.model.VehicleMesh.Section;

public final class FieldVehicleRenderer extends EntityRenderer<FieldVehicleEntity> {
    private static final int FRAME = 0x2c302b, STEEL = 0x4a4c42, GLASS = 0x3a4f56;
    private final VehicleMesh body = new VehicleMesh();
    private final VehicleMesh workshopClosed = new VehicleMesh();
    private final VehicleMesh workshopOpen = new VehicleMesh();
    private final VehicleMesh sensor = new VehicleMesh();
    private final VehicleMesh tire = new VehicleMesh();
    private final VehicleMesh rim = new VehicleMesh();
    private final double[] axles;
    private final double tireY, tireX;

    public FieldVehicleRenderer(EntityRendererProvider.Context context, boolean scout) {
        super(context);
        this.axles = scout ? new double[]{1.94,-1.70} : new double[]{2.56,-1.60,-2.73};
        this.tireY = scout ? .49 : .57;
        this.tireX = scout ? 1.19 : 1.10;
        this.shadowRadius = scout ? 1.2F : 1.5F;
        this.buildWheels();
        if (scout) this.buildScout();
        else this.buildTruck();
    }

    private void buildWheels() {
        this.tire.tube(at(-.19,0,0),at(-.14,0,0),tireY*.87,tireY,14,0x272b28);
        this.tire.tube(at(-.14,0,0),at(.14,0,0),tireY,tireY,14,0x313632);
        this.tire.tube(at(.14,0,0),at(.19,0,0),tireY,tireY*.87,14,0x272b28);
        this.rim.tube(at(.19,0,0),at(.225,0,0),tireY*.67,tireY*.62,14,0x555850);
        this.rim.tube(at(.225,0,0),at(.253,0,0),tireY*.26,tireY*.25,9,0x676a5c);
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3, y = Math.cos(a)*tireY*.45, z = Math.sin(a)*tireY*.45;
            this.rim.box(.225,y-.03,z-.03,.248,y+.03,z+.03,0x323530);
        }
        for (int i = 0; i < 12; i++) {
            double a = i * Math.PI / 6;
            Vec3 outer = at(0, Math.cos(a)*tireY*.99, Math.sin(a)*tireY*.99);
            this.tire.tube(outer.add(-.13,0,0),outer.add(.13,0,0),.021,.021,5,FRAME);
        }
    }

    private void buildScout() {
        int olive = 0x586445, panel = 0x657050, dark = 0x3d4939;
        this.body.box(-.85,.57,-2.66,.85,.80,2.89,FRAME);
        this.body.hull(12,0,(s,p)->p>=6 && p!=11?dark:((s+p)%5==0?panel:olive),
                new Section(-2.91,.68,.68,1.38),new Section(-2.45,1.22,.62,1.58),
                new Section(-1.52,1.28,.59,1.84),new Section(.93,1.28,.61,1.95),
                new Section(2.56,1.10,.64,1.42),new Section(2.92,.76,.75,1.29));
        this.body.hull(12,0,(s,p)->p<5?panel:olive,new Section(-1.97,.74,1.33,1.63),
                new Section(-1.38,.97,1.30,2.35),new Section(.66,.96,1.35,2.38),
                new Section(1.40,.88,1.43,1.92));
        for (int side : new int[]{-1,1}) {
            double x = side*.49;
            this.body.face(at(x-.24,1.90,1.32),at(x+.24,1.90,1.32),at(x+.20,2.19,1.01),
                    at(x-.20,2.19,1.01),STEEL);
            this.body.face(at(x-.17,1.969,1.285),at(x+.17,1.969,1.285),at(x+.15,2.105,1.145),
                    at(x-.15,2.105,1.145),0x34494b);
            this.body.box(x-.245,2.31,-.07,x+.245,2.39,.59,panel);
            this.body.tube(at(x-.12,2.394,.13),at(x+.12,2.394,.13),.035,.028,6,FRAME);
            this.body.tube(at(side*.87,1.28,2.65),at(side*.87,1.28,2.86),.118,.10,10,FRAME);
            this.body.tube(at(side*.87,1.28,2.855),at(side*.87,1.28,2.91),.085,.079,10,0xbfb38c);
            this.body.box(side*1.01-.08,1.13,-2.707,side*1.01+.08,1.27,-2.63,0x90463e);
            this.body.tube(at(side*.77,1.01,2.91),at(side*.80,1.14,3.03),.056,.04,8,STEEL);
            this.body.tube(at(side*1.16,1.17,-2.0),at(side*1.30,1.19,2.2),.059,.059,6,0x374034);
            this.body.tube(at(side*.91,1.64,-1.61),at(side*.92,1.57,-2.47),.051,.035,8,STEEL);
            for (int i=0;i<7;i++) {
                double z=-2.10+i*.116;
                this.body.box(x-.28,1.910,z,x+.27,1.939,z+.035,0x454c36);
            }
        }
        this.body.box(-.76,.70,2.86,.76,.88,3.02,STEEL);
        this.body.tube(at(-.46,1.26,2.92),at(.46,1.26,2.92),.045,.045,8,FRAME);
        this.body.tube(at(.59,2.18,-1.49),at(.68,3.08,-1.79),.022,.009,6,STEEL);
        this.sensor.hull(10,0,(s,p)->p<5?panel:dark,new Section(-.58,.46,.02,.22),
                new Section(-.35,.61,.01,.50),new Section(.40,.55,.01,.49),new Section(.59,.35,.03,.35));
        this.sensor.box(-.29,.16,.548,.29,.33,.591,STEEL);
        this.sensor.tube(at(-.17,.24,.585),at(-.17,.24,.689),.083,.065,10,0x374d4c);
        this.sensor.tube(at(.14,.24,.585),at(.14,.24,.667),.058,.051,10,0x344648);
    }

    private void buildTruck() {
        int base=0x626954, panel=0x777d66;
        this.body.box(-.86,.63,-3.56,.86,.89,3.40,FRAME);
        this.body.box(-.71,.93,1.54,.71,1.50,3.32,base);
        this.body.box(-.93,.81,3.32,.93,1.03,3.48,STEEL);
        this.body.box(-.62,1.08,3.31,.62,1.41,3.36,FRAME);
        for (int i = 0; i < 6; i++) {
            double x = -.54+i*.21;
            this.body.box(x,1.11,3.359,x+.036,1.40,3.39,STEEL);
        }
        this.body.box(-1.04,.99,0,1.04,1.92,1.68,base);
        this.body.hull(8,0,(s,p) -> base,
                new Section(-.04,1.04,1.74,2.69),new Section(1.22,1.04,1.74,2.64),
                new Section(1.68,1.01,1.68,2.18));
        this.body.face(at(-.87,1.88,1.688),at(.87,1.88,1.688),at(.77,2.51,1.345),at(-.77,2.51,1.345),GLASS);
        this.body.tube(at(0,1.88,1.695),at(0,2.52,1.34),.029,.029,6,FRAME);
        for (int side : new int[]{-1,1}) {
            double x = side*1.105;
            this.body.box(Math.min(x,x-side*.08),1.94,.13,Math.max(x,x-side*.08),2.38,1.17,GLASS);
            this.body.tube(at(side*.94,2.1,1.44),at(side*1.31,2.12,1.53),.035,.035,6,FRAME);
            this.body.box(side*1.31-.09,1.98,1.48,side*1.31+.09,2.27,1.57,FRAME);
        }
        this.body.box(-1.19, .98, -3.58, 1.19, 1.30, -.21, FRAME);
        this.body.box(-1.20, 2.82, -3.61, 1.20, 2.98, -.18, panel);
        this.body.box(-1.19, 1.29, -.34, 1.19, 2.82, -.20, base);
        this.body.box(-1.19, 1.27, -3.57, -1.02, 2.81, -.35, base);
        this.body.box(1.02, 1.28, -3.60, 1.19, 2.80, -2.92, base);
        this.body.box(1.02, 1.28, -1.05, 1.19, 2.80, -.33, base);
        this.body.box(1.02, 2.66, -2.92, 1.19, 2.78, -1.05, base);
        this.body.box(-.94, 1.29, -3.55, -.51, 2.53, -.42, 0x535a50);
        this.body.box(.64, 1.32, -2.69, 1.016, 1.85, -1.22, 0x6b604c);
        this.body.box(.62, 1.85, -2.72, 1.016, 1.94, -1.19, 0x4e5045);
        this.body.box(.85, 2.44, -2.71, 1.016, 2.49, -1.23, 0xf0d8a7);
        this.body.box(-.62, .72, -3.91, .62, .82, -3.60, STEEL);
        this.body.tube(at(0, .50, -3.61), at(0, .50, -3.87), .097, .073, 8, FRAME);
        for (int i = 0; i < 4; i++) {
            double z = -.67 - (.72 * i);
            this.body.box(-.508, 1.43, z - .17, -.466, 1.48, z + .17, STEEL);
            this.body.box(-1.207, 1.62, z - .245, -1.186, 2.62, z + .245, panel);
        }
        workshopClosed.box(1.04, 1.31, -2.916, 1.21, 2.653, -1.056, panel);
        workshopClosed.box(1.211, 1.60, -2.11, 1.247, 1.69, -1.89, STEEL);
        workshopOpen.box(1.08, 1.91, -2.917, 2.01, 2.00, -1.054, panel);
        workshopOpen.tube(at(1.91, 1.96, -2.79), at(1.18, 2.49, -2.79), .019, .019, 6, STEEL);
        workshopOpen.tube(at(1.91, 1.96, -1.18), at(1.18, 2.49, -1.18), .019, .019, 6, STEEL);
        for (int side : new int[]{-1, 1}) {
            double x = side * .58;
            workshopClosed.box(x - .54, 1.31, -3.65, x + .54, 2.79, -3.57, base);
            workshopClosed.box(x - .10, 1.90, -3.675, x + .10, 1.97, -3.647, STEEL);
            workshopOpen.box(side * 1.13 - .059, 1.31, -4.60, side * 1.13 + .059, 2.79, -3.56, panel);
        }
        this.lamps(3.37,.68,.10);
        for (int side : new int[]{-1,1}) {
            double x = side*1.17;
            this.body.tube(at(x,.96,.12),at(x,.96,1.54),.065,.060,8,STEEL);
            this.body.tube(at(side*.85,1.53,-.15),at(side*.85,3.04,-.21),.054,.051,8,FRAME);
            this.body.box(x-.095,1.08,-3.71,x+.095,1.23,-3.63,0x8b493a);
            for (int i=0;i<4;i++) {
                double z=-.48-i*.70;
                this.body.tube(at(side*1.21,1.54,z),at(side*1.19,2.48,z),.025,.021,6,0x565248);
            }
        }
    }

    private void lamps(double z,double x,double half) {
        for (double side : new double[]{-x,x})
            this.body.box(side-half,1.08,z,side+half,1.26,z+.057,0xbdb394);
    }

    private static Vec3 at(double x,double y,double z) { return new Vec3(x,y,z); }

    @Override public ResourceLocation getTextureLocation(FieldVehicleEntity entity) { return HelicopterRenderer.SURFACE; }

    @Override public boolean shouldRender(FieldVehicleEntity v, Frustum camera, double x, double y, double z) {
        return v.shouldRender(x,y,z) && camera.isVisible(v.getBoundingBox().inflate(3,1,3));
    }

    @Override public void render(FieldVehicleEntity v, float yaw, float partialTick, PoseStack pose,
                                 MultiBufferSource buffers, int light) {
        var out = buffers.getBuffer(RenderType.entityCutoutNoCull(this.getTextureLocation(v)));
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-Mth.rotLerp(partialTick, v.yRotO, v.getYRot())));
        this.body.draw(pose.last(),out,light);
        if (!v.scout()) (v.workshopOpen() ? this.workshopOpen : this.workshopClosed).draw(pose.last(),out,light);
        for (int i = 0; i < this.axles.length; i++) {
            for (int side : new int[]{-1,1}) {
                pose.pushPose();
                pose.translate(this.tireX*side,this.tireY,this.axles[i]);
                pose.mulPose(Axis.XP.rotationDegrees(v.wheelAngle()));
                pose.mulPose(Axis.YP.rotationDegrees(side < 0 ? 180 : 0));
                if (v.wheels() > 0 || i > 0) this.tire.draw(pose.last(),out,light);
                this.rim.draw(pose.last(),out,light);
                pose.popPose();
            }
        }
        if (v.scout()) {
            pose.pushPose();
            pose.translate(0,2.32,-.63);
            if (v.scanning()) pose.mulPose(Axis.YP.rotationDegrees((v.tickCount+partialTick)*7));
            this.sensor.draw(pose.last(),out,light);
            pose.popPose();
        }
        pose.popPose();
        super.render(v,yaw,partialTick,pose,buffers,light);
    }
}
