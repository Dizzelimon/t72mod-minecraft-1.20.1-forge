package com.example.t72mod.client.renderer;

import com.example.t72mod.entity.FieldVehicleEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public final class FieldVehicleRenderer extends EntityRenderer<FieldVehicleEntity> {
    public static final ModelLayerLocation SCOUT = layer("scout_car");
    public static final ModelLayerLocation TRUCK = layer("workshop_truck");
    private final ModelPart root;
    private final ModelPart[] wheels;
    private final ModelPart sensor;
    private final ResourceLocation texture;

    private static ModelLayerLocation layer(String n) {
        return new ModelLayerLocation(new ResourceLocation("t72mod", n), "main");
    }

    public FieldVehicleRenderer(EntityRendererProvider.Context ctx, boolean scout) {
        super(ctx);
        this.root = ctx.bakeLayer(scout ? SCOUT : TRUCK);
        this.sensor = this.root.getChild("sensor");
        this.wheels = new ModelPart[scout ? 4 : 6];
        for (int i = 0; i < this.wheels.length; i++) this.wheels[i] = root.getChild("wheel_" + i);
        this.texture = new ResourceLocation("t72mod", "textures/entity/" + (scout ? "scout_car" : "workshop_truck") + ".png");
        this.shadowRadius = 1.3F;
    }

    @Override public ResourceLocation getTextureLocation(FieldVehicleEntity e) { return texture; }

    @Override public void render(FieldVehicleEntity v, float yaw, float pt, PoseStack pose,
                                 MultiBufferSource buffers, int light) {
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(180 - Mth.rotLerp(pt, v.yRotO, v.getYRot())));
        for (int i = 0; i < this.wheels.length; i++) {
            this.wheels[i].xRot = v.wheelAngle() * Mth.DEG_TO_RAD;
            this.wheels[i].visible = v.wheels() > 0 || i >= 2;
        }
        this.sensor.yRot = v.scanning() ? (v.tickCount + pt) * 0.12F : 0;
        this.root.render(pose, buffers.getBuffer(RenderType.entityCutoutNoCull(texture)), light, OverlayTexture.NO_OVERLAY);
        pose.popPose();
        super.render(v, yaw, pt, pose, buffers, light);
    }

    public static LayerDefinition model(boolean scout) {
        var mesh = new MeshDefinition();
        var root = mesh.getRoot();
        var hull = CubeListBuilder.create()
                .texOffs(0, 0).addBox(-14, 6, -27, 28, 8, 54)
                .texOffs(100, 54).addBox(-12, 8, -29, 24, 3, 3)
                .texOffs(0, 87).addBox(-12, 13, -27.5F, 4, 3, 1)
                .texOffs(0, 87).addBox(8, 13, -27.5F, 4, 3, 1);
        if (scout) {
            hull.texOffs(0, 0).addBox(-14, 14, -25, 28, 5, 48)
                    .texOffs(8, 17).addBox(-12, 18, -13, 24, 7, 27)
                    .texOffs(110, 74).addBox(-10, 20, -14, 20, 4, 1);
        } else {
            hull.texOffs(0, 0).addBox(-12, 14, -26, 24, 7, 15)
                    .texOffs(7, 31).addBox(-14, 18, -12, 28, 14, 18)
                    .texOffs(110, 74).addBox(-12, 22, -13, 24, 6, 1)
                    .texOffs(0, 0).addBox(-16, 14, 6, 32, 20, 24)
                    .texOffs(99, 49).addBox(-13, 16, 30, 26, 16, 1);
        }
        root.addOrReplaceChild("hull", hull, PartPose.ZERO);
        int[] axles = scout ? new int[]{-19, 17} : new int[]{-20, 11, 23};
        for (int i = 0; i < axles.length * 2; i++) {
            int side = i % 2 == 0 ? -1 : 1;
            root.addOrReplaceChild("wheel_" + i, CubeListBuilder.create()
                    .texOffs(0, 108).addBox(-3, -6, -6, 6, 12, 12)
                    .texOffs(50, 103).addBox(side == -1 ? -3.7F : 2.7F, -3.5F, -3.5F, 1, 7, 7),
                    PartPose.offset(side * 15, 6, axles[i / 2]));
        }
        root.addOrReplaceChild("sensor", scout ? CubeListBuilder.create().texOffs(16, 0).addBox(-2, 0, -2, 4, 9, 4)
                .texOffs(115, 75).addBox(-10, 8, -2, 20, 3, 4) : CubeListBuilder.create(), PartPose.offset(0, 25, 3));
        return LayerDefinition.create(mesh, 256, 152);
    }
}
