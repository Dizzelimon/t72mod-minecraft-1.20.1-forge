package com.example.t72mod.client.renderer;

import com.example.t72mod.client.model.VehicleMesh;
import com.example.t72mod.entity.FieldVehicleEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import static com.example.t72mod.client.model.VehicleMesh.Section;

public final class FieldVehicleRenderer extends EntityRenderer<FieldVehicleEntity> {
    private static final int FRAME = 0x2c302b, STEEL = 0x4a4c42, GLASS = 0x3a4f56;
    private final VehicleMesh body = new VehicleMesh();
    private final VehicleMesh sensor = new VehicleMesh();
    private final VehicleMesh tire = new VehicleMesh();
    private final VehicleMesh rim = new VehicleMesh();
    private final double[] axles;
    private final double tireY, tireX;

    public FieldVehicleRenderer(EntityRendererProvider.Context context, boolean scout) {
        super(context);
        this.axles = scout ? new double[]{1.85,-1.62} : new double[]{2.56,-1.60,-2.73};
        this.tireY = scout ? .49 : .57;
        this.tireX = scout ? .99 : 1.10;
        this.shadowRadius = scout ? 1.2F : 1.5F;
        this.buildWheels();
        if (scout) this.buildScout();
        else this.buildTruck();
    }

    private void buildWheels() {
        this.tire.tube(at(-.19,0,0),at(-.14,0,0),tireY*.87,tireY,14,0x272b28);
        this.tire.tube(at(-.14,0,0),at(.14,0,0),tireY,tireY,14,0x313632);
        this.tire.tube(at(.14,0,0),at(.19,0,0),tireY,tireY*.87,14,0x272b28);
        this.rim.tube(at(.19,0,0),at(.225,0,0),tireY*.67,tireY*.62,14,0x555850);
        this.rim.tube(at(.225,0,0),at(.253,0,0),tireY*.26,tireY*.25,9,0x676a5c);
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3, y = Math.cos(a)*tireY*.45, z = Math.sin(a)*tireY*.45;
            this.rim.box(.225,y-.03,z-.03,.248,y+.03,z+.03,0x323530);
        }
        for (int i = 0; i < 12; i++) {
            double a = i * Math.PI / 6;
            Vec3 outer = at(0, Math.cos(a)*tireY*.99, Math.sin(a)*tireY*.99);
            this.tire.tube(outer.add(-.13,0,0),outer.add(.13,0,0),.021,.021,5,FRAME);
        }
    }

    private void buildScout() {
        int base = 0x555e44, dark = 0x414a39;
        this.body.hull(8, 0,(s,p) -> p < 4 || p == 7 ? base : dark,
                new Section(-2.48,.82,.62,1.26),new Section(-2.04,1.11,.52,1.51),
                new Section(1.70,1.08,.49,1.48),new Section(2.39,.92,.61,1.34),new Section(2.73,.68,.66,1.0));
        this.body.hull(8, 0,(s,p) -> (p == 0 || p == 3) && s == 1 ? GLASS : base,
                new Section(-1.89,.88,1.29,1.56),new Section(-1.30,.96,1.29,2.15),
                new Section(.57,.93,1.37,2.18),new Section(1.38,.87,1.27,1.46));
        this.body.face(at(-.69,1.57,1.275),at(.69,1.57,1.275),at(.53,2.02,.785),at(-.53,2.02,.785),GLASS);
        this.body.tube(at(0,1.56,1.28),at(0,2.02,.79),.026,.023,5,FRAME);
        this.body.box(-.81,.67,2.72,.81,.80,2.84,STEEL);
        this.lamps(2.67,1.00,.12);
        this.sensor.tube(at(0,0,0),at(0,.59,0),.072,.052,8,FRAME);
        this.sensor.box(-.54,.51,-.12,.54,.69,.12,0x5e5d4d);
        this.sensor.box(-.49,.54,.121,.49,.65,.135,0x2d3e3c);
    }

    private void buildTruck() {
        int base=0x676853, canvas=0x777266;
        this.body.box(-.86,.63,-3.56,.86,.89,3.40,FRAME);
        this.body.box(-.71,.93,1.54,.71,1.50,3.32,base);
        this.body.box(-.93,.81,3.32,.93,1.03,3.48,STEEL);
        this.body.box(-.62,1.08,3.31,.62,1.41,3.36,FRAME);
        for (int i = 0; i < 6; i++) {
            double x = -.54+i*.21;
            this.body.box(x,1.11,3.359,x+.036,1.40,3.39,STEEL);
        }
        this.body.box(-1.04,.99,0,1.04,1.92,1.68,base);
        this.body.hull(8,0,(s,p) -> base,
                new Section(-.04,1.04,1.74,2.69),new Section(1.22,1.04,1.74,2.64),
                new Section(1.68,1.01,1.68,2.18));
        this.body.face(at(-.87,1.88,1.688),at(.87,1.88,1.688),at(.77,2.51,1.345),at(-.77,2.51,1.345),GLASS);
        this.body.tube(at(0,1.88,1.695),at(0,2.52,1.34),.029,.029,6,FRAME);
        for (int side : new int[]{-1,1}) {
            double x = side*1.105;
            this.body.box(Math.min(x,x-side*.08),1.94,.13,Math.max(x,x-side*.08),2.38,1.17,GLASS);
            this.body.tube(at(side*.94,2.1,1.44),at(side*1.31,2.12,1.53),.035,.035,6,FRAME);
            this.body.box(side*1.31-.09,1.98,1.48,side*1.31+.09,2.27,1.57,FRAME);
        }
        this.body.box(-1.22,.96,-3.62,1.22,1.38,-.16,base);
        this.body.hull(10,0,(s,p) -> s % 2 == 0 ? canvas : 0x6d6a5c,
                new Section(-3.61,1.19,1.18,2.89),new Section(-3.44,1.24,1.14,2.99),
                new Section(-1.94,1.24,1.14,2.99),new Section(-.34,1.24,1.14,2.99),
                new Section(-.18,1.19,1.18,2.89));
        this.body.box(-.64,1.57,-3.646,.64,2.51,-3.61,0x53584b);
        this.body.box(-.56,1.64,-3.656,.56,2.45,-3.644,0x636759);
        this.lamps(3.37,.68,.10);
    }

    private void lamps(double z,double x,double half) {
        for (double side : new double[]{-x,x})
            this.body.box(side-half,1.08,z,side+half,1.26,z+.057,0xbdb394);
    }

    private static Vec3 at(double x,double y,double z) { return new Vec3(x,y,z); }

    @Override public ResourceLocation getTextureLocation(FieldVehicleEntity entity) { return HelicopterRenderer.SURFACE; }

    @Override public boolean shouldRender(FieldVehicleEntity v, Frustum camera, double x, double y, double z) {
        return v.shouldRender(x,y,z) && camera.isVisible(v.getBoundingBox().inflate(3,1,3));
    }

    @Override public void render(FieldVehicleEntity v, float yaw, float partialTick, PoseStack pose,
                                 MultiBufferSource buffers, int light) {
        var out = buffers.getBuffer(RenderType.entityCutoutNoCull(this.getTextureLocation(v)));
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-Mth.rotLerp(partialTick, v.yRotO, v.getYRot())));
        this.body.draw(pose.last(),out,light);
        for (int i = 0; i < this.axles.length; i++) {
            for (int side : new int[]{-1,1}) {
                pose.pushPose();
                pose.translate(this.tireX*side,this.tireY,this.axles[i]);
                pose.mulPose(Axis.XP.rotationDegrees(v.wheelAngle()));
                pose.mulPose(Axis.YP.rotationDegrees(side < 0 ? 180 : 0));
                if (v.wheels() > 0 || i > 0) this.tire.draw(pose.last(),out,light);
                this.rim.draw(pose.last(),out,light);
                pose.popPose();
            }
        }
        if (v.scout()) {
            pose.pushPose();
            pose.translate(0,2.15,-.47);
            if (v.scanning()) pose.mulPose(Axis.YP.rotationDegrees((v.tickCount+partialTick)*7));
            this.sensor.draw(pose.last(),out,light);
            pose.popPose();
        }
        pose.popPose();
        super.render(v,yaw,partialTick,pose,buffers,light);
    }
}
