package com.example.t72mod.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.entity.PartEntity;

/** A Forge part, exposed through the owner and never spawned or ticked separately. */
public final class VehiclePart extends PartEntity<LivingEntity> {
    private final VehiclePartEntity.Parent layout;
    private final int index;
    private final EntityDimensions size;

    private <T extends LivingEntity & VehiclePartEntity.Parent> VehiclePart(T owner,int index,EntityDimensions size) {
        super(owner);
        this.layout=owner;
        this.index=index;
        this.size=size;
        this.refreshDimensions();
    }

    public static <T extends LivingEntity & VehiclePartEntity.Parent> VehiclePart[] create(T owner,EntityDimensions[] sizes) {
        VehiclePart[] parts=new VehiclePart[sizes.length];
        for (int i=0;i<parts.length;i++) parts[i]=new VehiclePart(owner,i,sizes[i]);
        return parts;
    }

    public static void assignIds(VehiclePart[] parts,int parentId) {
        if (parts==null) return;
        for (int i=0;i<parts.length;i++) parts[i].setId(parentId+i+1);
    }

    public int index() { return this.index; }

    public void syncBox() {
        Vec3 position=this.layout.partPosition(this.index);
        this.setPos(position);
        this.setBoundingBox(this.layout.partBounds(this.index,this.getBoundingBox()));
        this.blocksBuilding=this.canBeCollidedWith();
    }

    @Override public EntityDimensions getDimensions(Pose pose) {
        return this.size == null ? super.getDimensions(pose) : this.size;
    }

    @Override public boolean is(Entity entity) { return entity==this || entity==this.getParent(); }
    @Override public boolean isPickable() { return this.getParent().isAlive() && this.layout.partIsActive(this.index); }
    @Override public boolean canBeCollidedWith() { return this.getParent().isAlive() && this.layout.partIsSolid(this.index); }
    @Override public boolean isPushable() { return false; }
    @Override public boolean shouldBeSaved() { return false; }

    @Override public boolean hurt(DamageSource source,float amount) {
        return this.hitBy(source,this.getBoundingBox().getCenter(),amount);
    }

    public boolean hitBy(DamageSource source,Vec3 point,float amount) {
        return this.isPickable() && this.layout.hurtPart(this.index,source,point,amount);
    }

    @Override public InteractionResult interact(Player player,InteractionHand hand) {
        return this.isPickable()?this.layout.interactPart(this.index,player,hand):InteractionResult.PASS;
    }

    @Override public InteractionResult interactAt(Player player,Vec3 hit,InteractionHand hand) {
        return this.interact(player,hand);
    }

    @Override protected void defineSynchedData() {}
    @Override protected void readAdditionalSaveData(CompoundTag tag) {}
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}
}
