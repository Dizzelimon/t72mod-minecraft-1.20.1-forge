package com.example.t72mod.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntBinaryOperator;

/** Small flat-shaded mesh. Coordinates are in blocks, with +Z forward and +Y up. */
public final class VehicleMesh {
    public record Section(double z, double halfWidth, double bottom, double top) {}
    private record Face(Vec3 a, Vec3 b, Vec3 c, Vec3 d, Vec3 normal, int color) {}
    private final List<Face> faces = new ArrayList<>();

    public void face(Vec3 a, Vec3 b, Vec3 c, Vec3 d, int color) {
        Vec3 normal = b.subtract(a).cross(c.subtract(a)).normalize();
        if (normal.lengthSqr() < 0.01) return;
        this.faces.add(new Face(a, b, c, d, normal, color));
    }

    public void box(double x0, double y0, double z0, double x1, double y1, double z1, int color) {
        Vec3 a = new Vec3(x0,y0,z0), b = new Vec3(x1,y0,z0), c = new Vec3(x1,y1,z0), d = new Vec3(x0,y1,z0);
        Vec3 e = new Vec3(x0,y0,z1), f = new Vec3(x1,y0,z1), g = new Vec3(x1,y1,z1), h = new Vec3(x0,y1,z1);
        this.face(b,a,d,c,color);
        this.face(e,f,g,h,color);
        this.face(a,e,h,d,color);
        this.face(f,b,c,g,color);
        this.face(d,h,g,c,color);
        this.face(a,b,f,e,color);
    }

    public void hull(int sides, double centerX, IntBinaryOperator colors, Section... stations) {
        for (int station = 0; station + 1 < stations.length; station++) {
            for (int panel = 0; panel < sides; panel++) {
                int material = colors.applyAsInt(station, panel);
                if (material < 0) continue;
                double a = (double) panel / sides * Math.PI * 2;
                double b = (double) (panel + 1) / sides * Math.PI * 2;
                this.face(point(stations[station],centerX,a), point(stations[station],centerX,b),
                        point(stations[station+1],centerX,b), point(stations[station+1],centerX,a), material);
            }
        }
        Section rear = stations[0], front = stations[stations.length - 1];
        for (int i = 0; i < sides; i++) {
            double a = (double) i / sides * Math.PI * 2, b = (double) (i + 1) / sides * Math.PI * 2;
            Vec3 ar = point(rear,centerX,a), br = point(rear,centerX,b);
            Vec3 af = point(front,centerX,a), bf = point(front,centerX,b);
            int rearColor = colors.applyAsInt(0, i), frontColor = colors.applyAsInt(stations.length - 2, i);
            if (rearColor >= 0)
                this.face(br, ar, new Vec3(centerX, (rear.bottom + rear.top) * 0.5, rear.z), br, rearColor);
            if (frontColor >= 0)
                this.face(af, bf, new Vec3(centerX, (front.bottom + front.top) * 0.5, front.z), af, frontColor);
        }
    }

    private static Vec3 point(Section s, double x, double angle) {
        return new Vec3(x + s.halfWidth * Math.cos(angle),
                (s.bottom + s.top) * 0.5 + (s.top - s.bottom) * 0.5 * Math.sin(angle), s.z);
    }

    public void tube(Vec3 from, Vec3 to, double r1, double r2, int sides, int color) {
        Vec3 along = to.subtract(from).normalize();
        Vec3 u = along.cross(Math.abs(along.y) > 0.9 ? new Vec3(1,0,0) : new Vec3(0,1,0)).normalize();
        Vec3 v = along.cross(u);
        for (int i = 0; i < sides; i++) {
            double a = (double) i / sides * Math.PI * 2, b = (double) (i + 1) / sides * Math.PI * 2;
            Vec3 d1 = u.scale(Math.cos(a)).add(v.scale(Math.sin(a)));
            Vec3 d2 = u.scale(Math.cos(b)).add(v.scale(Math.sin(b)));
            Vec3 p = from.add(d1.scale(r1)), q = from.add(d2.scale(r1));
            Vec3 r = to.add(d2.scale(r2)), s = to.add(d1.scale(r2));
            this.face(p,q,r,s,color);
            this.face(q,p,from,q,color);
            this.face(s,r,to,s,color);
        }
    }

    public void draw(PoseStack.Pose pose, VertexConsumer out, int light) {
        for (Face f : this.faces) {
            vertex(pose, out, f.a, f.normal, f.color, light, 0, 0);
            vertex(pose, out, f.b, f.normal, f.color, light, 1, 0);
            vertex(pose, out, f.c, f.normal, f.color, light, 1, 1);
            vertex(pose, out, f.d, f.normal, f.color, light, 0, 1);
        }
    }

    private static void vertex(PoseStack.Pose pose, VertexConsumer out, Vec3 pos, Vec3 normal,
                               int rgb, int light, float u, float v) {
        out.vertex(pose.pose(), (float)pos.x, (float)pos.y, (float)pos.z)
                .color(rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255, 255).uv(u,v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light)
                .normal(pose.normal(), (float)normal.x, (float)normal.y, (float)normal.z).endVertex();
    }
}
