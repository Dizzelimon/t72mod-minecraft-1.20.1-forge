package com.example.t72mod.client.renderer;

import com.example.t72mod.client.model.VehicleMesh;
import com.example.t72mod.entity.FpvDroneEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class FpvDroneRenderer extends EntityRenderer<FpvDroneEntity> {
    private final VehicleMesh frame = new VehicleMesh();
    private final VehicleMesh blade = new VehicleMesh();
    private static final double[] MOTORS = {-.35, .35};

    public FpvDroneRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = .24F;
        this.frame.box(-.145,.07,-.22,.145,.21,.22,0x434840);
        this.frame.box(-.108,.205,-.17,.108,.256,.089,0x778052);
        this.frame.tube(new Vec3(0,.163,.185),new Vec3(0,.163,.258),.074,.058,10,0x232d2a);
        this.frame.tube(new Vec3(0,.163,.257),new Vec3(0,.163,.270),.050,.043,10,0x557887);
        this.frame.tube(new Vec3(-.11,.19,-.17),new Vec3(-.125,.39,-.25),.010,.005,6,0x242a26);
        this.frame.box(-.109,.11,-.231,.109,.159,-.220,0xb85c45);
        for (double x : MOTORS) for (double z : MOTORS) {
            this.frame.tube(new Vec3(x*.21,.105,z*.21),new Vec3(x,.105,z),.038,.026,6,0x34383b);
            this.frame.tube(new Vec3(x,.070,z),new Vec3(x,.161,z),.060,.055,8,0x646d62);
            this.frame.box(x-.050,.022,z-.062,x+.050,.070,z+.062,0x272d27);
        }
        this.blade.box(-.165,0,-.021,.165,.014,.021,0x737b72);
        this.blade.box(-.021,.002,-.165,.021,.016,.165,0x656d67);
    }

    @Override public ResourceLocation getTextureLocation(FpvDroneEntity drone) { return HelicopterRenderer.SURFACE; }

    @Override public void render(FpvDroneEntity drone, float yaw, float partial, PoseStack pose,
                                 MultiBufferSource buffers, int light) {
        if (Minecraft.getInstance().getCameraEntity() == drone) return;
        var out = buffers.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(drone)));
        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-Mth.rotLerp(partial, drone.yRotO, drone.getYRot())));
        pose.mulPose(Axis.XP.rotationDegrees(Mth.lerp(partial, drone.xRotO, drone.getXRot())));
        pose.mulPose(Axis.ZP.rotationDegrees(drone.roll(partial)));
        this.frame.draw(pose.last(), out, light);
        float spin = drone.controllerId() < 0 ? 17 : (drone.tickCount + partial) * 117;
        for (double x : MOTORS) for (double z : MOTORS) {
            pose.pushPose();
            pose.translate(x,.161,z);
            pose.mulPose(Axis.YP.rotationDegrees(x*z > 0 ? spin : -spin));
            this.blade.draw(pose.last(), out, light);
            pose.popPose();
        }
        pose.popPose();
        super.render(drone, yaw, partial, pose, buffers, light);
    }
}
