package com.example.t72mod.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.ShulkerBoxBlock;

final class FreightRenderer {
    static void draw(int colors, PoseStack pose, MultiBufferSource buffers,int light,double floor,double z) {
        for (int i=0;i<2;i++) {
            int color=(colors >> (i*5)) & 31;
            if (color<1 || color>17) continue;
            var block=ShulkerBoxBlock.getBlockByColor(color==17 ? null : DyeColor.byId(color-1));
            pose.pushPose();
            pose.translate(i==0 ? -.88 : .10, floor,z);
            pose.scale(.78f,.78f,.78f);
            Minecraft.getInstance().getBlockRenderer().renderSingleBlock(block.defaultBlockState(),pose,buffers,light,OverlayTexture.NO_OVERLAY);
            pose.popPose();
        }
    }
}
