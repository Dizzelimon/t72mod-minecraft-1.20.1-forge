package com.example.t72mod.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class T72ServerConfig {
    public static final int DEFAULT_ARTILLERY_MAX_RANGE = 192;
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue ARTILLERY_MAX_RANGE;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("artillery");
        ARTILLERY_MAX_RANGE = builder
                .comment("Maximum artillery firing range in blocks (default is 192, double 6.1.0's 96)")
                .defineInRange("maxRange", DEFAULT_ARTILLERY_MAX_RANGE, 32, 512);
        builder.pop();
        SPEC = builder.build();
    }

    private T72ServerConfig() {}

    public static int artilleryMaxRange() {
        return SPEC.isLoaded() ? ARTILLERY_MAX_RANGE.get() : DEFAULT_ARTILLERY_MAX_RANGE;
    }
}
