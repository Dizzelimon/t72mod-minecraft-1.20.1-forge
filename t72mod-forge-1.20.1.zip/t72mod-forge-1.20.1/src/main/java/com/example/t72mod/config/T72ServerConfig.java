package com.example.t72mod.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

public final class T72ServerConfig {
    public static final int DEFAULT_ARTILLERY_MAX_RANGE = com.example.t72mod.entity.ArtilleryBallistics.DEFAULT_MAX_RANGE;
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue ARTILLERY_MAX_RANGE;
    private static final ForgeConfigSpec.BooleanValue ARTILLERY_RANGE_UPDATED;

    private static final List<String> DEFAULT_MG_AMMO = List.of("tacz:762x54", "tacz:308");
    private static final ForgeConfigSpec.ConfigValue<List<? extends String>> TACZ_MG_AMMO;
    private static final ForgeConfigSpec.ConfigValue<List<? extends String>> TACZ_DAMAGE_OVERRIDES;

    private static final ForgeConfigSpec.BooleanValue INFANTRY_MINES;
    private static final ForgeConfigSpec.IntValue INFANTRY_MINE_DAMAGE;

    private static final ForgeConfigSpec.BooleanValue VEHICLE_CONTACT_DAMAGE;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("artillery");
        ARTILLERY_MAX_RANGE = builder
                .comment("Maximum artillery firing range in blocks")
                .defineInRange("maxRange", DEFAULT_ARTILLERY_MAX_RANGE, 32, 512);
        ARTILLERY_RANGE_UPDATED = builder.comment("Tracks the migration of the old 192-block default")
                .define("rangePresetUpdated", false);
        builder.pop();
        builder.push("tacz");
        TACZ_MG_AMMO = builder.comment("TaCZ ammo IDs accepted in the machine-gun inventory slots")
                .defineListAllowEmpty("machineGunAmmo", () -> DEFAULT_MG_AMMO,
                        value -> value instanceof String id && ResourceLocation.tryParse(id) != null);
        TACZ_DAMAGE_OVERRIDES = builder.comment("Optional vehicle impact factors, e.g. tacz:ak47=0.75")
                .defineListAllowEmpty("vehicleDamageOverrides", List::of, T72ServerConfig::validDamageOverride);
        builder.pop();
        builder.push("mines");
        INFANTRY_MINES = builder.define("infantryEnabled", true);
        INFANTRY_MINE_DAMAGE = builder.defineInRange("infantryDamage", 7, 0, 20);
        builder.pop();
        builder.push("vehicles");
        VEHICLE_CONTACT_DAMAGE = builder.define("contactDamage", true);
        builder.pop();
        SPEC = builder.build();
    }

    private T72ServerConfig() {}

    public static void upgradeArtilleryRange(ModConfigEvent.Loading event) {
        var config = event.getConfig();
        if (config.getSpec() != SPEC || ARTILLERY_RANGE_UPDATED.get()) return;
        var values = config.getConfigData();
        if (ARTILLERY_MAX_RANGE.get() == 192) values.set("artillery.maxRange", DEFAULT_ARTILLERY_MAX_RANGE);
        values.set("artillery.rangePresetUpdated", true);
        SPEC.afterReload();
        config.save();
    }

    public static int artilleryMaxRange() {
        return SPEC.isLoaded() ? ARTILLERY_MAX_RANGE.get() : DEFAULT_ARTILLERY_MAX_RANGE;
    }
    public static boolean contactDamageEnabled() {
        return !SPEC.isLoaded() || VEHICLE_CONTACT_DAMAGE.get();
    }

    public static boolean infantryMinesEnabled() {
        return !SPEC.isLoaded() || INFANTRY_MINES.get();
    }

    public static int infantryMineDamage() {
        return SPEC.isLoaded() ? INFANTRY_MINE_DAMAGE.get() : 7;
    }

    public static List<? extends String> taczMachineGunAmmo() {
        return SPEC.isLoaded() ? TACZ_MG_AMMO.get() : DEFAULT_MG_AMMO;
    }

    private static boolean validDamageOverride(Object value) {
        if (!(value instanceof String entry)) return false;
        int separator = entry.indexOf('=');
        if (separator < 1 || ResourceLocation.tryParse(entry.substring(0, separator)) == null) return false;
        try {
            double factor = Double.parseDouble(entry.substring(separator + 1));
            return factor >= 0 && factor <= 4;
        } catch (NumberFormatException invalid) {
            return false;
        }
    }

    public static double taczDamageScale(ResourceLocation gunId) {
        if (gunId == null || !SPEC.isLoaded()) return 1;
        String prefix = gunId + "=";
        for (String entry : TACZ_DAMAGE_OVERRIDES.get()) {
            if (entry.startsWith(prefix)) return Double.parseDouble(entry.substring(prefix.length()));
        }
        return 1;
    }
}
