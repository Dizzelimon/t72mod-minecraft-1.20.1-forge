package com.example.t72mod.client.renderer;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.ArtilleryEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public final class ArtilleryRenderer extends EntityRenderer<ArtilleryEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(T72Mod.MODID, "artillery"), "main");
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(T72Mod.MODID, "textures/entity/artillery.png");

    private final ModelPart root;
    private final ModelPart tube;
    private final ModelPart brokenTube;

    public ArtilleryRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.root = context.bakeLayer(LAYER);
        this.tube = this.root.getChild("tube");
        this.brokenTube = this.root.getChild("broken");
        this.shadowRadius = 1.4F;
    }

    @Override
    public void render(ArtilleryEntity piece, float yaw, float partialTick, PoseStack poses,
                       MultiBufferSource buffers, int light) {
        poses.pushPose();
        poses.mulPose(Axis.YP.rotationDegrees(180 - Mth.rotLerp(partialTick, piece.yRotO, piece.getYRot())));
        this.tube.xRot = this.brokenTube.xRot = piece.elevation() * Mth.DEG_TO_RAD;
        this.tube.visible = piece.gunHealth() > 0;
        this.brokenTube.visible = !this.tube.visible;
        this.root.render(poses, buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE)), light, OverlayTexture.NO_OVERLAY);
        poses.popPose();
        super.render(piece, yaw, partialTick, poses, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(ArtilleryEntity entity) { return TEXTURE; }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("carriage", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-20, 3, -16, 40, 6, 32)
                .texOffs(0, 48).addBox(-22, 0, -10, 7, 17, 17)
                .texOffs(0, 48).addBox(15, 0, -10, 7, 17, 17)
                .texOffs(0, 0).addBox(-18, 1, 12, 7, 4, 32)
                .texOffs(0, 0).addBox(11, 1, 12, 7, 4, 32)
                .texOffs(0, 0).addBox(-12, 9, -8, 24, 12, 16)
                .texOffs(0, 43).addBox(-17, 12, -13, 34, 16, 4), PartPose.ZERO);
        root.addOrReplaceChild("tube", CubeListBuilder.create()
                .texOffs(64, 47).addBox(-3, -3, -45, 6, 6, 49)
                .texOffs(80, 40).addBox(-5, -5, -47, 10, 10, 9), PartPose.offset(0, 21.6F, 0));
        root.addOrReplaceChild("broken", CubeListBuilder.create()
                .texOffs(48, 53).addBox(-4, -4, -12, 8, 8, 16)
                .texOffs(8, 75).addBox(-4, -3, -16, 2, 4, 6)
                .texOffs(8, 75).addBox(2, 0, -14, 2, 4, 5), PartPose.offset(0, 21.6F, 0));
        return LayerDefinition.create(mesh, 256, 112);
    }
}
