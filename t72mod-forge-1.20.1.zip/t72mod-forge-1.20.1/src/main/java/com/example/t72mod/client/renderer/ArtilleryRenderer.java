package com.example.t72mod.client.renderer;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.AirframeLayout;
import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.ArtilleryTowVehicle;
import com.example.t72mod.client.model.VehicleMesh;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

public final class ArtilleryRenderer extends EntityRenderer<ArtilleryEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(T72Mod.MODID, "artillery"), "main");
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(T72Mod.MODID, "textures/entity/artillery.png");

    private final ModelPart root;
    private final ModelPart gunAssembly;
    private final ModelPart barrelGroup;
    private final ModelPart brokenGroup;
    private final ModelPart elevWheel;
    private final ModelPart travWheel;
    private final ModelPart leftTrail;
    private final ModelPart rightTrail;
    private final VehicleMesh drawbar = new VehicleMesh();

    public ArtilleryRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.root = context.bakeLayer(LAYER);
        this.gunAssembly = this.root.getChild("gun");
        this.barrelGroup = this.gunAssembly.getChild("recoil");
        this.brokenGroup = this.gunAssembly.getChild("broken");
        ModelPart upper = this.root.getChild("upper_carriage");
        this.elevWheel = upper.getChild("elev_wheel");
        this.travWheel = upper.getChild("trav_wheel");
        this.leftTrail = this.root.getChild("trail_l");
        this.rightTrail = this.root.getChild("trail_r");
        this.drawbar.tube(Vec3.ZERO, new Vec3(0, 0, 1), .054, .054, 8, 0x697063);
        this.shadowRadius = 1.65F;
    }

    @Override
    public void render(ArtilleryEntity piece, float yaw, float partialTick, PoseStack poses,
                       MultiBufferSource buffers, int light) {
        poses.pushPose();
        float interpYaw = piece.renderYaw(partialTick);
        float interpElev = piece.renderElevation(partialTick);
        boolean towing = piece.towVehicle().isPresent();
        this.leftTrail.yRot = towing ? -.151F : .36F;
        this.rightTrail.yRot = towing ? .151F : -.36F;
        this.leftTrail.xRot = towing ? 0 : -.145F;
        this.rightTrail.xRot = this.leftTrail.xRot;
        poses.mulPose(Axis.YP.rotationDegrees(180.0F - interpYaw));

        this.gunAssembly.xRot = interpElev * Mth.DEG_TO_RAD;
        this.elevWheel.xRot = interpElev * 0.18F;
        this.travWheel.zRot = interpYaw * 0.12F;

        boolean intact = piece.gunHealth() > 0;
        this.barrelGroup.visible = intact;
        this.brokenGroup.visible = !intact;

        int recoil = piece.recoilTicks();
        float recoilZ = recoil > 0 ? Mth.sin((recoil - partialTick) * (Mth.PI / 14.0F)) * 5.2F : 0.0F;
        this.barrelGroup.z = Math.max(0.0F, recoilZ);

        this.root.render(poses, buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE)), light, OverlayTexture.NO_OVERLAY);
        poses.popPose();
        if (towing && piece.level().getEntity(piece.towVehicleId()) instanceof ArtilleryTowVehicle tow) {
            var vehicle = tow.towEntity();
            Vec3 hitch = tow.rearHitch(vehicle.getPosition(partialTick), Mth.rotLerp(partialTick, vehicle.yRotO, vehicle.getYRot()));
            Vec3 eye = AirframeLayout.world(piece.getPosition(partialTick), interpYaw, 0, .51, -2.54);
            Vec3 span = hitch.subtract(eye);
            double length = span.length();
            if (length > .05 && length < 12) {
                Vec3 start = eye.subtract(piece.getPosition(partialTick));
                Vec3 axis = span.scale(1 / length);
                poses.pushPose();
                poses.translate(start.x, start.y, start.z);
                poses.mulPose(new Quaternionf().rotationTo(0, 0, 1, (float) axis.x, (float) axis.y, (float) axis.z));
                poses.scale(1, 1, (float) length);
                this.drawbar.draw(poses.last(), buffers.getBuffer(RenderType.entityCutoutNoCull(HelicopterRenderer.SURFACE)), light);
                poses.popPose();
            }
        }
        super.render(piece, yaw, partialTick, poses, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(ArtilleryEntity entity) {
        return TEXTURE;
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // Lower carriage, axle beam, central screw jack & ground baseplate (y=0 flush contact)
        root.addOrReplaceChild("carriage", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-18.5F, 7.2F, -1.5F, 37.0F, 3.6F, 4.0F)
                .texOffs(0, 12).addBox(-7.5F, 6.2F, -5.5F, 15.0F, 5.5F, 11.0F)
                .texOffs(0, 64).addBox(-3.0F, 1.5F, -2.5F, 6.0F, 6.0F, 6.0F)
                .texOffs(0, 0).addBox(-7.5F, 0.0F, -6.5F, 15.0F, 1.8F, 13.0F)
                .texOffs(0, 96).addBox(-11.0F, 6.8F, -4.5F, 3.0F, 3.2F, 4.0F)
                .texOffs(0, 96).addBox(8.0F, 6.8F, -4.5F, 3.0F, 3.2F, 4.0F)
                .texOffs(0, 0).addBox(-6.5F, 6.4F, 2.5F, 13.0F, 3.8F, 4.0F),
                PartPose.ZERO);

        // Two radial 16-sided volumetric rubber wheels with aligned painted steel rims & hubcaps (touching y=0)
        for (int side : new int[]{-1, 1}) {
            PartDefinition wheel = root.addOrReplaceChild(side < 0 ? "wheel_r" : "wheel_l",
                    CubeListBuilder.create(),
                    PartPose.offset(side * 19.5F, 9.0F, 0.5F));
            for (int k = 0; k < 4; k++) {
                wheel.addOrReplaceChild("tire_" + k, CubeListBuilder.create()
                        .texOffs(128, 64).addBox(-2.5F, -3.45F, -8.3F, 5.0F, 6.9F, 16.6F),
                        PartPose.rotation(k * (Mth.PI / 4.0F), 0.0F, 0.0F));
            }
            for (int k = 0; k < 2; k++) {
                float rimW = k == 0 ? 5.36F : 5.20F;
                wheel.addOrReplaceChild("rim_" + k, CubeListBuilder.create()
                        .texOffs(208, 64).addBox(-rimW * 0.5F, -5.0F, -5.0F, rimW, 10.0F, 10.0F),
                        PartPose.rotation(k * (Mth.PI / 4.0F), 0.0F, 0.0F));
            }
            wheel.addOrReplaceChild("hub", CubeListBuilder.create()
                    .texOffs(0, 96).addBox(-3.2F, -2.5F, -2.5F, 6.4F, 5.0F, 5.0F),
                    PartPose.ZERO);
        }

        // Split outrigger trails (опоры / станины) angling outward and firmly planted on ground via spades
        for (int side : new int[]{-1, 1}) {
            PartDefinition trail = root.addOrReplaceChild(side < 0 ? "trail_r" : "trail_l",
                    CubeListBuilder.create()
                            .texOffs(0, 0).addBox(-2.0F, -1.8F, 0.0F, 4.0F, 3.8F, 35.0F)
                            .texOffs(0, 96).addBox(-2.4F, -2.1F, -2.0F, 4.8F, 4.4F, 5.0F)
                            .texOffs(0, 64).addBox(-1.2F, 1.8F, 14.0F, 2.4F, 1.2F, 14.0F),
                    PartPose.offsetAndRotation(side * 5.5F, 8.2F, 4.0F, -0.145F, side * 0.36F, 0.0F));

            trail.addOrReplaceChild("spade", CubeListBuilder.create()
                    .texOffs(64, 160).addBox(-3.0F, -1.9F, -1.0F, 6.0F, 4.2F, 4.5F)
                    .texOffs(0, 0).addBox(-4.2F, 0.6F, 0.4F, 8.4F, 2.8F, 1.8F)
                    .texOffs(0, 96).addBox(-1.4F, 0.4F, 3.2F, 2.8F, 1.8F, 3.6F),
                    PartPose.offset(0.0F, -0.8F, 35.0F));
        }

        // Upper traversing mount, trunnion cheeks, V-sloped armor gun shield, gears, handwheels, optics & gunner seat
        PartDefinition upper = root.addOrReplaceChild("upper_carriage", CubeListBuilder.create()
                .texOffs(0, 64).addBox(-6.5F, -0.5F, -5.0F, 13.0F, 3.0F, 10.0F)
                .texOffs(0, 0).addBox(-6.2F, 2.0F, -3.5F, 3.0F, 10.5F, 7.0F)
                .texOffs(0, 0).addBox(3.2F, 2.0F, -3.5F, 3.0F, 10.5F, 7.0F)
                .texOffs(0, 0).addBox(-4.0F, 2.0F, -3.0F, 8.0F, 4.0F, 6.0F)
                // Elevation sector gear arc & traverse/elevation housings
                .texOffs(0, 128).addBox(-3.2F, 3.0F, -1.0F, 1.4F, 6.0F, 5.5F)
                .texOffs(0, 96).addBox(-8.2F, 4.0F, -1.5F, 2.4F, 4.5F, 4.5F)
                .texOffs(0, 96).addBox(6.0F, 1.5F, 1.5F, 2.8F, 4.0F, 4.5F)
                // Panoramic dial sight & lens housing on left cheek
                .texOffs(0, 96).addBox(4.5F, 10.5F, -2.5F, 2.2F, 5.5F, 2.5F)
                .texOffs(0, 128).addBox(4.2F, 15.5F, -2.8F, 2.8F, 2.2F, 3.0F)
                .texOffs(64, 128).addBox(4.3F, 17.5F, -3.2F, 2.6F, 2.6F, 3.8F)
                // Gunner seat boom, cushion & backrest
                .texOffs(0, 0).addBox(5.5F, -1.2F, 3.5F, 3.2F, 2.0F, 8.0F)
                .texOffs(0, 160).addBox(5.2F, 0.8F, 9.0F, 5.8F, 1.8F, 5.8F)
                .texOffs(0, 160).addBox(5.2F, 2.2F, 13.6F, 5.8F, 4.5F, 1.5F),
                PartPose.offset(0.0F, 11.2F, 0.0F));

        // Sloped V-angled armor shields framing the gun cradle
        upper.addOrReplaceChild("shield_l", CubeListBuilder.create()
                .texOffs(128, 0).addBox(-0.5F, 0.0F, -1.0F, 16.5F, 19.0F, 1.5F),
                PartPose.offsetAndRotation(5.0F, 1.0F, -8.5F, 0.28F, -0.22F, 0.0F));
        upper.addOrReplaceChild("shield_r", CubeListBuilder.create()
                .texOffs(128, 0).addBox(-16.0F, 0.0F, -1.0F, 16.5F, 19.0F, 1.5F),
                PartPose.offsetAndRotation(-5.0F, 1.0F, -8.5F, 0.28F, 0.22F, 0.0F));
        upper.addOrReplaceChild("shield_apron", CubeListBuilder.create()
                .texOffs(128, 0).addBox(-5.2F, -1.5F, -0.8F, 10.4F, 6.5F, 1.5F),
                PartPose.offsetAndRotation(0.0F, -1.5F, -8.2F, 0.28F, 0.0F, 0.0F));

        // Rotating elevation & traverse spoked handwheels
        upper.addOrReplaceChild("elev_wheel", CubeListBuilder.create()
                .texOffs(0, 96).addBox(-1.2F, -0.5F, -0.5F, 2.2F, 1.0F, 1.0F)
                .texOffs(0, 128).addBox(-1.4F, -3.2F, -0.5F, 0.8F, 6.4F, 1.0F)
                .texOffs(0, 128).addBox(-1.4F, -0.5F, -3.2F, 0.8F, 1.0F, 6.4F)
                .texOffs(0, 96).addBox(-1.6F, -3.4F, -3.4F, 1.0F, 1.0F, 6.8F)
                .texOffs(0, 96).addBox(-1.6F, 2.4F, -3.4F, 1.0F, 1.0F, 6.8F),
                PartPose.offset(-8.8F, 6.2F, 1.5F));

        upper.addOrReplaceChild("trav_wheel", CubeListBuilder.create()
                .texOffs(0, 96).addBox(-0.5F, -0.5F, -0.5F, 1.0F, 1.0F, 2.2F)
                .texOffs(0, 128).addBox(-3.0F, -0.5F, 1.0F, 6.0F, 1.0F, 0.8F)
                .texOffs(0, 128).addBox(-0.5F, -3.0F, 1.0F, 1.0F, 6.0F, 0.8F)
                .texOffs(0, 96).addBox(-3.2F, -3.2F, 0.9F, 6.4F, 1.0F, 1.0F)
                .texOffs(0, 96).addBox(-3.2F, 2.2F, 0.9F, 6.4F, 1.0F, 1.0F),
                PartPose.offset(7.4F, 3.5F, 6.0F));

        // Elevating gun cradle + upper recuperator + sliding recoiling barrel & muzzle brake (pivot y=21.6px = 1.35m)
        PartDefinition gun = root.addOrReplaceChild("gun", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-3.8F, -2.4F, -11.5F, 7.6F, 5.0F, 18.0F)
                .texOffs(0, 96).addBox(-4.8F, -1.6F, -2.0F, 9.6F, 3.2F, 4.0F)
                .texOffs(0, 64).addBox(-1.6F, 2.6F, -15.5F, 3.2F, 3.2F, 22.0F),
                PartPose.offset(0.0F, 21.6F, 0.0F));

        gun.addOrReplaceChild("recuperator_diag", CubeListBuilder.create()
                .texOffs(0, 64).addBox(-1.6F, -1.6F, -15.5F, 3.2F, 3.2F, 22.0F),
                PartPose.offsetAndRotation(0.0F, 4.2F, 0.0F, 0.0F, 0.0F, Mth.PI / 4.0F));

        PartDefinition recoil = gun.addOrReplaceChild("recoil", CubeListBuilder.create()
                .texOffs(0, 96).addBox(-3.2F, -2.8F, 1.0F, 6.4F, 5.6F, 9.5F)
                .texOffs(0, 96).addBox(-2.5F, -1.5F, 10.5F, 5.0F, 1.6F, 4.5F)
                .texOffs(0, 128).addBox(3.0F, -0.5F, 3.5F, 1.6F, 4.0F, 2.0F)
                .texOffs(0, 64).addBox(-2.6F, -2.6F, -19.0F, 5.2F, 5.2F, 20.0F)
                .texOffs(0, 64).addBox(-1.9F, -1.9F, -38.0F, 3.8F, 3.8F, 20.0F)
                .texOffs(0, 96).addBox(-2.4F, -2.4F, -27.5F, 4.8F, 4.8F, 5.0F)
                .texOffs(0, 64).addBox(-1.6F, -1.6F, -50.0F, 3.2F, 3.2F, 13.0F)
                .texOffs(64, 64).addBox(-3.4F, -2.5F, -56.5F, 6.8F, 5.0F, 7.0F)
                .texOffs(0, 96).addBox(-2.2F, -2.8F, -55.0F, 4.4F, 5.6F, 1.8F)
                .texOffs(0, 96).addBox(-2.2F, -2.8F, -51.8F, 4.4F, 5.6F, 1.8F),
                PartPose.ZERO);

        recoil.addOrReplaceChild("chamber_diag", CubeListBuilder.create()
                .texOffs(0, 64).addBox(-2.6F, -2.6F, -19.0F, 5.2F, 5.2F, 20.0F),
                PartPose.rotation(0.0F, 0.0F, Mth.PI / 4.0F));
        recoil.addOrReplaceChild("tube_diag", CubeListBuilder.create()
                .texOffs(0, 64).addBox(-1.9F, -1.9F, -38.0F, 3.8F, 3.8F, 20.0F)
                .texOffs(0, 64).addBox(-1.6F, -1.6F, -50.0F, 3.2F, 3.2F, 13.0F),
                PartPose.rotation(0.0F, 0.0F, Mth.PI / 4.0F));

        gun.addOrReplaceChild("broken", CubeListBuilder.create()
                .texOffs(128, 128).addBox(-3.5F, -3.0F, -12.0F, 7.0F, 6.0F, 16.0F)
                .texOffs(128, 128).addBox(-3.5F, -2.5F, -18.0F, 2.2F, 4.2F, 7.0F)
                .texOffs(128, 128).addBox(1.4F, 0.2F, -16.5F, 2.2F, 3.8F, 5.5F),
                PartPose.ZERO);

        return LayerDefinition.create(mesh, 256, 256);
    }
}
