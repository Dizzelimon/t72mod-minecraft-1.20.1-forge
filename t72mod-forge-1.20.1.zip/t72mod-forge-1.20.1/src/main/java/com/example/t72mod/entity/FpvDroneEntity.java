package com.example.t72mod.entity;

import com.example.t72mod.config.T72ServerConfig;
import com.example.t72mod.T72Mod;
import com.example.t72mod.item.FlightBattery;
import com.example.t72mod.network.ArtilleryMarkerPacket;
import com.example.t72mod.network.FpvViewPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.Optional;
import java.util.UUID;

public final class FpvDroneEntity extends Entity {
    public static final int BATTERY_CAPACITY = 2600;
    public static final String ACTIVE = "t72mod:fpv_active";
    public static final String LINKED = "t72mod:fpv_linked";
    public static final String STORED_CHARGE = "FpvCharge";
    private static final EntityDataAccessor<Integer> CONTROL = SynchedEntityData.defineId(FpvDroneEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> BATTERY = SynchedEntityData.defineId(FpvDroneEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Byte> ROLL = SynchedEntityData.defineId(FpvDroneEntity.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Boolean> FREE_ATTITUDE = SynchedEntityData.defineId(
            FpvDroneEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> LIMITED = SynchedEntityData.defineId(FpvDroneEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(
            FpvDroneEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Boolean> PAYLOAD = SynchedEntityData.defineId(FpvDroneEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> THROTTLE_PERCENT = SynchedEntityData.defineId(FpvDroneEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> PARCEL = SynchedEntityData.defineId(FpvDroneEntity.class, EntityDataSerializers.BOOLEAN);
    private ItemStack parcel = ItemStack.EMPTY;
    public boolean hasParcel() { return this.entityData.get(PARCEL); }
    private void setParcel(ItemStack stack) {
        parcel=stack;
        this.entityData.set(PARCEL,!stack.isEmpty());
    }

    private UUID operatorVehicle;
    private int airborneTicks;
    private Vec3 pendingPosition;
    private int interpolationTicks;
    private float pendingYaw, pendingPitch;
    private float previousRoll;
    private int keys;
    private float turn, tilt;
    private double throttle = .61;
    private int lastFrame = -100;
    private int lastMark = -100;
    private int wear = 12;
    private int chargeUsed;

    public FpvDroneEntity(EntityType<? extends FpvDroneEntity> type, Level level) {
        super(type, level);
        this.setMaxUpStep(0);
    }

    @Override protected void defineSynchedData() {
        this.entityData.define(PARCEL,false);
        this.entityData.define(CONTROL, -1);
        this.entityData.define(OWNER, Optional.empty());
        this.entityData.define(BATTERY, BATTERY_CAPACITY);
        this.entityData.define(ROLL, (byte) 0);
        this.entityData.define(LIMITED, false);
        this.entityData.define(FREE_ATTITUDE, true);
        this.entityData.define(PAYLOAD, false);
        this.entityData.define(THROTTLE_PERCENT, 61);
    }

    public int controllerId() { return this.entityData.get(CONTROL); }
    public boolean freeAttitude() { return this.entityData.get(FREE_ATTITUDE); }
    public boolean hasPayload() { return this.entityData.get(PAYLOAD); }
    public int throttlePercent() { return this.entityData.get(THROTTLE_PERCENT); }
    public int battery() { return this.entityData.get(BATTERY); }
    public boolean signalLimited() { return this.entityData.get(LIMITED); }
    public float roll(float partialTick) { return Mth.lerp(partialTick, this.previousRoll, this.entityData.get(ROLL)); }

    public void prepare(Player player, ItemStack kit) {
        this.entityData.set(OWNER, player == null ? Optional.empty() : Optional.of(player.getUUID()));
        if (kit.hasTag() && kit.getTag().contains(STORED_CHARGE))
            this.entityData.set(BATTERY, Mth.clamp(kit.getTag().getInt(STORED_CHARGE), 0, BATTERY_CAPACITY));
    }

    public void toggle(ServerPlayer player) {
        if (!this.isAlive() || !this.isOwnedBy(player) || player.level() != this.level()) return;
        if (this.controllerId() == player.getId()) {
            this.endControl(player, "fpv_released");
            return;
        }
        if (!operatorSeatAllowed(player) || player.isSpectator() || !player.isAlive() || this.battery() <= 0
                || this.distanceToSqr(player) > (double) FpvFlight.RANGE * FpvFlight.RANGE || this.controllerId() >= 0) {
            player.displayClientMessage(Component.translatable("message.t72mod.fpv_unavailable"), true);
            return;
        }
        if (player.getPersistentData().hasUUID(ACTIVE) && player.serverLevel().getEntity(player.getPersistentData().getUUID(ACTIVE))
                instanceof FpvDroneEntity previous && previous != this) previous.endControl(player, null);
        player.getPersistentData().putUUID(ACTIVE, this.getUUID());
        player.getPersistentData().putUUID(LINKED, this.getUUID());
        this.entityData.set(CONTROL, player.getId());
        this.operatorVehicle = player.isPassenger() ? player.getVehicle().getUUID() : null;
        this.lastFrame = this.tickCount;
        this.keys = 0;
        this.throttle = .61;
        this.entityData.set(THROTTLE_PERCENT, 61);
        this.airborneTicks = 0;
        this.chargeUsed = 0;
        this.setXRot(0);
        FpvViewPacket.send(player, this.getId());
        player.displayClientMessage(Component.translatable("message.t72mod.fpv_linked"), true);
    }

    public boolean isOwnedBy(Player player) { return this.entityData.get(OWNER).filter(player.getUUID()::equals).isPresent(); }

    private static boolean operatorSeatAllowed(Player pilot) {
        Entity vehicle = pilot.getVehicle();
        if (vehicle == null) return true;
        if (vehicle instanceof HelicopterEntity heli) return !heli.isPilot(pilot);
        if (vehicle instanceof T72TankEntity tank) return tank.bmpSeatOf(pilot) >= 2;
        return vehicle instanceof FieldVehicleEntity truck && truck.getControllingPassenger() != pilot;
    }

    private boolean stillHoldingController(Player player) {
        return player.getMainHandItem().is(T72Mod.FPV_CONTROLLER.get()) || player.getOffhandItem().is(T72Mod.FPV_CONTROLLER.get());
    }

    public void accept(ServerPlayer player, int flags, float roll, float pitch, int action) {
        if (this.controllerId() != player.getId() || !this.isOwnedBy(player)) return;
        if (action == 1) {
            this.endControl(player, "fpv_released");
        } else if (action == 2 && this.tickCount - this.lastMark >= 18) {
            this.lastMark = this.tickCount;
            this.markGround(player);
        } else if (action == 3) {
            this.entityData.set(FREE_ATTITUDE, !this.freeAttitude());
        } else if (action == 0 && Float.isFinite(roll) && Float.isFinite(pitch)) {
            this.lastFrame = this.tickCount;
            this.keys = flags & 127;
            this.turn = Mth.clamp(this.turn + roll, -31, 31);
            this.tilt = Mth.clamp(this.tilt + pitch, -24, 24);
        }
    }

    private void markGround(ServerPlayer player) {
        Vec3 from = this.getEyePosition();
        Vec3 to = from.add(this.getLookAngle().scale(86));
        var hit = this.level().clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        if (hit.getType() == HitResult.Type.MISS) {
            player.displayClientMessage(Component.translatable("message.t72mod.fpv_no_surface"), true);
            return;
        }
        BlockPos marker = hit.getBlockPos();
        com.example.t72mod.scenario.ReconExercise.markFromDrone(player, marker);
        com.example.t72mod.scenario.CrewRoutes.savePin(player,marker,"observation","");
        var dimension = this.level().dimension().location();
        for (ServerPlayer recipient : player.serverLevel().players()) {
            if (recipient != player && (player.getTeam() == null || !player.isAlliedTo(recipient)
                    || player.distanceToSqr(recipient) > FpvFlight.RANGE * FpvFlight.RANGE)) continue;
            var store = ArtilleryMarkerPacket.loadPlayerStore(recipient);
            if (!store.addMarker(dimension, marker.getX(), marker.getZ())) {
                recipient.displayClientMessage(Component.translatable("message.t72mod.artillery_marker_full"), true);
                continue;
            }
            ArtilleryMarkerPacket.savePlayerStore(recipient, store);
            ArtilleryMarkerPacket.syncToPlayer(recipient);
            recipient.displayClientMessage(Component.translatable("message.t72mod.fpv_marked", marker.getX(), marker.getZ()), true);
        }
    }

    private void endControl(ServerPlayer player, String message) {
        if (player != null) {
            var data = player.getPersistentData();
            if (data.hasUUID(ACTIVE) && this.getUUID().equals(data.getUUID(ACTIVE))) data.remove(ACTIVE);
            FpvViewPacket.send(player, -1);
            if (message != null) player.displayClientMessage(Component.translatable("message.t72mod." + message), true);
        }
        int energy = Math.max(0, this.battery() - this.chargeUsed);
        this.chargeUsed = 0;
        this.entityData.set(BATTERY, energy);
        this.operatorVehicle = null;
        this.entityData.set(CONTROL, -1);
        this.keys = 0;
        this.turn = 0;
        this.tilt = 0;
        this.airborneTicks = 0;
        this.entityData.set(LIMITED, false);
    }

    @Override public void tick() {
        this.previousRoll = this.entityData.get(ROLL);
        super.tick();
        if (this.level().isClientSide) {
            if (this.interpolationTicks > 0) {
                double fraction = 1D / this.interpolationTicks--;
                this.setPos(this.position().lerp(this.pendingPosition, fraction));
                this.setYRot(Mth.rotLerp((float) fraction, this.getYRot(), this.pendingYaw));
                this.setXRot(Mth.lerp((float) fraction, this.getXRot(), this.pendingPitch));
            }
            return;
        }
        if (!(this.level() instanceof ServerLevel server)) return;
        ServerPlayer pilot = this.controllerId() >= 0 && server.getEntity(this.controllerId()) instanceof ServerPlayer player
                && this.isOwnedBy(player) ? player : null;
        if (this.controllerId() >= 0 && (pilot == null || !pilot.isAlive() || pilot.isSpectator() || !operatorSeatAllowed(pilot)
                || !java.util.Objects.equals(this.operatorVehicle, pilot.isPassenger() ? pilot.getVehicle().getUUID() : null)
                || !this.stillHoldingController(pilot) || this.tickCount - this.lastFrame > 25
                || this.battery() - this.chargeUsed <= 0 || this.distanceToSqr(pilot) > 307 * 307))
            this.endControl(pilot, "fpv_lost");

        Vec3 motion;
        if (this.controllerId() >= 0 && pilot != null) {
            if (this.tickCount - this.lastFrame > 7) this.keys = 0;
            var state = FpvFlight.step(new FpvFlight.State(this.getYRot(), this.getXRot(), this.entityData.get(ROLL),
                    this.throttle, this.getDeltaMovement()), this.keys, this.turn, this.tilt, this.freeAttitude());
            this.turn = 0;
            this.tilt = 0;
            this.throttle = state.throttle();
            this.entityData.set(THROTTLE_PERCENT, (int) Math.round(this.throttle * 100));
            if (!this.onGround()) this.airborneTicks++;
            else this.airborneTicks = 0;
            this.setYRot(state.yaw());
            this.setXRot(state.pitch());
            this.entityData.set(ROLL, (byte) (int) state.roll());
            motion = FpvFlight.limitSignal(this.position(), this.hasParcel() ? state.velocity().scale(.82) : state.velocity(), pilot.position());
            boolean loaded = server.isPositionEntityTicking(BlockPos.containing(this.position().add(motion.scale(2.8))));
            this.entityData.set(LIMITED, !loaded || this.distanceToSqr(pilot) >= 270 * 270);
            if (!loaded) motion = new Vec3(0, Math.min(0, motion.y), 0);
            this.chargeUsed += (this.keys & FpvFlight.BOOST) != 0 || this.hasParcel() || this.hasPayload() ? 2 : 1;
            if (this.tickCount % 10 == 0) {
                this.entityData.set(BATTERY, Math.max(0, this.battery() - this.chargeUsed));
                this.chargeUsed = 0;
            }
        } else {
            this.entityData.set(ROLL, (byte) Mth.approach(this.entityData.get(ROLL), 0, 8));
            this.setXRot(Mth.approach(this.getXRot(), 0, 8));
            Vec3 current = this.getDeltaMovement();
            motion = this.onGround() ? new Vec3(current.x * .3, -.02, current.z * .3)
                    : new Vec3(current.x * .68, Math.max(-.42, current.y - .075), current.z * .68);
        }
        Vec3 previous = this.position();
        this.move(MoverType.SELF, motion);
        if (pilot != null && this.controllerId() >= 0 && this.hasPayload() && this.airborneTicks >= 8
                && this.payloadImpact(previous, motion, pilot)) {
            this.endControl(pilot, "fpv_impact");
            this.discard();
            server.explode(this, this.damageSources().explosion(this, pilot), null,
                    this.getX(), this.getY(), this.getZ(), 2.2F, false, T72ServerConfig.explosionInteraction(server));
            return;
        }
        boolean impact = this.horizontalCollision && motion.horizontalDistanceSqr() > 1
                || this.verticalCollision && Math.abs(motion.y) > .79;
        this.setDeltaMovement(this.horizontalCollision ? 0 : motion.x, this.verticalCollision ? 0 : motion.y,
                this.horizontalCollision ? 0 : motion.z);
        if (impact) this.hurt(this.damageSources().flyIntoWall(), 4);
        if (this.isInWater() && this.tickCount % 10 == 0) this.hurt(this.damageSources().drown(), 4);
    }

    private boolean payloadImpact(Vec3 previous, Vec3 motion, ServerPlayer pilot) {
        if (this.horizontalCollision && motion.horizontalDistanceSqr() > .035
                || this.verticalCollision && Math.abs(motion.y) > .22) return true;
        if (motion.lengthSqr() < .045) return false;
        Vec3 from = previous.add(0, .14, 0), to = this.position().add(0, .14, 0);
        for (Entity entity : this.level().getEntities(this, new AABB(from, to).inflate(.34),
                target -> target != pilot && !target.isSpectator() && target.isAlive() && target.isPickable()
                        && (target instanceof net.minecraft.world.entity.LivingEntity || target instanceof VehiclePart))) {
            AABB hit = entity.getBoundingBox().inflate(.25);
            if (hit.contains(from) || hit.contains(to) || hit.clip(from, to).isPresent()) return true;
        }
        return false;
    }

    @Override public InteractionResult interact(Player player, InteractionHand hand) {
        if (!this.isOwnedBy(player)) return InteractionResult.PASS;
        ItemStack held = player.getItemInHand(hand);
        if (held.is(T72Mod.FPV_CONTROLLER.get())) {
            if (!this.level().isClientSide && player instanceof ServerPlayer server) this.toggle(server);
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (this.controllerId() >= 0 || !this.onGround()) return InteractionResult.PASS;
        if (held.getItem() instanceof FlightBattery) {
            if (!this.level().isClientSide) {
                int incoming = FlightBattery.charge(held);
                FlightBattery.charge(held,this.battery());
                this.entityData.set(BATTERY,incoming);
                player.getInventory().setChanged();
                player.displayClientMessage(Component.translatable("message.t72mod.dock_charge",
                        incoming*100/BATTERY_CAPACITY),true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (!this.hasPayload() && !this.hasParcel() && (held.is(T72Mod.REPAIR_KIT.get()) || held.is(T72Mod.FUEL_CANISTER.get()))) {
            if (!this.level().isClientSide) this.setParcel(held.split(1));
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (held.isEmpty() && this.hasParcel()) {
            if (!this.level().isClientSide) {
                player.setItemInHand(hand,this.parcel);
                this.setParcel(ItemStack.EMPTY);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (held.is(Items.TNT) && !this.hasPayload() && !this.hasParcel()) {
            if (!this.level().isClientSide) {
                this.entityData.set(PAYLOAD, true);
                if (!player.getAbilities().instabuild) held.shrink(1);
                player.displayClientMessage(Component.translatable("message.t72mod.fpv_payload_loaded"), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (held.is(Items.SHEARS) && this.hasPayload()) {
            if (!this.level().isClientSide) {
                this.entityData.set(PAYLOAD, false);
                if (!player.getAbilities().instabuild) this.spawnAtLocation(Items.TNT);
                player.displayClientMessage(Component.translatable("message.t72mod.fpv_payload_removed"), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (held.is(Items.REDSTONE) && this.battery() < BATTERY_CAPACITY) {
            if (!this.level().isClientSide) {
                this.entityData.set(BATTERY, Math.min(BATTERY_CAPACITY, this.battery() + 500));
                if (!player.getAbilities().instabuild) held.shrink(1);
                player.displayClientMessage(Component.translatable("message.t72mod.fpv_recharged"), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (held.isEmpty() && player.isShiftKeyDown() && !this.hasPayload()) {
            if (!this.level().isClientSide) {
                ItemStack kit = new ItemStack(T72Mod.FPV_KIT.get());
                kit.getOrCreateTag().putInt(STORED_CHARGE, this.battery());
                if (!player.getInventory().add(kit)) return InteractionResult.FAIL;
                this.discard();
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override public boolean isPickable() { return this.isAlive(); }
    @Override protected float getEyeHeight(Pose pose, EntityDimensions size) { return .19F; }

    @Override public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide || !this.isAlive() || amount <= 0 || !Float.isFinite(amount)) return false;
        this.markHurt();
        this.wear -= Math.max(1, (int) amount);
        if (this.wear <= 0) {
            if (this.level() instanceof ServerLevel level && level.getEntity(this.controllerId()) instanceof ServerPlayer player)
                this.endControl(player, "fpv_lost");
            if (this.hasParcel()) { this.spawnAtLocation(this.parcel); this.setParcel(ItemStack.EMPTY); }
            this.level().playSound(null, this.blockPosition(), SoundEvents.ITEM_BREAK, SoundSource.NEUTRAL, .7F, .8F);
            this.discard();
        }
        return true;
    }

    @Override public void lerpTo(double x, double y, double z, float yaw, float pitch, int steps, boolean teleport) {
        if (teleport || !this.level().isClientSide) {
            this.interpolationTicks = 0;
            super.lerpTo(x, y, z, yaw, pitch, steps, teleport);
            return;
        }
        this.pendingPosition = new Vec3(x, y, z);
        this.pendingYaw = yaw;
        this.pendingPitch = pitch;
        this.interpolationTicks = Math.max(1, Math.min(2, steps));
    }

    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }

    @Override protected void addAdditionalSaveData(CompoundTag tag) {
        this.entityData.get(OWNER).ifPresent(id -> tag.putUUID("Owner", id));
        tag.putInt(STORED_CHARGE, Math.max(0, this.battery() - this.chargeUsed));
        tag.putInt("FrameHP", this.wear);
        tag.putBoolean("FreeAttitude", this.freeAttitude());
        if (hasParcel()) tag.put("Parcel",parcel.save(new CompoundTag()));
        tag.putBoolean("Payload", this.hasPayload());
    }

    @Override protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(OWNER, tag.hasUUID("Owner") ? Optional.of(tag.getUUID("Owner")) : Optional.empty());
        if (tag.contains(STORED_CHARGE)) this.entityData.set(BATTERY,
                Mth.clamp(tag.getInt(STORED_CHARGE), 0, BATTERY_CAPACITY));
        if (tag.contains("FreeAttitude")) this.entityData.set(FREE_ATTITUDE, tag.getBoolean("FreeAttitude"));
        this.entityData.set(PAYLOAD, tag.getBoolean("Payload"));
        setParcel(hasPayload() ? ItemStack.EMPTY : ItemStack.of(tag.getCompound("Parcel")));
        if (tag.contains("FrameHP")) this.wear = Mth.clamp(tag.getInt("FrameHP"), 1, 12);
    }
}
