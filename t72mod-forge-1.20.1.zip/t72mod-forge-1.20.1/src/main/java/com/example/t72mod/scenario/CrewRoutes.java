package com.example.t72mod.scenario;

import com.example.t72mod.entity.AirframeLayout;
import com.example.t72mod.entity.FreightRack.Carrier;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.HelicopterType;
import com.example.t72mod.item.VehicleTools;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import java.util.Comparator;
import java.util.ArrayList;
import com.example.t72mod.network.CrewChartPacket;
import com.example.t72mod.network.ModMessages;
import com.example.t72mod.entity.FpvDroneEntity;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraftforge.network.PacketDistributor;

public final class CrewRoutes extends SavedData {
    private final CompoundTag crews;
    private CrewRoutes() { this(new CompoundTag()); }
    private CrewRoutes(CompoundTag data) { crews=data; }
    @Override public CompoundTag save(CompoundTag tag) {
        tag.putInt("Version",1);
        tag.put("Crews",crews.copy());
        return tag;
    }
    private static CrewRoutes get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(t->new CrewRoutes(t.getCompound("Crews")),CrewRoutes::new,"t72mod_crew_routes");
    }
    private static String key(Player p) {
        return p.getTeam()==null ? "p:"+p.getUUID() : "t:"+p.getTeam().getName();
    }
    private static int say(ServerPlayer p,String key,Object... args) {
        p.sendSystemMessage(Component.translatable("route.t72mod."+key,args));
        return 1;
    }
    @SubscribeEvent public static void register(RegisterCommandsEvent e) {
        var root=Commands.literal("t72route");
        for (String job : new String[]{"supply","rescue"})
            root.then(Commands.literal(job).then(Commands.argument("x",IntegerArgumentType.integer(-30000000,30000000))
                    .then(Commands.argument("z",IntegerArgumentType.integer(-30000000,30000000))
                            .executes(c->start(c,job)))));
        root.then(Commands.literal("board").executes(c->rescue(c.getSource().getPlayerOrException(),false)));
        root.then(Commands.literal("unload").executes(c->rescue(c.getSource().getPlayerOrException(),true)));
        root.then(Commands.literal("status").executes(c->show(c.getSource().getPlayerOrException(),false)));
        root.then(Commands.literal("journal").executes(c->show(c.getSource().getPlayerOrException(),true)));
        root.then(Commands.literal("stop").executes(c->{
            var p=c.getSource().getPlayerOrException();var store=get(p.serverLevel());
            store.crews.getCompound(key(p)).remove("Active");store.setDirty();
            return say(p,"stopped");
        }));
        root.then(Commands.literal("map").executes(c->chart(c.getSource().getPlayerOrException())));
        var mark=Commands.literal("mark");
        for (var type : new String[]{"road","bridge","obstacle","landing"})
            mark.then(Commands.literal(type).executes(c->mark(c.getSource().getPlayerOrException(),type,""))
                    .then(Commands.argument("note",StringArgumentType.greedyString())
                            .executes(c->mark(c.getSource().getPlayerOrException(),type,StringArgumentType.getString(c,"note")))));
        root.then(mark);
        root.then(Commands.literal("unmark").then(Commands.argument("x",IntegerArgumentType.integer())
                .then(Commands.argument("z",IntegerArgumentType.integer()).executes(c->
                        unmark(c.getSource().getPlayerOrException(),IntegerArgumentType.getInteger(c,"x"),IntegerArgumentType.getInteger(c,"z"))))));
        e.getDispatcher().register(root);
    }
    private static int mark(ServerPlayer p,String type,String note) {
        var level=p.serverLevel();
        Entity observer=p;
        var data=p.getPersistentData();
        if (data.hasUUID(FpvDroneEntity.ACTIVE) && level.getEntity(data.getUUID(FpvDroneEntity.ACTIVE)) instanceof FpvDroneEntity drone
                && drone.controllerId()==p.getId()) observer=drone;
        var hit=observer.pick(observer==p?32:72,1,false);
        if (hit.getType()!=net.minecraft.world.phys.HitResult.Type.BLOCK || !level.hasChunkAt(((net.minecraft.world.phys.BlockHitResult)hit).getBlockPos()))
            return say(p,"no_surface");
        return savePin(p,((net.minecraft.world.phys.BlockHitResult)hit).getBlockPos(),type,note);
    }
    public static int savePin(ServerPlayer p,BlockPos point,String type,String note) {
        var store=get(p.serverLevel());
        var crew=store.crews.getCompound(key(p));
        var pins=crew.getList("Pins",Tag.TAG_COMPOUND);
        var target=new CompoundTag();
        for (int i=0;i<pins.size();i++) {
            var existing=pins.getCompound(i);
            if (existing.getInt("X")==point.getX() && existing.getInt("Z")==point.getZ()) { target=existing;break; }
        }
        if (target.isEmpty()) {
            if (pins.size()>=16) return say(p,"map_full");
            pins.add(target);
        }
        target.putInt("X",point.getX());target.putInt("Z",point.getZ());target.putString("Kind",type);
        target.putString("Note",net.minecraft.util.StringUtil.truncateStringIfNecessary(note,48,false));
        crew.put("Pins",pins);store.crews.put(key(p),crew);store.setDirty();
        return say(p,"marked",point.getX(),point.getZ());
    }
    private static int unmark(ServerPlayer p,int x,int z) {
        var store=get(p.serverLevel());var crew=store.crews.getCompound(key(p));var pins=crew.getList("Pins",Tag.TAG_COMPOUND);
        for (int i=0;i<pins.size();i++) {
            var pin=pins.getCompound(i);
            if (pin.getInt("X")==x && pin.getInt("Z")==z) {pins.remove(i);store.setDirty();return say(p,"unmarked");}
        }
        return say(p,"no_pin");
    }
    private static int chart(ServerPlayer p) {
        var crew=get(p.serverLevel()).crews.getCompound(key(p));var list=new ArrayList<CrewChartPacket.Pin>();
        var pins=crew.getList("Pins",Tag.TAG_COMPOUND);
        for (int i=0;i<Math.min(16,pins.size());i++) {
            var pin=pins.getCompound(i);list.add(new CrewChartPacket.Pin(pin.getString("Kind"),pin.getInt("X"),pin.getInt("Z"),pin.getString("Note")));
        }
        if (crew.contains("Active")) {
            var job=crew.getCompound("Active");var home=BlockPos.of(job.getLong("Home"));
            list.add(new CrewChartPacket.Pin("home",home.getX(),home.getZ(),""));
            list.add(new CrewChartPacket.Pin("goal",job.getInt("X"),job.getInt("Z"),""));
        }
        ModMessages.INSTANCE.send(PacketDistributor.PLAYER.with(()->p),new CrewChartPacket(p.level().dimension().location(),list));return 1;
    }
    private static int start(CommandContext<CommandSourceStack> ctx,String kind) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        var p=ctx.getSource().getPlayerOrException();var level=p.serverLevel();var store=get(level);
        int x=IntegerArgumentType.getInteger(ctx,"x"), z=IntegerArgumentType.getInteger(ctx,"z");
        if (kind.equals("supply") && !level.isNight()) return say(p,"night");
        double distance=Math.hypot(x-p.getX(),z-p.getZ());
        if (distance<40 || distance>1500 || !level.getWorldBorder().isWithinBounds(new BlockPos(x,p.getBlockY(),z))) return say(p,"range");
        var crew=store.crews.getCompound(key(p));
        if (crew.contains("Active")) return say(p,"active");
        var job=new CompoundTag();
        job.putString("Kind",kind);job.putLong("Home",p.blockPosition().asLong());
        job.putInt("X",x);job.putInt("Z",z);job.putLong("Started",level.getGameTime());
        crew.put("Active",job);store.crews.put(key(p),crew);store.setDirty();
        return say(p,kind,x,z);
    }
    private static boolean atGoal(Entity v,CompoundTag job,boolean home) {
        var p=BlockPos.of(job.getLong("Home"));
        double x=home?p.getX():job.getInt("X"),z=home?p.getZ():job.getInt("Z");
        return Math.hypot(v.getX()-x,v.getZ()-z)<=12;
    }
    public static void loaded(Player player,Entity carrier,int slot) {
        if (!(player instanceof ServerPlayer p)) return;
        var store=get(p.serverLevel());var job=store.crews.getCompound(key(p)).getCompound("Active");
        if (!job.getString("Kind").equals("supply") || job.hasUUID("Vehicle") || !atGoal(carrier,job,true)) return;
        job.putLong("Revision",((Carrier)carrier).freight().revision(slot));
        job.putUUID("Vehicle",carrier.getUUID());job.putInt("Slot",slot);store.setDirty();
        say(p,"onboard",job.getInt("X"),job.getInt("Z"));
    }
    public static void moved(Player player,Entity source,int slot,Entity target,int next) {
        if (!(player instanceof ServerPlayer p)) return;
        var store=get(p.serverLevel());var crew=store.crews.getCompound(key(p));var job=crew.getCompound("Active");
        if (!job.getString("Kind").equals("supply") || !job.hasUUID("Vehicle")
                || !job.getUUID("Vehicle").equals(source.getUUID()) || job.getInt("Slot")!=slot
                || job.getLong("Revision")+1 != ((Carrier)source).freight().revision(slot)) return;
        if (target!=null) {
            job.putUUID("Vehicle",target.getUUID());job.putInt("Slot",next);
            job.putLong("Revision",((Carrier)target).freight().revision(next));
        } else if (atGoal(source,job,false)) {
            store.finish(p,crew,job);return;
        } else {
            job.remove("Vehicle");say(p,"retry");
        }
        store.setDirty();
    }
    private static int rescue(ServerPlayer p,boolean finish) {
        var level=p.serverLevel();var store=get(level);var crew=store.crews.getCompound(key(p));var job=crew.getCompound("Active");
        if (!job.getString("Kind").equals("rescue")) return say(p,"none");
        var air=level.getEntitiesOfClass(HelicopterEntity.class,p.getBoundingBox().inflate(9),
                h->h.model()==HelicopterType.MI8 && h.bayOpen() && h.onGround() && VehicleTools.mayHandleFreight(p,h)
                        && atGoal(h,job,finish)).stream().min(Comparator.comparingDouble(p::distanceToSqr)).orElse(null);
        if (air==null) return say(p,"land");
        Vec3 rear=AirframeLayout.world(air.position(),air.getYRot(),0,.1,-6.7);
        if (finish) {
            if (!job.hasUUID("Person") || !(level.getEntity(job.getUUID("Person")) instanceof Villager villager)
                    || villager.getVehicle()!=air) return say(p,"passenger");
            BlockPos ground=BlockPos.containing(rear).below();
            if (!level.getBlockState(ground).isFaceSturdy(level,ground,net.minecraft.core.Direction.UP)
                    || !level.noCollision(villager,villager.getBoundingBox().move(rear.subtract(villager.position())))) return say(p,"blocked");
            villager.stopRiding();villager.teleportTo(rear.x,rear.y,rear.z);
            store.finish(p,crew,job);return 1;
        }
        if (job.hasUUID("Person")) return say(p,"active");
        var person=level.getEntitiesOfClass(Villager.class,air.getBoundingBox().inflate(9),
                v->v.isAlive() && !v.isPassenger() && !v.isBaby() && v.position().distanceToSqr(rear)<=64)
                .stream().min(Comparator.comparingDouble(v->v.position().distanceToSqr(rear))).orElse(null);
        if (person==null || !air.boardRescuePassenger(person)) return say(p,"passenger");
        job.putUUID("Person",person.getUUID());store.setDirty();return say(p,"return");
    }
    private void finish(ServerPlayer p,CompoundTag crew,CompoundTag job) {
        var log=crew.getList("Journal",Tag.TAG_COMPOUND);
        var record=job.copy();record.putLong("Finished",p.serverLevel().getGameTime());
        log.add(record);if (log.size()>24) log.remove(0);
        crew.put("Journal",log);crew.remove("Active");setDirty();say(p,"done");
    }
    private static int show(ServerPlayer p,boolean history) {
        var crew=get(p.serverLevel()).crews.getCompound(key(p));
        if (history) {
            var log=crew.getList("Journal",Tag.TAG_COMPOUND);
            if (log.isEmpty()) return say(p,"empty");
            for (int i=Math.max(0,log.size()-8);i<log.size();i++) {
                var j=log.getCompound(i);
                say(p,"entry",Component.translatable("route.t72mod.kind_"+j.getString("Kind")),
                        j.getInt("X"),j.getInt("Z"),(j.getLong("Finished")-j.getLong("Started"))/20);
            }
            return 1;
        }
        if (!crew.contains("Active")) return say(p,"none");
        var j=crew.getCompound("Active");var home=BlockPos.of(j.getLong("Home"));
        return say(p,"status",Component.translatable("route.t72mod.kind_"+j.getString("Kind")),home.getX(),home.getZ(),
                j.getInt("X"),j.getInt("Z"),Component.translatable("route.t72mod."+
                        (j.hasUUID("Person")||j.hasUUID("Vehicle")?"stage_loaded":"stage_wait")));
    }
}
