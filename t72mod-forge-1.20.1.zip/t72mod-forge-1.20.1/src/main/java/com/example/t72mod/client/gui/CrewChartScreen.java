package com.example.t72mod.client.gui;

import com.example.t72mod.network.CrewChartPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class CrewChartScreen extends Screen {
    private final CrewChartPacket chart;
    private CrewChartScreen(CrewChartPacket chart) {
        super(Component.translatable("chart.t72mod.title"));
        this.chart=chart;
    }
    public static void open(CrewChartPacket chart) {
        var mc=Minecraft.getInstance();
        if (mc.level!=null && mc.level.dimension().location().equals(chart.dimension())) mc.setScreen(new CrewChartScreen(chart));
    }
    @Override protected void init() {
        addRenderableWidget(Button.builder(Component.translatable("chart.t72mod.refresh"),b->{
            if (minecraft.getConnection()!=null) minecraft.getConnection().sendCommand("t72route map");
        }).bounds(width/2-45,height-24,90,20).build());
    }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void render(GuiGraphics g,int mx,int my,float pt) {
        renderBackground(g);
        var player=minecraft.player;
        if (player==null) return;
        int left=12,top=28,right=width-12,bottom=height-42,cx=(left+right)/2,cy=(top+bottom)/2;
        int ox=player.getBlockX(),oz=player.getBlockZ();
        double scale=.65;
        for (var p:chart.pins()) scale=Math.max(scale,Math.max(Math.abs(p.x()-ox)/(double)Math.max(1,cx-left-12),
                Math.abs(p.z()-oz)/(double)Math.max(1,cy-top-12)));
        g.fill(left,top,right,bottom,0xff1c3236);
        for (int i=-4;i<=4;i++){
            int x=cx+i*(right-left)/8,y=cy+i*(bottom-top)/8;
            g.vLine(x,top,bottom,0xff304549);g.hLine(left,right,y,0xff304549);
        }
        g.drawCenteredString(font,title,cx,8,0xffffff);
        g.drawString(font,"N",left+4,top+3,0xffc8d7cd);
        Component legend=Component.translatable("chart.t72mod.help",ox,oz);
        for (var p:chart.pins()) {
            int x=cx+(int)Math.round((p.x()-ox)/scale),y=cy+(int)Math.round((p.z()-oz)/scale);
            String symbol=switch(p.kind()) {case "home" -> "H";case "goal" -> "X";case "landing" -> "+";case "road" -> "=";case "bridge" -> "#";default -> "!";};
            g.drawCenteredString(font,symbol,x,y-4,0xffffd277);
            if (Math.abs(mx-x)<=8 && Math.abs(my-y)<=8) legend=Component.translatable("chart.t72mod.pin",
                    Component.translatable("chart.t72mod."+p.kind()),p.x(),p.z(),p.note());
        }
        g.fill(cx-2,cy-2,cx+2,cy+2,0xff73e9db);
        g.drawCenteredString(font,font.plainSubstrByWidth(legend.getString(),width-12),cx,bottom+4,0xffe8ede4);
        super.render(g,mx,my,pt);
    }
}
