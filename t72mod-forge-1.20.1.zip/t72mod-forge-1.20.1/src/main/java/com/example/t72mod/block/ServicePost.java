package com.example.t72mod.block;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.item.VehicleTools;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import java.util.Comparator;

public final class ServicePost extends Block {
    public ServicePost(Properties p) { super(p); }
    @Override public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        var held=player.getItemInHand(hand);
        if (!held.is(T72Mod.REPAIR_KIT.get())) {
            player.displayClientMessage(Component.translatable("message.t72mod.post_kit"),true);
            return InteractionResult.CONSUME;
        }
        var point=Vec3.atCenterOf(pos);
        var target=level.getEntitiesOfClass(T72TankEntity.class,new AABB(pos).inflate(5),t ->
                t.isAlive() && t.onGround() && !t.isVehicle() && t.distanceToSqr(point)<=25
                        && VehicleTools.mayHandleFreight(player,t) && (t.isWreck() || t.hasBrokenModules() || t.getHealth()<t.getMaxHealth()))
                .stream().min(Comparator.comparingDouble(t->t.distanceToSqr(point)));
        if (target.isPresent() && target.get().overhaul()) {
            if (!player.getAbilities().instabuild) held.shrink(1);
            player.displayClientMessage(Component.translatable("message.t72mod.post_done"),true);
        } else player.displayClientMessage(Component.translatable("message.t72mod.post_empty"),true);
        return InteractionResult.CONSUME;
    }
}
