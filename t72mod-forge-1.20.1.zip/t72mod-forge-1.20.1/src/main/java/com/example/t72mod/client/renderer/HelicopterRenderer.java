package com.example.t72mod.client.renderer;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.HelicopterType;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class HelicopterRenderer extends EntityRenderer<HelicopterEntity> {
    public static final ModelLayerLocation MI8_LAYER = layer("mi8");
    public static final ModelLayerLocation MI24_LAYER = layer("mi24");

    private final ModelPart root;
    public static final ModelLayerLocation KA52_LAYER = layer("ka52");
    private final ModelPart mainRotor;
    private final ModelPart secondRotor;
    private final ModelPart door;
    private final ModelPart tailRotor;
    private final ModelPart chest;
    private final ModelPart launchers;
    private final ResourceLocation texture;

    private static ModelLayerLocation layer(String name) {
        return new ModelLayerLocation(new ResourceLocation(T72Mod.MODID, name), "main");
    }

    public HelicopterRenderer(EntityRendererProvider.Context context, HelicopterType type) {
        super(context);
        this.root = context.bakeLayer(switch (type) { case MI8 -> MI8_LAYER; case MI24 -> MI24_LAYER; case KA52 -> KA52_LAYER; });
        this.secondRotor = root.getChild("second_rotor");
        this.door = root.getChild("door");
        this.mainRotor = this.root.getChild("main_rotor");
        this.tailRotor = this.root.getChild("tail_rotor");
        this.chest = this.root.getChild("chest");
        this.launchers = this.root.getChild("launchers");
        this.texture = new ResourceLocation(T72Mod.MODID, "textures/entity/" + type.name().toLowerCase(java.util.Locale.ROOT) + ".png");
        this.shadowRadius = 2.25F;
    }

    @Override
    public void render(HelicopterEntity aircraft, float yaw, float partialTick, PoseStack poses,
                       MultiBufferSource buffers, int light) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.getVehicle() == aircraft && mc.options.getCameraType().isFirstPerson()) return;
        poses.pushPose();
        poses.scale(1.35F, 1.35F, 1.35F);
        poses.mulPose(Axis.YP.rotationDegrees(180 - Mth.rotLerp(partialTick, aircraft.yRotO, aircraft.getYRot())));
        poses.mulPose(Axis.XP.rotationDegrees(aircraft.visualPitch()));
        poses.mulPose(Axis.ZP.rotationDegrees(aircraft.visualRoll()));
        this.mainRotor.yRot = aircraft.rotorAngle(partialTick) * Mth.DEG_TO_RAD;
        this.tailRotor.xRot = this.mainRotor.yRot * 3;
        this.chest.visible = aircraft.hasChest();
        this.mainRotor.visible = aircraft.rotorHealth() > 0;
        this.tailRotor.visible = aircraft.tailHealth() > 0 && aircraft.model() != HelicopterType.KA52;
        this.secondRotor.visible = this.mainRotor.visible && aircraft.model() == HelicopterType.KA52;
        this.secondRotor.yRot = -this.mainRotor.yRot + 0.48F;
        this.door.visible = aircraft.model() == HelicopterType.MI8 && !aircraft.isCabinOpen();
        this.launchers.visible = aircraft.model().armed && aircraft.launcherHealth() > 0;
        VertexConsumer vertices = buffers.getBuffer(RenderType.entityCutoutNoCull(this.texture));
        this.root.render(poses, vertices, light, OverlayTexture.NO_OVERLAY);
        poses.popPose();
        super.render(aircraft, yaw, partialTick, poses, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(HelicopterEntity aircraft) {
        return this.texture;
    }

    public static LayerDefinition createBodyLayer(HelicopterType type) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        boolean transport = type == HelicopterType.MI8;
        boolean coaxial = type == HelicopterType.KA52;
        int width = coaxial ? 36 : type.armed ? 32 : 42;
        int half = width / 2;
        root.addOrReplaceChild("fuselage", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-half, 10, -23, width, 6, 49)
                .texOffs(0, 0).addBox(-half, 16, -23, width, 12, 14)
                .texOffs(0, 0).addBox(half - 2, 16, -9, 2, transport ? 23 : 13, 35)
                .texOffs(0, 0).addBox(-half, 16, 10, 2, transport ? 23 : 13, 16)
                .texOffs(0, 0).addBox(-half, transport ? 37 : 24, -9, 2, 5, 19)
                .texOffs(0, 0).addBox(-half + 3, 6, -24, width - 6, 4, 45)
                .texOffs(0, 0).addBox(-half + 3, transport ? 39 : 28, -15, width - 6, 4, 38)
                .texOffs(68, 60).addBox(-7, 20, 24, 14, 11, coaxial ? 27 : 44)
                .texOffs(68, 60).addBox(-3, 23, coaxial ? 47 : 57, 6, coaxial ? 14 : 23, 12)
                .texOffs(68, 60).addBox(-13, 24, 49, 26, 2, 9)
                .texOffs(150, 60).addBox(-9, transport ? 41 : 31, -4, 18, 5, 27)
                .texOffs(150, 60).addBox(-2, transport ? 44 : 35, 6, 4, coaxial ? 15 : 8, 4), PartPose.ZERO);
        CubeListBuilder cockpit = CubeListBuilder.create();
        if (coaxial) {
            cockpit.texOffs(128, 128).addBox(-15, 19, -37, 30, 10, 21)
                    .texOffs(0, 0).addBox(-16, 9, -42, 32, 10, 28)
                    .texOffs(68, 60).addBox(-36, 15, -2, 72, 3, 15)
                    .texOffs(150, 60).addBox(17, 11, -26, 3, 4, 17);
        } else if (type.armed) {
            cockpit.texOffs(128, 128).addBox(-9, 16, -39, 18, 12, 17)
                    .texOffs(128, 128).addBox(-7, 24, -28, 14, 9, 14)
                    .texOffs(0, 0).addBox(-12, 9, -39, 24, 8, 20)
                    .texOffs(68, 60).addBox(-33, 13, -8, 66, 3, 17);
        } else {
            cockpit.texOffs(128, 128).addBox(-18, 18, -33, 36, 11, 12)
                    .texOffs(0, 0).addBox(-18, 10, -34, 36, 8, 13)
                    .texOffs(128, 128).addBox(-21.1F, 19, 12, 1, 6, 9)
                    .texOffs(128, 128).addBox(20.1F, 19, -10, 1, 7, 30)
                    .texOffs(68, 60).addBox(-11, 9, 25, 22, 10, 3);
        }
        root.addOrReplaceChild("launchers", CubeListBuilder.create()
                .texOffs(0, 177).addBox(-32, 7, -12, 8, 7, 22)
                .texOffs(0, 177).addBox(24, 7, -12, 8, 7, 22), PartPose.ZERO);
        root.addOrReplaceChild("cockpit", cockpit, PartPose.ZERO);
        root.addOrReplaceChild("gear", CubeListBuilder.create()
                .texOffs(150, 60).addBox(-2, 3, -22, 4, 10, 4)
                .texOffs(150, 60).addBox(-half, 3, 10, width, 5, 4)
                .texOffs(0, 177).addBox(-4, 0, -25, 8, 7, 9)
                .texOffs(0, 177).addBox(-half - 4, 0, 7, 7, 7, 10)
                .texOffs(0, 177).addBox(half - 3, 0, 7, 7, 7, 10), PartPose.ZERO);
        root.addOrReplaceChild("main_rotor", CubeListBuilder.create()
                .texOffs(0, 208).addBox(-67, -1, -3, 134, 2, 6)
                .texOffs(0, 220).addBox(-3, -1, -67, 6, 2, 134), PartPose.offset(0, transport ? 52 : 43, 8));
        root.addOrReplaceChild("second_rotor", CubeListBuilder.create()
                .texOffs(0, 208).addBox(-61, -1, -3, 122, 2, 6)
                .texOffs(0, 221).addBox(-3, -1, -61, 6, 2, 122), PartPose.offset(0, 51, 8));
        root.addOrReplaceChild("door", CubeListBuilder.create()
                .texOffs(60, 9).addBox(-21, 16, -9, 2, 21, 19)
                .texOffs(128, 128).addBox(-21.2F, 26, -6, 1, 7, 12), PartPose.ZERO);
        root.addOrReplaceChild("tail_rotor", CubeListBuilder.create()
                .texOffs(0, 177).addBox(-1, -13, -1, 2, 26, 2)
                .texOffs(0, 177).addBox(-1, -1, -13, 2, 2, 26), PartPose.offset(4, 34, 65));
        root.addOrReplaceChild("cabin_seats", CubeListBuilder.create()
                .texOffs(0, 177).addBox(-14, 16, -2, 7, 3, 10)
                .texOffs(0, 177).addBox(7, 16, -2, 7, 3, 10)
                .texOffs(0, 177).addBox(-14, 16, 10, 7, 3, 10)
                .texOffs(0, 177).addBox(7, 16, 10, 7, 3, 10), PartPose.ZERO);
        root.addOrReplaceChild("chest", CubeListBuilder.create()
                .texOffs(112, 176).addBox(-6, 16, 15, 12, 10, 10)
                .texOffs(154, 176).addBox(-1, 21, 24, 2, 3, 2), PartPose.ZERO);
        return LayerDefinition.create(mesh, 320, 384);
    }
}
