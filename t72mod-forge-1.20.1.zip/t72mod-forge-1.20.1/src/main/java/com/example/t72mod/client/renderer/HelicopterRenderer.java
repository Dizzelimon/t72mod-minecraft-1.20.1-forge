package com.example.t72mod.client.renderer;

import com.example.t72mod.client.model.AirframeModel;
import com.example.t72mod.entity.AirframeLayout;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.HelicopterType;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public final class HelicopterRenderer extends EntityRenderer<HelicopterEntity> {
    public static final ResourceLocation SURFACE = new ResourceLocation("t72mod", "textures/entity/mesh_surface.png");
    private static final ResourceLocation GLASS = new ResourceLocation("t72mod", "textures/entity/mesh_glass.png");
    private final AirframeModel model;

    public HelicopterRenderer(EntityRendererProvider.Context ctx, HelicopterType type) {
        super(ctx);
        this.model = new AirframeModel(type);
        this.shadowRadius = 1.7F;
    }

    @Override public ResourceLocation getTextureLocation(HelicopterEntity aircraft) { return SURFACE; }

    @Override public boolean shouldRender(HelicopterEntity h, Frustum camera, double x, double y, double z) {
        return h.shouldRender(x,y,z) && camera.isVisible(h.getBoundingBox().inflate(12,2.5,12));
    }

    @Override public void render(HelicopterEntity h, float yaw, float pt, PoseStack poses,
                                 MultiBufferSource buffers, int light) {
        var surface = buffers.getBuffer(RenderType.entityCutoutNoCull(SURFACE));
        poses.pushPose();
        poses.mulPose(Axis.YP.rotationDegrees(-Mth.rotLerp(pt,h.yRotO,h.getYRot())));

        // Only the flying shell banks. A parked cabin remains aligned with its collision deck.
        poses.mulPose(Axis.XP.rotationDegrees(h.visualPitch()));
        poses.mulPose(Axis.ZP.rotationDegrees(h.visualRoll()));
        this.model.body.draw(poses.last(),surface,light);
        this.model.cabin.draw(poses.last(),surface,light);
        if (h.model() == HelicopterType.MI8 && !h.isCabinOpen()) this.model.door.draw(poses.last(),surface,light);
        if (h.model().armed && h.launcherHealth() > 0) this.model.stores.draw(poses.last(),surface,light);
        if (h.rotorHealth() > 0) {
            drawRotor(h, poses, surface, light, h.rotorAngle(pt), 0);
            if (h.model() == HelicopterType.KA52) drawRotor(h, poses, surface, light, -h.rotorAngle(pt)+20, .51);
        }
        if (h.model() != HelicopterType.KA52 && h.tailHealth() > 0) {
            poses.pushPose();
            poses.translate(.12,3.65,AirframeLayout.tailZ(h.model()));
            poses.mulPose(Axis.XP.rotationDegrees(h.rotorAngle(pt)*3));
            this.model.tail.draw(poses.last(),surface,light);
            poses.popPose();
        }
        this.model.glass.draw(poses.last(), buffers.getBuffer(RenderType.entityTranslucent(GLASS)), light);
        poses.popPose();
        super.render(h,yaw,pt,poses,buffers,light);
    }

    private void drawRotor(HelicopterEntity h, PoseStack poses, com.mojang.blaze3d.vertex.VertexConsumer out,
                           int light, float angle, double offset) {
        poses.pushPose();
        poses.translate(0, AirframeLayout.rotorY(h.model())+offset,-.53);
        poses.mulPose(Axis.YP.rotationDegrees(angle));
        this.model.rotor.draw(poses.last(),out,light);
        poses.popPose();
    }
}
