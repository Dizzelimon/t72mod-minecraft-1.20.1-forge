package com.example.t72mod.client.renderer;

import com.example.t72mod.client.model.AirframeModel;
import com.example.t72mod.entity.AirframeLayout;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.HelicopterType;
import com.example.t72mod.entity.HelicopterCabin;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public final class HelicopterRenderer extends EntityRenderer<HelicopterEntity> {
    public static final ResourceLocation SURFACE = new ResourceLocation("t72mod", "textures/entity/mesh_surface.png");
    private static final ResourceLocation GLASS = new ResourceLocation("t72mod", "textures/entity/mesh_glass.png");
    private final AirframeModel model;

    public HelicopterRenderer(EntityRendererProvider.Context ctx, HelicopterType type) {
        super(ctx);
        this.model = new AirframeModel(type);
        this.shadowRadius = 1.7F;
    }

    @Override public ResourceLocation getTextureLocation(HelicopterEntity aircraft) { return SURFACE; }

    @Override public boolean shouldRender(HelicopterEntity h, Frustum camera, double x, double y, double z) {
        return h.shouldRender(x,y,z) && camera.isVisible(h.getBoundingBox().inflate(12,2.5,12));
    }

    @Override public void render(HelicopterEntity h, float yaw, float pt, PoseStack poses,
                                 MultiBufferSource buffers, int light) {
        var surface = buffers.getBuffer(RenderType.entityCutoutNoCull(SURFACE));
        poses.pushPose();
        poses.mulPose(Axis.YP.rotationDegrees(-Mth.rotLerp(pt,h.yRotO,h.getYRot())));

        // Only the flying shell banks. A parked cabin remains aligned with its collision deck.
        poses.mulPose(Axis.XP.rotationDegrees(h.visualPitch()));
        poses.mulPose(Axis.ZP.rotationDegrees(h.visualRoll()));
        this.model.body.draw(poses.last(),surface,light);
        this.model.cabin.draw(poses.last(),surface,light);
        if (h.isCabinOpen()) this.model.steps.draw(poses.last(),surface,light);
        else this.model.door.draw(poses.last(),surface,light);
        if (h.model()==HelicopterType.MI8) {
            float ramp=h.rampProgress(pt);
            if (ramp<=0) this.model.rearHatch.draw(poses.last(),surface,light);
            else if (ramp>=.999F) this.model.rearRampDeck.draw(poses.last(),surface,light);
            else {
                var layout=HelicopterCabin.forType(h.model());
                poses.pushPose();
                poses.translate(0,layout.floor,layout.rear-.09);
                poses.mulPose(Axis.XP.rotationDegrees(Mth.lerp(ramp,90,-28)));
                poses.scale(1,1,Mth.lerp(ramp,.83F,1));
                this.model.rearRamp.draw(poses.last(),surface,light);
                poses.popPose();
            }
        }
        if (h.launcherHealth() > 0) this.model.stores.draw(poses.last(),surface,light);
        else this.model.storeDamage.draw(poses.last(),surface,light);
        if (h.engineHealth() < 45) this.model.engineDamage.draw(poses.last(),surface,light);
        if (h.tailHealth() < 45) this.model.tailDamage.draw(poses.last(),surface,light);
        if (h.rotorHealth() == 0) this.model.rotorDamage.draw(poses.last(),surface,light);
        if (h.rotorHealth() > 0) {
            drawRotor(h, poses, surface, light, h.rotorAngle(pt), 0);
            if (h.model() == HelicopterType.KA52) drawRotor(h, poses, surface, light, -h.rotorAngle(pt)+20, .51);
        }
        if (h.model() != HelicopterType.KA52 && h.tailHealth() > 0) {
            poses.pushPose();
            poses.translate(.12,3.65,AirframeLayout.tailZ(h.model()));
            poses.mulPose(Axis.XP.rotationDegrees(h.rotorAngle(pt)*3));
            this.model.tail.draw(poses.last(),surface,light);
            poses.popPose();
        }
        var glazing = buffers.getBuffer(RenderType.entityTranslucent(GLASS));
        this.model.glass.draw(poses.last(),glazing,light);
        if (!h.isCabinOpen()) this.model.doorGlass.draw(poses.last(),glazing,light);
        poses.popPose();
        super.render(h,yaw,pt,poses,buffers,light);
    }

    private void drawRotor(HelicopterEntity h, PoseStack poses, com.mojang.blaze3d.vertex.VertexConsumer out,
                           int light, float angle, double offset) {
        poses.pushPose();
        poses.translate(0, AirframeLayout.rotorY(h.model())+offset,-.53);
        poses.mulPose(Axis.YP.rotationDegrees(angle));
        this.model.rotor.draw(poses.last(),out,light);
        poses.popPose();
    }
}
