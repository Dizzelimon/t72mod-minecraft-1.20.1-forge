package com.example.t72mod.network;

import com.example.t72mod.client.gui.CrewChartScreen;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public record CrewChartPacket(ResourceLocation dimension, List<Pin> pins) {
    public record Pin(String kind, int x, int z, String note) {}
    public static void encode(CrewChartPacket packet,FriendlyByteBuf buf) {
        buf.writeResourceLocation(packet.dimension);
        buf.writeCollection(packet.pins,(b,p)->{
            b.writeUtf(p.kind,16);b.writeInt(p.x);b.writeInt(p.z);b.writeUtf(p.note,48);
        });
    }
    public static CrewChartPacket decode(FriendlyByteBuf buf) {
        var dimension=buf.readResourceLocation();
        var pins=buf.readCollection(FriendlyByteBuf.limitValue(ArrayList::new,18),
                b->new Pin(b.readUtf(16),b.readInt(),b.readInt(),b.readUtf(48)));
        return new CrewChartPacket(dimension,List.copyOf(pins));
    }
    public static void handle(CrewChartPacket packet,Supplier<NetworkEvent.Context> supplied) {
        var context=supplied.get();
        context.enqueueWork(()-> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->CrewChartScreen.open(packet)));
        context.setPacketHandled(true);
    }
}
