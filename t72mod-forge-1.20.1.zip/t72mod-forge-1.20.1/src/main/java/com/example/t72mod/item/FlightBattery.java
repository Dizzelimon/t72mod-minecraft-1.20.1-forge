package com.example.t72mod.item;

import com.example.t72mod.entity.FpvDroneEntity;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class FlightBattery extends Item {
    public FlightBattery() { super(new Properties().stacksTo(1)); }

    public static int charge(ItemStack pack) {
        return pack.hasTag() && pack.getTag().contains(FpvDroneEntity.STORED_CHARGE)
                ? Mth.clamp(pack.getTag().getInt(FpvDroneEntity.STORED_CHARGE),0,FpvDroneEntity.BATTERY_CAPACITY)
                : FpvDroneEntity.BATTERY_CAPACITY;
    }

    public static void charge(ItemStack pack,int energy) {
        pack.getOrCreateTag().putInt(FpvDroneEntity.STORED_CHARGE,Mth.clamp(energy,0,FpvDroneEntity.BATTERY_CAPACITY));
    }

    @Override public boolean isBarVisible(ItemStack stack) { return true; }
    @Override public int getBarWidth(ItemStack stack) { return Math.round(charge(stack)*13F/FpvDroneEntity.BATTERY_CAPACITY); }
    @Override public int getBarColor(ItemStack stack) { return charge(stack)<390 ? 0xc2743e : 0x80ab65; }
}
