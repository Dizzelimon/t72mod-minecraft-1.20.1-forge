package com.example.t72mod.network;

import com.example.t72mod.client.FpvClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.function.Supplier;

public record FpvViewPacket(int droneId) {
    public static void send(ServerPlayer player, int id) {
        if (player instanceof FakePlayer || player.connection == null
                || player.connection.connection.channel() == null || !player.connection.connection.isConnected()) return;
        ModMessages.INSTANCE.send(PacketDistributor.PLAYER.with(() -> player), new FpvViewPacket(id));
    }

    static void encode(FpvViewPacket packet, FriendlyByteBuf out) { out.writeVarInt(packet.droneId); }
    static FpvViewPacket decode(FriendlyByteBuf in) { return new FpvViewPacket(in.readVarInt()); }

    static void handle(FpvViewPacket packet, Supplier<NetworkEvent.Context> supplier) {
        var context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> FpvClient.select(packet.droneId)));
        context.setPacketHandled(true);
    }
}
