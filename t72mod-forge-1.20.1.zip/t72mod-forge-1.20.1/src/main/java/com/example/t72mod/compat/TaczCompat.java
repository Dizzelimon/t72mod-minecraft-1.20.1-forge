package com.example.t72mod.compat;

import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.ModList;

/** Common entry points. Keep TaCZ types out of classes loaded without the optional mod. */
public final class TaczCompat {
    private static final boolean PRESENT = ModList.get().isLoaded("tacz");

    private TaczCompat() {}

    public static void register() {
        if (PRESENT) TaczIntegration.register();
    }

    public static boolean isGun(ItemStack stack) {
        return PRESENT && TaczIntegration.isGun(stack);
    }

    public static boolean acceptsMachineGunAmmo(ItemStack stack) {
        return PRESENT && !stack.isEmpty() && TaczIntegration.acceptsAmmo(stack);
    }

    public static int loadMachineGunAmmo(ItemStack stack, int freeSpace) {
        return PRESENT && !stack.isEmpty() && freeSpace > 0 ? TaczIntegration.loadAmmo(stack, freeSpace) : 0;
    }
}
