package com.example.t72mod.client.model;

import com.example.t72mod.entity.BmpCabin;
import net.minecraft.world.phys.Vec3;

public final class BmpHullModel {
    private static final int ARMOR = 0x616752, SIDE = 0x505a46, STEEL = 0x434741, FLOOR = 0x777a6b;
    public final VehicleMesh hull = new VehicleMesh();
    public final VehicleMesh doors = new VehicleMesh();
    public final VehicleMesh steps = new VehicleMesh();

    public BmpHullModel() {
        this.hull.box(-1.49,.53,-3.24,1.49,BmpCabin.FLOOR,2.72,STEEL);
        this.hull.box(-.70,BmpCabin.FLOOR,-3.2,.70,BmpCabin.FLOOR+.007,2.65,FLOOR);
        this.hull.box(-1.43,BmpCabin.ROOF,-3.20,1.43,2.96,2.49,ARMOR);
        this.hull.face(at(-1.49,2.14,3.49),at(1.49,2.14,3.49),at(1.43,2.95,2.48),at(-1.43,2.95,2.48),ARMOR);
        this.hull.face(at(-1.49,.71,3.46),at(1.49,.71,3.46),at(1.49,2.14,3.49),at(-1.49,2.14,3.49),SIDE);
        this.hull.box(-1.46,.70,2.68,1.46,2.72,2.79,SIDE);
        this.hull.box(-1.27,1.24,2.46,.56,1.74,2.67,STEEL);
        this.hull.box(-1.12,1.71,2.40,.11,1.82,2.51,0x323a35);
        this.hull.box(-1.08,2.44,2.69,-.30,2.67,2.83,0x354546);
        this.hull.box(-1.05,2.46,2.84,-.33,2.65,2.87,0x485f64);
        for (int side : new int[]{-1,1}) {
            double inner = side * 1.38, edge = side * 1.68, top = side * 1.43;
            this.hull.face(at(edge,.88,-3.24),at(edge,.88,3.46),at(top,2.96,2.50),at(top,2.96,-3.24),
                    side > 0 ? SIDE : ARMOR);
            this.hull.box(Math.min(inner,inner + side * .16),BmpCabin.FLOOR,-3.23,
                    Math.max(inner,inner + side * .16),BmpCabin.ROOF,2.68,0x787a68);
            this.hull.box(side == 1 ? .86 : -1.49,.78,-3.28,side == 1 ? 1.49 : -.86,2.80,-3.17,SIDE);
            this.hull.box(Math.min(side*1.46,side*1.78),.24,-2.85,Math.max(side*1.46,side*1.78),.34,2.86,0x30312b);
            this.hull.box(Math.min(side*1.43,side*1.82),1.22,-3.04,Math.max(side*1.43,side*1.82),1.34,3.03,0x42463d);
            for (int i = 0; i < 7; i++) {
                double z = -2.66 + i * .89;
                double r = i == 0 || i == 6 ? .43 : .47;
                double y = i == 0 || i == 6 ? .75 : .66;
                this.hull.tube(at(side*1.42,y,z),at(side*1.795,y,z),r,r,12,0x30322e);
                this.hull.tube(at(side*1.794,y,z),at(side*1.82,y,z),r*.69,r*.64,12,0x6a7060);
                this.hull.tube(at(side*1.818,y,z),at(side*1.87,y,z),r*.27,r*.25,8,0x4a503f);
            }
            for (int i = 0; i < 33; i++) {
                double z = -2.94 + .18 * i;
                this.hull.box(Math.min(side*1.43,side*1.82),.16,z,Math.max(side*1.43,side*1.82),.25,z+.158,STEEL);
            }
            for (double z : new double[]{-2.40,-1.58,-.75}) {
                AirframeModel.seat(this.hull,side*1.04,z,BmpCabin.FLOOR+.015,true);
                this.hull.tube(at(side*1.28,2.58,z-.30),at(side*1.28,2.58,z+.31),.024,.024,6,STEEL);
            }
            this.hull.box(Math.min(side*1.06,side*1.35),1.58,-3.325,Math.max(side*1.06,side*1.35),1.83,-3.31,0x873b30);
        }
        AirframeModel.seat(this.hull, BmpCabin.DRIVER.x, BmpCabin.DRIVER.z, BmpCabin.FLOOR+.015, false);
        this.hull.box(.81,.91,.71,1.28,1.39,1.59,0x444e40);
        this.hull.box(.81,1.36,.74,1.29,1.44,1.59,0x626956);
        for (int i = 0; i < 6; i++)
            this.hull.box(.92+i*.057,2.96,1.58,.947+i*.057,2.99,2.31,STEEL);
        this.doors.box(-.85,.78,-3.36,-.01,2.77,-3.20,ARMOR);
        this.doors.box(.01,.78,-3.36,.85,2.77,-3.20,ARMOR);
        for (double x : new double[]{-.32,.17}) this.doors.box(x,1.38,-3.39,x+.15,1.45,-3.35,STEEL);
        for (int i = 0; i < 3; i++) {
            double y = .07 + i * .23, z = -4.26 + i * .405;
            this.steps.box(-.80,y,z-.27,.80,y+.16,z+.29,STEEL);
            for (int j = 0; j < 3; j++)
                this.steps.box(-.73,y+.159,z-.21+j*.17,.73,y+.176,z-.17+j*.17,0x666b5d);
        }
    }

    private static Vec3 at(double x,double y,double z) { return new Vec3(x,y,z); }
}
