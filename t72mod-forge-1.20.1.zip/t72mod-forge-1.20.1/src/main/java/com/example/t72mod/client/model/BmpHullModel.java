package com.example.t72mod.client.model;

import com.example.t72mod.entity.BmpCabin;
import net.minecraft.world.phys.Vec3;

public final class BmpHullModel {
    private static final int ARMOR = 0x606b50, SIDE = 0x465446, STEEL = 0x404942, FLOOR = 0x74756a, PERISCOPE = 0x3d5355;
    public final VehicleMesh hull = new VehicleMesh();
    public final VehicleMesh doors = new VehicleMesh();
    public final VehicleMesh steps = new VehicleMesh();
    public final VehicleMesh hatchClosed = new VehicleMesh();
    public final VehicleMesh hatchOpen = new VehicleMesh();
    public final VehicleMesh dashboard = new VehicleMesh();
    public final VehicleMesh turret = new VehicleMesh();

    public BmpHullModel() {
        this.buildHull();
        this.buildInterior();
        this.buildTurret();
    }

    private void buildHull() {
        double roof = BmpCabin.ROOF;
        this.hull.box(-1.50,.59,-3.23,1.50,BmpCabin.FLOOR,2.82,STEEL);
        this.hull.box(-.72,BmpCabin.FLOOR,-3.22,.72,BmpCabin.FLOOR+.012,2.78,FLOOR);
        this.hull.box(-1.28,roof,-3.17,1.28,roof+.15,1.18,ARMOR);
        this.hull.box(-1.23,roof,1.18,-1.08,roof+.12,2.20,ARMOR);
        this.hull.box(-.28,roof,1.18,1.23,roof+.12,2.32,ARMOR);
        this.hull.box(-1.08,roof,1.17,-.28,roof+.11,1.56,ARMOR);
        this.hull.box(-1.08,roof,2.25,-.28,roof+.12,2.34,ARMOR);

        Vec3 n0=at(-1.38,.49,3.65), n1=at(1.38,.49,3.65);
        Vec3 n2=at(-1.27,1.42,3.51), n3=at(1.27,1.42,3.51);
        this.hull.face(n0,n1,n3,n2,SIDE);
        this.hull.face(n2,n3,at(1.23,roof+.12,2.33),at(-1.23,roof+.12,2.33),ARMOR);
        this.hull.face(at(-1.12,1.52,3.47),at(1.12,1.52,3.47),
                at(1.07,2.36,2.71),at(-1.07,2.36,2.71),0x6b7759);
        this.hull.box(-1.38,.49,2.80,1.38,.60,3.58,STEEL);
        this.hull.tube(at(-1.32,1.48,3.50),at(1.32,1.48,3.50),.045,.045,6,STEEL);
        for (int side : new int[]{-1,1}) {
            this.side(side);
            this.hull.face(at(side*1.38,.49,3.65),at(side*1.75,1.32,3.22),
                    at(side*1.23,2.82,2.33),at(side*1.27,1.42,3.51),SIDE);
            this.hull.face(at(side*1.38,.49,3.65),at(side*1.50,.59,2.82),
                    at(side*1.75,1.32,3.22),at(side*1.50,1.20,3.22),STEEL);
            double x=side*1.08;
            this.hull.tube(at(x,1.73,3.22),at(x,1.72,3.37),.12,.10,10,STEEL);
            this.hull.tube(at(x,1.72,3.37),at(x,1.72,3.39),.084,.084,10,0xc9bf94);
            this.hull.tube(at(side*1.09,2.09,2.82),at(side*1.09,1.93,3.09),.035,.027,6,0x2e3930);
            this.hull.box(x-.105,1.53,-3.303,x+.105,1.69,-3.27,0x814034);
        }
        for (double x : new double[]{-.96,-.69,-.42,.49,.77,1.02}) {
            this.hull.box(x-.096,roof+.095,2.23,x+.096,roof+.23,2.43,STEEL);
            this.hull.box(x-.076,roof+.125,2.428,x+.076,roof+.204,2.442,PERISCOPE);
        }
        this.hatchClosed.box(-1.09,roof+.03,1.56,-.27,roof+.16,2.25,ARMOR);
        this.hatchClosed.box(-.95,roof+.16,1.66,-.41,roof+.20,2.14,0x728260);
        this.hatchOpen.box(-1.11,roof+.03,1.54,-.26,roof+.69,1.66,ARMOR);
        this.hatchOpen.box(-.98,roof+.12,1.515,-.40,roof+.56,1.54,0x6e785d);
    }

    private void side(int side) {
        double edge=side*1.75, ridge=side*1.24, inner=side*1.43;
        this.hull.face(at(edge,1.31,-3.23),at(edge,1.32,3.22),
                at(ridge,2.82,2.32),at(ridge,2.85,-3.23),side>0 ? SIDE : ARMOR);
        this.hull.box(Math.min(inner,inner+side*.10),BmpCabin.FLOOR,-3.24,Math.max(inner,inner+side*.10),
                BmpCabin.ROOF,2.77,0x787b68);
        this.hull.box(side==1?.87:-1.51,.79,-3.32,side==1?1.51:-.87,2.78,-3.17,SIDE);
        rangeBox(this.hull,side,1.42,1.82,.19,.26,-2.87,2.88,0x262c27);
        rangeBox(this.hull,side,1.44,1.83,1.15,1.31,-3.14,3.12,0x353c32);
        for (int i=0;i<7;i++) {
            double z=-2.65+i*.88, y=i==0 || i==6 ? .72 : .62;
            double r=i==0 || i==6 ? .42 : .46;
            this.hull.tube(at(side*1.42,y,z),at(side*1.78,y,z),r,r,14,0x313731);
            this.hull.tube(at(side*1.78,y,z),at(side*1.82,y,z),r*.71,r*.63,12,0x6a735f);
            this.hull.tube(at(side*1.82,y,z),at(side*1.855,y,z),r*.28,r*.25,8,0x405043);
        }
        for (int i=0;i<34;i++) {
            double z=-3.00+i*.177;
            rangeBox(this.hull,side,1.42,1.85,.125,.22,z,z+.161,STEEL);
        }
        for (int i=0;i<6;i++){
            double z=-2.8+i*.96;
            this.hull.tube(at(side*1.76,1.41,z),at(side*1.62,2.02,z+.02),.020,.019,5,0x343d35);
        }
    }

    private void buildInterior() {
        for (int side : new int[]{-1,1}) for (double z : new double[]{-2.40,-1.58,-.75}) {
            AirframeModel.seat(this.hull,side*1.06,z,BmpCabin.FLOOR+.015,true);
            this.hull.tube(at(side*1.26,2.48,z-.30),at(side*1.26,2.48,z+.31),.023,.024,6,STEEL);
        }
        AirframeModel.seat(this.hull,BmpCabin.DRIVER.x,BmpCabin.DRIVER.z,BmpCabin.FLOOR+.016,false);
        this.hull.box(.86,.89,.64,1.32,1.37,1.39,STEEL);
        for (double x : new double[]{-.62,-.19,.28,.63})
            this.hull.box(x-.046,BmpCabin.FLOOR+.014,-3.18,x+.046,BmpCabin.FLOOR+.025,-.21,0x686c5e);
        double x = BmpCabin.DRIVER.x;
        this.dashboard.box(x-.43,1.13,2.60,x+.43,1.91,2.81,0x4f5749);
        this.dashboard.box(x-.40,1.79,2.54,x+.40,1.94,2.62,0x353d37);
        for (int i=0;i<4;i++) {
            double xx=x-.28+i*.17;
            this.dashboard.tube(at(xx,1.84,2.54),at(xx,1.84,2.508),.056,.055,10,0x252e29);
            this.dashboard.box(xx-.005,1.812,2.505,xx+.008,1.870,2.509,0xb3b99a);
        }
        this.dashboard.box(x-.22,1.36,2.31,x+.22,1.40,2.50,0x383f35);
        this.dashboard.tube(at(x-.18,1.36,2.35),at(x-.18,1.68,2.38),.027,.025,7,STEEL);
        this.dashboard.tube(at(x+.18,1.36,2.35),at(x+.18,1.68,2.38),.027,.025,7,STEEL);
        for (int dir : new int[]{-1,1}) {
            double low=dir==-1?-.87:.01, high=dir==-1?-.01:.87;
            this.doors.box(low,.78,-3.39,high,2.72,-3.20,ARMOR);
            this.doors.box(low+.18,1.49,-3.43,high-.17,1.54,-3.39,STEEL);
        }
        for (int i=0;i<3;i++) {
            double y=.07+i*.23,z=-4.26+i*.405;
            this.steps.box(-.80,y,z-.27,.80,y+.16,z+.29,STEEL);
            for (int j=0;j<3;j++)
                this.steps.box(-.73,y+.159,z-.21+j*.17,.73,y+.176,z-.17+j*.17,0x666b5d);
        }
    }

    private void buildTurret() {
        this.turret.hull(12,0,(s,p)->(s+p)%4==0 ? 0x6c785b : ARMOR,
                new VehicleMesh.Section(-1.07,.52,2.74,3.33),new VehicleMesh.Section(-.60,1.03,2.71,3.57),
                new VehicleMesh.Section(.59,1.07,2.72,3.57),new VehicleMesh.Section(1.12,.68,2.77,3.38));
        for (int side : new int[]{-1,1}) {
            this.turret.box(side*.47-.21,3.42,-.32,side*.47+.21,3.55,.33,0x535e4e);
            this.turret.box(side*.47-.13,3.55,.11,side*.47+.13,3.73,.30,STEEL);
            this.turret.box(side*.47-.087,3.60,.298,side*.47+.087,3.688,.313,PERISCOPE);
            for (int j=0;j<3;j++) {
                double z=-.44+.18*j;
                this.turret.tube(at(side*.89,3.06,z),at(side*1.11,3.25,z+.16),.074,.058,8,STEEL);
            }
        }
        this.turret.box(.30,3.46,.49,.64,3.62,.79,SIDE);
        this.turret.tube(at(-.70,3.45,-.65),at(-.72,4.21,-.78),.024,.012,6,0x343c34);
    }

    private static void rangeBox(VehicleMesh mesh,int side,double x0,double x1,double y0,double y1,
                                 double z0,double z1,int color) {
        mesh.box(Math.min(side*x0,side*x1),y0,z0,Math.max(side*x0,side*x1),y1,z1,color);
    }

    private static Vec3 at(double x,double y,double z) { return new Vec3(x,y,z); }
}
