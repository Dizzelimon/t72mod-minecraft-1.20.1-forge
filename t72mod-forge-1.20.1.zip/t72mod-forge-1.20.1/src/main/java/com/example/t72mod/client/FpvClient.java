package com.example.t72mod.client;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.FpvDroneEntity;
import com.example.t72mod.entity.FpvFlight;
import com.example.t72mod.network.FpvInputPacket;
import com.example.t72mod.network.ModMessages;
import net.minecraft.client.CameraType;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWGamepadState;
import org.lwjgl.system.MemoryStack;
import com.example.t72mod.config.FpvControls;

@Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class FpvClient {
    private static final KeyMapping EXIT = key("exit", GLFW.GLFW_KEY_X);
    private static final KeyMapping MODE = key("mode", GLFW.GLFW_KEY_K);
    private static final KeyMapping MARK = key("mark", GLFW.GLFW_KEY_G);
    private static int requested = -1;
    private static int wait;
    private static FpvDroneEntity viewing;
    private static CameraType previousCamera;
    private static float pilotYaw, pilotPitch, originalPitch;

    private FpvClient() {}

    private static KeyMapping key(String key, int code) {
        return new KeyMapping("key.t72mod.fpv_" + key, code, "key.categories.t72mod.flight");
    }

    @Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Keys {
        @SubscribeEvent public static void register(RegisterKeyMappingsEvent event) {
            event.register(EXIT);
            event.register(MARK);
            event.register(MODE);
        }
    }

    public static FpvDroneEntity current() { return viewing; }

    public static void select(int entityId) {
        if (entityId != requested) clearCamera(Minecraft.getInstance());
        requested = entityId;
        wait = 40;
    }

    private static void clearCamera(Minecraft client) {
        if (viewing != null && client.getCameraEntity() == viewing && client.player != null) {
            client.setCameraEntity(client.player);
            client.player.setXRot(originalPitch);
        }
        if (previousCamera != null) client.options.setCameraType(previousCamera);
        previousCamera = null;
        viewing = null;
    }

    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft client = Minecraft.getInstance();
        boolean exit = EXIT.consumeClick();
        boolean mark = MARK.consumeClick();
        boolean mode = MODE.consumeClick();
        if (client.level == null || client.player == null) {
            select(-1);
            return;
        }
        if (requested < 0) return;
        if (exit) {
            ModMessages.INSTANCE.sendToServer(new FpvInputPacket(requested, 0, 0, 0, 1));
            select(-1);
            return;
        }
        if (!(client.level.getEntity(requested) instanceof FpvDroneEntity drone) || !drone.isAlive()) {
            clearCamera(client);
            if (--wait <= 0) {
                ModMessages.INSTANCE.sendToServer(new FpvInputPacket(requested, 0, 0, 0, 1));
                select(-1);
            }
            return;
        }
        wait = 25;
        var player = client.player;
        if (viewing != drone) {
            viewing = drone;
            previousCamera = client.options.getCameraType();
            client.options.setCameraType(CameraType.FIRST_PERSON);
            client.setCameraEntity(drone);
            pilotYaw = player.getYRot();
            originalPitch = player.getXRot();
            pilotPitch = 0;
            player.setXRot(pilotPitch);
        } else if (client.getCameraEntity() != drone) client.setCameraEntity(drone);
        if (client.options.getCameraType() != CameraType.FIRST_PERSON) client.options.setCameraType(CameraType.FIRST_PERSON);

        var options = client.options;
        boolean input = client.screen == null && client.isWindowActive();
        int flags = input
                ? mask(options.keyUp, FpvFlight.FORWARD) | mask(options.keyDown, FpvFlight.BACK)
                | mask(options.keyLeft, FpvFlight.LEFT) | mask(options.keyRight, FpvFlight.RIGHT)
                | mask(options.keyJump, FpvFlight.UP) | mask(options.keyShift, FpvFlight.DOWN)
                | mask(options.keySprint, FpvFlight.BOOST) : 0;
        float roll = Mth.wrapDegrees(player.getYRot() - pilotYaw) * 1.45F;
        float pitch = (player.getXRot() - pilotPitch) * 1.27F;
        if (input && FpvControls.GAMEPAD.get()) {
            try (MemoryStack memory = MemoryStack.stackPush()) {
                var pad = GLFWGamepadState.malloc(memory);
                int device = GLFW.GLFW_JOYSTICK_1 + FpvControls.DEVICE.get() - 1;
                if (GLFW.glfwGetGamepadState(device,pad)) {
                    double dead=FpvControls.DEAD_ZONE.get();
                    float lift=FpvControls.stick(-pad.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_Y),dead);
                    float yaw=FpvControls.stick(pad.axes(GLFW.GLFW_GAMEPAD_AXIS_LEFT_X),dead);
                    flags |= lift > .12 ? FpvFlight.FORWARD : lift < -.12 ? FpvFlight.BACK : 0;
                    flags |= yaw > .12 ? FpvFlight.RIGHT : yaw < -.12 ? FpvFlight.LEFT : 0;
                    roll += FpvControls.stick(pad.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_X),dead)*8;
                    pitch += FpvControls.stick(-pad.axes(GLFW.GLFW_GAMEPAD_AXIS_RIGHT_Y),dead)*7;
                }
            }
        }
        roll *= FpvControls.ROLL.get();
        pitch *= FpvControls.PITCH.get() * (FpvControls.INVERT.get() ? -1 : 1);
        // Recenter the virtual stick. The view comes from the drone rather than the player.
        player.setXRot(pilotPitch);
        player.setYRot(pilotYaw);
        ModMessages.INSTANCE.sendToServer(new FpvInputPacket(requested, flags, input ? roll : 0, input ? pitch : 0, 0));
        if (input && mark) ModMessages.INSTANCE.sendToServer(new FpvInputPacket(requested, 0, 0, 0, 2));
        if (input && mode) ModMessages.INSTANCE.sendToServer(new FpvInputPacket(requested, 0, 0, 0, 3));
    }

    private static int mask(KeyMapping key, int flags) { return key.isDown() ? flags : 0; }

    @SubscribeEvent public static void stopBodyMovement(MovementInputUpdateEvent event) {
        if (viewing == null || event.getEntity() != Minecraft.getInstance().player) return;
        var input = event.getInput();
        input.leftImpulse = 0;
        input.forwardImpulse = 0;
        input.jumping = false;
        input.shiftKeyDown = false;
    }

    @SubscribeEvent public static void preventBodyClick(InputEvent.InteractionKeyMappingTriggered event) {
        if (viewing == null) return;
        event.setCanceled(true);
        event.setSwingHand(false);
    }

    @SubscribeEvent public static void camera(ViewportEvent.ComputeCameraAngles event) {
        if (viewing != null && event.getCamera().getEntity() == viewing)
            event.setRoll(viewing.roll((float) event.getPartialTick()) * .78F);
    }

    @SubscribeEvent public static void drawHud(RenderGuiOverlayEvent.Post event) {
        Minecraft client = Minecraft.getInstance();
        if (viewing == null || client.player == null || client.options.hideGui || client.screen != null
                || !event.getOverlay().id().equals(VanillaGuiOverlay.CROSSHAIR.id())) return;
        GuiGraphics g = event.getGuiGraphics();
        int width = g.guiWidth(), height = g.guiHeight();
        int distance = Mth.ceil(client.player.distanceTo(viewing));
        int battery = Mth.ceil(viewing.battery() * 100D / FpvDroneEntity.BATTERY_CAPACITY);
        int color = viewing.signalLimited() || battery < 15 ? 0xFFFFB465 : 0xFFE2FCB8;
        g.drawCenteredString(client.font, Component.translatable("hud.t72mod.fpv_status",
                distance, FpvFlight.RANGE, battery, viewing.getBlockY(), Component.translatable(
                        viewing.freeAttitude() ? "hud.t72mod.fpv_free" : "hud.t72mod.fpv_stabilized")), width / 2, 12, color);
        g.drawCenteredString(client.font, Component.translatable("hud.t72mod.fpv_throttle", viewing.throttlePercent(),
                Component.translatable(viewing.hasPayload() ? "hud.t72mod.fpv_loaded" : viewing.hasParcel() ? "hud.t72mod.fpv_parcel" : "hud.t72mod.fpv_recon")),
                width / 2, 24, viewing.hasPayload() ? 0xFFFFB465 : color);
        if (viewing.signalLimited())
            g.drawCenteredString(client.font, Component.translatable("hud.t72mod.fpv_edge"), width / 2, 36, color);
        g.drawCenteredString(client.font, Component.translatable("hud.t72mod.fpv_keys", MARK.getTranslatedKeyMessage(),
                EXIT.getTranslatedKeyMessage(), MODE.getTranslatedKeyMessage()), width / 2, height - 27, 0xFFEDF1D6);
    }
}
