package com.example.t72mod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class FieldObstacleBlock extends HorizontalDirectionalBlock {
    public static final VoxelShape TOOTH = Shapes.or(box(0,0,0,16,3,16), box(1,3,1,15,7,15),
            box(3,7,3,13,11,13), box(5,11,5,11,15,11), box(7,15,7,9,17,9));
    public static final VoxelShape SANDBAGS = Shapes.or(box(0,0,3,16,5,13), box(1,5,4,15,10,12),
            box(0,10,4,16,14,12));
    public static final VoxelShape BARRIER = Shapes.or(box(0,0,0,16,4,16), box(0,4,2,16,8,14),
            box(0,8,4,16,13,12), box(0,13,5,16,16,11));

    private final VoxelShape northSouth;
    private final VoxelShape eastWest;

    public FieldObstacleBlock(Properties properties, VoxelShape shape) {
        super(properties);
        this.northSouth = shape;
        VoxelShape[] rotated = shape.toAabbs().stream()
                .map(box -> Shapes.box(box.minZ,box.minY,1-box.maxX,box.maxZ,box.maxY,1-box.minX))
                .toArray(VoxelShape[]::new);
        this.eastWest = rotated.length == 0 ? Shapes.empty() : Shapes.or(rotated[0],rotated);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING,context.getHorizontalDirection().getOpposite());
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING,rotation.rotate(state.getValue(FACING)));
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return this.rotate(state,mirror.getRotation(state.getValue(FACING)));
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return state.getValue(FACING).getAxis() == Direction.Axis.X ? this.eastWest : this.northSouth;
    }
}
