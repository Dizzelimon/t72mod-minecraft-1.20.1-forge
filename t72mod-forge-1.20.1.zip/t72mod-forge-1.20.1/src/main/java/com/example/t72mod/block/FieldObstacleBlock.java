package com.example.t72mod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import com.example.t72mod.entity.T72TankEntity;

public final class FieldObstacleBlock extends HorizontalDirectionalBlock {
    public static final VoxelShape TOOTH = Shapes.or(box(0,0,0,16,6,16), box(1,6,1,15,12,15),
            box(2.7,12,2.7,13.3,17,13.3),box(4.4,17,4.4,11.6,21,11.6),box(6,21,6,10,25,10));
    public static final VoxelShape SANDBAGS = Shapes.or(box(0,0,2,16,7,14), box(0,7,3,16,14,13),
            box(0,14,4,16,21,12));
    public static final VoxelShape BARRIER = Shapes.or(box(0,0,0,16,5,16), box(0,5,2,16,11,14),
            box(0,11,3,16,18,13), box(0,18,5,16,25,11));

    private final VoxelShape northSouth;
    private final VoxelShape eastWest;

    public FieldObstacleBlock(Properties properties, VoxelShape shape) {
        super(properties);
        this.northSouth = shape;
        VoxelShape[] rotated = shape.toAabbs().stream()
                .map(box -> Shapes.box(box.minZ,box.minY,1-box.maxX,box.maxZ,box.maxY,1-box.minX))
                .toArray(VoxelShape[]::new);
        this.eastWest = rotated.length == 0 ? Shapes.empty() : Shapes.or(rotated[0],rotated);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING,context.getHorizontalDirection().getOpposite());
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING,rotation.rotate(state.getValue(FACING)));
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return this.rotate(state,mirror.getRotation(state.getValue(FACING)));
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return state.getValue(FACING).getAxis() == Direction.Axis.X ? this.eastWest : this.northSouth;
    }
    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        VoxelShape shape = this.getShape(state,level,pos,context);
        if (context instanceof EntityCollisionContext e && e.getEntity() instanceof T72TankEntity) {
            // Tank tracks run into the body of the barrier instead of using the bevel as a step.
            return Shapes.create(shape.bounds());
        }
        return shape;
    }

}
