package com.example.t72mod.entity;

import com.example.t72mod.T72Mod;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class HelicopterEntity extends PathfinderMob implements VehiclePartEntity.Parent {
    public static final int FORWARD = 1;
    public static final int BACK = 2;
    public static final int LEFT = 4;
    public static final int RIGHT = 8;
    public static final int ASCEND = 16;
    public static final int DESCEND = 32;
    public static final int STRAFE_LEFT = 64;
    public static final int STRAFE_RIGHT = 128;
    public static final int TOGGLE_ENGINE = 0;
    public static final int CARGO = 1;
    public static final int FIRE = 2;
    public static final int CANNON = 3;
    private static final int FIRST_DECK_SECTION = 4;
    public static final int RELOAD_ROCKETS=4;
    public static final int TOGGLE_RAMP=5;
    public static final int LOAD_HELD_ROCKETS=6;
    public static final int SELECT_SEAT=16;
    private static final int MAIN_ROTOR = 0;
    private static final int TAIL_ROTOR = 1;
    private static final int LEFT_POD = 2;
    private static final EntityDimensions[] FLIGHT_PARTS = {
            EntityDimensions.fixed(1.75F, 0.50F), EntityDimensions.fixed(1.0F, 1.15F),
            EntityDimensions.fixed(0.78F, 0.55F), EntityDimensions.fixed(0.78F, 0.55F)
    };
    private static final int MAX_PART_HEALTH = 100;
    public static final int MAX_ROCKETS = 12;
    private static final int MAX_CANNON_AMMO = 240;
    private static final int AMMO_PER_INGOT = 20;
    private static final int GUN_COOLDOWN_TICKS = 4;
    private static final EntityDataAccessor<Boolean> ENGINE_ON = boolData();
    private static final EntityDataAccessor<Boolean> HAS_CHEST = boolData();
    private static final EntityDataAccessor<Boolean> CABIN_OPEN = boolData();
    private static final EntityDataAccessor<Integer> FUEL = integerData();
    private static final EntityDataAccessor<Integer> ROTOR = integerData();
    private static final EntityDataAccessor<Integer> TAIL = integerData();
    private static final EntityDataAccessor<Integer> ENGINE = integerData();
    private static final EntityDataAccessor<CompoundTag> SEATS =
            SynchedEntityData.defineId(HelicopterEntity.class,EntityDataSerializers.COMPOUND_TAG);
    private static final EntityDataAccessor<Boolean> RAMP_OPEN=boolData();
    private static final EntityDataAccessor<Boolean> DECK_HOLD=boolData();
    private static final EntityDataAccessor<Integer> ROCKETS = integerData();
    private static final EntityDataAccessor<Integer> CANNON_AMMO = integerData();
    private static final EntityDataAccessor<Integer> RPM = integerData();
    private static final EntityDataAccessor<Integer> LEAN = integerData();
    private static final EntityDataAccessor<Integer> LAUNCHER = integerData();

    private final SimpleContainer cargo = new SimpleContainer(27) {
        @Override
        public boolean stillValid(Player player) {
            return hasChest() && isAlive() && (hasPassenger(player)
                    || (onGround() && distanceToSqr(player) <= 36));
        }
    };
    private final HelicopterCabin cabin;
    private final VehiclePart[] flightParts;
    private final Map<UUID,Vec3> walkers=new HashMap<>();
    private Vec3 partOrigin;
    private float partHeading;
    private boolean partsDoor,partsRamp;
    private int nextSeat=-1;
    private int rampTicks;
    private int oldRampTicks;
    private static final int RAMP_TIME=14;
    private int flightInput;
    private int inputAge;
    private int fuelTicks;
    private int rocketCooldown;
    private int gunCooldown;
    private float rotorAngle;
    private float previousRotorAngle;
    private float turnVelocity;
    private float leanPitch;
    private float leanRoll;
    private boolean airborne;

    public HelicopterEntity(EntityType<? extends HelicopterEntity> type, Level level) {
        super(type, level);
        this.cabin = HelicopterCabin.forType(this.model());
        this.flightParts=VehiclePart.create(this,this.cabin.partDimensions(FLIGHT_PARTS,this.model()==HelicopterType.MI8));
        this.setId(ENTITY_COUNTER.getAndAdd(this.flightParts.length+1)+1);
        this.updatePartPositions();
        this.setNoAi(true);
        this.setNoGravity(true);
        this.blocksBuilding = true;
    }

    @Override public boolean isMultipartEntity() { return true; }
    @Override public VehiclePart[] getParts() { return this.flightParts; }
    @Override public void setId(int id) {
        super.setId(id);
        VehiclePart.assignIds(this.flightParts,id);
    }

    private void updatePartPositions() {
        boolean ramp=this.rampDeployed();
        if (this.position().equals(this.partOrigin) && this.getYRot()==this.partHeading
                && this.isCabinOpen()==this.partsDoor && ramp==this.partsRamp) return;
        this.partOrigin=this.position();
        this.partHeading=this.getYRot();
        this.partsDoor=this.isCabinOpen();
        this.partsRamp=ramp;
        for (VehiclePart part : this.flightParts) if (this.partShouldExist(part.index())) part.syncBox();
    }

    private static EntityDataAccessor<Boolean> boolData() {
        return SynchedEntityData.defineId(HelicopterEntity.class, EntityDataSerializers.BOOLEAN);
    }

    private static EntityDataAccessor<Integer> integerData() {
        return SynchedEntityData.defineId(HelicopterEntity.class, EntityDataSerializers.INT);
    }

    public static AttributeSupplier.Builder attributes(HelicopterType model) {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, model.hullHealth)
                .add(Attributes.ARMOR, model.armed ? 11 : 5).add(Attributes.KNOCKBACK_RESISTANCE, 1);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ENGINE_ON, false);
        this.entityData.define(HAS_CHEST, false);
        this.entityData.define(CABIN_OPEN, false);
        this.entityData.define(FUEL, 0);
        this.entityData.define(ROTOR, MAX_PART_HEALTH);
        this.entityData.define(TAIL, MAX_PART_HEALTH);
        this.entityData.define(ENGINE, MAX_PART_HEALTH);
        this.entityData.define(ROCKETS, 0);
        this.entityData.define(SEATS,new CompoundTag());
        this.entityData.define(RAMP_OPEN,false);
        this.entityData.define(DECK_HOLD,false);
        this.entityData.define(CANNON_AMMO, 0);
        this.entityData.define(RPM, 0);
        this.entityData.define(LEAN, 0);
        this.entityData.define(LAUNCHER, MAX_PART_HEALTH);
    }

    public HelicopterType model() {
        if (this.getType() == T72Mod.KA52.get()) return HelicopterType.KA52;
        return this.getType() == T72Mod.MI24.get() ? HelicopterType.MI24 : HelicopterType.MI8;
    }

    public void giveStarterFuel() {
        this.entityData.set(FUEL, this.model().fuelCapacity / 2);
        this.entityData.set(ROCKETS, this.model().armed ? 4 : 0);
        this.entityData.set(CANNON_AMMO, this.model().armed ? 80 : 0);
    }

    public boolean isCabinOpen() { return this.entityData.get(CABIN_OPEN); }
    public boolean hasChest() { return this.entityData.get(HAS_CHEST); }
    public boolean engineOn() { return this.entityData.get(ENGINE_ON); }
    public int fuel() { return this.entityData.get(FUEL); }
    public int rotorHealth() { return this.entityData.get(ROTOR); }
    public int tailHealth() { return this.entityData.get(TAIL); }
    public int engineHealth() { return this.entityData.get(ENGINE); }
    public int launcherHealth() { return this.entityData.get(LAUNCHER); }
    public int rockets() { return this.entityData.get(ROCKETS); }
    public int cannonAmmo() { return this.entityData.get(CANNON_AMMO); }
    public int rpm() { return this.entityData.get(RPM); }

    public float visualPitch() { return (byte) (this.entityData.get(LEAN) >> 8); }
    public float visualRoll() { return (byte) (int) this.entityData.get(LEAN); }

    public float rotorAngle(float partialTick) {
        return Mth.rotLerp(partialTick, this.previousRotorAngle, this.rotorAngle);
    }

    public boolean isPilot(Player player) {
        return this.isAlive() && this.hasPassenger(player) && this.seatOf(player)==0;
    }

    private boolean hasPilot() {
        for (Entity passenger : this.getPassengers()) if (this.seatOf(passenger)==0) return true;
        return false;
    }

    public boolean isRampOpen() { return this.entityData.get(RAMP_OPEN); }
    private boolean rampDeployed() { return this.isRampOpen() && this.rampTicks==RAMP_TIME; }
    public float rampProgress(float pt) { return Mth.lerp(pt,this.oldRampTicks,this.rampTicks)/RAMP_TIME; }
    public boolean deckHold() { return this.entityData.get(DECK_HOLD); }

    public boolean insideWalkableCabin(Player player) {
        return this.cabin.contains(AirframeLayout.local(this.position(),this.getYRot(),player.position()));
    }

    private int seatOf(Entity passenger) {
        CompoundTag seats=this.entityData.get(SEATS);
        for (int i=0;i<this.cabin.seatCount();i++) {
            String key=Integer.toString(i);
            if (seats.hasUUID(key) && seats.getUUID(key).equals(passenger.getUUID())) return i;
        }
        return -1;
    }

    private boolean seatOccupied(int seat) {
        for (Entity passenger : this.getPassengers()) if (this.seatOf(passenger)==seat) return true;
        return false;
    }

    private InteractionResult selectSeat(Player player,int seat) {
        if (!this.insideWalkableCabin(player) || player.isPassenger()
                || seat<0 || seat>=this.cabin.seatCount()) return InteractionResult.PASS;
        Vec3 p=this.cabin.seatHitCenter(seat);
        Vec3 target=AirframeLayout.world(this.position(),this.getYRot(),p.x,p.y+.36,p.z);
        if (player.getEyePosition().distanceToSqr(target)>8.41
                || this.level().clip(new ClipContext(player.getEyePosition(),target,ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE,player)).getType()!=HitResult.Type.MISS) return InteractionResult.FAIL;
        if (this.level().isClientSide) return InteractionResult.SUCCESS;
        if (this.seatOccupied(seat)) {
            player.displayClientMessage(Component.translatable("message.t72mod.seat_occupied"),true);
            return InteractionResult.FAIL;
        }
        this.nextSeat=seat;
        boolean mounted;
        try {
            mounted=player.startRiding(this,true);
        } finally {
            this.nextSeat=-1;
        }
        return mounted?InteractionResult.CONSUME:InteractionResult.FAIL;
    }

    public void handleCrewAction(Player player,int command) {
        if (this.level().isClientSide || !this.isAlive() || !player.isAlive() || player.isSpectator()) return;
        if (command>=SELECT_SEAT && command<SELECT_SEAT+this.cabin.seatCount()) {
            if (player.getMainHandItem().isEmpty()) this.selectSeat(player,command-SELECT_SEAT);
            return;
        }
        if (command == TOGGLE_RAMP) {
            if (this.canOperateRearRamp(player)) this.toggleRamp(player);
            return;
        }
        if (command != RELOAD_ROCKETS && command != LOAD_HELD_ROCKETS) return;
        if (!this.hasPassenger(player) && !this.insideWalkableCabin(player)
                && this.getBoundingBox().distanceToSqr(player.getEyePosition())>16) return;
        if (command==RELOAD_ROCKETS) this.loadRockets(player,ItemStack.EMPTY);
        else if (player.getMainHandItem().is(T72Mod.AIR_ROCKET.get())) this.loadRockets(player,player.getMainHandItem());
    }

    public boolean canOperateRearRamp(Player player) {
        return this.model() == HelicopterType.MI8 && !player.isSpectator()
                && (this.hasPassenger(player) || this.insideWalkableCabin(player)
                    || this.isCabinOpen() && this.nearRearRamp(player));
    }

    private boolean nearRearRamp(Player player) {
        if (this.model()!=HelicopterType.MI8) return false;
        Vec3 p=AirframeLayout.local(this.position(),this.getYRot(),player.position());
        return Math.abs(p.x)<1.9 && p.z>this.cabin.rear-3.0 && p.z<this.cabin.rear+.55
                && p.y>-.65 && p.y<this.cabin.floor+.60;
    }

    private void toggleRamp(Player player) {
        this.entityData.set(RAMP_OPEN,!this.isRampOpen());
        this.level().playSound(null,this.blockPosition(),SoundEvents.IRON_DOOR_OPEN,SoundSource.NEUTRAL,.7F,.66F);
        player.displayClientMessage(Component.translatable(this.isRampOpen()
                ?"message.t72mod.ramp_open":"message.t72mod.ramp_closed"),true);
    }

    private void loadRockets(Player player,ItemStack inHand) {
        if (!this.model().armed) return;
        if (!this.onGround()) {
            player.displayClientMessage(Component.translatable("message.t72mod.rockets_land"),true);
            return;
        }
        int remaining=MAX_ROCKETS-this.rockets(), loaded=0;
        if (remaining==0) {
            player.displayClientMessage(Component.translatable("message.t72mod.rockets_full",MAX_ROCKETS),true);
            return;
        }
        if (player.getAbilities().instabuild) loaded=remaining;
        else if (inHand.is(T72Mod.AIR_ROCKET.get())) {
            loaded=Math.min(remaining,inHand.getCount());
            inHand.shrink(loaded);
        } else {
            for (ItemStack stack : player.getInventory().items) {
                if (!stack.is(T72Mod.AIR_ROCKET.get())) continue;
                int take=Math.min(remaining-loaded,stack.getCount());
                stack.shrink(take);
                loaded+=take;
                if (loaded==remaining) break;
            }
        }
        if (loaded==0) {
            player.displayClientMessage(Component.translatable("message.t72mod.rockets_missing"),true);
            return;
        }
        player.getInventory().setChanged();
        this.entityData.set(ROCKETS,this.rockets()+loaded);
        this.level().playSound(null,this.blockPosition(),SoundEvents.ARMOR_EQUIP_IRON,SoundSource.PLAYERS,.9F,1);
        player.displayClientMessage(Component.translatable("message.t72mod.rockets_loaded",loaded,this.rockets(),MAX_ROCKETS),true);
    }

    public void acceptInput(Player sender, int input) {
        if (this.isPilot(sender)) {
            this.flightInput = input & 255;
            this.inputAge = 0;
        }
    }

    public void handleAction(Player player, int command) {
        if (!this.isAlive() || !this.hasPassenger(player)) return;
        if (command == CARGO) {
            this.openCargo(player);
        } else if (this.isPilot(player)) {
            if (command == TOGGLE_ENGINE) {
                if (this.engineOn()) {
                    this.entityData.set(ENGINE_ON, false);
                } else if (this.fuel() > 0 && this.engineHealth() > 0 && this.rotorHealth() > 0) {
                    if (!this.secureCabin()) {
                        player.displayClientMessage(Component.translatable("message.t72mod.ramp_close_first"),true);
                        return;
                    }
                    this.entityData.set(CABIN_OPEN, false);
                    this.entityData.set(ENGINE_ON, true);
                }
            } else if (command == FIRE) {
                this.fireRocket(player);
            } else if (command == CANNON) {
                this.fireCannon(player);
            }
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.isAlive() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        ItemStack held = player.getItemInHand(hand);
        if (this.model().armed && held.is(T72Mod.AIR_ROCKET.get())) {
            if (!this.level().isClientSide) this.loadRockets(player,held);
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (!this.onGround()) return InteractionResult.PASS;
        if (held.isEmpty() && player.isShiftKeyDown() && this.nearRearRamp(player)
                && this.canOperateRearRamp(player)) {
            if (!this.level().isClientSide) this.toggleRamp(player);
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        int fuelValue = T72TankEntity.getFuelValue(held);
        if (held.is(Items.CHEST) && !this.hasChest()) {
            if (!this.level().isClientSide) {
                this.entityData.set(HAS_CHEST, true);
                this.consumeSupply(player, held);
                player.displayClientMessage(Component.translatable("message.t72mod.cargo_installed"), true);
            }
        } else if (fuelValue > 0 && this.fuel() < this.model().fuelCapacity) {
            if (!this.level().isClientSide) {
                this.entityData.set(FUEL, Math.min(this.model().fuelCapacity, this.fuel() + fuelValue));
                this.consumeSupply(player, held);
                this.level().playSound(null, this.blockPosition(), SoundEvents.BUCKET_FILL, SoundSource.PLAYERS, 1, 1);
            }
        } else if (held.is(T72Mod.REPAIR_KIT.get())
                && (this.getHealth() < this.getMaxHealth() || this.rotorHealth() < MAX_PART_HEALTH
                || this.tailHealth() < MAX_PART_HEALTH || this.engineHealth() < MAX_PART_HEALTH
                || this.launcherHealth() < MAX_PART_HEALTH)) {
            if (!this.level().isClientSide) {
                this.heal(55);
                this.entityData.set(ROTOR, MAX_PART_HEALTH);
                this.entityData.set(TAIL, MAX_PART_HEALTH);
                this.entityData.set(ENGINE, MAX_PART_HEALTH);
                this.entityData.set(LAUNCHER, MAX_PART_HEALTH);
                this.consumeSupply(player, held);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1, 1);
            }
        } else if (this.model().armed && held.is(Items.IRON_INGOT) && this.cannonAmmo() < MAX_CANNON_AMMO) {
            if (!this.level().isClientSide) {
                this.entityData.set(CANNON_AMMO, Math.min(MAX_CANNON_AMMO, this.cannonAmmo() + AMMO_PER_INGOT));
                this.consumeSupply(player, held);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON,
                        SoundSource.PLAYERS, 0.8F, 1.2F);
            }
        } else if (player.isShiftKeyDown() && held.isEmpty() && this.isCabinOpen() && !this.insideWalkableCabin(player)) {
            if (this.level().isClientSide) return InteractionResult.SUCCESS;
            return this.enterCabin(player);
        } else if (player.isShiftKeyDown()) {
            if (!this.level().isClientSide) this.openCargo(player);
        } else {
            if (held.isEmpty() && !this.insideWalkableCabin(player) && !this.level().isClientSide)
                player.displayClientMessage(Component.translatable("message.t72mod.mi8_board"),true);
            return InteractionResult.PASS;
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    private void consumeSupply(Player player, ItemStack stack) {
        if (player.getAbilities().instabuild) return;
        boolean lava = stack.is(Items.LAVA_BUCKET);
        stack.shrink(1);
        if (lava) {
            ItemStack bucket = new ItemStack(Items.BUCKET);
            if (!player.addItem(bucket)) player.drop(bucket, false);
        }
    }

    private void openCargo(Player player) {
        if (!this.hasChest()) {
            player.displayClientMessage(Component.translatable("message.t72mod.cargo_missing"), true);
            return;
        }
        player.openMenu(new SimpleMenuProvider((id, inventory, owner) -> ChestMenu.threeRows(id, inventory, this.cargo),
                Component.translatable("menu.t72mod.helicopter_cargo")));
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return passenger instanceof Player && this.isAlive() && this.getPassengers().size() < this.model().seats;
    }

    @Override
    protected void addPassenger(Entity passenger) {
        super.addPassenger(passenger);
        if (this.level().isClientSide || this.seatOf(passenger)>=0) return;
        int seat=this.nextSeat;
        if (seat<0) {
            for (int i=0;i<this.cabin.seatCount();i++) {
                if (!this.seatOccupied(i)) { seat=i; break; }
            }
        }
        if (seat>=0) {
            CompoundTag seats=this.entityData.get(SEATS).copy();
            seats.putUUID(Integer.toString(seat),passenger.getUUID());
            this.entityData.set(SEATS,seats);
            this.walkers.remove(passenger.getUUID());
        }
    }

    @Override
    protected void positionRider(Entity passenger,Entity.MoveFunction move) {
        int seat=this.seatOf(passenger);
        if (seat<0 || !this.hasPassenger(passenger)) return;
        Vec3 offset=this.cabin.seat(seat);
        Vec3 location=AirframeLayout.world(this.position(),this.getYRot(),offset.x,offset.y,offset.z);
        move.accept(passenger,location.x,location.y+passenger.getMyRidingOffset(),location.z);
    }

    @Override
    protected void removePassenger(Entity passenger) {
        int seat=this.seatOf(passenger);
        super.removePassenger(passenger);
        if (!this.level().isClientSide && seat>=0) {
            CompoundTag seats=this.entityData.get(SEATS).copy();
            seats.remove(Integer.toString(seat));
            this.entityData.set(SEATS,seats);
            if (passenger instanceof Player player && player.isAlive() && this.isAlive()) {
                Vec3 p=this.cabin.seat(seat);
                this.walkers.put(player.getUUID(),new Vec3(0,this.cabin.floor+.02,p.z));
            }
        }
        if (seat==0) {
            this.flightInput=0;
            this.inputAge=0;
            if (!this.level().isClientSide && this.onGround()) this.entityData.set(ENGINE_ON,false);
        }
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        if (this.isAlive()) {
            Vec3 p=AirframeLayout.local(this.position(),this.getYRot(),passenger.position());
            double z=Mth.clamp(p.z,this.cabin.rear+.43,this.cabin.front-.43);
            for (double shift : new double[]{-.36,.36,-.85}) {
                double safeZ=Mth.clamp(z+shift,this.cabin.rear+.43,this.cabin.front-.43);
                Vec3 aisle=AirframeLayout.world(this.position(),this.getYRot(),0,this.cabin.floor+.023,safeZ);
                if (this.level().noCollision(passenger,passenger.getBoundingBox().move(aisle.subtract(passenger.position())))) return aisle;
            }
            if (!this.onGround()) return AirframeLayout.world(this.position(),this.getYRot(),0,this.cabin.floor+.023,z);
        }
        return super.getDismountLocationForPassenger(passenger);
    }

    @Override public boolean canBeCollidedWith() { return false; }

    @Override
    public boolean canCollideWith(Entity other) {
        if (other instanceof VehiclePart part && part.getParent()==this) return false;
        return super.canCollideWith(other);
    }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    public void travel(Vec3 ignored) {
        // Flight runs on the server. Client positions come from entity tracking.
    }

    @Override
    public void tick() {
        boolean predict = this.level().isClientSide && !this.walkers.isEmpty();
        Vec3 oldPosition = predict ? this.position() : null;
        float oldYaw = this.getYRot();
        super.tick();
        if (!this.isAlive()) return;
        this.oldRampTicks=this.rampTicks;
        this.rampTicks=Mth.clamp(this.rampTicks+(this.isRampOpen()?1:-1),0,RAMP_TIME);
        if (this.level().isClientSide) {
            if (predict && (!this.position().equals(oldPosition) || this.getYRot() != oldYaw))
                this.carryWalkers();
            this.updatePartPositions();
            this.previousRotorAngle = this.rotorAngle;
            this.rotorAngle = Mth.wrapDegrees(this.rotorAngle + this.rpm() * 0.83F);
            if ((this.engineHealth() < 50 || this.rotorHealth() < 35) && this.tickCount % 4 == 0) {
                this.level().addParticle(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.9,
                        this.getZ(), 0, 0.08, 0);
            }
            return;
        }

        if (this.rocketCooldown > 0) this.rocketCooldown--;
        if (this.gunCooldown > 0) this.gunCooldown--;
        if (this.inputAge < 12) this.inputAge++;
        this.updateWalkers();
        this.entityData.set(DECK_HOLD,!this.walkers.isEmpty());
        int input=this.inputAge<12 && this.hasPilot()?this.flightInput:0;
        if (this.fuel() == 0 || this.engineHealth() == 0 || this.rotorHealth() == 0 || this.isInWater()) this.entityData.set(ENGINE_ON, false);
        int rotorSpeed = this.rpm();
        int targetSpeed = this.engineOn() ? Math.min(100, Math.min(this.rotorHealth(), this.engineHealth()) + 15) : 0;
        rotorSpeed += Mth.clamp(targetSpeed - rotorSpeed, -3, 2);
        this.entityData.set(RPM, rotorSpeed);
        if (this.engineOn() && ++this.fuelTicks >= this.model().fuelInterval * (this.onGround() ? 2 : 1)) {
            this.fuelTicks = 0;
            this.entityData.set(FUEL, Math.max(0, this.fuel() - 1));
        }
        Vec3 before = this.position();
        float beforeYaw = this.getYRot();
        this.fly(input,rotorSpeed);
        if (!this.walkers.isEmpty() && (!this.position().equals(before) || this.getYRot() != beforeYaw))
            this.carryWalkers();
        // An unattended aircraft keeps lift for its descent, then shuts down on touchdown.
        if (this.onGround() && !this.hasPilot()) {
            this.entityData.set(ENGINE_ON, false);
        }
        this.entityData.set(CABIN_OPEN, this.onGround()
                && !this.engineOn() && this.getDeltaMovement().horizontalDistanceSqr() < 0.0025);
        this.updatePartPositions();
        if (rotorSpeed >= 52 && VehicleContactDamage.enabled() && this.tickCount % 3 == 0) this.damageRotorContacts(rotorSpeed);
    }

    private Vec3 rotorTransform(Vec3 local) {
        return local.zRot(-this.visualRoll() * Mth.DEG_TO_RAD)
                .xRot(-this.visualPitch() * Mth.DEG_TO_RAD).yRot(-this.getYRot() * Mth.DEG_TO_RAD);
    }

    private void damageRotorContacts(int speed) {
        HelicopterType type = this.model();
        Player pilot = null;
        for (Entity crew : this.getPassengers()) {
            if (crew instanceof Player player && this.isPilot(player)) { pilot = player; break; }
        }
        Player operator = pilot;
        if (this.rotorHealth() > 0) {
            Vec3 center = this.position().add(this.rotorTransform(new Vec3(0, AirframeLayout.rotorY(type),
                    AirframeLayout.MAIN_ROTOR_Z)));
            Vec3 normal = this.rotorTransform(new Vec3(0, 1, 0));
            double radius = AirframeLayout.rotorRadius(type);
            double vertical = 1 + radius * Math.sqrt(Math.max(0, 1 - normal.y * normal.y));
            Vec3 top = type == HelicopterType.KA52 ? center.add(normal.scale(.51)) : center;
            AABB vicinity = new AABB(center, top).inflate(radius + .3, vertical, radius + .3);
            for (LivingEntity target : this.level().getEntitiesOfClass(LivingEntity.class, vicinity,
                    e -> !this.walkers.containsKey(e.getUUID()) && VehicleContactDamage.canHit(this, operator, e))) {
                if (this.bladesReach(target, center, normal, radius) || this.bladesReach(target, top, normal, radius))
                    target.hurt(this.damageSources().mobAttack(this), 4 + speed * .10F);
            }
        }
        if (type == HelicopterType.KA52 || this.tailHealth() <= 0) return;
        Vec3 center = this.position().add(this.rotorTransform(new Vec3(.12, AirframeLayout.TAIL_ROTOR_Y,
                AirframeLayout.tailZ(type))));
        Vec3 normal = this.rotorTransform(new Vec3(1, 0, 0));
        double radius = AirframeLayout.TAIL_ROTOR_RADIUS;
        for (LivingEntity target : this.level().getEntitiesOfClass(LivingEntity.class,
                new AABB(center, center).inflate(radius + .35), e -> VehicleContactDamage.canHit(this, operator, e))) {
            if (this.bladesReach(target, center, normal, radius))
                target.hurt(this.damageSources().mobAttack(this), 3 + speed * .055F);
        }
    }

    private boolean bladesReach(LivingEntity target, Vec3 center, Vec3 normal, double radius) {
        AABB bounds = target.getBoundingBox();
        if (!VehicleContactDamage.discIntersects(bounds, center, normal, radius)) return false;
        Vec3 to = bounds.getCenter().subtract(center);
        Vec3 contact = center.add(to.subtract(normal.scale(to.dot(normal))));
        return this.level().clip(new ClipContext(center, contact, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE,
                this)).getType() == HitResult.Type.MISS;
    }

    private void updateWalkers() {
        if (this.tickCount % 5 == 0) {
            for (Player player : this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(5, 1, 5),
                    this::canWalkInCabin)) {
                Vec3 local = this.localFeet(player);
                if (this.cabin.contains(local)) this.walkers.putIfAbsent(player.getUUID(), local);
            }
        }
        var iterator = this.walkers.entrySet().iterator();
        while (iterator.hasNext()) {
            var entry = iterator.next();
            Player player = this.level().getPlayerByUUID(entry.getKey());
            Vec3 next = player != null && this.canWalkInCabin(player)
                    ? this.resolveWalker(player, entry.getValue()) : null;
            if (next == null) iterator.remove();
            else entry.setValue(next);
        }
    }

    private boolean canWalkInCabin(Player player) {
        return player.isAlive() && !player.isSpectator() && !player.isPassenger() && !player.getAbilities().flying;
    }

    private Vec3 localFeet(Player player) {
        return AirframeLayout.local(this.position(), this.getYRot(), player.position());
    }

    /** The client applies the same local cabin boundary before sending walking movement. */
    public boolean predictCabinWalk(Player player) {
        if (!this.isAlive() || !this.canWalkInCabin(player)) {
            this.walkers.remove(player.getUUID());
            return false;
        }
        Vec3 previous = this.walkers.get(player.getUUID());
        if (previous == null) {
            previous = AirframeLayout.local(this.position(), this.getYRot(), new Vec3(player.xo, player.yo, player.zo));
            if (!this.cabin.contains(previous)) previous = this.localFeet(player);
            if (!this.cabin.contains(previous)) return false;
        }
        Vec3 next = this.resolveWalker(player, previous);
        if (next == null) this.walkers.remove(player.getUUID());
        else this.walkers.put(player.getUUID(), next);
        return next != null;
    }

    private Vec3 resolveWalker(Player player, Vec3 previous) {
        Vec3 local = this.localFeet(player);
        if (this.isCabinOpen() && this.cabin.atSideDoor(local))
            return this.cabin.contains(local) ? local : null;
        if (this.rampDeployed() && this.cabin.atRamp(local))
            return this.cabin.contains(local) || !this.onGround() && this.cabin.overRamp(local) ? local : null;
        if (previous.z < this.cabin.rear && !this.cabin.contains(local)) return null;
        if (Math.abs(local.x) > this.cabin.halfWidth + 1.0 || local.z < this.cabin.rear - 1.0
                || local.z > this.cabin.front + 1.0 || local.y < this.cabin.floor - .86
                || local.y > this.cabin.ceiling + 1) return null;

        Vec3 constrained = this.constrainWalker(local, previous, player.getBbWidth() / 2, player.getBbHeight());
        double correction = constrained.distanceToSqr(local);
        if (correction > 1.0E-7) {
            Vec3 point = AirframeLayout.world(this.position(), this.getYRot(), constrained.x, constrained.y, constrained.z);
            if (correction > .25 && player instanceof ServerPlayer server && server.connection != null)
                server.connection.teleport(point.x, point.y, point.z, player.getYRot(), player.getXRot());
            else player.setPos(point);
            if (constrained.y != local.y) player.setDeltaMovement(player.getDeltaMovement().multiply(1, 0, 1));
        }
        return constrained;
    }

    public Vec3 constrainWalker(Vec3 local, Vec3 previous) {
        return this.constrainWalker(local, previous, .30, 1.80);
    }

    private Vec3 constrainWalker(Vec3 local, Vec3 previous, double radius, double height) {
        double x = Mth.clamp(local.x, -this.cabin.halfWidth + radius, this.cabin.halfWidth - radius);
        double z = Mth.clamp(local.z, this.cabin.rear + radius, this.cabin.front - radius);
        if (this.model() == HelicopterType.MI8) {
            double wallStart = AirframeLayout.MI8_BULKHEAD_MIN_Z - radius;
            double wallEnd = AirframeLayout.MI8_BULKHEAD_MAX_Z + radius;
            double doorway = AirframeLayout.MI8_BULKHEAD_OPEN_HALF_WIDTH - radius;
            if (Math.abs(x) > doorway) {
                if (previous.z <= wallStart && z > wallStart) z = wallStart;
                else if (previous.z >= wallEnd && z < wallEnd) z = wallEnd;
                else if (z > wallStart && z < wallEnd) x = Math.copySign(doorway, x);
            }
        }
        double headroom = Math.max(this.cabin.floor, this.cabin.ceiling - height);
        return new Vec3(x, Mth.clamp(local.y, this.cabin.floor, headroom), z);
    }

    private void carryWalkers() {
        for (var entry : this.walkers.entrySet()) {
            Player player = this.level().getPlayerByUUID(entry.getKey());
            if (player == null) continue;
            Vec3 local = entry.getValue();
            player.setPos(AirframeLayout.world(this.position(), this.getYRot(), local.x, local.y, local.z));
            player.resetFallDistance();
        }
    }

    private InteractionResult enterCabin(Player player) {
        if (!this.isCabinOpen() || !player.isAlive() || player.isPassenger()) return InteractionResult.FAIL;
        Vec3 target = AirframeLayout.world(this.position(), this.getYRot(), 0,this.cabin.floor+.015,this.cabin.doorZ);
        if (!this.level().noCollision(player, player.getBoundingBox().move(target.subtract(player.position())))) {
            return InteractionResult.FAIL;
        }
        player.teleportTo(target.x, target.y, target.z);
        player.resetFallDistance();
        this.walkers.put(player.getUUID(),new Vec3(0,this.cabin.floor+.015,this.cabin.doorZ));
        return InteractionResult.CONSUME;
    }

    private boolean secureCabin() {
        if (!this.isCabinOpen()) return true;
        if (this.isRampOpen() || this.rampTicks!=0) return false;
        var travelers=this.level().getEntitiesOfClass(Player.class,this.getBoundingBox().inflate(4.7,1,4.7),
                p->p.isAlive() && !p.isPassenger() && !p.isSpectator() && this.insideWalkableCabin(p));
        for (Player traveler : travelers) {
            Vec3 local=AirframeLayout.local(this.position(),this.getYRot(),traveler.position());
            this.walkers.put(traveler.getUUID(),local);
        }
        return true;
    }

    private void fly(int input, int rotorSpeed) {
        Vec3 velocity = this.getDeltaMovement();
        boolean powered = this.engineOn() && rotorSpeed >= 64;
        boolean hold=powered && (this.deckHold() || !this.onGround() && this.isVehicle() && !this.hasPilot());
        boolean controlled=powered && this.hasPilot() && !hold;
        if (this.deckHold() && powered) velocity=Vec3.ZERO;
        int forward = controlled ? axis(input, FORWARD, BACK) : 0;
        int sideways = controlled ? axis(input, STRAFE_RIGHT, STRAFE_LEFT) : 0;
        int vertical = controlled ? axis(input, ASCEND, DESCEND) : 0;
        int turn = controlled ? axis(input, RIGHT, LEFT) : 0;
        float authority = 0.43F + 0.57F * Math.min(this.engineHealth(), this.rotorHealth()) / 100.0F;
        boolean lostYaw = this.tailHealth() == 0 && this.model() != HelicopterType.KA52;
        if (this.onGround() && vertical <= 0) {
            forward = 0;
            sideways = 0;
        }
        float turnTarget = lostYaw ? this.airborne && rotorSpeed > 35 ? 4.8F : 0
                : turn * this.model().turnRate * (0.52F + 0.48F * this.tailHealth() / 100.0F);
        this.turnVelocity=hold?0:Mth.lerp(.28F,this.turnVelocity,turnTarget);
        this.setYRot(Mth.wrapDegrees(this.getYRot() + this.turnVelocity));
        this.yBodyRot = this.getYRot();
        this.yHeadRot = this.getYRot();

        Vec3 desired = AirframeLayout.world(Vec3.ZERO, this.getYRot(), -sideways * .60, 0, forward < 0 ? -.58 : forward);
        if (desired.lengthSqr() > 1) desired = desired.normalize();
        desired = desired.scale(this.model().speed * authority);
        double climb = hold ? 0 : controlled ? vertical * .30 * authority : powered ? -.13 : Math.max(-.82, velocity.y - .052);
        if (vertical < 0 && this.level().getBlockCollisions(this, this.getBoundingBox().move(0,-.61,0)).iterator().hasNext())
            climb = Math.max(-.13, climb);
        if (this.getY() >= this.level().getMaxBuildHeight() + 35 && climb > 0) climb = 0;
        // A light downward probe keeps the grounded state stable as the pilot lets go of the controls.
        double y = this.onGround() && climb <= 0 ? -.04 : Mth.lerp(powered ? .32 : .75, velocity.y, climb);
        double blend = desired.lengthSqr() < .0001 ? .23 : .13;
        Vec3 motion = new Vec3(Mth.lerp(blend, velocity.x, desired.x), y, Mth.lerp(blend, velocity.z, desired.z));
        this.move(MoverType.SELF, motion);
        this.airborne = !this.onGround();
        this.setDeltaMovement(this.horizontalCollision ? 0 : motion.x, this.verticalCollision ? 0 : motion.y,
                this.horizontalCollision ? 0 : motion.z);
        this.leanPitch = this.airborne ? Mth.lerp(.22F, this.leanPitch, forward * 7F) : 0;
        this.leanRoll = this.airborne ? Mth.lerp(.22F, this.leanRoll, sideways * 7F + turn * 4F) : 0;
        this.entityData.set(LEAN, ((Math.round(this.leanPitch) & 255) << 8) | (Math.round(this.leanRoll) & 255));

    }

    private static int axis(int flags, int positive, int negative) {
        return ((flags & positive) != 0 ? 1 : 0) - ((flags & negative) != 0 ? 1 : 0);
    }

    private void fireCannon(Player player) {
        if (!this.model().armed || this.launcherHealth() <= 0 || !this.engineOn()
                || this.rpm() < 65 || this.gunCooldown > 0 || this.cannonAmmo() <= 0) return;
        float yaw = this.getYRot() + Mth.clamp(Mth.wrapDegrees(player.getYRot() - this.getYRot()), -20, 20);
        Vec3 direction = Vec3.directionFromRotation(Mth.clamp(player.getXRot(), -12, 35), yaw);
        int side = (this.cannonAmmo() & 1) == 0 ? 1 : -1;
        Vec3 pod = AirframeLayout.store(this.model(),side);
        Vec3 center = AirframeLayout.world(this.position(),this.getYRot(),pod.x+side*.36,pod.y-.09,pod.z);
        Vec3 muzzle = AirframeLayout.world(this.position(),this.getYRot(),pod.x+side*.36,pod.y-.09,pod.z+1.17);
        if (this.level().clip(new ClipContext(center, muzzle, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, this)).getType() != HitResult.Type.MISS) return;
        TankShellEntity round = new TankShellEntity(T72Mod.TANK_SHELL.get(), this.level());
        round.setOwner(player);
        round.configureShell(this, this.model() == HelicopterType.MI8 ? 5 : 8, 0.0F, 0.001F);
        round.setPos(muzzle.x, muzzle.y, muzzle.z);
        round.shoot(direction.x, direction.y, direction.z, 3.4F, 0.0F);
        if (this.level().addFreshEntity(round)) {
            this.gunCooldown = GUN_COOLDOWN_TICKS;
            this.entityData.set(CANNON_AMMO, this.cannonAmmo() - 1);
            this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_LAUNCH,
                    SoundSource.PLAYERS, 1.2F, 1.55F);
        }
    }

    private void fireRocket(Player player) {
        if (this.model().armed && this.launcherHealth() == 0) {
            player.displayClientMessage(Component.translatable("message.t72mod.launcher_broken"), true);
            return;
        }
        if (!this.model().armed || this.onGround() || this.rpm() < 72 || this.rocketCooldown > 0) return;
        if (this.rockets()==0) {
            player.displayClientMessage(Component.translatable("message.t72mod.rockets_reload_hint"),true);
            return;
        }
        Vec3 direction = Vec3.directionFromRotation(3, this.getYRot());
        Vec3 pod = AirframeLayout.store(this.model(),(this.rockets() & 1) == 0 ? 1 : -1);
        Vec3 center = AirframeLayout.world(this.position(),this.getYRot(),pod.x,pod.y,pod.z);
        Vec3 muzzle = AirframeLayout.world(this.position(),this.getYRot(),pod.x,pod.y,pod.z+.95);
        if (this.level().clip(new ClipContext(center, muzzle, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, this)).getType() != HitResult.Type.MISS) return;
        TankShellEntity rocket = new TankShellEntity(T72Mod.TANK_SHELL.get(), this.level());
        rocket.setOwner(player);
        rocket.configureShell(this, this.model() == HelicopterType.MI8 ? 24 : 35, 2.2F, 0.005F);
        rocket.setPos(muzzle.x, muzzle.y, muzzle.z);
        rocket.shoot(direction.x, direction.y, direction.z, 2.1F, 0.0F);
        if (this.level().addFreshEntity(rocket)) {
            this.entityData.set(ROCKETS, this.rockets() - 1);
            this.rocketCooldown = 14;
            this.level().playSound(null, this.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 2, 1.0F);
        }
    }

    @Override
    public Vec3 partPosition(int part) {
        if (part >= FIRST_DECK_SECTION) {
            int index = part - FIRST_DECK_SECTION;
            if (index >= this.cabin.seatCount()) return this.cabin.shell(index).position(this);
            Vec3 seat = this.cabin.seatHitCenter(index);
            return AirframeLayout.world(this.position(),this.getYRot(),seat.x,seat.y,seat.z);
        }
        return switch (part) {
            case MAIN_ROTOR -> AirframeLayout.world(this.position(), this.getYRot(), 0,
                    AirframeLayout.rotorY(this.model()) - .20, -.53);
            case TAIL_ROTOR -> AirframeLayout.world(this.position(), this.getYRot(), .12, 3.05, AirframeLayout.tailZ(this.model()));
            default -> {
                Vec3 pod = AirframeLayout.store(this.model(),part == LEFT_POD ? -1 : 1);
                yield AirframeLayout.world(this.position(),this.getYRot(),pod.x,pod.y-.28,pod.z);
            }
        };
    }

    @Override
    public AABB partBounds(int index, AABB fallback) {
        return index >= FIRST_DECK_SECTION + this.cabin.seatCount()
                ? this.cabin.shell(index-FIRST_DECK_SECTION).bounds(this) : fallback;
    }

    @Override
    public boolean partIsActive(int index) {
        if (index>=FIRST_DECK_SECTION) return index<FIRST_DECK_SECTION+this.cabin.seatCount();
        return switch (index) {
            case MAIN_ROTOR -> this.rotorHealth()>0;
            case TAIL_ROTOR -> this.tailHealth()>0;
            default -> this.launcherHealth()>0;
        };
    }

    @Override
    public boolean partIsSolid(int index) {
        int local=index-FIRST_DECK_SECTION;
        return local>=this.cabin.seatCount() && this.partShouldExist(index);
    }

    @Override
    public boolean partShouldExist(int index) {
        if (index<FIRST_DECK_SECTION+this.cabin.seatCount()) return true;
        int local=index-FIRST_DECK_SECTION;
        if (this.cabin.isRamp(local)) return this.rampDeployed();
        return !this.cabin.isStep(local) || this.isCabinOpen();
    }

    @Override
    public InteractionResult interactPart(int index,Player player,InteractionHand hand) {
        int seat=index-FIRST_DECK_SECTION;
        if (hand==InteractionHand.MAIN_HAND && player.getItemInHand(hand).isEmpty()
                && seat>=0 && seat<this.cabin.seatCount()) return this.selectSeat(player,seat);
        return this.mobInteract(player,hand);
    }

    public int aimSeat(Player player) {
        if (!this.insideWalkableCabin(player)) return -1;
        Vec3 start=player.getEyePosition(), end=start.add(player.getLookAngle().scale(3));
        double best=9.0;
        int action=-1;
        for (int i=0;i<this.cabin.seatCount();i++) {
            var hit=this.flightParts[FIRST_DECK_SECTION+i].getBoundingBox().inflate(.09).clip(start,end);
            if (hit.isEmpty()) continue;
            double depth=start.distanceToSqr(hit.get());
            if (depth<best) {
                best=depth;
                action=SELECT_SEAT+i;
            }
        }
        return action;
    }

    public boolean clearCabinFireLine(Vec3 outside, Vec3 inside) {
        Vec3 from = AirframeLayout.local(this.position(), this.getYRot(), outside);
        Vec3 to = AirframeLayout.local(this.position(), this.getYRot(), inside);
        AABB shell = new AABB(-this.cabin.halfWidth, this.cabin.floor, this.cabin.rear,
                this.cabin.halfWidth, this.cabin.ceiling, this.cabin.front);
        return this.isCabinOpen() && CabinFireLine.throughOpening(shell, from, to, 0, this.cabin.halfWidth,
                this.cabin.doorZ - this.cabin.doorWidth / 2, this.cabin.doorZ + this.cabin.doorWidth / 2,
                this.cabin.floor, this.cabin.ceiling)
                || this.rampDeployed() && CabinFireLine.throughOpening(shell, from, to, 1, this.cabin.rear,
                -1.07, 1.07, this.cabin.floor - .05, this.cabin.ceiling);
    }

    public int rocketCapacity() { return MAX_ROCKETS; }

    @Override
    public boolean hurtPart(int index, DamageSource source, Vec3 impact, float amount) {
        if (index >= FIRST_DECK_SECTION) return this.hitAirframe(source, impact, amount);
        var module = switch (index) {
            case MAIN_ROTOR -> ROTOR;
            case TAIL_ROTOR -> TAIL;
            default -> LAUNCHER;
        };
        return this.damageModule(source, amount, module);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return this.hitAirframe(source, source.getSourcePosition(), amount);
    }

    public boolean hitAirframe(DamageSource source, Vec3 hit, float amount) {
        Vec3 relative = hit == null ? Vec3.ZERO : hit.subtract(this.position());
        double tailward = -relative.dot(Vec3.directionFromRotation(0, this.getYRot()));
        return this.damageModule(source, amount, tailward > 4.9 ? TAIL : relative.y > AirframeLayout.rotorY(this.model()) - 0.28 ? ROTOR : ENGINE);
    }

    private boolean damageModule(DamageSource source, float amount, EntityDataAccessor<Integer> module) {
        if (this.level().isClientSide || !this.isAlive() || amount <= 0 || !Float.isFinite(amount)) return false;
        boolean shellImpact = source.getDirectEntity() instanceof TankShellEntity;
        boolean explosion = source.is(DamageTypeTags.IS_EXPLOSION);
        if (explosion && source.getDirectEntity() instanceof TankShellEntity shell && shell.excludeFromBlast(this)) return false;
        float damage = source.is(T72Mod.TACZ_BULLETS) ? Math.min(amount, 40) * 0.55F : amount;
        if (shellImpact && !explosion) this.invulnerableTime = 0;
        boolean hit = super.hurt(source, damage);
        if (!hit || !this.isAlive() || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return hit;
        int previous = this.entityData.get(module);
        int moduleDamage = Mth.ceil(damage * (explosion ? 1.85F : 1.55F));
        this.entityData.set(module, Math.max(0, previous - moduleDamage));
        if (previous > 0 && this.entityData.get(module) == 0) {
            if (module == ENGINE || module == ROTOR) this.entityData.set(ENGINE_ON, false);
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.PLAYERS, 1.4F, 0.83F);
        }
        return true;
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide && this.hasChest()) {
            this.entityData.set(HAS_CHEST, false);
            Containers.dropContents(this.level(), this.blockPosition(), this.cargo);
            this.spawnAtLocation(Items.CHEST);
        }
        this.ejectPassengers();
        super.die(source);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Fuel", this.fuel());
        tag.putInt("Rotor", this.rotorHealth());
        tag.putInt("Tail", this.tailHealth());
        tag.putInt("Engine", this.engineHealth());
        tag.putInt("Launcher", this.launcherHealth());
        tag.putInt("Rockets", this.rockets());
        tag.put("CabinSeats",this.entityData.get(SEATS).copy());
        tag.putInt("CannonAmmo", this.cannonAmmo());
        tag.putBoolean("Chest", this.hasChest());
        ListTag contents = new ListTag();
        for (int slot = 0; slot < this.cargo.getContainerSize(); slot++) {
            ItemStack item = this.cargo.getItem(slot);
            if (item.isEmpty()) continue;
            CompoundTag entry = new CompoundTag();
            entry.putByte("Slot", (byte) slot);
            contents.add(item.save(entry));
        }
        tag.put("Cargo", contents);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(FUEL, Mth.clamp(tag.getInt("Fuel"), 0, this.model().fuelCapacity));
        if (tag.contains("Rotor")) this.entityData.set(ROTOR, Mth.clamp(tag.getInt("Rotor"), 0, MAX_PART_HEALTH));
        if (tag.contains("Tail")) this.entityData.set(TAIL, Mth.clamp(tag.getInt("Tail"), 0, MAX_PART_HEALTH));
        if (tag.contains("Engine")) this.entityData.set(ENGINE, Mth.clamp(tag.getInt("Engine"), 0, MAX_PART_HEALTH));
        if (tag.contains("Launcher")) this.entityData.set(LAUNCHER, Mth.clamp(tag.getInt("Launcher"), 0, MAX_PART_HEALTH));
        this.entityData.set(SEATS,tag.getCompound("CabinSeats"));
        this.entityData.set(ROCKETS, Mth.clamp(tag.getInt("Rockets"), 0, this.model().armed ? MAX_ROCKETS : 0));
        this.entityData.set(CANNON_AMMO, Mth.clamp(tag.getInt("CannonAmmo"), 0, this.model().armed ? MAX_CANNON_AMMO : 0));
        this.entityData.set(HAS_CHEST, tag.getBoolean("Chest"));
        this.cargo.clearContent();
        for (Tag entry : tag.getList("Cargo", Tag.TAG_COMPOUND)) {
            CompoundTag item = (CompoundTag) entry;
            int slot = item.getByte("Slot") & 255;
            if (slot < this.cargo.getContainerSize()) this.cargo.setItem(slot, ItemStack.of(item));
        }
    }
}
