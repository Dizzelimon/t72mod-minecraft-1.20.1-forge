package com.example.t72mod.entity;

import com.example.t72mod.sound.VehicleSounds;
import com.example.t72mod.T72Mod;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class HelicopterEntity extends PathfinderMob implements VehiclePartEntity.Parent {
    public static final int FORWARD = 1;
    public static final int BACK = 2;
    public static final int LEFT = 4;
    public static final int RIGHT = 8;
    public static final int ASCEND = 16;
    public static final int DESCEND = 32;
    public static final int STRAFE_LEFT = 64;
    public static final int STRAFE_RIGHT = 128;
    public static final int TOGGLE_ENGINE = 0;
    public static final int CARGO = 1;
    public static final int FIRE = 2;
    public static final int CANNON = 3;
    private static final int FIRST_DECK_SECTION = 4;
    private static final int PILOT_SEAT = FIRST_DECK_SECTION;
    private static final int COPILOT_SEAT = PILOT_SEAT + 1;
    private static final int MAIN_ROTOR = 0;
    private static final int TAIL_ROTOR = 1;
    private static final int LEFT_POD = 2;
    private static final int RIGHT_POD = 3;
    private static final EntityDimensions[] FLIGHT_PARTS = {
            EntityDimensions.fixed(1.75F, 0.50F), EntityDimensions.fixed(1.0F, 1.15F),
            EntityDimensions.fixed(0.78F, 0.55F), EntityDimensions.fixed(0.78F, 0.55F)
    };
    private static final CabinSection[] CABIN = transportCabin();
    private static final EntityDimensions[] TRANSPORT_PARTS = transportParts();

    private static CabinSection[] transportCabin() {
        var sections = new java.util.ArrayList<CabinSection>();
        sections.add(new CabinSection(-.62, 1.38, 3.28, .57, .69, .67));
        sections.add(new CabinSection(.58, 1.38, 3.28, .57, .69, .67));
        for (int i = 0; i < 8; i++) {
            double z = -3.12 + i * .96;
            sections.add(new CabinSection(0, 1.17, z, 3.03, .18, .97));
            sections.add(new CabinSection(0, 3.43, z, 2.65, .26, .99));
            sections.add(new CabinSection(-1.53, 1.35, z, .27, 2.08, .97));
            if (z < 0 || z > 2.4) sections.add(new CabinSection(1.53, 1.35, z, .27, 2.08, .97));
        }
        sections.add(new CabinSection(1.55, 1.35, .22, .27, 2.08, .42));
        sections.add(new CabinSection(1.55, 1.35, 2.27, .27, 2.08, .29));
        sections.add(new CabinSection(0, 1.35, -3.67, 2.95, 2.08, .22));
        sections.add(new CabinSection(0, 1.35, 4.12, 2.9, 2.04, .22));
        double door = AirframeLayout.MI8_DOOR_Z;
        sections.add(new CabinSection(2.37, .30, door, .8, .19, 1.12));
        sections.add(new CabinSection(2.02, .70, door, .61, .19, 1.12));
        sections.add(new CabinSection(1.70, 1.10, door, .52, .18, 1.12));
        return sections.toArray(CabinSection[]::new);
    }

    private static EntityDimensions[] transportParts() {
        EntityDimensions[] parts = java.util.Arrays.copyOf(FLIGHT_PARTS, FIRST_DECK_SECTION + CABIN.length);
        parts[LEFT_POD] = null;
        parts[RIGHT_POD] = null;
        for (int i = 0; i < CABIN.length; i++) parts[i + FIRST_DECK_SECTION] = CABIN[i].dimensions();
        return parts;
    }

    private static final int MAX_PART_HEALTH = 100;
    private static final int MAX_ROCKETS = 12;
    private static final int MAX_CANNON_AMMO = 240;
    private static final int AMMO_PER_INGOT = 20;
    private static final int GUN_COOLDOWN_TICKS = 4;
    private static final EntityDataAccessor<Boolean> ENGINE_ON = boolData();
    private static final EntityDataAccessor<Boolean> HAS_CHEST = boolData();
    private static final EntityDataAccessor<Boolean> CABIN_OPEN = boolData();
    private static final EntityDataAccessor<Integer> FUEL = integerData();
    private static final EntityDataAccessor<Integer> ROTOR = integerData();
    private static final EntityDataAccessor<Integer> TAIL = integerData();
    private static final EntityDataAccessor<Integer> ENGINE = integerData();
    private static final EntityDataAccessor<Integer> ROCKETS = integerData();
    private static final EntityDataAccessor<Integer> CANNON_AMMO = integerData();
    private static final EntityDataAccessor<Integer> RPM = integerData();
    private static final EntityDataAccessor<Integer> LEAN = integerData();
    private static final EntityDataAccessor<Integer> LAUNCHER = integerData();

    private final SimpleContainer cargo = new SimpleContainer(27) {
        @Override
        public boolean stillValid(Player player) {
            return hasChest() && isAlive() && (hasPassenger(player)
                    || (onGround() && distanceToSqr(player) <= 36));
        }
    };
    private final VehiclePartEntity[] flightParts;
    private int flightInput;
    private int inputAge;
    private int fuelTicks;
    private int rocketCooldown;
    private int gunCooldown;
    private float rotorAngle;
    private float previousRotorAngle;
    private float turnVelocity;
    private float leanPitch;
    private float leanRoll;
    private boolean airborne;

    public HelicopterEntity(EntityType<? extends HelicopterEntity> type, Level level) {
        super(type, level);
        this.flightParts = new VehiclePartEntity[this.model().armed ? FLIGHT_PARTS.length : TRANSPORT_PARTS.length];
        this.setNoAi(true);
        this.setNoGravity(true);
        this.blocksBuilding = true;
    }

    private static EntityDataAccessor<Boolean> boolData() {
        return SynchedEntityData.defineId(HelicopterEntity.class, EntityDataSerializers.BOOLEAN);
    }

    private static EntityDataAccessor<Integer> integerData() {
        return SynchedEntityData.defineId(HelicopterEntity.class, EntityDataSerializers.INT);
    }

    public static AttributeSupplier.Builder attributes(HelicopterType model) {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, model.hullHealth)
                .add(Attributes.ARMOR, model.armed ? 11 : 5).add(Attributes.KNOCKBACK_RESISTANCE, 1);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ENGINE_ON, false);
        this.entityData.define(HAS_CHEST, false);
        this.entityData.define(CABIN_OPEN, false);
        this.entityData.define(FUEL, 0);
        this.entityData.define(ROTOR, MAX_PART_HEALTH);
        this.entityData.define(TAIL, MAX_PART_HEALTH);
        this.entityData.define(ENGINE, MAX_PART_HEALTH);
        this.entityData.define(ROCKETS, 0);
        this.entityData.define(CANNON_AMMO, 0);
        this.entityData.define(RPM, 0);
        this.entityData.define(LEAN, 0);
        this.entityData.define(LAUNCHER, MAX_PART_HEALTH);
    }

    public HelicopterType model() {
        if (this.getType() == T72Mod.KA52.get()) return HelicopterType.KA52;
        return this.getType() == T72Mod.MI24.get() ? HelicopterType.MI24 : HelicopterType.MI8;
    }

    public void giveStarterFuel() {
        this.entityData.set(FUEL, this.model().fuelCapacity / 2);
        this.entityData.set(ROCKETS, this.model().armed ? 4 : 0);
        this.entityData.set(CANNON_AMMO, this.model().armed ? 80 : 0);
    }

    public boolean isCabinOpen() { return this.entityData.get(CABIN_OPEN); }
    public boolean hasChest() { return this.entityData.get(HAS_CHEST); }
    public boolean engineOn() { return this.entityData.get(ENGINE_ON); }
    public int fuel() { return this.entityData.get(FUEL); }
    public int rotorHealth() { return this.entityData.get(ROTOR); }
    public int tailHealth() { return this.entityData.get(TAIL); }
    public int engineHealth() { return this.entityData.get(ENGINE); }
    public int launcherHealth() { return this.entityData.get(LAUNCHER); }
    public int rockets() { return this.entityData.get(ROCKETS); }
    public int cannonAmmo() { return this.entityData.get(CANNON_AMMO); }
    public int rpm() { return this.entityData.get(RPM); }

    public float visualPitch() { return (byte) (this.entityData.get(LEAN) >> 8); }
    public float visualRoll() { return (byte) (int) this.entityData.get(LEAN); }

    public float rotorAngle(float partialTick) {
        return Mth.rotLerp(partialTick, this.previousRotorAngle, this.rotorAngle);
    }

    public boolean isPilot(Player player) {
        return this.isAlive() && this.getFirstPassenger() == player;
    }

    public void acceptInput(Player sender, int input) {
        if (this.isPilot(sender)) {
            this.flightInput = input & 255;
            this.inputAge = 0;
        }
    }

    public void handleAction(Player player, int command) {
        if (!this.isAlive() || !this.hasPassenger(player)) return;
        if (command == CARGO) {
            this.openCargo(player);
        } else if (this.isPilot(player)) {
            if (command == TOGGLE_ENGINE) {
                if (this.engineOn()) {
                    this.entityData.set(ENGINE_ON, false);
                } else if (this.fuel() > 0 && this.engineHealth() > 0 && this.rotorHealth() > 0) {
                    if (!this.secureCabin()) {
                        player.displayClientMessage(Component.translatable("message.t72mod.cabin_seats_needed"), true);
                        return;
                    }
                    this.entityData.set(CABIN_OPEN, false);
                    this.entityData.set(ENGINE_ON, true);
                }
            } else if (command == FIRE) {
                this.fireRocket(player);
            } else if (command == CANNON) {
                this.fireCannon(player);
            }
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.isAlive() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!this.onGround() && !this.isCabinOpen()) return InteractionResult.FAIL;
        ItemStack held = player.getItemInHand(hand);
        int fuelValue = T72TankEntity.getFuelValue(held);
        if (held.is(Items.CHEST) && !this.hasChest()) {
            if (!this.level().isClientSide) {
                this.entityData.set(HAS_CHEST, true);
                this.consumeSupply(player, held);
                player.displayClientMessage(Component.translatable("message.t72mod.cargo_installed"), true);
            }
        } else if (fuelValue > 0 && this.fuel() < this.model().fuelCapacity) {
            if (!this.level().isClientSide) {
                this.entityData.set(FUEL, Math.min(this.model().fuelCapacity, this.fuel() + fuelValue));
                this.consumeSupply(player, held);
                this.level().playSound(null, this.blockPosition(), SoundEvents.BUCKET_FILL, SoundSource.PLAYERS, 1, 1);
            }
        } else if (held.is(T72Mod.REPAIR_KIT.get())
                && (this.getHealth() < this.getMaxHealth() || this.rotorHealth() < MAX_PART_HEALTH
                || this.tailHealth() < MAX_PART_HEALTH || this.engineHealth() < MAX_PART_HEALTH
                || this.launcherHealth() < MAX_PART_HEALTH)) {
            if (!this.level().isClientSide) {
                this.heal(55);
                this.entityData.set(ROTOR, MAX_PART_HEALTH);
                this.entityData.set(TAIL, MAX_PART_HEALTH);
                this.entityData.set(ENGINE, MAX_PART_HEALTH);
                this.entityData.set(LAUNCHER, MAX_PART_HEALTH);
                this.consumeSupply(player, held);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1, 1);
            }
        } else if (this.model().armed && held.is(T72Mod.AIR_ROCKET.get()) && this.rockets() < MAX_ROCKETS) {
            if (!this.level().isClientSide) {
                int loaded = Math.min(held.getCount(), MAX_ROCKETS - this.rockets());
                this.entityData.set(ROCKETS, this.rockets() + loaded);
                if (!player.getAbilities().instabuild) held.shrink(loaded);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, 1, 1);
            }
        } else if (this.model().armed && held.is(Items.IRON_INGOT) && this.cannonAmmo() < MAX_CANNON_AMMO) {
            if (!this.level().isClientSide) {
                this.entityData.set(CANNON_AMMO, Math.min(MAX_CANNON_AMMO, this.cannonAmmo() + AMMO_PER_INGOT));
                this.consumeSupply(player, held);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON,
                        SoundSource.PLAYERS, 0.8F, 1.2F);
            }
        } else if (player.isShiftKeyDown() && held.isEmpty() && this.isCabinOpen() && !this.insideCabin(player)) {
            if (this.level().isClientSide) return InteractionResult.SUCCESS;
            return this.enterCabin(player);
        } else if (player.isShiftKeyDown()) {
            if (!this.level().isClientSide) this.openCargo(player);
        } else if (this.getPassengers().size() < this.model().seats) {
            if (this.model() == HelicopterType.MI8 && this.getFirstPassenger() == null) {
                Vec3 local = AirframeLayout.local(this.position(), this.getYRot(), player.position());
                if (!this.insideCabin(player) || local.z < 2.13 || !held.isEmpty()) {
                    if (!this.level().isClientSide)
                        player.displayClientMessage(Component.translatable("message.t72mod.mi8_board"), true);
                    return InteractionResult.FAIL;
                }
            }
            if (!this.level().isClientSide && !player.startRiding(this)) return InteractionResult.FAIL;
        } else {
            return InteractionResult.FAIL;
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    private void consumeSupply(Player player, ItemStack stack) {
        if (player.getAbilities().instabuild) return;
        boolean lava = stack.is(Items.LAVA_BUCKET);
        stack.shrink(1);
        if (lava) {
            ItemStack bucket = new ItemStack(Items.BUCKET);
            if (!player.addItem(bucket)) player.drop(bucket, false);
        }
    }

    private void openCargo(Player player) {
        if (!this.hasChest()) {
            player.displayClientMessage(Component.translatable("message.t72mod.cargo_missing"), true);
            return;
        }
        player.openMenu(new SimpleMenuProvider((id, inventory, owner) -> ChestMenu.threeRows(id, inventory, this.cargo),
                Component.translatable("menu.t72mod.helicopter_cargo")));
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return passenger instanceof Player && this.isAlive() && this.getPassengers().size() < this.model().seats;
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction move) {
        if (!this.hasPassenger(passenger)) return;
        int seat = this.getPassengers().indexOf(passenger);
        Vec3 location = switch (this.model()) {
            case MI8 -> AirframeLayout.world(this.position(), this.getYRot(),
                    seat == 0 ? -.62 : seat == 1 ? .58 : seat % 2 == 0 ? -1.08 : 1.08,
                    1.60, seat <= 1 ? 3.29 : -1.17 - (seat - 2) / 2 * .92);
            case MI24 -> AirframeLayout.world(this.position(), this.getYRot(), 0, seat == 0 ? 1.44 : 1.25,
                    seat == 0 ? 2.32 : 3.79);
            case KA52 -> AirframeLayout.world(this.position(), this.getYRot(), seat == 0 ? -.52 : .52, 1.39, 3.05);
        };
        move.accept(passenger, location.x, location.y + passenger.getMyRidingOffset(), location.z);
    }

    @Override
    protected void removePassenger(Entity passenger) {
        boolean wasPilot = this.getFirstPassenger() == passenger;
        super.removePassenger(passenger);
        if (wasPilot) {
            this.flightInput = 0;
            this.inputAge = 0;
            if (!this.level().isClientSide && this.onGround()) {
                this.entityData.set(ENGINE_ON, false);
            }
        }
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        if (this.isCabinOpen()) {
            return AirframeLayout.world(this.position(), this.getYRot(), 0, AirframeLayout.MI8_FLOOR + .02, 2.04);
        }
        if (!this.onGround()) return this.position().add(0, -0.4, 0);
        for (float side : new float[]{90, -90, 180, 0}) {
            Vec3 location = this.position().add(Vec3.directionFromRotation(0, this.getYRot() + side).scale(2.9));
            if (this.level().noCollision(passenger, passenger.getBoundingBox().move(location.subtract(passenger.position())))) {
                return location;
            }
        }
        return this.position().add(0, this.getBbHeight(), 0);
    }

    @Override
    public boolean canBeCollidedWith() { return this.isAlive() && !this.isCabinOpen(); }

    @Override
    public boolean canCollideWith(Entity other) {
        if (other instanceof VehiclePartEntity part && part.parent() == this) return false;
        return super.canCollideWith(other);
    }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    public void travel(Vec3 ignored) {
        // Flight runs on the server. Client positions come from entity tracking.
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.isAlive()) return;
        if (this.level().isClientSide) {
            this.previousRotorAngle = this.rotorAngle;
            this.rotorAngle = Mth.wrapDegrees(this.rotorAngle + this.rpm() * 0.83F);
            if ((this.engineHealth() < 50 || this.rotorHealth() < 35) && this.tickCount % 4 == 0) {
                this.level().addParticle(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.9,
                        this.getZ(), 0, 0.08, 0);
            }
            return;
        }

        if (this.rocketCooldown > 0) this.rocketCooldown--;
        if (this.gunCooldown > 0) this.gunCooldown--;
        if (this.inputAge < 12) this.inputAge++;
        int input = this.inputAge < 12 && this.getFirstPassenger() instanceof Player ? this.flightInput : 0;
        if (this.fuel() == 0 || this.engineHealth() == 0 || this.rotorHealth() == 0 || this.isInWater()) this.entityData.set(ENGINE_ON, false);
        int rotorSpeed = this.rpm();
        int targetSpeed = this.engineOn() ? Math.min(100, Math.min(this.rotorHealth(), this.engineHealth()) + 15) : 0;
        rotorSpeed += Mth.clamp(targetSpeed - rotorSpeed, -3, 2);
        this.entityData.set(RPM, rotorSpeed);
        if (this.engineOn() && ++this.fuelTicks >= this.model().fuelInterval * (this.onGround() ? 2 : 1)) {
            this.fuelTicks = 0;
            this.entityData.set(FUEL, Math.max(0, this.fuel() - 1));
        }
        this.fly(input, rotorSpeed);
        // An unattended aircraft keeps lift for its descent, then shuts down on touchdown.
        if (this.onGround() && this.getFirstPassenger() == null) {
            this.entityData.set(ENGINE_ON, false);
        }
        this.entityData.set(CABIN_OPEN, this.model() == HelicopterType.MI8 && this.onGround()
                && !this.engineOn() && this.getDeltaMovement().horizontalDistanceSqr() < 0.0025);
        if (this.isAlive()) VehiclePartEntity.updateParts(this, this.flightParts,
                this.model().armed ? FLIGHT_PARTS : TRANSPORT_PARTS);
    }

    private boolean insideCabin(Player player) {
        Vec3 local = AirframeLayout.local(this.position(), this.getYRot(), player.position());
        return Math.abs(local.x) < 1.43 && local.z > -3.60 && local.z < 4.09 && local.y > 1.24 && local.y < 3.45;
    }

    private InteractionResult enterCabin(Player player) {
        if (!this.isCabinOpen() || !player.isAlive() || player.isPassenger()) return InteractionResult.FAIL;
        Vec3 target = this.position().add(0, AirframeLayout.MI8_FLOOR + 0.01, 0);
        if (!this.level().noCollision(player, player.getBoundingBox().move(target.subtract(player.position())))) {
            return InteractionResult.FAIL;
        }
        player.teleportTo(target.x, target.y, target.z);
        player.resetFallDistance();
        return InteractionResult.CONSUME;
    }

    private boolean secureCabin() {
        if (!this.isCabinOpen()) return true;
        var passengers = this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(4.7, 1, 4.7),
                player -> player.isAlive() && !player.isPassenger() && !player.isSpectator() && this.insideCabin(player));
        if (passengers.size() + this.getPassengers().size() > this.model().seats
                || passengers.stream().anyMatch(Player::isShiftKeyDown)) return false;
        for (Player passenger : passengers) {
            if (!passenger.startRiding(this, true)) return false;
        }
        return true;
    }

    private void fly(int input, int rotorSpeed) {
        Vec3 velocity = this.getDeltaMovement();
        boolean powered = this.engineOn() && rotorSpeed >= 64;
        boolean controlled = powered && this.getFirstPassenger() instanceof Player;
        int forward = controlled ? axis(input, FORWARD, BACK) : 0;
        int sideways = controlled ? axis(input, STRAFE_RIGHT, STRAFE_LEFT) : 0;
        int vertical = controlled ? axis(input, ASCEND, DESCEND) : 0;
        int turn = controlled ? axis(input, RIGHT, LEFT) : 0;
        float authority = 0.43F + 0.57F * Math.min(this.engineHealth(), this.rotorHealth()) / 100.0F;
        boolean lostYaw = this.tailHealth() == 0 && this.model() != HelicopterType.KA52;
        if (this.onGround() && vertical <= 0) {
            forward = 0;
            sideways = 0;
        }
        float turnTarget = lostYaw ? this.airborne && rotorSpeed > 35 ? 4.8F : 0
                : turn * this.model().turnRate * (0.52F + 0.48F * this.tailHealth() / 100.0F);
        this.turnVelocity = Mth.lerp(.28F, this.turnVelocity, turnTarget);
        this.setYRot(Mth.wrapDegrees(this.getYRot() + this.turnVelocity));
        this.yBodyRot = this.getYRot();
        this.yHeadRot = this.getYRot();

        Vec3 desired = AirframeLayout.world(Vec3.ZERO, this.getYRot(), -sideways * .60, 0, forward < 0 ? -.58 : forward);
        if (desired.lengthSqr() > 1) desired = desired.normalize();
        desired = desired.scale(this.model().speed * authority);
        double climb = controlled ? vertical * .30 * authority : powered ? -.13 : Math.max(-.82, velocity.y - .052);
        if (vertical < 0 && this.level().getBlockCollisions(this, this.getBoundingBox().move(0,-.61,0)).iterator().hasNext())
            climb = Math.max(-.13, climb);
        if (this.getY() >= this.level().getMaxBuildHeight() + 35 && climb > 0) climb = 0;
        // A light downward probe keeps the grounded state stable as the pilot lets go of the controls.
        double y = this.onGround() && climb <= 0 ? -.04 : Mth.lerp(powered ? .32 : .75, velocity.y, climb);
        double blend = desired.lengthSqr() < .0001 ? .23 : .13;
        Vec3 motion = new Vec3(Mth.lerp(blend, velocity.x, desired.x), y, Mth.lerp(blend, velocity.z, desired.z));
        this.move(MoverType.SELF, motion);
        this.airborne = !this.onGround();
        this.setDeltaMovement(this.horizontalCollision ? 0 : motion.x, this.verticalCollision ? 0 : motion.y,
                this.horizontalCollision ? 0 : motion.z);
        this.leanPitch = this.airborne ? Mth.lerp(.22F, this.leanPitch, forward * 7F) : 0;
        this.leanRoll = this.airborne ? Mth.lerp(.22F, this.leanRoll, sideways * 7F + turn * 4F) : 0;
        this.entityData.set(LEAN, ((Math.round(this.leanPitch) & 255) << 8) | (Math.round(this.leanRoll) & 255));

    }

    private static int axis(int flags, int positive, int negative) {
        return ((flags & positive) != 0 ? 1 : 0) - ((flags & negative) != 0 ? 1 : 0);
    }

    private void fireCannon(Player player) {
        if (!this.model().armed || this.launcherHealth() <= 0 || !this.engineOn()
                || this.rpm() < 65 || this.gunCooldown > 0 || this.cannonAmmo() <= 0) return;
        float yaw = this.getYRot() + Mth.clamp(Mth.wrapDegrees(player.getYRot() - this.getYRot()), -20, 20);
        Vec3 direction = Vec3.directionFromRotation(Mth.clamp(player.getXRot(), -12, 35), yaw);
        Vec3 center = this.position().add(0, 1.45, 0);
        Vec3 muzzle = center.add(direction.scale(2.8));
        if (this.level().clip(new ClipContext(center, muzzle, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, this)).getType() != HitResult.Type.MISS) return;
        TankShellEntity round = new TankShellEntity(T72Mod.TANK_SHELL.get(), this.level());
        round.setOwner(player);
        round.configureShell(this, 8, 0.0F, 0.001F);
        round.setPos(muzzle.x, muzzle.y, muzzle.z);
        round.shoot(direction.x, direction.y, direction.z, 3.4F, 0.0F);
        if (this.level().addFreshEntity(round)) {
            this.gunCooldown = GUN_COOLDOWN_TICKS;
            this.entityData.set(CANNON_AMMO, this.cannonAmmo() - 1);
            this.level().playSound(null, this.blockPosition(), VehicleSounds.AUTOMATIC_FIRE.get(),
                    SoundSource.PLAYERS, 1.2F, 1.55F);
        }
    }

    private void fireRocket(Player player) {
        if (this.model().armed && this.launcherHealth() == 0) {
            player.displayClientMessage(Component.translatable("message.t72mod.launcher_broken"), true);
            return;
        }
        if (!this.model().armed || this.onGround() || this.rpm() < 72 || this.rocketCooldown > 0 || this.rockets() == 0) return;
        Vec3 direction = Vec3.directionFromRotation(3, this.getYRot());
        Vec3 center = this.position().add(0, 1.15, 0);
        Vec3 muzzle = center.add(direction.scale(2.2));
        if (this.level().clip(new ClipContext(center, muzzle, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, this)).getType() != HitResult.Type.MISS) return;
        TankShellEntity rocket = new TankShellEntity(T72Mod.TANK_SHELL.get(), this.level());
        rocket.setOwner(player);
        rocket.configureShell(this, 35, 2.2F, 0.005F);
        rocket.setPos(muzzle.x, muzzle.y, muzzle.z);
        rocket.shoot(direction.x, direction.y, direction.z, 2.1F, 0.0F);
        if (this.level().addFreshEntity(rocket)) {
            this.entityData.set(ROCKETS, this.rockets() - 1);
            this.rocketCooldown = 14;
            this.level().playSound(null, this.blockPosition(), VehicleSounds.ROCKET.get(), SoundSource.PLAYERS, 2, 1.0F);
        }
    }

    @Override
    public Vec3 partPosition(int part) {
        if (part >= FIRST_DECK_SECTION) return CABIN[part - FIRST_DECK_SECTION].position(this);
        return switch (part) {
            case MAIN_ROTOR -> AirframeLayout.world(this.position(), this.getYRot(), 0,
                    AirframeLayout.rotorY(this.model()) - .20, -.53);
            case TAIL_ROTOR -> AirframeLayout.world(this.position(), this.getYRot(), .12, 3.05, AirframeLayout.tailZ(this.model()));
            default -> AirframeLayout.world(this.position(), this.getYRot(), part == LEFT_POD ? -2.6 : 2.6, 1.2, -.6);
        };
    }

    @Override
    public AABB partBounds(int index, AABB fallback) {
        return index >= FIRST_DECK_SECTION ? CABIN[index - FIRST_DECK_SECTION].bounds(this) : fallback;
    }

    @Override
    public boolean partIsActive(int index) {
        if (index >= FIRST_DECK_SECTION) return this.isCabinOpen();
        return switch (index) {
            case MAIN_ROTOR -> this.rotorHealth() > 0;
            case TAIL_ROTOR -> this.tailHealth() > 0;
            default -> this.launcherHealth() > 0;
        };
    }

    @Override
    public boolean partIsSolid(int index) { return index >= FIRST_DECK_SECTION && this.isCabinOpen(); }

    @Override
    public InteractionResult interactPart(int index, Player player, InteractionHand hand) {
        if (index == COPILOT_SEAT && this.getFirstPassenger() == null && player.getItemInHand(hand).isEmpty())
            return InteractionResult.PASS;
        return index >= FIRST_DECK_SECTION ? this.mobInteract(player, hand) : InteractionResult.PASS;
    }

    @Override
    public boolean hurtPart(int index, DamageSource source, Vec3 impact, float amount) {
        if (index >= FIRST_DECK_SECTION) return this.hitAirframe(source, impact, amount);
        var module = switch (index) {
            case MAIN_ROTOR -> ROTOR;
            case TAIL_ROTOR -> TAIL;
            default -> LAUNCHER;
        };
        return this.damageModule(source, amount, module);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return this.hitAirframe(source, source.getSourcePosition(), amount);
    }

    public boolean hitAirframe(DamageSource source, Vec3 hit, float amount) {
        Vec3 relative = hit == null ? Vec3.ZERO : hit.subtract(this.position());
        double tailward = -relative.dot(Vec3.directionFromRotation(0, this.getYRot()));
        return this.damageModule(source, amount, tailward > 4.9 ? TAIL : relative.y > AirframeLayout.rotorY(this.model()) - 0.28 ? ROTOR : ENGINE);
    }

    private boolean damageModule(DamageSource source, float amount, EntityDataAccessor<Integer> module) {
        if (this.level().isClientSide || !this.isAlive() || amount <= 0 || !Float.isFinite(amount)) return false;
        boolean shellImpact = source.getDirectEntity() instanceof TankShellEntity;
        boolean explosion = source.is(DamageTypeTags.IS_EXPLOSION);
        if (explosion && source.getDirectEntity() instanceof TankShellEntity shell && shell.excludeFromBlast(this)) return false;
        float damage = source.is(T72Mod.TACZ_BULLETS) ? Math.min(amount, 40) * 0.55F : amount;
        if (shellImpact && !explosion) this.invulnerableTime = 0;
        boolean hit = super.hurt(source, damage);
        if (!hit || !this.isAlive() || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return hit;
        int previous = this.entityData.get(module);
        int moduleDamage = Mth.ceil(damage * (explosion ? 1.85F : 1.55F));
        this.entityData.set(module, Math.max(0, previous - moduleDamage));
        if (previous > 0 && this.entityData.get(module) == 0) {
            if (module == ENGINE || module == ROTOR) this.entityData.set(ENGINE_ON, false);
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.PLAYERS, 1.4F, 0.83F);
        }
        return true;
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide && this.hasChest()) {
            this.entityData.set(HAS_CHEST, false);
            Containers.dropContents(this.level(), this.blockPosition(), this.cargo);
            this.spawnAtLocation(Items.CHEST);
        }
        this.ejectPassengers();
        super.die(source);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Fuel", this.fuel());
        tag.putInt("Rotor", this.rotorHealth());
        tag.putInt("Tail", this.tailHealth());
        tag.putInt("Engine", this.engineHealth());
        tag.putInt("Launcher", this.launcherHealth());
        tag.putInt("Rockets", this.rockets());
        tag.putInt("CannonAmmo", this.cannonAmmo());
        tag.putBoolean("Chest", this.hasChest());
        ListTag contents = new ListTag();
        for (int slot = 0; slot < this.cargo.getContainerSize(); slot++) {
            ItemStack item = this.cargo.getItem(slot);
            if (item.isEmpty()) continue;
            CompoundTag entry = new CompoundTag();
            entry.putByte("Slot", (byte) slot);
            contents.add(item.save(entry));
        }
        tag.put("Cargo", contents);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(FUEL, Mth.clamp(tag.getInt("Fuel"), 0, this.model().fuelCapacity));
        if (tag.contains("Rotor")) this.entityData.set(ROTOR, Mth.clamp(tag.getInt("Rotor"), 0, MAX_PART_HEALTH));
        if (tag.contains("Tail")) this.entityData.set(TAIL, Mth.clamp(tag.getInt("Tail"), 0, MAX_PART_HEALTH));
        if (tag.contains("Engine")) this.entityData.set(ENGINE, Mth.clamp(tag.getInt("Engine"), 0, MAX_PART_HEALTH));
        if (tag.contains("Launcher")) this.entityData.set(LAUNCHER, Mth.clamp(tag.getInt("Launcher"), 0, MAX_PART_HEALTH));
        this.entityData.set(ROCKETS, Mth.clamp(tag.getInt("Rockets"), 0, this.model().armed ? MAX_ROCKETS : 0));
        this.entityData.set(CANNON_AMMO, Mth.clamp(tag.getInt("CannonAmmo"), 0, this.model().armed ? MAX_CANNON_AMMO : 0));
        this.entityData.set(HAS_CHEST, tag.getBoolean("Chest"));
        this.cargo.clearContent();
        for (Tag entry : tag.getList("Cargo", Tag.TAG_COMPOUND)) {
            CompoundTag item = (CompoundTag) entry;
            int slot = item.getByte("Slot") & 255;
            if (slot < this.cargo.getContainerSize()) this.cargo.setItem(slot, ItemStack.of(item));
        }
    }
}
