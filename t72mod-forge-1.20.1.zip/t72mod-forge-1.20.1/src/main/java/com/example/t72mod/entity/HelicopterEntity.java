package com.example.t72mod.entity;

import com.example.t72mod.T72Mod;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class HelicopterEntity extends PathfinderMob implements VehiclePartEntity.Parent {
    public static final int FORWARD = 1;
    public static final int BACK = 2;
    public static final int LEFT = 4;
    public static final int RIGHT = 8;
    public static final int ASCEND = 16;
    public static final int DESCEND = 32;
    public static final int YAW_LEFT = 64;
    public static final int YAW_RIGHT = 128;
    public static final int TOGGLE_ENGINE = 0;
    public static final int CARGO = 1;
    public static final int FIRE = 2;
    public static final int CANNON = 3;
    private static final int FIRST_DECK_SECTION = 4;
    private static final double DECK_HEIGHT = 1.35;
    private static final int MAIN_ROTOR = 0;
    private static final int TAIL_ROTOR = 1;
    private static final int LEFT_POD = 2;
    private static final int RIGHT_POD = 3;
    private static final EntityDimensions[] FLIGHT_PARTS = {
            EntityDimensions.fixed(1.75F, 0.50F), EntityDimensions.fixed(1.0F, 1.15F),
            EntityDimensions.fixed(0.78F, 0.55F), EntityDimensions.fixed(0.78F, 0.55F)
    };
    private static final EntityDimensions DECK = EntityDimensions.fixed(2.04F, 0.22F);
    private static final EntityDimensions[] TRANSPORT_PARTS = {
            FLIGHT_PARTS[0], FLIGHT_PARTS[1], null, null, DECK, DECK, DECK
    };
    private static final int MAX_PART_HEALTH = 100;
    private static final int MAX_ROCKETS = 12;
    private static final int MAX_CANNON_AMMO = 240;
    private static final int AMMO_PER_INGOT = 20;
    private static final int GUN_COOLDOWN_TICKS = 4;
    private static final EntityDataAccessor<Boolean> ENGINE_ON = boolData();
    private static final EntityDataAccessor<Boolean> HAS_CHEST = boolData();
    private static final EntityDataAccessor<Boolean> CABIN_OPEN = boolData();
    private static final EntityDataAccessor<Integer> FUEL = integerData();
    private static final EntityDataAccessor<Integer> ROTOR = integerData();
    private static final EntityDataAccessor<Integer> TAIL = integerData();
    private static final EntityDataAccessor<Integer> ENGINE = integerData();
    private static final EntityDataAccessor<Integer> ROCKETS = integerData();
    private static final EntityDataAccessor<Integer> CANNON_AMMO = integerData();
    private static final EntityDataAccessor<Integer> RPM = integerData();
    private static final EntityDataAccessor<Integer> LEAN = integerData();
    private static final EntityDataAccessor<Integer> LAUNCHER = integerData();

    private final SimpleContainer cargo = new SimpleContainer(27) {
        @Override
        public boolean stillValid(Player player) {
            return hasChest() && isAlive() && (hasPassenger(player)
                    || (onGround() && distanceToSqr(player) <= 36));
        }
    };
    private final VehiclePartEntity[] flightParts;
    private int flightInput;
    private int inputAge;
    private int fuelTicks;
    private int rocketCooldown;
    private int gunCooldown;
    private float rotorAngle;
    private float previousRotorAngle;

    public HelicopterEntity(EntityType<? extends HelicopterEntity> type, Level level) {
        super(type, level);
        this.flightParts = new VehiclePartEntity[this.model().armed ? FLIGHT_PARTS.length : TRANSPORT_PARTS.length];
        this.setNoAi(true);
        this.setNoGravity(true);
        this.blocksBuilding = true;
    }

    private static EntityDataAccessor<Boolean> boolData() {
        return SynchedEntityData.defineId(HelicopterEntity.class, EntityDataSerializers.BOOLEAN);
    }

    private static EntityDataAccessor<Integer> integerData() {
        return SynchedEntityData.defineId(HelicopterEntity.class, EntityDataSerializers.INT);
    }

    public static AttributeSupplier.Builder attributes(HelicopterType model) {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, model.hullHealth)
                .add(Attributes.ARMOR, model.armed ? 11 : 5).add(Attributes.KNOCKBACK_RESISTANCE, 1);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ENGINE_ON, false);
        this.entityData.define(HAS_CHEST, false);
        this.entityData.define(CABIN_OPEN, false);
        this.entityData.define(FUEL, 0);
        this.entityData.define(ROTOR, MAX_PART_HEALTH);
        this.entityData.define(TAIL, MAX_PART_HEALTH);
        this.entityData.define(ENGINE, MAX_PART_HEALTH);
        this.entityData.define(ROCKETS, 0);
        this.entityData.define(CANNON_AMMO, 0);
        this.entityData.define(RPM, 0);
        this.entityData.define(LEAN, 0);
        this.entityData.define(LAUNCHER, MAX_PART_HEALTH);
    }

    public HelicopterType model() {
        if (this.getType() == T72Mod.KA52.get()) return HelicopterType.KA52;
        return this.getType() == T72Mod.MI24.get() ? HelicopterType.MI24 : HelicopterType.MI8;
    }

    public void giveStarterFuel() {
        this.entityData.set(FUEL, this.model().fuelCapacity / 2);
        this.entityData.set(ROCKETS, this.model().armed ? 4 : 0);
        this.entityData.set(CANNON_AMMO, this.model().armed ? 80 : 0);
    }

    public boolean isCabinOpen() { return this.entityData.get(CABIN_OPEN); }
    public boolean hasChest() { return this.entityData.get(HAS_CHEST); }
    public boolean engineOn() { return this.entityData.get(ENGINE_ON); }
    public int fuel() { return this.entityData.get(FUEL); }
    public int rotorHealth() { return this.entityData.get(ROTOR); }
    public int tailHealth() { return this.entityData.get(TAIL); }
    public int engineHealth() { return this.entityData.get(ENGINE); }
    public int launcherHealth() { return this.entityData.get(LAUNCHER); }
    public int rockets() { return this.entityData.get(ROCKETS); }
    public int cannonAmmo() { return this.entityData.get(CANNON_AMMO); }
    public int rpm() { return this.entityData.get(RPM); }

    public float visualPitch() { return (byte) (this.entityData.get(LEAN) >> 8); }
    public float visualRoll() { return (byte) (int) this.entityData.get(LEAN); }

    public float rotorAngle(float partialTick) {
        return Mth.rotLerp(partialTick, this.previousRotorAngle, this.rotorAngle);
    }

    public boolean isPilot(Player player) {
        return this.isAlive() && this.getFirstPassenger() == player;
    }

    public void acceptInput(Player sender, int input) {
        if (this.isPilot(sender)) {
            this.flightInput = input & 255;
            this.inputAge = 0;
        }
    }

    public void handleAction(Player player, int command) {
        if (!this.isAlive() || !this.hasPassenger(player)) return;
        if (command == CARGO) {
            this.openCargo(player);
        } else if (this.isPilot(player)) {
            if (command == TOGGLE_ENGINE) {
                if (this.engineOn()) {
                    this.entityData.set(ENGINE_ON, false);
                } else if (this.fuel() > 0 && this.engineHealth() > 0 && this.rotorHealth() > 0) {
                    if (!this.secureCabin()) {
                        player.displayClientMessage(Component.translatable("message.t72mod.cabin_seats_needed"), true);
                        return;
                    }
                    this.entityData.set(CABIN_OPEN, false);
                    this.entityData.set(ENGINE_ON, true);
                    this.level().playSound(null, this.blockPosition(), SoundEvents.MINECART_RIDING,
                            SoundSource.NEUTRAL, 1, 0.65F);
                }
            } else if (command == FIRE) {
                this.fireRocket(player);
            } else if (command == CANNON) {
                this.fireCannon(player);
            }
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.isAlive() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!this.onGround()) return InteractionResult.FAIL;
        ItemStack held = player.getItemInHand(hand);
        int fuelValue = T72TankEntity.getFuelValue(held);
        if (held.is(Items.CHEST) && !this.hasChest()) {
            if (!this.level().isClientSide) {
                this.entityData.set(HAS_CHEST, true);
                this.consumeSupply(player, held);
                player.displayClientMessage(Component.translatable("message.t72mod.cargo_installed"), true);
            }
        } else if (fuelValue > 0 && this.fuel() < this.model().fuelCapacity) {
            if (!this.level().isClientSide) {
                this.entityData.set(FUEL, Math.min(this.model().fuelCapacity, this.fuel() + fuelValue));
                this.consumeSupply(player, held);
                this.level().playSound(null, this.blockPosition(), SoundEvents.BUCKET_FILL, SoundSource.PLAYERS, 1, 1);
            }
        } else if (held.is(T72Mod.REPAIR_KIT.get())
                && (this.getHealth() < this.getMaxHealth() || this.rotorHealth() < MAX_PART_HEALTH
                || this.tailHealth() < MAX_PART_HEALTH || this.engineHealth() < MAX_PART_HEALTH
                || this.launcherHealth() < MAX_PART_HEALTH)) {
            if (!this.level().isClientSide) {
                this.heal(55);
                this.entityData.set(ROTOR, MAX_PART_HEALTH);
                this.entityData.set(TAIL, MAX_PART_HEALTH);
                this.entityData.set(ENGINE, MAX_PART_HEALTH);
                this.entityData.set(LAUNCHER, MAX_PART_HEALTH);
                this.consumeSupply(player, held);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1, 1);
            }
        } else if (this.model().armed && held.is(T72Mod.AIR_ROCKET.get()) && this.rockets() < MAX_ROCKETS) {
            if (!this.level().isClientSide) {
                int loaded = Math.min(held.getCount(), MAX_ROCKETS - this.rockets());
                this.entityData.set(ROCKETS, this.rockets() + loaded);
                if (!player.getAbilities().instabuild) held.shrink(loaded);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, 1, 1);
            }
        } else if (this.model().armed && held.is(Items.IRON_INGOT) && this.cannonAmmo() < MAX_CANNON_AMMO) {
            if (!this.level().isClientSide) {
                this.entityData.set(CANNON_AMMO, Math.min(MAX_CANNON_AMMO, this.cannonAmmo() + AMMO_PER_INGOT));
                this.consumeSupply(player, held);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON,
                        SoundSource.PLAYERS, 0.8F, 1.2F);
            }
        } else if (player.isShiftKeyDown() && held.isEmpty() && this.isCabinOpen() && !this.insideCabin(player)) {
            if (this.level().isClientSide) return InteractionResult.SUCCESS;
            return this.enterCabin(player);
        } else if (player.isShiftKeyDown()) {
            if (!this.level().isClientSide) this.openCargo(player);
        } else if (this.getPassengers().size() < this.model().seats) {
            if (!this.level().isClientSide && !player.startRiding(this)) return InteractionResult.FAIL;
        } else {
            return InteractionResult.FAIL;
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    private void consumeSupply(Player player, ItemStack stack) {
        if (player.getAbilities().instabuild) return;
        boolean lava = stack.is(Items.LAVA_BUCKET);
        stack.shrink(1);
        if (lava) {
            ItemStack bucket = new ItemStack(Items.BUCKET);
            if (!player.addItem(bucket)) player.drop(bucket, false);
        }
    }

    private void openCargo(Player player) {
        if (!this.hasChest()) {
            player.displayClientMessage(Component.translatable("message.t72mod.cargo_missing"), true);
            return;
        }
        player.openMenu(new SimpleMenuProvider((id, inventory, owner) -> ChestMenu.threeRows(id, inventory, this.cargo),
                Component.translatable("menu.t72mod.helicopter_cargo")));
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return passenger instanceof Player && this.isAlive() && this.getPassengers().size() < this.model().seats;
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction move) {
        if (!this.hasPassenger(passenger)) return;
        int seat = this.getPassengers().indexOf(passenger);
        double forward = seat == 0 ? 1.50 : seat < 3 ? 0.0 : -1.15;
        double right = seat == 0 ? 0.0 : seat % 2 == 0 ? 0.80 : -0.80;
        float yaw = this.getYRot();
        Vec3 location = this.position().add(Vec3.directionFromRotation(0, yaw).scale(forward))
                .add(Vec3.directionFromRotation(0, yaw + 90).scale(right));
        move.accept(passenger, location.x, location.y + 0.85 + passenger.getMyRidingOffset(), location.z);
    }

    @Override
    protected void removePassenger(Entity passenger) {
        boolean wasPilot = this.getFirstPassenger() == passenger;
        super.removePassenger(passenger);
        if (wasPilot) {
            this.flightInput = 0;
            this.inputAge = 0;
        }
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        if (!this.onGround()) return this.position().add(0, -0.4, 0);
        for (float side : new float[]{90, -90, 180, 0}) {
            Vec3 location = this.position().add(Vec3.directionFromRotation(0, this.getYRot() + side).scale(2.9));
            if (this.level().noCollision(passenger, passenger.getBoundingBox().move(location.subtract(passenger.position())))) {
                return location;
            }
        }
        return this.position().add(0, this.getBbHeight(), 0);
    }

    @Override
    public boolean canBeCollidedWith() { return this.isAlive() && !this.isCabinOpen(); }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    public void travel(Vec3 ignored) {
        // Flight runs on the server. Client positions come from entity tracking.
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.isAlive()) return;
        if (this.level().isClientSide) {
            this.previousRotorAngle = this.rotorAngle;
            this.rotorAngle = Mth.wrapDegrees(this.rotorAngle + this.rpm() * 0.83F);
            if ((this.engineHealth() < 50 || this.rotorHealth() < 35) && this.tickCount % 4 == 0) {
                this.level().addParticle(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.9,
                        this.getZ(), 0, 0.08, 0);
            }
            return;
        }

        if (this.rocketCooldown > 0) this.rocketCooldown--;
        if (this.gunCooldown > 0) this.gunCooldown--;
        if (this.inputAge < 12) this.inputAge++;
        int input = this.inputAge < 12 && this.getFirstPassenger() instanceof Player ? this.flightInput : 0;
        if (this.fuel() == 0 || this.engineHealth() == 0 || this.rotorHealth() == 0 || this.isInWater()) this.entityData.set(ENGINE_ON, false);
        int rotorSpeed = this.rpm();
        int targetSpeed = this.engineOn() ? Math.min(100, Math.min(this.rotorHealth(), this.engineHealth()) + 15) : 0;
        rotorSpeed += Mth.clamp(targetSpeed - rotorSpeed, -3, 2);
        this.entityData.set(RPM, rotorSpeed);
        if (this.engineOn() && ++this.fuelTicks >= this.model().fuelInterval * (this.onGround() ? 2 : 1)) {
            this.fuelTicks = 0;
            this.entityData.set(FUEL, Math.max(0, this.fuel() - 1));
        }
        if (this.engineOn() && this.tickCount % 18 == 0) {
            this.level().playSound(null, this.blockPosition(), SoundEvents.MINECART_RIDING,
                    SoundSource.NEUTRAL, 0.65F, 0.55F + rotorSpeed / 230.0F);
        }
        this.fly(input, rotorSpeed);
        this.entityData.set(CABIN_OPEN, this.model() == HelicopterType.MI8 && this.onGround()
                && !this.engineOn() && this.getDeltaMovement().horizontalDistanceSqr() < 0.0025);
        if (this.isAlive()) VehiclePartEntity.updateParts(this, this.flightParts,
                this.model().armed ? FLIGHT_PARTS : TRANSPORT_PARTS);
    }

    private boolean insideCabin(Player player) {
        Vec3 local = player.position().subtract(this.position()).yRot(this.getYRot() * Mth.DEG_TO_RAD);
        return Math.abs(local.x) < 1.38 && Math.abs(local.z) < 2.04 && local.y > 0.9 && local.y < 3.6;
    }

    private InteractionResult enterCabin(Player player) {
        if (!this.isCabinOpen() || !player.isAlive() || player.isPassenger()) return InteractionResult.FAIL;
        Vec3 target = this.position().add(0, DECK_HEIGHT + 0.01, 0);
        if (!this.level().noCollision(player, player.getBoundingBox().move(target.subtract(player.position())))) {
            return InteractionResult.FAIL;
        }
        player.teleportTo(target.x, target.y, target.z);
        player.resetFallDistance();
        return InteractionResult.CONSUME;
    }

    private boolean secureCabin() {
        if (!this.isCabinOpen()) return true;
        var passengers = this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(0.5),
                player -> player.isAlive() && !player.isPassenger() && !player.isSpectator() && this.insideCabin(player));
        if (passengers.size() + this.getPassengers().size() > this.model().seats
                || passengers.stream().anyMatch(Player::isShiftKeyDown)) return false;
        for (Player passenger : passengers) {
            if (!passenger.startRiding(this, true)) return false;
        }
        return true;
    }

    private void fly(int input, int rotorSpeed) {
        Vec3 velocity = this.getDeltaMovement();
        boolean lifted = rotorSpeed >= 72;
        boolean controlled = lifted && this.engineOn() && this.getFirstPassenger() instanceof Player;
        int forward = controlled ? axis(input, FORWARD, BACK) : 0;
        int sideways = controlled ? axis(input, RIGHT, LEFT) : 0;
        int vertical = controlled ? axis(input, ASCEND, DESCEND) : 0;
        float authority = 0.42F + 0.58F * Math.min(this.engineHealth(), this.rotorHealth()) / 100.0F;
        if (lifted && !this.onGround() && this.tailHealth() == 0 && this.model() != HelicopterType.KA52) {
            this.setYRot(this.getYRot() + 5.5F);
        } else if (controlled && (this.tailHealth() > 0 || this.model() == HelicopterType.KA52)) {
            this.setYRot(this.getYRot() + axis(input, YAW_RIGHT, YAW_LEFT) * this.model().turnRate
                    * (0.45F + 0.55F * this.tailHealth() / 100.0F));
        }
        if (this.onGround() && vertical <= 0) {
            forward = 0;
            sideways = 0;
        }
        this.yBodyRot = this.getYRot();
        this.yHeadRot = this.getYRot();

        Vec3 desired = Vec3.directionFromRotation(0, this.getYRot()).scale(forward)
                .add(Vec3.directionFromRotation(0, this.getYRot() + 90).scale(sideways * 0.65));
        if (desired.lengthSqr() > 1) desired = desired.normalize();
        desired = desired.scale(this.model().speed * authority);
        double descent = !lifted ? Math.max(-0.88, velocity.y - 0.052) : controlled ? vertical * 0.28 * authority : -0.16;
        if (this.getY() >= this.level().getMaxBuildHeight() + 35 && descent > 0) descent = 0;
        double nextY = this.onGround() && descent <= 0 ? -0.04 : Mth.lerp(lifted ? 0.23 : 0.75, velocity.y, descent);

        Vec3 motion = new Vec3(Mth.lerp(0.12, velocity.x, desired.x), nextY, Mth.lerp(0.12, velocity.z, desired.z));
        this.move(MoverType.SELF, motion);
        this.setDeltaMovement(this.horizontalCollision ? 0 : motion.x, this.verticalCollision ? 0 : motion.y,
                this.horizontalCollision ? 0 : motion.z);
        this.entityData.set(LEAN, ((-forward * 9 & 255) << 8) | (-sideways * 12 & 255));
        if ((this.onGround() && motion.y < -0.44) || (this.horizontalCollision && motion.horizontalDistanceSqr() > 0.23)) {
            float impact = (float) (Math.abs(motion.y) * 45 + motion.horizontalDistance() * 26);
            this.hurt(this.damageSources().flyIntoWall(), impact);
        }
    }

    private static int axis(int flags, int positive, int negative) {
        return ((flags & positive) != 0 ? 1 : 0) - ((flags & negative) != 0 ? 1 : 0);
    }

    private void fireCannon(Player player) {
        if (!this.model().armed || this.launcherHealth() <= 0 || !this.engineOn()
                || this.rpm() < 65 || this.gunCooldown > 0 || this.cannonAmmo() <= 0) return;
        float yaw = this.getYRot() + Mth.clamp(Mth.wrapDegrees(player.getYRot() - this.getYRot()), -20, 20);
        Vec3 direction = Vec3.directionFromRotation(Mth.clamp(player.getXRot(), -12, 35), yaw);
        Vec3 center = this.position().add(0, 1.45, 0);
        Vec3 muzzle = center.add(direction.scale(2.8));
        if (this.level().clip(new ClipContext(center, muzzle, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, this)).getType() != HitResult.Type.MISS) return;
        TankShellEntity round = new TankShellEntity(T72Mod.TANK_SHELL.get(), this.level());
        round.setOwner(player);
        round.configureShell(this, 8, 0.0F, 0.001F);
        round.setPos(muzzle.x, muzzle.y, muzzle.z);
        round.shoot(direction.x, direction.y, direction.z, 3.4F, 0.0F);
        if (this.level().addFreshEntity(round)) {
            this.gunCooldown = GUN_COOLDOWN_TICKS;
            this.entityData.set(CANNON_AMMO, this.cannonAmmo() - 1);
            this.level().playSound(null, this.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH,
                    SoundSource.PLAYERS, 1.2F, 1.55F);
        }
    }

    private void fireRocket(Player player) {
        if (this.model().armed && this.launcherHealth() == 0) {
            player.displayClientMessage(Component.translatable("message.t72mod.launcher_broken"), true);
            return;
        }
        if (!this.model().armed || this.onGround() || this.rpm() < 72 || this.rocketCooldown > 0 || this.rockets() == 0) return;
        Vec3 direction = Vec3.directionFromRotation(3, this.getYRot());
        Vec3 center = this.position().add(0, 1.15, 0);
        Vec3 muzzle = center.add(direction.scale(2.2));
        if (this.level().clip(new ClipContext(center, muzzle, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, this)).getType() != HitResult.Type.MISS) return;
        TankShellEntity rocket = new TankShellEntity(T72Mod.TANK_SHELL.get(), this.level());
        rocket.setOwner(player);
        rocket.configureShell(this, 35, 2.2F, 0.005F);
        rocket.setPos(muzzle.x, muzzle.y, muzzle.z);
        rocket.shoot(direction.x, direction.y, direction.z, 2.1F, 0.0F);
        if (this.level().addFreshEntity(rocket)) {
            this.entityData.set(ROCKETS, this.rockets() - 1);
            this.rocketCooldown = 14;
            this.level().playSound(null, this.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 2, 0.8F);
        }
    }

    @Override
    public Vec3 partPosition(int part) {
        Vec3 forward = Vec3.directionFromRotation(0, this.getYRot());
        if (part >= FIRST_DECK_SECTION) {
            return this.position().add(forward.scale((part - FIRST_DECK_SECTION - 1) * 1.02))
                    .add(0, DECK_HEIGHT - DECK.height, 0);
        }
        return switch (part) {
            case MAIN_ROTOR -> this.position().add(forward.scale(-0.67))
                    .add(0, this.model() == HelicopterType.MI8 ? 4.06 : 3.47, 0);
            case TAIL_ROTOR -> this.position().add(forward.scale(this.model() == HelicopterType.KA52 ? -4.25 : -5.36)).add(0, 2.3, 0);
            default -> this.position().add(Vec3.directionFromRotation(0, this.getYRot() + 90)
                    .scale(part == LEFT_POD ? -1.75 : 1.75)).add(0, 0.38, 0);
        };
    }

    @Override
    public boolean partIsActive(int index) {
        if (index >= FIRST_DECK_SECTION) return this.isCabinOpen();
        return switch (index) {
            case MAIN_ROTOR -> this.rotorHealth() > 0;
            case TAIL_ROTOR -> this.tailHealth() > 0;
            default -> this.launcherHealth() > 0;
        };
    }

    @Override
    public boolean partIsSolid(int index) { return index >= FIRST_DECK_SECTION && this.isCabinOpen(); }

    @Override
    public InteractionResult interactPart(int index, Player player, InteractionHand hand) {
        return index >= FIRST_DECK_SECTION ? this.mobInteract(player, hand) : InteractionResult.PASS;
    }

    @Override
    public boolean hurtPart(int index, DamageSource source, Vec3 impact, float amount) {
        if (index >= FIRST_DECK_SECTION) return this.hitAirframe(source, impact, amount);
        var module = switch (index) {
            case MAIN_ROTOR -> ROTOR;
            case TAIL_ROTOR -> TAIL;
            default -> LAUNCHER;
        };
        return this.damageModule(source, amount, module);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return this.hitAirframe(source, source.getSourcePosition(), amount);
    }

    public boolean hitAirframe(DamageSource source, Vec3 hit, float amount) {
        Vec3 relative = hit == null ? Vec3.ZERO : hit.subtract(this.position());
        double tailward = -relative.dot(Vec3.directionFromRotation(0, this.getYRot()));
        return this.damageModule(source, amount, tailward > 1.12 ? TAIL : relative.y > 1.65 ? ROTOR : ENGINE);
    }

    private boolean damageModule(DamageSource source, float amount, EntityDataAccessor<Integer> module) {
        if (this.level().isClientSide || !this.isAlive() || amount <= 0 || !Float.isFinite(amount)) return false;
        boolean shellImpact = source.getDirectEntity() instanceof TankShellEntity;
        boolean explosion = source.is(DamageTypeTags.IS_EXPLOSION);
        if (explosion && source.getDirectEntity() instanceof TankShellEntity shell && shell.excludeFromBlast(this)) return false;
        float damage = source.is(T72Mod.TACZ_BULLETS) ? Math.min(amount, 40) * 0.55F : amount;
        if (shellImpact && !explosion) this.invulnerableTime = 0;
        boolean hit = super.hurt(source, damage);
        if (!hit || !this.isAlive() || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return hit;
        int previous = this.entityData.get(module);
        int moduleDamage = Mth.ceil(damage * (explosion ? 1.85F : 1.55F));
        this.entityData.set(module, Math.max(0, previous - moduleDamage));
        if (previous > 0 && this.entityData.get(module) == 0) {
            if (module == ENGINE || module == ROTOR) this.entityData.set(ENGINE_ON, false);
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.PLAYERS, 1.4F, 0.83F);
        }
        return true;
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide && this.hasChest()) {
            this.entityData.set(HAS_CHEST, false);
            Containers.dropContents(this.level(), this.blockPosition(), this.cargo);
            this.spawnAtLocation(Items.CHEST);
        }
        this.ejectPassengers();
        super.die(source);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Fuel", this.fuel());
        tag.putInt("Rotor", this.rotorHealth());
        tag.putInt("Tail", this.tailHealth());
        tag.putInt("Engine", this.engineHealth());
        tag.putInt("Launcher", this.launcherHealth());
        tag.putInt("Rockets", this.rockets());
        tag.putInt("CannonAmmo", this.cannonAmmo());
        tag.putBoolean("Chest", this.hasChest());
        ListTag contents = new ListTag();
        for (int slot = 0; slot < this.cargo.getContainerSize(); slot++) {
            ItemStack item = this.cargo.getItem(slot);
            if (item.isEmpty()) continue;
            CompoundTag entry = new CompoundTag();
            entry.putByte("Slot", (byte) slot);
            contents.add(item.save(entry));
        }
        tag.put("Cargo", contents);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(FUEL, Mth.clamp(tag.getInt("Fuel"), 0, this.model().fuelCapacity));
        if (tag.contains("Rotor")) this.entityData.set(ROTOR, Mth.clamp(tag.getInt("Rotor"), 0, MAX_PART_HEALTH));
        if (tag.contains("Tail")) this.entityData.set(TAIL, Mth.clamp(tag.getInt("Tail"), 0, MAX_PART_HEALTH));
        if (tag.contains("Engine")) this.entityData.set(ENGINE, Mth.clamp(tag.getInt("Engine"), 0, MAX_PART_HEALTH));
        if (tag.contains("Launcher")) this.entityData.set(LAUNCHER, Mth.clamp(tag.getInt("Launcher"), 0, MAX_PART_HEALTH));
        this.entityData.set(ROCKETS, Mth.clamp(tag.getInt("Rockets"), 0, this.model().armed ? MAX_ROCKETS : 0));
        this.entityData.set(CANNON_AMMO, Mth.clamp(tag.getInt("CannonAmmo"), 0, this.model().armed ? MAX_CANNON_AMMO : 0));
        this.entityData.set(HAS_CHEST, tag.getBoolean("Chest"));
        this.cargo.clearContent();
        for (Tag entry : tag.getList("Cargo", Tag.TAG_COMPOUND)) {
            CompoundTag item = (CompoundTag) entry;
            int slot = item.getByte("Slot") & 255;
            if (slot < this.cargo.getContainerSize()) this.cargo.setItem(slot, ItemStack.of(item));
        }
    }
}
