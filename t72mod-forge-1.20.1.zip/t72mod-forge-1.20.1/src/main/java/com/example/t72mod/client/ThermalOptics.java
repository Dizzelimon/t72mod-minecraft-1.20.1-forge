package com.example.t72mod.client;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.FpvDroneEntity;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.T72TankEntity;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

import java.util.List;

@Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ThermalOptics {
    private static final KeyMapping THERMAL = new KeyMapping("key.t72mod.thermal", GLFW.GLFW_KEY_O,
            "key.categories.t72mod.flight");
    private static Entity optics;
    private static boolean on;
    private static List<LivingEntity> heat = List.of();

    private ThermalOptics() {}

    @Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Keys {
        @SubscribeEvent public static void register(RegisterKeyMappingsEvent event) { event.register(THERMAL); }
    }

    private static Entity available(Minecraft client) {
        if (client.player == null || client.level == null) return null;
        FpvDroneEntity drone = FpvClient.current();
        if (drone != null && drone.battery() > 80) return drone;
        Entity seat = client.player.getVehicle();
        if (seat instanceof T72TankEntity tank && tank.weaponOperator() == client.player
                && tank.getTurretHealth() > 15 && tank.engineRunning()) return tank;
        if (seat instanceof HelicopterEntity air && air.isPilot(client.player)
                && air.engineOn() && air.engineHealth() > 20) return air;
        return null;
    }

    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        var game = Minecraft.getInstance();
        Entity device = available(game);
        if (device != optics) {
            optics = device;
            on = false;
            heat = List.of();
        }
        if (THERMAL.consumeClick() && optics != null && game.screen == null) {
            on = !on;
            if (!on) heat = List.of();
        }
        if (!on || game.player == null || game.player.tickCount % 4 != 0) return;
        Vec3 view = game.gameRenderer.getMainCamera().getPosition();
        AABB area = new AABB(view, view).inflate(60, 42, 60);
        Vec3 gaze = Vec3.directionFromRotation(game.gameRenderer.getMainCamera().getXRot(),
                game.gameRenderer.getMainCamera().getYRot());
        heat = game.level.getEntitiesOfClass(LivingEntity.class, area, target -> {
            if (target == game.player || target == optics || !target.isAlive() || target.isSpectator()
                    || target.getVehicle() == optics) return false;
            Vec3 center = target.getBoundingBox().getCenter();
            if (center.subtract(view).dot(gaze) < .1 || center.distanceToSqr(view) > 60 * 60) return false;
            return game.level.clip(new ClipContext(view, center, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE,
                    game.getCameraEntity())).getType() == HitResult.Type.MISS;
        });
    }

    @SubscribeEvent public static void contours(RenderLevelStageEvent event) {
        if (!on || heat.isEmpty() || event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        var game = Minecraft.getInstance();
        Vec3 camera = event.getCamera().getPosition();
        var buffers = game.renderBuffers().bufferSource();
        var out = buffers.getBuffer(RenderType.lines());
        for (LivingEntity target : heat) {
            if (!target.isAlive() || target.isRemoved()) continue;
            AABB outline = target.getBoundingBox().move(target.getPosition(event.getPartialTick()).subtract(target.position()))
                    .move(-camera.x, -camera.y, -camera.z).inflate(.025);
            boolean allied = game.player != null && game.player.isAlliedTo(target);
            LevelRenderer.renderLineBox(event.getPoseStack(), out, outline, allied ? .53F : 1F,
                    allied ? .92F : .68F, allied ? .84F : .24F, .78F);
        }
        buffers.endBatch(RenderType.lines());
    }

    @SubscribeEvent public static void overlay(RenderGuiOverlayEvent.Post event) {
        if (!on || !event.getOverlay().id().equals(VanillaGuiOverlay.CROSSHAIR.id())) return;
        var graphics = event.getGuiGraphics();
        int w = graphics.guiWidth(), h = graphics.guiHeight();
        graphics.fill(0, 0, w, h, 0x333A5240);
        graphics.drawString(Minecraft.getInstance().font, Component.translatable("hud.t72mod.thermal"),
                8, h - 64, 0xFFE4F4BE);
    }
}
