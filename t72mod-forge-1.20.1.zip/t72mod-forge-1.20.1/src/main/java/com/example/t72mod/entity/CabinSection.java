package com.example.t72mod.entity;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Parked vehicle geometry in block units. Split long walls into small pieces at doorways. */
public record CabinSection(double x, double y, double z, double width, double height, double length) {
    public EntityDimensions dimensions() {
        return EntityDimensions.fixed((float) Math.max(width,length), (float) height);
    }

    public Vec3 position(Entity vehicle) {
        return AirframeLayout.world(vehicle.position(), vehicle.getYRot(), x, y, z);
    }

    public AABB bounds(Entity vehicle) {
        Vec3 center = this.position(vehicle);
        double yaw = Math.toRadians(vehicle.getYRot());
        double dx = (Math.abs(Math.cos(yaw)) * width + Math.abs(Math.sin(yaw)) * length) * 0.5;
        double dz = (Math.abs(Math.sin(yaw)) * width + Math.abs(Math.cos(yaw)) * length) * 0.5;
        return new AABB(center.x - dx, center.y, center.z - dz, center.x + dx, center.y + height, center.z + dz);
    }
}
