package com.example.t72mod.entity;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Parked vehicle geometry in block units. Split long walls into small pieces at doorways. */
public record CabinSection(double x, double y, double z, double width, double height, double length) {
    public static void wall(java.util.List<CabinSection> out, double x, double y, double minZ, double maxZ, double height) {
        if (maxZ <= minZ) return;
        int count = (int) Math.ceil((maxZ-minZ)/.44);
        double length = (maxZ-minZ)/count;
        for (int i = 0; i < count; i++)
            out.add(new CabinSection(x,y,minZ+(i+.5)*length,.16,height,length+.015));
    }

    public static void crossWall(java.util.List<CabinSection> out, double z, double y, double halfWidth, double height) {
        int count = (int) Math.ceil(halfWidth*2/.48);
        double width = halfWidth*2/count;
        for (int i = 0; i < count; i++)
            out.add(new CabinSection(-halfWidth+(i+.5)*width,y,z,width+.015,height,.14));
    }

    public EntityDimensions dimensions() {
        return EntityDimensions.fixed((float) Math.max(width,length), (float) height);
    }

    public Vec3 position(Entity vehicle) {
        return AirframeLayout.world(vehicle.position(), vehicle.getYRot(), x, y, z);
    }

    public AABB bounds(Entity vehicle) {
        return this.bounds(vehicle.position(),vehicle.getYRot());
    }

    public AABB bounds(Vec3 origin,float heading) {
        Vec3 center = AirframeLayout.world(origin, heading,x,y,z);
        double yaw = Math.toRadians(heading);
        double dx = (Math.abs(Math.cos(yaw)) * width + Math.abs(Math.sin(yaw)) * length) * 0.5;
        double dz = (Math.abs(Math.sin(yaw)) * width + Math.abs(Math.cos(yaw)) * length) * 0.5;
        return new AABB(center.x - dx, center.y, center.z - dz, center.x + dx, center.y + height, center.z + dz);
    }
}
