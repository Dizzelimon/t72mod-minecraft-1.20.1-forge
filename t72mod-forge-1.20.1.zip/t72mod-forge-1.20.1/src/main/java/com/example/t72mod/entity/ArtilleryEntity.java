package com.example.t72mod.entity;

import com.example.t72mod.T72Mod;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.world.entity.MoverType;
import com.example.t72mod.config.T72ServerConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class ArtilleryEntity extends PathfinderMob implements VehiclePartEntity.Parent {
    public static final int MIN_RANGE = ArtilleryBallistics.MIN_RANGE;
    public static final int DEFAULT_MAX_RANGE = ArtilleryBallistics.DEFAULT_MAX_RANGE;
    private static final int CAPACITY = 24;
    private static final int FULL_HEALTH = 100;
    private static final float GRAVITY = ArtilleryBallistics.GRAVITY;

    private static final int PART_WHEEL_R = 0;
    private static final int PART_WHEEL_L = 1;
    private static final int PART_TRAIL_R = 2;
    private static final int PART_TRAIL_L = 3;
    private static final int PART_SPADE_R = 4;
    private static final int PART_SPADE_L = 5;
    private static final int PART_BARREL_START = 6;
    private static final double[] BARREL_DISTANCES = {0.85D, 1.65D, 2.45D, 3.20D};

    private static final EntityDimensions[] PART_DIMENSIONS = {
            EntityDimensions.fixed(0.56F, 1.12F),
            EntityDimensions.fixed(0.56F, 1.12F),
            EntityDimensions.fixed(0.62F, 0.56F),
            EntityDimensions.fixed(0.62F, 0.56F),
            EntityDimensions.fixed(0.68F, 0.45F),
            EntityDimensions.fixed(0.68F, 0.45F),
            EntityDimensions.fixed(0.48F, 0.42F),
            EntityDimensions.fixed(0.44F, 0.38F),
            EntityDimensions.fixed(0.40F, 0.36F),
            EntityDimensions.fixed(0.46F, 0.40F)
    };

    private static final EntityDataAccessor<Integer> GUN = data();
    private static final EntityDataAccessor<Integer> TRAVERSE = data();
    private static final EntityDataAccessor<Integer> AMMO = data();
    private static final EntityDataAccessor<Integer> RELOAD = data();
    private static final EntityDataAccessor<Integer> ELEVATION = data();
    private static final EntityDataAccessor<Integer> RECOIL = data();
    private static final EntityDataAccessor<Integer> TOW_ENTITY_ID = data();

    private static final EntityDataAccessor<Optional<UUID>> TOW_VEHICLE = SynchedEntityData.defineId(
            ArtilleryEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private final VehiclePart[] subParts;
    private Vec3 partOrigin;
    private float partHeading;
    private int partElevation;
    private float renderedYaw;
    private float previousRenderedYaw;
    private float renderedElevation;
    private float previousRenderedElevation;
    private boolean renderAimInitialized;

    private static EntityDataAccessor<Integer> data() {
        return SynchedEntityData.defineId(ArtilleryEntity.class, EntityDataSerializers.INT);
    }

    public ArtilleryEntity(EntityType<? extends ArtilleryEntity> type, Level level) {
        super(type, level);
        this.setNoAi(true);
        this.setMaxUpStep(.85F);
        this.blocksBuilding = true;
        this.subParts=VehiclePart.create(this,PART_DIMENSIONS);
        this.setId(ENTITY_COUNTER.getAndAdd(this.subParts.length+1)+1);
        this.updatePartPositions();
    }

    public Optional<UUID> towVehicle() { return this.entityData.get(TOW_VEHICLE); }
    public int towVehicleId() { return this.entityData.get(TOW_ENTITY_ID); }

    void attachToTowVehicle(Entity vehicle) {
        this.setTowVehicle(vehicle.getUUID());
        this.entityData.set(TOW_ENTITY_ID, vehicle.getId());
    }

    public void setTowVehicle(@javax.annotation.Nullable UUID id) {
        this.entityData.set(TOW_VEHICLE, Optional.ofNullable(id));
        if (id == null) this.entityData.set(TOW_ENTITY_ID, -1);
        else this.entityData.set(ELEVATION, 5);
    }

    public void unhitch() {
        if (!(this.level() instanceof ServerLevel server)) return;
        UUID id = this.towVehicle().orElse(null);
        if (id != null && server.getEntity(id) instanceof ArtilleryTowVehicle tow
                && tow.towedGun().filter(this.getUUID()::equals).isPresent()) tow.uncouple();
        else this.setTowVehicle(null);
    }

    private void followTowVehicle() {
        if (!(this.level() instanceof ServerLevel server) || this.towVehicle().isEmpty()) return;
        Entity entity = server.getEntity(this.towVehicle().get());
        if (entity == null) return;
        if (!(entity instanceof ArtilleryTowVehicle tow) || !entity.isAlive()
                || tow.towedGun().filter(this.getUUID()::equals).isEmpty()) {
            this.setTowVehicle(null);
            return;
        }
        this.entityData.set(TOW_ENTITY_ID, entity.getId());
        Vec3 hitch = tow.rearHitch();
        Vec3 toward = hitch.subtract(this.position()).multiply(1, 0, 1);
        double distance = toward.length();
        if (distance > 15) { tow.uncouple(); return; }
        if (distance < 1.0E-4) return;
        double move = Mth.clamp(distance - 3.45, -.35, .68);
        if (Math.abs(move) > .035) this.move(MoverType.SELF, toward.scale(move / distance));
        float heading = ArtilleryBallistics.yawTo(hitch.x, hitch.z, this.getX(), this.getZ());
        this.setYRot(Mth.approachDegrees(this.getYRot(), heading, 24));
    }

    @Override public boolean isMultipartEntity() { return true; }
    @Override public VehiclePart[] getParts() { return this.subParts; }
    @Override public void setId(int id) {
        super.setId(id);
        VehiclePart.assignIds(this.subParts,id);
    }

    private void updatePartPositions() {
        if (this.position().equals(this.partOrigin) && this.getYRot()==this.partHeading
                && this.elevation()==this.partElevation) return;
        this.partOrigin=this.position();
        this.partHeading=this.getYRot();
        this.partElevation=this.elevation();
        for (VehiclePart part : this.subParts) part.syncBox();
    }

    public static int maxRange() {
        return T72ServerConfig.artilleryMaxRange();
    }

    public static AttributeSupplier.Builder attributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 160)
                .add(Attributes.ARMOR, 7).add(Attributes.KNOCKBACK_RESISTANCE, 1);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(GUN, FULL_HEALTH);
        this.entityData.define(TRAVERSE, FULL_HEALTH);
        this.entityData.define(AMMO, 0);
        this.entityData.define(RELOAD, 0);
        this.entityData.define(ELEVATION, 37);
        this.entityData.define(RECOIL, 0);
        this.entityData.define(TOW_VEHICLE, Optional.empty());
        this.entityData.define(TOW_ENTITY_ID, -1);
    }

    public int gunHealth() { return this.entityData.get(GUN); }
    public int traverseHealth() { return this.entityData.get(TRAVERSE); }
    public int ammunition() { return this.entityData.get(AMMO); }
    public int reloadTicks() { return this.entityData.get(RELOAD); }
    public int elevation() { return this.entityData.get(ELEVATION); }
    public int recoilTicks() { return this.entityData.get(RECOIL); }

    public void loadStarterAmmo() { this.entityData.set(AMMO, 3); }

    public float renderYaw(float partialTick) {
        return this.renderAimInitialized
                ? Mth.rotLerp(partialTick, this.previousRenderedYaw, this.renderedYaw)
                : Mth.rotLerp(partialTick, this.yRotO, this.getYRot());
    }

    public float renderElevation(float partialTick) {
        return this.renderAimInitialized
                ? Mth.lerp(partialTick, this.previousRenderedElevation, this.renderedElevation)
                : this.elevation();
    }

    private void sampleRenderAim() {
        if (!this.renderAimInitialized) {
            this.renderedYaw = this.getYRot();
            this.renderedElevation = this.elevation();
            this.renderAimInitialized = true;
        }
        this.previousRenderedYaw = this.renderedYaw;
        this.previousRenderedElevation = this.renderedElevation;
        float deltaYaw = Mth.wrapDegrees(this.getYRot() - this.renderedYaw);
        this.renderedYaw = Mth.wrapDegrees(this.renderedYaw + Mth.clamp(deltaYaw, -18.0F, 18.0F));
        this.renderedElevation = Mth.approach(this.renderedElevation, this.elevation(), 6.0F);
    }

    @Override
    protected boolean canAddPassenger(Entity rider) {
        return rider instanceof Player && this.isAlive() && this.towVehicle().isEmpty() && this.getPassengers().isEmpty();
    }

    @Override
    public double getPassengersRidingOffset() { return 0.72D; }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction move) {
        Vec3 seatPos = AirframeLayout.world(this.position(), this.getYRot(),
                -0.51D, 0.72D + passenger.getMyRidingOffset(), -0.74D);
        move.accept(passenger, seatPos.x, seatPos.y, seatPos.z);
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        for (float angle : new float[]{90.0F, -90.0F, 0.0F, 180.0F}) {
            double dist = angle == 180.0F ? 3.25D : 2.35D;
            Vec3 pos = this.position().add(Vec3.directionFromRotation(0.0F, this.getYRot() + angle).scale(dist));
            if (this.level().noCollision(passenger, passenger.getBoundingBox().move(pos.subtract(passenger.position())))) {
                return pos;
            }
        }
        return this.position().add(0.0D, 1.85D, 0.0D);
    }

    @Override
    public boolean canBeCollidedWith() { return this.isAlive(); }

    @Override
    public boolean canCollideWith(Entity other) {
        if (other instanceof VehiclePart part && part.getParent() == this) return false;
        return super.canCollideWith(other);
    }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    public void travel(Vec3 ignored) { super.travel(Vec3.ZERO); }

    @Override
    public void tick() {
        super.tick();
        this.yBodyRot = this.getYRot();
        this.yBodyRotO = this.yRotO;
        this.yHeadRot = this.getYRot();
        this.yHeadRotO = this.yRotO;

        if (this.level().isClientSide) {
            this.sampleRenderAim();
            if (this.isAlive() && this.gunHealth() == 0 && this.tickCount % 5 == 0) {
                this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY() + 1.35D, this.getZ(), 0, 0.06, 0);
            }
        } else {
            if (this.reloadTicks() > 0) this.entityData.set(RELOAD, this.reloadTicks() - 1);
            if (this.recoilTicks() > 0) this.entityData.set(RECOIL, this.recoilTicks() - 1);
            this.followTowVehicle();
        }
        if (this.isAlive()) this.updatePartPositions();
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.isAlive() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        ItemStack item = player.getItemInHand(hand);
        if (item.is(T72Mod.ARTILLERY_SHELL.get()) && this.ammunition() < CAPACITY) {
            if (!this.level().isClientSide) {
                int loaded = Math.min(CAPACITY - this.ammunition(), item.getCount());
                this.entityData.set(AMMO, this.ammunition() + loaded);
                if (!player.getAbilities().instabuild) item.shrink(loaded);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, 1, 1);
                this.notice(player, "artillery_loaded");
            }
        } else if (item.is(T72Mod.REPAIR_KIT.get()) && (this.getHealth() < this.getMaxHealth()
                || this.gunHealth() < FULL_HEALTH || this.traverseHealth() < FULL_HEALTH)) {
            if (!this.level().isClientSide) {
                this.heal(65);
                this.entityData.set(GUN, FULL_HEALTH);
                this.entityData.set(TRAVERSE, FULL_HEALTH);
                if (!player.getAbilities().instabuild) item.shrink(1);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1, 1);
            }
        } else if (this.isEmplaced() && !this.isVehicle()) {
            if (!this.level().isClientSide) {
                if (!player.startRiding(this)) return InteractionResult.FAIL;
                this.notice(player, "artillery_map_hint");
            }
        } else {
            return InteractionResult.PASS;
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    private boolean isEmplaced() {
        return this.towVehicle().isEmpty() && this.hasGroundSupport();
    }

    public boolean hasGroundSupport() {
        if (this.onGround()) return true;
        AABB hull = this.getBoundingBox();
        AABB groundCheck = new AABB(hull.minX + 0.10, hull.minY - 0.08, hull.minZ + 0.10,
                hull.maxX - 0.10, hull.minY, hull.maxZ - 0.10);
        return this.level().getBlockCollisions(this, groundCheck).iterator().hasNext();
    }

    public void aimAt(Player operator, int x, int z) {
        if (!(this.level() instanceof ServerLevel level) || !this.isAlive() || !this.isEmplaced()
                || this.getFirstPassenger() != operator) {
            return;
        }
        if (this.gunHealth() == 0 || this.traverseHealth() == 0) return;

        Vec3 pivot = this.position().add(0, ArtilleryBallistics.PIVOT_Y_OFFSET, 0);
        double targetY = level.isLoaded(new BlockPos(x, 0, z))
                ? level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z)
                : this.getY();
        ArtilleryBallistics.Solution solution = ArtilleryBallistics.solve(pivot, x + 0.5D, targetY, z + 0.5D);
        this.setYRot(solution.yawDeg());
        this.yBodyRot = solution.yawDeg();
        this.yHeadRot = solution.yawDeg();
        this.entityData.set(ELEVATION, solution.elevationDeg());
    }

    public boolean shootAt(Player operator, int x, int z) {
        if (!(this.level() instanceof ServerLevel level) || !this.isAlive() || !this.isEmplaced()
                || this.getFirstPassenger() != operator || this.reloadTicks() > 0) return false;
        if (this.gunHealth() == 0 || this.traverseHealth() == 0) {
            this.notice(operator, "artillery_broken");
            return false;
        }
        if (this.ammunition() == 0 && !operator.getAbilities().instabuild) {
            this.notice(operator, "artillery_empty");
            return false;
        }

        double dx = x + 0.5D - this.getX();
        double dz = z + 0.5D - this.getZ();
        double range = Math.hypot(dx, dz);
        int allowedMax = maxRange();
        if (!ArtilleryBallistics.isRangeAllowed(range, allowedMax)) {
            operator.displayClientMessage(Component.translatable("message.t72mod.artillery_out_of_range",
                    Mth.floor(range + 0.5D), MIN_RANGE, allowedMax), true);
            return false;
        }

        if (!canSimulatePath(level, this.getX(), this.getZ(), x, z)) {
            this.notice(operator, "artillery_unloaded");
            return false;
        }

        Vec3 pivot = this.position().add(0, ArtilleryBallistics.PIVOT_Y_OFFSET, 0);
        int groundHeight = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        ArtilleryBallistics.Solution selected = ArtilleryBallistics.solve(pivot, x + .5, groundHeight, z + .5);
        if (ArtilleryBallistics.dispersionRadius(range) >= .5) {
            for (int attempt = 0; attempt < 5; attempt++) {
                var impact = ArtilleryBallistics.dispersedTarget(x, z, range, this.random);
                int impactX = impact.blockX();
                int impactZ = impact.blockZ();
                if (!canSimulatePath(level, this.getX(), this.getZ(), impactX, impactZ)) continue;
                int impactY = level.getHeight(Heightmap.Types.MOTION_BLOCKING, impactX, impactZ);
                var spread = ArtilleryBallistics.solve(pivot, impactX + .5, impactY, impactZ + .5);
                if (spread.valid()) {
                    selected = spread;
                    break;
                }
            }
        }
        ArtilleryBallistics.Solution solution = selected;
        if (!solution.valid()) {
            operator.displayClientMessage(Component.translatable("message.t72mod.artillery_out_of_range",
                    Mth.floor(range + 0.5D), MIN_RANGE, allowedMax), true);
            return false;
        }

        Vec3 aim = solution.velocity().normalize();
        Vec3 muzzleEnd = pivot.add(aim.scale(ArtilleryBallistics.MUZZLE_LENGTH));
        if (level.clip(new ClipContext(pivot, muzzleEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this))
                .getType() != HitResult.Type.MISS) {
            this.notice(operator, "artillery_blocked");
            return false;
        }

        TankShellEntity shell = T72Mod.TANK_SHELL.get().create(level);
        if (shell == null) return false;
        shell.setOwner(operator);
        shell.configureShell(this, 150, 4.8F, GRAVITY);
        shell.setPos(pivot);
        shell.setDeltaMovement(solution.velocity());
        if (!level.addFreshEntity(shell)) return false;

        if (!operator.getAbilities().instabuild) {
            this.entityData.set(AMMO, this.ammunition() - 1);
        }
        this.entityData.set(RELOAD, 95);
        this.entityData.set(RECOIL, 14);
        this.setYRot(solution.yawDeg());
        this.yBodyRot = solution.yawDeg();
        this.yHeadRot = solution.yawDeg();
        this.entityData.set(ELEVATION, solution.elevationDeg());

        level.sendParticles(ParticleTypes.FLASH, muzzleEnd.x, muzzleEnd.y, muzzleEnd.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, muzzleEnd.x, muzzleEnd.y, muzzleEnd.z, 9, 0.15, 0.15, 0.15, 0.01);
        level.playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 3.2F, 1.0F);
        return true;
    }

    public static boolean canSimulatePath(ServerLevel level, double startX, double startZ, int targetX, int targetZ) {
        BlockPos targetPos = new BlockPos(targetX, 0, targetZ);
        if (!level.isLoaded(targetPos) || !level.isPositionEntityTicking(targetPos)) {
            return false;
        }
        for (ArtilleryBallistics.SamplePoint sample : ArtilleryBallistics.trajectorySamples(startX, startZ, targetX, targetZ)) {
            BlockPos check = new BlockPos(sample.blockX(), 0, sample.blockZ());
            if (!level.isLoaded(check) || !level.isPositionEntityTicking(check)) {
                return false;
            }
        }
        return true;
    }

    private void notice(Player player, String id) {
        player.displayClientMessage(Component.translatable("message.t72mod." + id), true);
    }

    @Override
    public Vec3 partPosition(int index) {
        Vec3 center = this.partCenter(index);
        return center.add(0.0D, -PART_DIMENSIONS[index].height * 0.5D, 0.0D);
    }

    private Vec3 partCenter(int index) {
        float yaw = this.getYRot();
        return switch (index) {
            case PART_WHEEL_R -> AirframeLayout.world(this.position(), yaw, 1.22D, 0.56D, -0.03D);
            case PART_WHEEL_L -> AirframeLayout.world(this.position(), yaw, -1.22D, 0.56D, -0.03D);
            case PART_TRAIL_R -> AirframeLayout.world(this.position(), yaw, 0.74D, 0.30D, -1.30D);
            case PART_TRAIL_L -> AirframeLayout.world(this.position(), yaw, -0.74D, 0.30D, -1.30D);
            case PART_SPADE_R -> AirframeLayout.world(this.position(), yaw, 1.14D, 0.225D, -2.35D);
            case PART_SPADE_L -> AirframeLayout.world(this.position(), yaw, -1.14D, 0.225D, -2.35D);
            default -> {
                int barrelIdx = index - PART_BARREL_START;
                double dist = BARREL_DISTANCES[Mth.clamp(barrelIdx, 0, BARREL_DISTANCES.length - 1)];
                Vec3 pivot = this.position().add(0.0D, ArtilleryBallistics.PIVOT_Y_OFFSET, 0.0D);
                yield pivot.add(Vec3.directionFromRotation(-this.elevation(), yaw).scale(dist));
            }
        };
    }

    @Override
    public AABB partBounds(int index, AABB fallback) {
        Vec3 c = this.partCenter(index);
        EntityDimensions dim = PART_DIMENSIONS[index];
        double hw = dim.width * 0.5D;
        double hh = dim.height * 0.5D;
        return new AABB(c.x - hw, c.y - hh, c.z - hw, c.x + hw, c.y + hh, c.z + hw);
    }

    @Override
    public boolean partIsActive(int index) {
        if (index < PART_BARREL_START) return true;
        return index == PART_BARREL_START || this.gunHealth() > 0;
    }

    @Override
    public boolean partIsSolid(int index) {
        return this.partIsActive(index);
    }

    @Override
    public boolean partShouldExist(int index) {
        return true;
    }

    @Override
    public boolean hurtPart(int index, DamageSource source, Vec3 contact, float amount) {
        return this.hitModule(source, amount, index >= PART_BARREL_START ? GUN : TRAVERSE);
    }

    @Override
    public InteractionResult interactPart(int index, Player player, InteractionHand hand) {
        return this.mobInteract(player, hand);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return this.hitAssembly(source, source.getSourcePosition(), amount);
    }

    public boolean hitAssembly(DamageSource source, Vec3 hit, float amount) {
        EntityDataAccessor<Integer> part = hit != null && hit.y - this.getY() > 0.85 ? GUN : TRAVERSE;
        return this.hitModule(source, amount, part);
    }

    private boolean hitModule(DamageSource source, float amount, EntityDataAccessor<Integer> part) {
        if (this.level().isClientSide || !this.isAlive() || amount <= 0 || !Float.isFinite(amount)) return false;
        if (source.getDirectEntity() instanceof TankShellEntity shell) {
            if (source.is(DamageTypeTags.IS_EXPLOSION) && shell.excludeFromBlast(this)) return false;
            this.invulnerableTime = 0;
        }
        float damage = source.is(T72Mod.TACZ_BULLETS) ? Math.min(amount, 45) * 0.62F : amount;
        boolean accepted = super.hurt(source, damage);
        if (accepted && this.isAlive() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            int previous = this.entityData.get(part);
            this.entityData.set(part, Math.max(0, previous - Mth.ceil(damage * 1.5F)));
            if (previous > 0 && this.entityData.get(part) == 0) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.PLAYERS, 1.4F, 0.86F);
            }
        }
        return accepted;
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide) {
            this.unhitch();
            this.ejectPassengers();
            if (this.ammunition() > 0) this.spawnAtLocation(new ItemStack(T72Mod.ARTILLERY_SHELL.get(), this.ammunition()));
            this.entityData.set(AMMO, 0);
        }
        super.die(source);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Gun", this.gunHealth());
        tag.putInt("Traverse", this.traverseHealth());
        tag.putInt("Ammo", this.ammunition());
        tag.putInt("Reload", this.reloadTicks());
        tag.putInt("Elevation", this.elevation());
        this.towVehicle().ifPresent(id -> tag.putUUID("TowVehicle", id));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Gun")) this.entityData.set(GUN, Mth.clamp(tag.getInt("Gun"), 0, FULL_HEALTH));
        if (tag.contains("Traverse")) this.entityData.set(TRAVERSE, Mth.clamp(tag.getInt("Traverse"), 0, FULL_HEALTH));
        if (tag.contains("Elevation")) this.entityData.set(ELEVATION, Mth.clamp(tag.getInt("Elevation"), 0, 90));
        this.setTowVehicle(tag.hasUUID("TowVehicle") ? tag.getUUID("TowVehicle") : null);
        this.entityData.set(AMMO, Mth.clamp(tag.getInt("Ammo"), 0, CAPACITY));
        this.entityData.set(RELOAD, Mth.clamp(tag.getInt("Reload"), 0, 95));
    }
}
