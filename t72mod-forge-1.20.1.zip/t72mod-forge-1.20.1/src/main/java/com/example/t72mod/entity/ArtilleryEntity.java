package com.example.t72mod.entity;

import com.example.t72mod.T72Mod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class ArtilleryEntity extends PathfinderMob {
    public static final int MIN_RANGE = 16;
    public static final int MAX_RANGE = 96;
    private static final int CAPACITY = 24;
    private static final int FULL_HEALTH = 100;
    private static final float GRAVITY = 0.085F;
    private static final EntityDataAccessor<Integer> GUN = data();
    private static final EntityDataAccessor<Integer> TRAVERSE = data();
    private static final EntityDataAccessor<Integer> AMMO = data();
    private static final EntityDataAccessor<Integer> RELOAD = data();
    private static final EntityDataAccessor<Integer> ELEVATION = data();

    private static EntityDataAccessor<Integer> data() {
        return SynchedEntityData.defineId(ArtilleryEntity.class, EntityDataSerializers.INT);
    }

    public ArtilleryEntity(EntityType<? extends ArtilleryEntity> type, Level level) {
        super(type, level);
        this.setNoAi(true);
        this.blocksBuilding = true;
    }

    public static AttributeSupplier.Builder attributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 160)
                .add(Attributes.ARMOR, 7).add(Attributes.KNOCKBACK_RESISTANCE, 1);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(GUN, FULL_HEALTH);
        this.entityData.define(TRAVERSE, FULL_HEALTH);
        this.entityData.define(AMMO, 0);
        this.entityData.define(RELOAD, 0);
        this.entityData.define(ELEVATION, 37);
    }

    public int gunHealth() { return this.entityData.get(GUN); }
    public int traverseHealth() { return this.entityData.get(TRAVERSE); }
    public int ammunition() { return this.entityData.get(AMMO); }
    public int reloadTicks() { return this.entityData.get(RELOAD); }
    public int elevation() { return this.entityData.get(ELEVATION); }

    public void loadStarterAmmo() { this.entityData.set(AMMO, 3); }

    @Override
    protected boolean canAddPassenger(Entity rider) {
        return rider instanceof Player && this.isAlive() && this.getPassengers().isEmpty();
    }

    @Override
    public double getPassengersRidingOffset() { return 0.54; }

    @Override
    public boolean canBeCollidedWith() { return this.isAlive(); }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    public void travel(Vec3 ignored) { super.travel(Vec3.ZERO); }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            if (this.isAlive() && this.gunHealth() == 0 && this.tickCount % 5 == 0) {
                this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY() + 1.3, this.getZ(), 0, 0.06, 0);
            }
        } else if (this.reloadTicks() > 0) {
            this.entityData.set(RELOAD, this.reloadTicks() - 1);
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.isAlive() || hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        ItemStack item = player.getItemInHand(hand);
        if (item.is(T72Mod.ARTILLERY_SHELL.get()) && this.ammunition() < CAPACITY) {
            if (!this.level().isClientSide) {
                int loaded = Math.min(CAPACITY - this.ammunition(), item.getCount());
                this.entityData.set(AMMO, this.ammunition() + loaded);
                if (!player.getAbilities().instabuild) item.shrink(loaded);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON, SoundSource.PLAYERS, 1, 1);
                this.notice(player, "artillery_loaded");
            }
        } else if (item.is(T72Mod.REPAIR_KIT.get()) && (this.getHealth() < this.getMaxHealth()
                || this.gunHealth() < FULL_HEALTH || this.traverseHealth() < FULL_HEALTH)) {
            if (!this.level().isClientSide) {
                this.heal(65);
                this.entityData.set(GUN, FULL_HEALTH);
                this.entityData.set(TRAVERSE, FULL_HEALTH);
                if (!player.getAbilities().instabuild) item.shrink(1);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1, 1);
            }
        } else if (this.isEmplaced() && !this.isVehicle()) {
            if (!this.level().isClientSide) {
                if (!player.startRiding(this)) return InteractionResult.FAIL;
                this.notice(player, "artillery_map_hint");
            }
        } else {
            return InteractionResult.PASS;
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    private boolean isEmplaced() {
        if (this.onGround()) return true;
        AABB hull = this.getBoundingBox();
        AABB groundCheck = new AABB(hull.minX + 0.10, hull.minY - 0.08, hull.minZ + 0.10,
                hull.maxX - 0.10, hull.minY, hull.maxZ - 0.10);
        return this.level().getBlockCollisions(this, groundCheck).iterator().hasNext();
    }

    public boolean shootAt(Player operator, int x, int z) {
        if (!(this.level() instanceof ServerLevel level) || !this.isAlive() || !this.isEmplaced()
                || this.getFirstPassenger() != operator || this.reloadTicks() > 0) return false;
        if (this.gunHealth() == 0 || this.traverseHealth() == 0) {
            this.notice(operator, "artillery_broken");
            return false;
        }
        if (this.ammunition() == 0 && !operator.getAbilities().instabuild) {
            this.notice(operator, "artillery_empty");
            return false;
        }

        double dx = x + 0.5 - this.getX();
        double dz = z + 0.5 - this.getZ();
        double range = Math.hypot(dx, dz);
        if (range < MIN_RANGE || range > MAX_RANGE || !level.hasChunkAt(new BlockPos(x, 0, z))) {
            this.notice(operator, "artillery_range");
            return false;
        }
        for (int sample = 1; sample <= 8; sample++) {
            if (!level.hasChunkAt(BlockPos.containing(this.getX() + dx * sample / 8,
                    this.getY(), this.getZ() + dz * sample / 8))) {
                this.notice(operator, "artillery_range");
                return false;
            }
        }

        Vec3 pivot = this.position().add(0, 1.35, 0);
        int elevation = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
        int flightTicks = Mth.ceil(32 + range * 0.25);
        double airDrag = 0.99F;
        double displacementScale = (1 - Math.pow(airDrag, flightTicks)) / (1 - airDrag);
        double gravityDrop = GRAVITY * (flightTicks - displacementScale) / (1 - airDrag);
        Vec3 velocity = new Vec3(dx, elevation - 0.12 - pivot.y + gravityDrop, dz).scale(1 / displacementScale);
        if (velocity.y < 0.4 || velocity.y > 4.2) {
            this.notice(operator, "artillery_range");
            return false;
        }
        Vec3 aim = velocity.normalize();
        Vec3 end = pivot.add(aim.scale(2.4));
        if (level.clip(new ClipContext(pivot, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this))
                .getType() != HitResult.Type.MISS) {
            this.notice(operator, "artillery_blocked");
            return false;
        }

        TankShellEntity shell = T72Mod.TANK_SHELL.get().create(level);
        if (shell == null) return false;
        shell.setOwner(operator);
        shell.configureShell(this, 150, 4.8F, GRAVITY);
        shell.setPos(pivot);
        shell.setDeltaMovement(velocity);
        if (!level.addFreshEntity(shell)) return false;
        if (!operator.getAbilities().instabuild) this.entityData.set(AMMO, this.ammunition() - 1);
        this.entityData.set(RELOAD, 95);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        this.setYRot(yaw);
        this.yBodyRot = yaw;
        this.entityData.set(ELEVATION, Mth.floor(Math.toDegrees(Math.atan2(velocity.y, velocity.horizontalDistance()))));

        level.sendParticles(ParticleTypes.FLASH, end.x, end.y, end.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, end.x, end.y, end.z, 9, 0.15, 0.15, 0.15, 0.01);
        level.playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 3.2F, 1.0F);
        return true;
    }

    private void notice(Player player, String id) {
        player.displayClientMessage(Component.translatable("message.t72mod." + id), true);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return this.hitAssembly(source, source.getSourcePosition(), amount);
    }

    public boolean hitAssembly(DamageSource source, Vec3 hit, float amount) {
        if (this.level().isClientSide || !this.isAlive() || amount <= 0 || !Float.isFinite(amount)) return false;
        if (source.getDirectEntity() instanceof TankShellEntity shell) {
            if (source.is(DamageTypeTags.IS_EXPLOSION) && shell.excludeFromBlast(this)) return false;
            this.invulnerableTime = 0;
        }
        float damage = source.is(T72Mod.TACZ_BULLETS) ? Math.min(amount, 45) * 0.62F : amount;
        boolean accepted = super.hurt(source, damage);
        if (accepted && this.isAlive() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            EntityDataAccessor<Integer> part = hit != null && hit.y - this.getY() > 0.85 ? GUN : TRAVERSE;
            int previous = this.entityData.get(part);
            this.entityData.set(part, Math.max(0, previous - Mth.ceil(damage * 1.5F)));
            if (previous > 0 && this.entityData.get(part) == 0) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.PLAYERS, 1.4F, 0.86F);
            }
        }
        return accepted;
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide) {
            this.ejectPassengers();
            if (this.ammunition() > 0) this.spawnAtLocation(new ItemStack(T72Mod.ARTILLERY_SHELL.get(), this.ammunition()));
            this.entityData.set(AMMO, 0);
        }
        super.die(source);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Gun", this.gunHealth());
        tag.putInt("Traverse", this.traverseHealth());
        tag.putInt("Ammo", this.ammunition());
        tag.putInt("Reload", this.reloadTicks());
        tag.putInt("Elevation", this.elevation());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Gun")) this.entityData.set(GUN, Mth.clamp(tag.getInt("Gun"), 0, FULL_HEALTH));
        if (tag.contains("Traverse")) this.entityData.set(TRAVERSE, Mth.clamp(tag.getInt("Traverse"), 0, FULL_HEALTH));
        if (tag.contains("Elevation")) this.entityData.set(ELEVATION, Mth.clamp(tag.getInt("Elevation"), 0, 90));
        this.entityData.set(AMMO, Mth.clamp(tag.getInt("Ammo"), 0, CAPACITY));
        this.entityData.set(RELOAD, Mth.clamp(tag.getInt("Reload"), 0, 95));
    }
}
