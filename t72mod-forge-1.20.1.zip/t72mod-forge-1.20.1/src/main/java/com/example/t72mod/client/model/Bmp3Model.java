package com.example.t72mod.client.model;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.T72TankEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class Bmp3Model extends EntityModel<T72TankEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(T72Mod.MODID, "bmp3"), "main");

    private final ModelPart root;
    private final ModelPart hull;
    private final ModelPart turret;
    private final ModelPart barrel;
    private final ModelPart brokenBarrel;
    private final ModelPart hatch;

    public Bmp3Model(ModelPart root) {
        this.root = root;
        this.hull = root.getChild("hull");
        this.turret = root.getChild("turret");
        this.barrel = this.turret.getChild("barrel");
        this.brokenBarrel = this.turret.getChild("broken_barrel");
        this.hatch = this.turret.getChild("hatch");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-17.0F, 5.0F, -30.0F, 34.0F, 9.0F, 60.0F)
                .texOffs(0, 0).addBox(-16.0F, 12.0F, -32.0F, 32.0F, 4.0F, 18.0F)
                .texOffs(0, 0).addBox(-16.0F, 13.0F, 8.0F, 32.0F, 3.0F, 22.0F)
                .texOffs(0, 80).addBox(-22.0F, 8.0F, -30.0F, 3.0F, 7.0F, 60.0F)
                .texOffs(0, 80).addBox(19.0F, 8.0F, -30.0F, 3.0F, 7.0F, 60.0F)
                .texOffs(0, 140).addBox(-22.0F, 0.0F, -30.0F, 6.0F, 9.0F, 60.0F)
                .texOffs(0, 140).addBox(16.0F, 0.0F, -30.0F, 6.0F, 9.0F, 60.0F)
                // BMP-3 rear troop access hatches and raised engine deck.
                .texOffs(120, 0).addBox(-14.0F, 12.0F, 24.0F, 28.0F, 3.0F, 7.0F)
                .texOffs(120, 0).addBox(-12.0F, 15.0F, 17.0F, 24.0F, 2.0F, 6.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        for (int i = 0; i < 7; i++) {
            float zOffset = -25.0F + i * 8.0F;
            hull.addOrReplaceChild("wheel_l_" + i, CubeListBuilder.create()
                    .texOffs(160, 0).addBox(-21.0F, 1.0F, zOffset - 3.5F, 2.0F, 6.0F, 7.0F),
                    PartPose.ZERO);
            hull.addOrReplaceChild("wheel_r_" + i, CubeListBuilder.create()
                    .texOffs(160, 0).addBox(19.0F, 1.0F, zOffset - 3.5F, 2.0F, 6.0F, 7.0F),
                    PartPose.ZERO);
        }

        PartDefinition turret = root.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-11.0F, 15.0F, -13.0F, 22.0F, 7.0F, 25.0F)
                .texOffs(80, 80).addBox(-10.0F, 16.0F, -17.0F, 20.0F, 5.0F, 5.0F)
                .texOffs(120, 20).addBox(-10.0F, 15.0F, 11.0F, 20.0F, 5.0F, 5.0F)
                .texOffs(160, 20).addBox(-12.5F, 18.0F, -10.0F, 2.0F, 3.0F, 6.0F),
                PartPose.offset(0.0F, 0.0F, -2.0F));

        turret.addOrReplaceChild("barrel", CubeListBuilder.create()
                .texOffs(120, 40).addBox(-4.0F, -3.0F, -6.0F, 8.0F, 6.0F, 6.0F)
                .texOffs(120, 60).addBox(-1.4F, -1.4F, -43.0F, 2.8F, 2.8F, 39.0F)
                .texOffs(120, 40).addBox(-2.0F, -2.0F, -23.0F, 4.0F, 4.0F, 7.0F),
                PartPose.offset(0.0F, 18.0F, -15.0F));

        turret.addOrReplaceChild("broken_barrel", CubeListBuilder.create()
                .texOffs(120, 40).addBox(-4.3F, -3.2F, -7.0F, 8.6F, 6.4F, 7.0F)
                .texOffs(0, 140).addBox(-2.1F, -2.2F, -13.0F, 4.2F, 4.4F, 6.0F)
                .texOffs(0, 141).addBox(-2.1F, -2.2F, -17.0F, 1.4F, 1.8F, 5.0F)
                .texOffs(0, 141).addBox(0.7F, 0.4F, -15.0F, 1.4F, 1.8F, 3.0F),
                PartPose.offset(0.0F, 18.0F, -15.0F));

        turret.addOrReplaceChild("hatch", CubeListBuilder.create()
                .texOffs(80, 100).addBox(-5.0F, -1.5F, -7.0F, 10.0F, 2.0F, 10.0F),
                PartPose.offset(4.0F, 22.0F, 2.0F));

        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(T72TankEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        float partialTick = ageInTicks - entity.tickCount;

        float hullYaw = Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot());
        float turretYaw = entity.renderTurretYaw(partialTick);
        float relativeTurretYaw = Mth.wrapDegrees(turretYaw - hullYaw);

        // Negated because renderer applies 180.0F - hullYaw around +Y
        this.turret.yRot = (float) Math.toRadians(-relativeTurretYaw);

        float pitch = entity.renderBarrelPitch(partialTick);
        // Negated so negative pitch (looking UP) raises the barrel (+Y)
        this.barrel.xRot = (float) Math.toRadians(-pitch);
        this.brokenBarrel.xRot = this.barrel.xRot;
        this.barrel.visible = !entity.isGunBroken();
        this.brokenBarrel.visible = entity.isGunBroken();

        float recoilOffset = entity.getRecoilTicks() > 0
                ? Mth.sin((entity.getRecoilTicks() - partialTick) * 0.3F) * 6.5F
                : 0.0F;
        this.barrel.z = -15.0F + recoilOffset;

        this.hatch.xRot = entity.isHatchOpen() ? -1.35F : 0.0F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, float red, float green, float blue, float alpha) {
        poseStack.pushPose();
        this.turret.translateAndRotate(poseStack);
        this.barrel.render(poseStack,buffer,packedLight,packedOverlay,red,green,blue,alpha);
        this.brokenBarrel.render(poseStack,buffer,packedLight,packedOverlay,red,green,blue,alpha);
        poseStack.popPose();
    }
}
