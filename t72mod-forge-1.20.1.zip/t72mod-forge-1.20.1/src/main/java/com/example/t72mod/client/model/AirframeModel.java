package com.example.t72mod.client.model;

import com.example.t72mod.entity.AirframeLayout;
import com.example.t72mod.entity.HelicopterType;
import net.minecraft.world.phys.Vec3;

import static com.example.t72mod.client.model.VehicleMesh.Section;

public final class AirframeModel {
    private static final int RUBBER = 0x252729;
    private static final int STEEL = 0x616864;
    private static final int GLASS = 0x293d42;
    private static final int FRAME = 0x22292a;
    private static final int TRIM = 0x50584c;
    private static final int BENCH = 0x504d3b;
    private static final int FLOOR = 0x474945;
    public final VehicleMesh body = new VehicleMesh();
    public final VehicleMesh glass = new VehicleMesh();
    public final VehicleMesh cabin = new VehicleMesh();
    public final VehicleMesh door = new VehicleMesh();
    public final VehicleMesh rotor = new VehicleMesh();
    public final VehicleMesh tail = new VehicleMesh();
    public final VehicleMesh stores = new VehicleMesh();

    public AirframeModel(HelicopterType type) {
        if (type == HelicopterType.MI8) this.transport();
        else if (type == HelicopterType.MI24) this.tandem();
        else this.coaxial();
        this.blades(type);
    }

    private void transport() {
        int olive = 0x606451, paint = 0x767761, lower = 0x484e42;
        body.hull(12, 0, (s,p) -> {
            if (s >= 3 && s <= 5 && (p == 0 || p == 11)) return -1;
            if (s >= 6 && s <= 8 && (p <= 5 || p == 11)) return -1;
            if (p >= 6 && p <= 10) return lower;
            return (s + p * 2) % 7 <= 1 ? paint : olive;
        }, sec(-4.4,.63,1.38,2.76), sec(-3.65,1.43,.91,3.62), sec(-2.6,1.85,.71,3.95),
                sec(.43,1.85,.71,3.95), sec(1.02,1.85,.71,3.95), sec(1.58,1.83,.75,3.95),
                sec(2.13,1.80,.78,3.90), sec(3.3,1.73,.90,3.80), sec(4.45,1.43,1.00,3.23),
                sec(5.20,.78,1.18,2.50), sec(5.46,.33,1.46,2.09));
        glass.hull(12,0,(s,p) -> p <= 5 || p == 11 ? ((p == 0 || p == 5) ? 0x405259 : GLASS) : -1,
                sec(2.12,1.797,.79,3.885), sec(3.3,1.72,.91,3.79), sec(4.45,1.422,1.01,3.22),
                sec(5.20,.774,1.19,2.49));
        for (double x : new double[]{-.97,0,.97}) {
            body.tube(new Vec3(x,2.37,5.05), new Vec3(x*.66,3.26,4.18), .042,.038,6,FRAME);
        }
        for (double z : new double[]{-2.64,-1.64,-.64}) {
            body.box(-1.829,2.51,z-.33,-1.805,3.04,z+.33,FRAME);
            body.box(-1.835,2.56,z-.27,-1.828,2.98,z+.27,0x3b5258);
            body.box(1.805,2.51,z-.33,1.829,3.04,z+.33,FRAME);
            body.box(1.828,2.56,z-.27,1.835,2.98,z+.27,0x3b5258);
        }
        door.box(1.46,1.32,.43,1.68,3.43,2.13,olive);
        door.box(1.68,2.56,.72,1.695,3.03,1.66,GLASS);
        door.box(1.69,2.13,.58,1.74,2.20,.90,STEEL);
        body.box(1.44,1.34,.42,1.75,1.48,2.13,TRIM);
        body.box(1.54,3.38,.38,1.73,3.51,2.16,TRIM);
        this.transportDeck();
        this.boom(-12.04,-3.54,2.45,olive,false);
        gears(-1.71,3.73,1.92);
        for (double x : new double[]{-1,1}) {
            body.hull(10,x,(s,p)-> p<5?paint:olive,sec(-2.7,.40,3.55,4.30),
                    sec(-1.9,.54,3.62,4.57),sec(1.65,.55,3.66,4.56),sec(2.25,.42,3.70,4.39));
            body.tube(new Vec3(x,4.01,2.25),new Vec3(x,4.01,2.32),.32,.33,12,FRAME);
            body.tube(new Vec3(x,4.01,-2.7),new Vec3(x*1.31,4.00,-2.99),.32,.27,12,0x45433d);
            body.hull(10,x*1.78,(s,p)->lower,sec(-2.8,.20,.94,1.42),sec(-2.29,.29,.83,1.57),
                    sec(.08,.28,.85,1.56),sec(.52,.09,1,1.36));
        }
    }

    private void transportDeck() {
        cabin.box(-1.51,1.21,-3.63,1.51,AirframeLayout.MI8_FLOOR,4.15,FLOOR);
        cabin.box(-.73,1.351,-3.53,.73,1.365,3.62,0x595b53);
        cabin.box(-1.45,1.36,4.06,1.45,2.05,4.43,0x333c39);
        cabin.box(-1.4,1.92,4.02,1.38,2.15,4.19,0x505e58);
        for (double x : new double[]{-.95,-.68,-.41,-.14,.21,.48,.73,1.0}) {
            cabin.box(x,2.151,4.045,x+.12,2.163,4.15,0x191f1c);
            cabin.box(x+.028,2.164,4.075,x+.076,2.171,4.12,0x9ba373);
        }
        seat(cabin,-.62,3.28,1.43,false);
        seat(cabin,.58,3.28,1.43,false);
        for (double z : new double[]{-3.06,-2.13,-1.20,-.27}) {
            seat(cabin,-1.12,z,1.40,true);
            seat(cabin,1.12,z,1.40,true);
        }
        for (double x : new double[]{-1.43,1.43}) {
            cabin.tube(new Vec3(x,2.90,-3.36),new Vec3(x,2.90,.28),.032,.032,6,STEEL);
        }
        cabin.box(1.47,.30,.65,2.77,.49,1.77,0x454948);
        cabin.box(1.46,.72,.65,2.32,.89,1.77,STEEL);
        cabin.box(1.44,1.11,.65,1.96,1.28,1.77,STEEL);
    }

    public static void seat(VehicleMesh mesh,double x,double z,double y,boolean side) {
        mesh.box(x-.26,y,z-.30,x+.26,y+.32,z+.30,0x353a35);
        mesh.box(x-.30,y+.32,z-.34,x+.30,y+.45,z+.34,BENCH);
        if (side) {
            double back = x + Math.signum(x)*.28;
            mesh.box(back-.06,y+.39,z-.32,back+.06,y+.97,z+.32,BENCH);
        } else mesh.box(x-.27,y+.40,z-.35,x+.27,y+.97,z-.22,BENCH);
    }

    private void tandem() {
        int sand=0x87785d, olive=0x555b45;
        body.hull(12,0,(s,p)->p>6?0x505345:((s*2+p)%6<2?olive:sand),
                sec(-4.0,.68,1.21,2.67),sec(-2.8,1.32,.83,3.27),sec(-.35,1.65,.72,3.53),
                sec(1.65,1.55,.82,3.34),sec(2.80,1.34,.96,2.84),sec(4.60,1.05,1,2.55),
                sec(5.25,.39,1.18,1.77));
        canopy(1.51,3.53,3.52,.83,2.31);
        canopy(3.23,4.97,2.95,.68,2.00);
        this.boom(-10.75,-3.28,2.22,olive,false);
        wings(2.85,olive);
        gears(-1.48,3.42,1.46);
        for (double x:new double[]{-.72,.72}) {
            body.hull(10,x,(s,p)->olive,sec(-2.66,.34,2.9,3.69),sec(-1.85,.47,2.95,3.91),
                    sec(1.37,.40,2.97,3.79),sec(1.95,.26,3.07,3.57));
            body.tube(new Vec3(x,3.32,1.90),new Vec3(x,3.32,2.02),.24,.22,10,FRAME);
        }
    }

    private void coaxial() {
        int paint=0x626c68, dark=0x43524d;
        body.hull(10,0,(s,p)->p>5?dark:((p+s*2)%7<3?dark:paint),
                sec(-3.86,.45,1.39,2.68),sec(-2.71,1.37,.95,3.17),sec(-.41,1.57,.61,3.55),
                sec(1.44,1.65,.71,3.10),sec(3.00,1.45,.82,2.63),sec(4.74,1.10,.99,2.05),
                sec(5.24,.50,1.21,1.76));
        canopy(1.61,4.12,3.62,1.35,2.14);
        this.boom(-8.55,-3.25,2.37,paint,true);
        wings(2.71,dark);
        gears(-1.42,3.20,1.42);
        for (double x:new double[]{-1.10,1.10}) {
            body.hull(10,x,(s,p)->paint,sec(-2.81,.38,2.23,3.18),sec(-1.46,.53,2.18,3.43),
                    sec(1.19,.47,2.19,3.18),sec(1.74,.30,2.22,2.98));
            body.tube(new Vec3(x,2.65,1.72),new Vec3(x,2.65,1.83),.26,.25,10,FRAME);
        }
    }

    private void canopy(double back,double nose,double top,double width,double bottom) {
        glass.hull(12,0,(s,p)->p >= 6 && p != 11 ? -1 : (p%4 == 0 ? 0x48585c : GLASS),
                sec(back,width*.74,bottom,top-.34),sec(back+.42,width,bottom,top),
                sec(nose-.46,width*.88,bottom,top-.17),sec(nose,width*.45,bottom,top-.62));
        body.tube(new Vec3(0,top,back+.43),new Vec3(0,top-.58,nose),.034,.025,6,FRAME);
    }

    private void boom(double rear,double front,double y,int color,boolean doubleFin) {
        body.hull(10,0,(s,p)->p<5?color:TRIM,sec(rear,.10,y+.18,y+.4),
                sec(rear+1.14,.21,y-.10,y+.52),sec(front-2.9,.35,y-.33,y+.55),sec(front,.63,y-.63,y+.68));
        for(double x:doubleFin?new double[]{-.68,.68}:new double[]{0}) {
            body.face(new Vec3(x,y,rear+.12),new Vec3(x,y+1.6,rear+.31),
                    new Vec3(x,y+1.89,rear+1.12),new Vec3(x,y,rear+2.22),color);
            body.tube(new Vec3(x,y,rear+.18),new Vec3(x,y+1.6,rear+.32),.08,.055,6,color);
        }
        body.box(-1.39,y+.14,rear+1.20,1.39,y+.27,rear+2.01,color);
    }

    private void gears(double mainZ,double noseZ,double gauge) {
        for(double x:new double[]{-gauge,gauge}) {
            body.tube(new Vec3(x*.83,1.22,mainZ),new Vec3(x,.41,mainZ),.086,.067,8,STEEL);
            body.tube(new Vec3(x*.74,.88,mainZ+.91),new Vec3(x,.41,mainZ),.072,.056,8,STEEL);
            tire(x,mainZ,.41);
        }
        body.tube(new Vec3(0,1.35,noseZ),new Vec3(0,.32,noseZ),.09,.07,8,STEEL);
        tire(-.18,noseZ,.32);tire(.18,noseZ,.32);
    }

    private void tire(double x,double z,double radius) {
        body.tube(new Vec3(x-.135,radius,z),new Vec3(x+.135,radius,z),radius,radius,16,RUBBER);
        body.tube(new Vec3(x-.153,radius,z),new Vec3(x+.153,radius,z),radius*.53,radius*.53,10,STEEL);
    }

    private void wings(double reach,int color) {
        for(int sign:new int[]{-1,1}) {
            body.face(new Vec3(sign*1.3,2.24,1.48),new Vec3(sign*reach,1.82,.87),
                    new Vec3(sign*reach,1.67,-.55),new Vec3(sign*1.3,2.12,-.92),color);
            body.tube(new Vec3(sign*1.34,2.22,1.46),new Vec3(sign*reach,1.80,.84),.15,.066,6,color);
            stores.tube(new Vec3(sign*2.18,1.53,-.81),new Vec3(sign*2.18,1.53,.85),.27,.27,12,0x444948);
        }
    }

    private void blades(HelicopterType type) {
        double radius=type==HelicopterType.MI8?10.63:type==HelicopterType.MI24?8.5:7.25;
        int count=type==HelicopterType.KA52?3:5;
        double y=AirframeLayout.rotorY(type);
        body.tube(new Vec3(0,y-.83,-.53),new Vec3(0,y+(type==HelicopterType.KA52?.53:.04),-.53),.19,.13,12,STEEL);
        rotor.tube(new Vec3(0,-.10,0),new Vec3(0,.13,0),.48,.45,12,STEEL);
        for (int i=0;i<count;i++) {
            double a=i*Math.PI*2/count;
            Vec3 dir=new Vec3(Math.sin(a),0,Math.cos(a));
            Vec3 edge=new Vec3(dir.z,0,-dir.x);
            rotor.tube(dir.scale(.30),dir.scale(1.0),.09,.065,6,STEEL);
            Vec3 root=dir.scale(.88), tip=dir.scale(radius);
            rotor.face(root.add(edge.scale(-.24)),root.add(edge.scale(.19)),
                    tip.add(edge.scale(.12)).add(0,-.13,0),tip.add(edge.scale(-.19)).add(0,-.13,0),0x353c3d);
        }
        for(int i=0;i<3;i++) {
            double a=i*Math.PI*2/3;
            tail.tube(Vec3.ZERO,new Vec3(0,Math.cos(a)*1.12,Math.sin(a)*1.12),.10,.074,6,0x424b4b);
        }
    }

    private static Section sec(double z,double r,double bottom,double top) { return new Section(z,r,bottom,top); }
}
