package com.example.t72mod.client.model;

import com.example.t72mod.entity.AirframeLayout;
import com.example.t72mod.entity.HelicopterType;
import com.example.t72mod.entity.HelicopterCabin;
import net.minecraft.world.phys.Vec3;

import static com.example.t72mod.client.model.VehicleMesh.Section;

public final class AirframeModel {
    private static final int RUBBER = 0x252729;
    private static final int STEEL = 0x616864;
    private static final int GLASS = 0x293d42;
    private static final int FRAME = 0x22292a;
    private static final int TRIM = 0x50584c;
    private static final int BENCH = 0x504d3b;
    private static final int FLOOR = 0x474945;
    public final VehicleMesh body = new VehicleMesh();
    public final VehicleMesh glass = new VehicleMesh();
    public final VehicleMesh cabin = new VehicleMesh();
    public final VehicleMesh door = new VehicleMesh();
    public final VehicleMesh rotor = new VehicleMesh();
    public final VehicleMesh tail = new VehicleMesh();
    public final VehicleMesh stores = new VehicleMesh();
    public final VehicleMesh rearHatch=new VehicleMesh();
    public final VehicleMesh rearRamp=new VehicleMesh();
    public final VehicleMesh rearRampDeck=new VehicleMesh();
    public final VehicleMesh doorGlass = new VehicleMesh();
    public final VehicleMesh steps = new VehicleMesh();
    public final VehicleMesh engineDamage = new VehicleMesh();
    public final VehicleMesh tailDamage = new VehicleMesh();
    public final VehicleMesh rotorDamage = new VehicleMesh();
    public final VehicleMesh storeDamage = new VehicleMesh();

    private final HelicopterType modelType;

    public AirframeModel(HelicopterType type) {
        this.modelType = type;
        if (type == HelicopterType.MI8) this.transport();
        else if (type == HelicopterType.MI24) this.tandem();
        else this.coaxial();
        this.blades(type);
        var layout = HelicopterCabin.forType(type);
        for (int i = 0; i < 3; i++) {
            var b = layout.step(i);
            this.steps.box(b.x()-b.width()/2,b.y(),b.z()-b.length()/2,
                    b.x()+b.width()/2,b.y()+b.height(),b.z()+b.length()/2,0x49534a);
            this.steps.box(b.x()-b.width()/2,b.y()+b.height(),b.z()-b.length()/2,
                    b.x()+b.width()/2,b.y()+b.height()+.014,b.z()-b.length()/2+.055,0x70756a);
        }
        this.damageModels(type);
    }

    private void transport() {
        int olive = 0x606451, paint = 0x767761, lower = 0x484e42;
        body.hullEnds(12, 0, (s,p) -> {
            if (s >= 3 && s <= 5 && (p == 0 || p == 11)) return -1;
            if (s >= 6 && s <= 8 && p >= 1 && p <= 4) return -1;
            if (s >= 6 && s <= 8 && (p == 0 || p == 5)) return 0x405259;
            if (p >= 6 && p <= 10 || p == 11) return lower;
            return (s + p * 2) % 7 <= 1 ? paint : olive;
        },false,true,sec(-3.64,1.43,.92,3.62),sec(-3.39,1.47,.89,3.72),sec(-2.6,1.85,.71,3.95),
                sec(.43,1.85,.71,3.95), sec(1.02,1.85,.71,3.95), sec(1.58,1.83,.75,3.95),
                sec(2.13,1.80,.78,3.90), sec(3.3,1.73,.90,3.80), sec(4.45,1.43,1.00,3.23),
                sec(5.20,.78,1.18,2.50), sec(5.46,.33,1.46,2.09));
        glass.hull(12,0,(s,p) -> p >= 1 && p <= 4 ? GLASS : -1,false,
                sec(2.12,1.797,.79,3.885), sec(3.3,1.72,.91,3.79), sec(4.45,1.422,1.01,3.22),
                sec(5.20,.774,1.19,2.49));
        for (double x : new double[]{-.97,0,.97}) {
            body.tube(new Vec3(x,2.37,5.05), new Vec3(x*.66,3.26,4.18), .042,.038,6,FRAME);
        }
        for (double z : new double[]{-2.64,-1.64,-.64}) {
            body.box(-1.829,2.51,z-.33,-1.805,3.04,z+.33,FRAME);
            body.box(-1.835,2.56,z-.27,-1.828,2.98,z+.27,0x3b5258);
            body.box(1.805,2.51,z-.33,1.829,3.04,z+.33,FRAME);
            body.box(1.828,2.56,z-.27,1.835,2.98,z+.27,0x3b5258);
        }
        door.box(1.46,1.32,.43,1.68,3.43,2.13,olive);
        door.box(1.68,2.56,.72,1.695,3.03,1.66,GLASS);
        door.box(1.69,2.13,.58,1.74,2.20,.90,STEEL);
        body.box(1.44,1.34,.42,1.75,1.48,2.13,TRIM);
        body.box(1.54,3.38,.38,1.73,3.51,2.16,TRIM);
        this.transportDeck();
        this.cargoDoor(olive);
        this.wings(2.91,olive);
        this.boom(-12.04,-3.54,2.45,olive,false);
        gears(-1.71,3.73,1.92);
        for (double x : new double[]{-1,1}) {
            body.hull(10,x,(s,p)-> p<5?paint:olive,sec(-2.7,.40,3.55,4.30),
                    sec(-1.9,.54,3.62,4.57),sec(1.65,.55,3.66,4.56),sec(2.25,.42,3.70,4.39));
            body.tube(new Vec3(x,4.01,2.25),new Vec3(x,4.01,2.32),.32,.33,12,FRAME);
            body.tube(new Vec3(x,4.01,-2.7),new Vec3(x*1.31,4.00,-2.99),.32,.27,12,0x45433d);
            body.hull(10,x*1.78,(s,p)->lower,sec(-2.8,.20,.94,1.42),sec(-2.29,.29,.83,1.57),
                    sec(.08,.28,.85,1.56),sec(.52,.09,1,1.36));
        }
    }

    private void cargoDoor(int paint) {
        var layout=HelicopterCabin.forType(HelicopterType.MI8);
        double z=layout.rear;
        body.box(-1.42,1.30,z-.09,-1.09,3.42,z+.08,TRIM);
        body.box(1.09,1.30,z-.09,1.42,3.42,z+.08,TRIM);
        body.box(-1.40,3.35,z-.09,1.40,3.59,z+.15,paint);
        body.box(-1.40,.94,z-.06,1.40,1.35,z+.10,TRIM);
        rearHatch.box(-1.10,1.35,z-.15,1.10,3.37,z-.058,paint);
        rearHatch.box(-.04,1.47,z-.169,.04,3.29,z-.149,FRAME);
        for (double x:new double[]{-.90,.90}) {
            rearHatch.box(x-.12,2.22,z-.188,x+.12,2.28,z-.161,STEEL);
            rearHatch.box(x-.09,2.68,z-.170,x+.09,3.18,z-.149,TRIM);
        }
        // The lower panel swings clear, then the treads extend to their collision surfaces.
        rearRamp.box(-1.066,-.068,-2.02,1.066,-.01,-.02,paint);
        for (double x:new double[]{-1.053,1.053})
            rearRamp.box(x-.019,-.014,-1.99,x+.019,.040,-.04,FRAME);
        for (int i=0;i<4;i++) {
            var step=layout.rampStep(i);
            double min=step.z()-step.length()/2,max=step.z()+step.length()/2;
            rearRampDeck.box(-1.10,step.y(),min,1.10,step.y()+step.height(),max,TRIM);
            for (int j=0;j<4;j++) {
                double zz=min+.052+j*.15;
                rearRampDeck.box(-1.04,step.y()+step.height(),zz,1.04,step.y()+step.height()+.008,zz+.03,STEEL);
            }
        }
        for (int sign : new int[]{-1,1}) {
            rearRampDeck.tube(new Vec3(sign*1.10,1.33,z),new Vec3(sign*1.10,.14,z-2.60),.052,.043,7,STEEL);
            rearRampDeck.tube(new Vec3(sign*1.09,1.64,z-.06),new Vec3(sign*1.09,.71,z-1.34),.025,.025,7,0x292d2d);
        }
    }

    private void transportDeck() {
        cabin.box(-1.51,1.21,-3.55,1.51,AirframeLayout.MI8_FLOOR,2.24,FLOOR);
        cabin.box(-1.20,1.21,2.24,1.20,AirframeLayout.MI8_FLOOR,4.22,FLOOR);
        cabin.box(-1.02,1.23,4.22,1.02,1.38,4.98,0x333c39);
        cabin.box(-1.74,1.21,-2.65,-1.44,1.352,2.14,0x39433e);
        cabin.box(1.44,1.21,-2.65,1.74,1.352,.44,0x39433e);
        cabin.box(-.73,1.351,-3.53,.73,1.365,3.62,0x595b53);
        cabin.box(-1.38,1.36,4.06,1.38,2.05,4.43,0x333c39);
        cabin.box(-1.34,1.92,4.02,1.34,2.15,4.19,0x505e58);
        for (double x : new double[]{-.95,-.68,-.41,-.14,.21,.48,.73,1.0}) {
            cabin.box(x,2.151,4.045,x+.12,2.163,4.15,0x191f1c);
            cabin.box(x+.028,2.164,4.075,x+.076,2.171,4.12,0x9ba373);
        }
        // Opaque bulkhead and an open centre doorway between the troop bay and flight deck.
        double doorway = AirframeLayout.MI8_BULKHEAD_OPEN_HALF_WIDTH;
        double wallStart = AirframeLayout.MI8_BULKHEAD_MIN_Z;
        double wallEnd = AirframeLayout.MI8_BULKHEAD_MAX_Z;
        for (int side : new int[]{-1,1}) {
            double low = side < 0 ? -1.72 : doorway;
            double high = side < 0 ? -doorway : 1.72;
            double frame = side * (doorway + .032);
            cabin.box(low,1.35,wallStart,high,3.55,wallEnd,0x62685d);
            cabin.box(frame-.032,1.36,wallStart-.05,frame+.032,3.47,wallEnd+.03,0x39433e);
            cabin.box(low+.16,2.25,wallStart-.03,high-.16,2.72,wallStart-.009,0x575e50);
        }
        cabin.box(-doorway,3.44,wallStart,doorway,3.82,wallEnd,0x62685d);
        cockpitInstruments(-.67,3.47,1.35,4.06,false);
        cockpitInstruments(.67,3.47,1.35,4.06,false);
        cabin.box(-.18,1.37,3.45,.18,1.99,4.12,0x3e4846);
        cabin.box(-.16,1.984,3.55,.16,2.002,4.10,0x52605b);
        cabin.tube(new Vec3(.09,2.0,3.71),new Vec3(.11,2.19,3.81),.019,.017,6,FRAME);
        for (double z : new double[]{-3.06,-2.13,-1.20,-.27}) {
            seat(cabin,-1.12,z,1.40,true);
            seat(cabin,1.12,z,1.40,true);
        }
        for (double x : new double[]{-1.43,1.43}) {
            cabin.tube(new Vec3(x,2.90,-3.36),new Vec3(x,2.90,.28),.032,.032,6,STEEL);
        }
        for (double z : new double[]{-2.83,-1.93,-1.03,-.13}) {
            cabin.box(-1.30,3.14,z,1.30,3.18,z+.055,0x555a50);
        }
    }

    public static void seat(VehicleMesh mesh,double x,double z,double y,boolean side) {
        mesh.box(x-.26,y,z-.30,x+.26,y+.32,z+.30,0x353a35);
        mesh.box(x-.30,y+.32,z-.34,x+.30,y+.45,z+.34,BENCH);
        if (side) {
            double back = x + Math.signum(x)*.28;
            mesh.box(back-.06,y+.39,z-.32,back+.06,y+.97,z+.32,BENCH);
        } else mesh.box(x-.27,y+.40,z-.35,x+.27,y+.97,z-.22,BENCH);
    }

    private void tandem() {
        int sand=0x87785d, olive=0x555b45;
        body.hull(12,0,(s,p)->s>=4 && s<=5 && p>=1 && p<=4 || s==4 && (p==0 || p==11) ? -1
                        : p>6?0x505345:((s*2+p)%6<2?olive:sand),
                sec(-4.0,.68,1.21,2.67),sec(-2.8,1.32,.83,3.27),sec(-.35,1.65,.72,3.53),
                sec(.76,1.55,.82,3.33),sec(1.42,1.47,.85,3.16),sec(2.99,1.29,.96,2.81),
                sec(4.60,1.05,1,2.55),sec(5.25,.39,1.18,1.77));
        canopy(1.45,3.18,3.91,.86,1.77,true);
        canopy(3.30,5.02,3.13,.74,1.54,false);
        body.box(-.68,2.31,3.174,.68,2.63,3.304,FRAME);
        body.box(-1.263,1.67,1.42,-1.17,2.42,2.94,olive);
        body.box(.84,1.65,1.40,1.26,2.54,1.46,olive);
        body.box(1.122,2.42,1.435,1.31,2.55,2.972,olive);
        body.box(-1.12,1.48,2.99,-.73,2.34,4.62,olive);
        body.box(.73,1.48,2.99,1.12,2.34,4.62,olive);
        body.box(-.92,1.32,4.55,.92,2.14,5.08,olive);
        body.box(-.64,2.55,1.43,.64,3.54,1.64,olive);
        this.attackCabin(HelicopterType.MI24,olive);
        this.cockpitInstruments(-.04,2.31,1.28,2.98,false);
        this.cockpitInstruments(.04,3.70,1.06,4.31,false);
        this.panel(-.90,1.86,-1.85,1.78,.64,0x555b4b);
        this.panel(.90,1.86,-1.85,1.78,.64,0x655f4e);
        this.boom(-10.75,-3.28,2.22,olive,false);
        wings(2.85,olive);
        gears(-1.48,3.42,1.46);
        for (double x:new double[]{-.72,.72}) {
            body.hull(10,x,(s,p)->olive,sec(-2.66,.34,2.9,3.69),sec(-1.85,.47,2.95,3.91),
                    sec(1.37,.40,2.97,3.79),sec(1.95,.26,3.07,3.57));
            body.tube(new Vec3(x,3.32,1.90),new Vec3(x,3.32,2.02),.24,.22,10,FRAME);
        }
    }

    private void coaxial() {
        int paint=0x626c68, dark=0x43524d;
        body.hull(12,0,(s,p)->s>=3 && s<=4 && p>=1 && p<=4 || s==3 && (p==0 || p==11) ? -1
                        : p>5?dark:((p+s*2)%7<3?dark:paint),
                sec(-3.86,.45,1.39,2.68),sec(-2.71,1.37,.95,3.17),sec(-.41,1.57,.61,3.55),
                sec(1.12,1.65,.71,3.09),sec(2.89,1.53,.80,2.70),sec(4.08,1.29,.88,2.36),
                sec(4.74,1.10,.99,2.05),sec(5.24,.50,1.21,1.76));
        canopy(1.15,4.13,3.55,1.40,1.55,true);
        body.box(-1.43,1.70,1.16,-1.31,2.27,2.84,paint);
        body.box(1.315,2.16,1.17,1.43,2.29,2.83,paint);
        body.box(-1.32,1.48,2.89,-.96,2.22,4.12,paint);
        body.box(.96,1.48,2.89,1.32,2.22,4.12,paint);
        body.box(-1.05,2.35,1.12,1.05,3.20,1.30,paint);
        body.box(-.88,1.28,3.92,.88,1.98,4.28,dark);
        this.attackCabin(HelicopterType.KA52,paint);
        this.cockpitInstruments(-.56,2.86,1.16,3.56,true);
        this.cockpitInstruments(.56,2.86,1.16,3.56,true);
        this.panel(-.91,1.54,-1.81,1.52,.67,0x4f5c54);
        this.panel(.91,1.54,-1.81,1.52,.67,0x58645d);
        body.tube(new Vec3(0,1.28,4.75),new Vec3(0,1.36,5.34),.25,.19,12,0x414c4b);
        this.boom(-8.55,-3.25,2.37,paint,true);
        wings(2.71,dark);
        gears(-1.42,3.20,1.42);
        for (double x:new double[]{-1.10,1.10}) {
            body.hull(10,x,(s,p)->paint,sec(-2.81,.38,2.23,3.18),sec(-1.46,.53,2.18,3.43),
                    sec(1.19,.47,2.19,3.18),sec(1.74,.30,2.22,2.98));
            body.tube(new Vec3(x,2.65,1.72),new Vec3(x,2.65,1.83),.26,.25,10,FRAME);
        }
    }

    private void canopy(double back,double nose,double top,double width,double bottom,boolean doorSide) {
        glass.hull(12,0,(s,p)-> p >= 6 && p != 11 || p % 4 == 0 || doorSide && s<2 && (p==0 || p==11)
                        ? -1 : GLASS,false,
                sec(back,width*.74,bottom,top-.34),sec(back+.42,width,bottom,top),
                sec(nose-.46,width*.88,bottom,top-.17),sec(nose,width*.45,bottom,top-.62));
        body.hull(12,0,(s,p)-> p < 6 && p % 4 == 0 ? 0x354246 : -1,false,
                sec(back,width*.74,bottom,top-.34),sec(back+.42,width,bottom,top),
                sec(nose-.46,width*.88,bottom,top-.17),sec(nose,width*.45,bottom,top-.62));
        body.tube(new Vec3(0,top,back+.43),new Vec3(0,top-.58,nose),.034,.025,6,FRAME);
        for (int side : new int[]{-1,1}) {
            body.tube(new Vec3(side*width*.70,bottom+.30,back+.13),
                    new Vec3(side*width*.82,bottom+.25,nose-.36),.058,.044,6,FRAME);
            body.tube(new Vec3(side*width*.42,bottom+.32,nose),
                    new Vec3(side*width*.42,top-.63,nose-.18),.038,.031,6,FRAME);
        }
    }

    private void attackCabin(HelicopterType type,int paint) {
        var space = HelicopterCabin.forType(type);
        double w = space.halfWidth, d0 = space.doorZ-space.doorWidth/2, d1 = space.doorZ+space.doorWidth/2;
        cabin.box(-w,space.floor-.11,space.rear,w,space.floor,space.front,FLOOR);
        cabin.box(-w,space.floor,space.rear,-w+.13,space.floor+.62,space.front,paint);
        cabin.box(w-.13,space.floor,space.rear,w,space.floor+.66,d0,paint);
        cabin.box(w-.13,space.floor,d1,w,space.floor+.67,space.front,paint);
        cabin.box(-w,space.floor,space.rear,w,space.ceiling-.12,space.rear+.13,0x4d5750);
        cabin.box(-w*.68,.94,space.front-.14,w*.68,space.floor+.43,space.front-.02,paint);
        this.door.box(w-.11,space.floor,d0,w+.025,space.floor+.76,d1,paint);
        this.door.box(w-.09,space.floor+.76,d0,w+.045,space.ceiling-.27,d0+.066,FRAME);
        this.door.box(w-.09,space.floor+.76,d1-.066,w+.045,space.ceiling-.27,d1,FRAME);
        this.door.box(w-.09,space.ceiling-.32,d0,w+.045,space.ceiling-.27,d1,FRAME);
        this.doorGlass.box(w-.084,space.floor+.76,d0+.057,w-.062,space.ceiling-.29,d1-.057,GLASS);
        cabin.box(w-.07,space.ceiling-.22,d0-.08,w+.10,space.ceiling-.11,d1+.08,FRAME);
        cabin.box(-w+.03,space.floor+.84,space.rear+.29,-w+.19,space.floor+.91,space.rear+1.03,0x333e39);
        if (type == HelicopterType.MI24) seat(cabin,-.49,1.05,space.floor+.02,true);
    }

    private void cockpitInstruments(double x,double z,double floor,double dash,boolean digital) {
        seat(cabin,x,z,floor+.05,false);
        cabin.box(x-.39,floor+.46,dash-.09,x+.39,floor+1.10,dash+.12,0x3b4844);
        cabin.box(x-.38,floor+1.08,dash-.11,x+.38,floor+1.17,dash+.14,0x282f2d);
        if (digital) {
            for (double offset : new double[]{-.17,.17}) {
                cabin.box(x+offset-.146,floor+.65,dash-.119,x+offset+.146,floor+1.03,dash-.101,0x1a2828);
                cabin.box(x+offset-.113,floor+.685,dash-.125,x+offset+.113,floor+.996,dash-.118,0x476c59);
                cabin.box(x+offset-.092,floor+.83,dash-.130,x+offset+.091,floor+.849,dash-.126,0x97a36d);
            }
        } else {
            for (int row=0; row<2; row++) for (int col=0;col<4;col++) {
                double px=x-.263+col*.175, py=floor+.76+row*.19;
                cabin.tube(new Vec3(px,py,dash-.10),new Vec3(px,py,dash-.14),.063,.060,10,0x202827);
                cabin.box(px-.005,py-.032,dash-.144,px+.008,py+.042,dash-.141,0xb1bd9c);
                cabin.box(px-.047,py+.019,dash-.144,px-.030,py+.028,dash-.141,0xaab084);
            }
        }
        for (double pedal : new double[]{-.15,.15})
            cabin.box(x+pedal-.07,floor+.14,dash-.22,x+pedal+.07,floor+.18,dash-.10,0x5d635c);
        cabin.tube(new Vec3(x,floor+.08,z+.36),new Vec3(x+.035,floor+.72,z+.43),.024,.027,8,FRAME);
        cabin.box(x-.018,floor+.68,z+.40,x+.092,floor+.85,z+.49,FRAME);
        cabin.box(x-.24,floor+.53,z+.06,x-.19,floor+.58,z+.19,0x6d4f3f);
        cabin.box(x+.15,floor+.55,z-.06,x+.21,floor+.59,z+.06,0x796f51);
    }

    private void panel(double x,double y,double z,double length,double h,int color) {
        double side=Math.signum(x), shellX=side*(Math.abs(x)+.54);
        body.box(Math.min(shellX,shellX+side*.021),y,z,Math.max(shellX,shellX+side*.021),y+h,z+length,color);
        for (int i=0;i<5;i++) {
            double zz=z+.20+i*(length-.25)/5;
            body.box(Math.min(shellX,shellX+side*.032),y+.12,zz,Math.max(shellX,shellX+side*.032),y+h-.09,zz+.032,0x353e38);
        }
    }

    private void damageModels(HelicopterType type) {
        double engineY = type == HelicopterType.MI8 ? 4.10 : type == HelicopterType.MI24 ? 3.36 : 2.71;
        double intakeX = type == HelicopterType.MI8 ? 1 : type == HelicopterType.MI24 ? .72 : 1.10;
        double engineZ = type == HelicopterType.MI8 ? 2.31 : type == HelicopterType.MI24 ? 2.01 : 1.83;
        for (int side : new int[]{-1,1}) {
            engineDamage.tube(new Vec3(side*intakeX,engineY,engineZ-.01),new Vec3(side*intakeX,engineY,engineZ+.038),
                    .245,.22,10,0x212524);
            engineDamage.tube(new Vec3(side*intakeX,engineY-.12,engineZ+.04),
                    new Vec3(side*intakeX+side*.11,engineY+.11,engineZ+.04),.031,.027,6,0x9a5c49);
            Vec3 p = AirframeLayout.store(type,side);
            storeDamage.tube(p.add(-.04,0,-.48),p.add(.15,.09,-.96),.23,.16,8,0x302d29);
        }
        double tailZ=AirframeLayout.tailZ(type), y=type==HelicopterType.KA52?2.74:3.26;
        tailDamage.tube(new Vec3(0,y-.32,tailZ+.44),new Vec3(.14,y+.14,tailZ+.61),.22,.17,7,0x372f28);
        tailDamage.tube(new Vec3(.12,y,tailZ+.48),new Vec3(.29,y-.21,tailZ+.40),.035,.027,5,0x89674b);
        double rotorY=AirframeLayout.rotorY(type);
        rotorDamage.tube(new Vec3(0,rotorY-.16,-.53),new Vec3(0,rotorY+.10,-.53),.33,.27,8,0x302b26);
        rotorDamage.tube(new Vec3(0,rotorY-.01,-.53),new Vec3(.65,rotorY-.13,-.47),.089,.076,6,0x605049);
    }

    private void boom(double rear,double front,double y,int color,boolean doubleFin) {
        Section tip = sec(rear,.10,y+.18,y+.4);
        Section rearBeam = sec(rear+1.14,.21,y-.10,y+.52);
        Section beam = sec(front-2.9,.35,y-.33,y+.55);
        if (this.modelType == HelicopterType.MI8) {
            body.hull(10,0,(s,p)->p<5?color:TRIM,tip,rearBeam,beam,
                    sec(front-1.21,.54,3.42,3.98),sec(front,.60,3.58,4.11));
        } else body.hull(10,0,(s,p)->p<5?color:TRIM,tip,rearBeam,beam,sec(front,.63,y-.63,y+.68));
        for(double x:doubleFin?new double[]{-.68,.68}:new double[]{0}) {
            body.face(new Vec3(x,y,rear+.12),new Vec3(x,y+1.6,rear+.31),
                    new Vec3(x,y+1.89,rear+1.12),new Vec3(x,y,rear+2.22),color);
            body.tube(new Vec3(x,y,rear+.18),new Vec3(x,y+1.6,rear+.32),.08,.055,6,color);
        }
        body.box(-1.39,y+.14,rear+1.20,1.39,y+.27,rear+2.01,color);
    }

    private void gears(double mainZ,double noseZ,double gauge) {
        for(double x:new double[]{-gauge,gauge}) {
            body.tube(new Vec3(x*.83,1.22,mainZ),new Vec3(x,.41,mainZ),.086,.067,8,STEEL);
            body.tube(new Vec3(x*.74,.88,mainZ+.91),new Vec3(x,.41,mainZ),.072,.056,8,STEEL);
            tire(x,mainZ,.41);
        }
        body.tube(new Vec3(0,1.35,noseZ),new Vec3(0,.32,noseZ),.09,.07,8,STEEL);
        tire(-.18,noseZ,.32);tire(.18,noseZ,.32);
    }

    private void tire(double x,double z,double radius) {
        body.tube(new Vec3(x-.135,radius,z),new Vec3(x+.135,radius,z),radius,radius,16,RUBBER);
        body.tube(new Vec3(x-.153,radius,z),new Vec3(x+.153,radius,z),radius*.53,radius*.53,10,STEEL);
    }

    private void wings(double reach,int color) {
        // Mi-8 mounts sit behind the side door and ladder.
        double shift=this.modelType==HelicopterType.MI8?-1.96:0;
        for (int sign:new int[]{-1,1}) {
            body.face(new Vec3(sign*1.3,2.24,1.48+shift),new Vec3(sign*reach,1.82,.87+shift),
                    new Vec3(sign*reach,1.67,-.55+shift),new Vec3(sign*1.3,2.12,-.92+shift),color);
            body.tube(new Vec3(sign*1.34,2.22,1.46+shift),new Vec3(sign*reach,1.80,.84+shift),.15,.066,6,color);
            Vec3 pod = AirframeLayout.store(this.modelType,sign);
            stores.tube(pod.add(0,0,-.82),pod.add(0,0,.77),.27,.27,12,0x444948);
            stores.tube(pod.add(0,0,.77),pod.add(0,0,.87),.27,.22,12,0x353d3a);
            for (int ring=0; ring<5; ring++) {
                double a=ring*Math.PI*2/5;
                Vec3 center=pod.add(Math.cos(a)*.13,Math.sin(a)*.13,.875);
                stores.tube(center,center.add(0,0,.024),.045,.045,7,0x222727);
            }
            stores.tube(pod.add(sign*.36,-.09,-.70),pod.add(sign*.36,-.09,.88),.106,.081,9,0x333938);
            stores.tube(pod.add(sign*.36,-.09,.82),pod.add(sign*.36,-.09,1.12),.049,.036,8,0x242a28);
        }
    }

    private void blades(HelicopterType type) {
        double radius = AirframeLayout.rotorRadius(type);
        int count=type==HelicopterType.KA52?3:5;
        double y=AirframeLayout.rotorY(type);
        body.tube(new Vec3(0,y-.83,-.53),new Vec3(0,y+(type==HelicopterType.KA52?.53:.04),-.53),.19,.13,12,STEEL);
        rotor.tube(new Vec3(0,-.10,0),new Vec3(0,.13,0),.48,.45,12,STEEL);
        for (int i=0;i<count;i++) {
            double a=i*Math.PI*2/count;
            Vec3 dir=new Vec3(Math.sin(a),0,Math.cos(a));
            Vec3 edge=new Vec3(dir.z,0,-dir.x);
            rotor.tube(dir.scale(.30),dir.scale(1.0),.09,.065,6,STEEL);
            Vec3 root=dir.scale(.88), tip=dir.scale(radius);
            rotor.face(root.add(edge.scale(-.24)),root.add(edge.scale(.19)),
                    tip.add(edge.scale(.12)).add(0,-.13,0),tip.add(edge.scale(-.19)).add(0,-.13,0),0x353c3d);
        }
        for(int i=0;i<3;i++) {
            double a=i*Math.PI*2/3;
            tail.tube(Vec3.ZERO,new Vec3(0,Math.cos(a)*1.12,Math.sin(a)*1.12),.10,.074,6,0x424b4b);
        }
    }

    private static Section sec(double z,double r,double bottom,double top) { return new Section(z,r,bottom,top); }
}
