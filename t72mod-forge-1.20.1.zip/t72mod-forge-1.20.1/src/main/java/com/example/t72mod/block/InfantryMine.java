package com.example.t72mod.block;

import com.example.t72mod.config.T72ServerConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class InfantryMine extends Block {
    public static final BooleanProperty ARMED = BooleanProperty.create("armed");
    public static final BooleanProperty OVERGROWN = BooleanProperty.create("overgrown");

    public InfantryMine(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(ARMED, false).setValue(OVERGROWN, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ARMED, OVERGROWN);
    }

    @Override public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(ARMED, T72ServerConfig.infantryMinesEnabled());
    }

    @Override public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.getValue(OVERGROWN) && level.getBlockState(pos.below()).is(Blocks.GRASS_BLOCK)
                && level.getMaxLocalRawBrightness(pos.above()) >= 9) {
            level.setBlock(pos, state.setValue(OVERGROWN, true), UPDATE_CLIENTS);
        }
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return box(4, 0, 4, 12, 2, 12);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        var held = player.getItemInHand(hand);
        if (held.is(Items.BONE_MEAL) && !state.getValue(OVERGROWN) && level.getBlockState(pos.below()).is(Blocks.GRASS_BLOCK)) {
            if (!level.isClientSide) {
                level.setBlock(pos, state.setValue(OVERGROWN, true), UPDATE_CLIENTS);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!player.isShiftKeyDown() || !held.is(Items.SHEARS)) return InteractionResult.PASS;
        if (!level.isClientSide) {
            boolean armed = !state.getValue(ARMED) && T72ServerConfig.infantryMinesEnabled();
            level.setBlock(pos, state.setValue(ARMED, armed), UPDATE_ALL);
            player.displayClientMessage(Component.translatable(armed ? "message.t72mod.mine_armed" : "message.t72mod.mine_safe"), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!(level instanceof ServerLevel server) || !state.getValue(ARMED) || !T72ServerConfig.infantryMinesEnabled()
                || !(entity instanceof LivingEntity living) || !living.isAlive() || living.isPassenger()
                || living instanceof Player player && (player.isCreative() || player.isSpectator())
                || !(living instanceof Player) && living.getType().getCategory() == MobCategory.MISC
                || living.getTags().contains("t72mod_mine_safe")
                || !living.getBoundingBox().intersects(new AABB(pos).deflate(.18, 0, .18)
                        .setMaxY(pos.getY() + .23))) return;
        BlockState current = level.getBlockState(pos);
        if (!current.is(this) || !current.getValue(ARMED) || !level.removeBlock(pos, false)) return;
        living.hurt(level.damageSources().explosion(null, null), T72ServerConfig.infantryMineDamage());
        server.sendParticles(ParticleTypes.EXPLOSION, pos.getX() + .5, pos.getY() + .25, pos.getZ() + .5, 1, 0, 0, 0, 0);
        level.playSound(null, pos, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, .9F, 1.3F);
    }
}
