package com.example.t72mod.block;

import com.example.t72mod.config.T72ServerConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class InfantryMine extends Block {
    public static final BooleanProperty ARMED = BooleanProperty.create("armed");

    public InfantryMine(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(ARMED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ARMED);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return box(4, 0, 4, 12, 2, 12);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND || !player.isShiftKeyDown()
                || !player.getItemInHand(hand).is(Items.SHEARS)) return InteractionResult.PASS;
        if (!level.isClientSide) {
            boolean armed = !state.getValue(ARMED) && T72ServerConfig.infantryMinesEnabled();
            level.setBlock(pos, state.setValue(ARMED, armed), UPDATE_ALL);
            player.displayClientMessage(Component.translatable(armed ? "message.t72mod.mine_armed" : "message.t72mod.mine_safe"), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!(level instanceof ServerLevel server) || !state.getValue(ARMED) || !T72ServerConfig.infantryMinesEnabled()
                || !(entity instanceof LivingEntity living) || !living.isAlive() || living.isPassenger()
                || living instanceof Player player && (player.isCreative() || player.isSpectator())
                || !(living instanceof Player) && living.getType().getCategory() == MobCategory.MISC
                || living.getTags().contains("t72mod_mine_safe")
                || Math.abs(living.getX() - pos.getX() - .5) > .36
                || Math.abs(living.getZ() - pos.getZ() - .5) > .36
                || living.getY() > pos.getY() + .25) return;
        if (!level.getBlockState(pos).is(this) || !level.removeBlock(pos, false)) return;
        living.hurt(level.damageSources().explosion(null, null), T72ServerConfig.infantryMineDamage());
        server.sendParticles(ParticleTypes.POOF, pos.getX() + .5, pos.getY() + .25, pos.getZ() + .5, 12, .3, .18, .3, .06);
        level.playSound(null, pos, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, .9F, 1.3F);
    }
}
