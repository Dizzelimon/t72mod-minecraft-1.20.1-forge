package com.example.t72mod.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Per-dimension quick markers for the artillery map (max 3 per dimension). */
public final class ArtilleryMarkerStore {
    public static final int MAX_MARKERS = 3;
    public static final String NBT_KEY = "t72mod_artillery_markers";

    public record Marker(int x, int z) {}

    private final Map<ResourceLocation, List<Marker>> byDimension = new HashMap<>();

    public List<Marker> list(ResourceLocation dimension) {
        List<Marker> markers = this.byDimension.get(dimension);
        return markers == null ? List.of() : Collections.unmodifiableList(new ArrayList<>(markers));
    }

    public boolean addMarker(ResourceLocation dimension, int x, int z) {
        List<Marker> list = this.byDimension.computeIfAbsent(dimension, k -> new ArrayList<>());
        for (Marker existing : list) {
            if (existing.x == x && existing.z == z) {
                return true;
            }
        }
        if (list.size() >= MAX_MARKERS) {
            return false;
        }
        list.add(new Marker(x, z));
        return true;
    }

    public boolean deleteMarker(ResourceLocation dimension, int index) {
        List<Marker> list = this.byDimension.get(dimension);
        if (list == null || index < 0 || index >= list.size()) {
            return false;
        }
        list.remove(index);
        if (list.isEmpty()) {
            this.byDimension.remove(dimension);
        }
        return true;
    }

    public void setMarkers(ResourceLocation dimension, List<Marker> markers) {
        if (markers == null || markers.isEmpty()) {
            this.byDimension.remove(dimension);
            return;
        }
        List<Marker> copy = new ArrayList<>();
        for (Marker marker : markers) {
            if (copy.size() >= MAX_MARKERS) break;
            copy.add(marker);
        }
        this.byDimension.put(dimension, copy);
    }

    public CompoundTag writeNbt() {
        CompoundTag root = new CompoundTag();
        for (Map.Entry<ResourceLocation, List<Marker>> entry : this.byDimension.entrySet()) {
            ListTag list = new ListTag();
            for (Marker marker : entry.getValue()) {
                CompoundTag item = new CompoundTag();
                item.putInt("X", marker.x);
                item.putInt("Z", marker.z);
                list.add(item);
            }
            root.put(entry.getKey().toString(), list);
        }
        return root;
    }

    public void readNbt(CompoundTag root) {
        this.byDimension.clear();
        if (root == null) return;
        for (String key : root.getAllKeys()) {
            ResourceLocation dim = ResourceLocation.tryParse(key);
            if (dim == null) continue;
            ListTag listTag = root.getList(key, Tag.TAG_COMPOUND);
            List<Marker> loaded = new ArrayList<>();
            for (int i = 0; i < listTag.size() && loaded.size() < MAX_MARKERS; i++) {
                CompoundTag item = listTag.getCompound(i);
                loaded.add(new Marker(item.getInt("X"), item.getInt("Z")));
            }
            if (!loaded.isEmpty()) {
                this.byDimension.put(dim, loaded);
            }
        }
    }
}
