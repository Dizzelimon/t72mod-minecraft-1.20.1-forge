package com.example.t72mod.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public final class GroundTraction {
    private static final TagKey<Block> MUD = surface("mud");
    private static final TagKey<Block> LOOSE = surface("loose");
    private static final TagKey<Block> SOIL = surface("soil");
    private float softness;
    private int lastSample = Integer.MIN_VALUE;
    private double wearDistance;

    private static TagKey<Block> surface(String name) {
        return TagKey.create(Registries.BLOCK, new ResourceLocation("t72mod", "surface/" + name));
    }

    public static BlockPos contact(Entity vehicle, double side, double forward) {
        double yaw = Math.toRadians(vehicle.getYRot());
        return BlockPos.containing(vehicle.getX() + side * Math.cos(yaw) - forward * Math.sin(yaw),
                vehicle.getY() - .05, vehicle.getZ() + side * Math.sin(yaw) + forward * Math.cos(yaw));
    }

    public static float sample(Entity vehicle, BlockPos pos) {
        if (!vehicle.level().hasChunkAt(pos)) return 0;
        BlockState base = vehicle.level().getBlockState(pos);
        if (base.is(MUD)) return 1;
        if (base.is(LOOSE) || vehicle.level().getBlockState(pos.above()).is(LOOSE)) return .6f;
        if (base.is(SOIL)) return vehicle.level().isRainingAt(pos.above()) ? .4f : .15f;
        return 0;
    }

    public float update(Entity vehicle) {
        if (!vehicle.onGround() || vehicle.isInWater()) return 0;
        if (lastSample != Integer.MIN_VALUE && vehicle.tickCount - lastSample < 4) return softness;
        float sum = 0;
        for (int side = -1; side <= 1; side += 2)
            for (int end = -1; end <= 1; end += 2)
                sum += sample(vehicle, contact(vehicle, side * .9, end * 1.4));
        float target = sum / 4;
        softness = lastSample == Integer.MIN_VALUE ? target : (softness + target) * .5f;
        lastSample = vehicle.tickCount;
        return softness;
    }

    public boolean wear(Entity vehicle) {
        double distance = Math.hypot(vehicle.getX() - vehicle.xo, vehicle.getZ() - vehicle.zo);
        if (!vehicle.onGround() || vehicle.isInWater() || distance < .01 || distance > 2) return false;
        wearDistance += distance * (.20 + update(vehicle));
        if (wearDistance < 300) return false;
        wearDistance -= 300;
        return true;
    }

    public double distance() { return wearDistance; }
    public void restore(double value) {
        wearDistance = Double.isFinite(value) ? Math.max(0, Math.min(300, value)) : 0;
    }

    public static float tankFactor(TankType type,float soft) {
        float penalty = switch (type) {
            case BMP3 -> .14f;
            case T72B,T90M -> .22f;
            case LEOPARD2 -> .26f;
            case ABRAMS -> .30f;
        };
        return 1-soft*penalty;
    }
}
