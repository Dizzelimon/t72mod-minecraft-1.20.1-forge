package com.example.t72mod.entity;

import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Original FPV feel for the Minecraft recon drone. Values are in game ticks and blocks. */
public final class FpvFlight {
    public static final int RANGE = 300;
    public static final int FORWARD = 1, BACK = 2, LEFT = 4, RIGHT = 8, UP = 16, DOWN = 32, BOOST = 64;

    private FpvFlight() {}

    public record State(float yaw, float pitch, float roll, double throttle, Vec3 velocity) {}

    public static State step(State state, int keys, float turn, float tilt) {
        return step(state, keys, turn, tilt, false);
    }

    public static State step(State state, int keys, float turn, float tilt, boolean freeAttitude) {
        int throttleStick = axis(keys, FORWARD, BACK);
        int yawStick = axis(keys, RIGHT, LEFT);
        int lift = axis(keys, UP, DOWN);
        boolean boost = (keys & BOOST) != 0;
        float pitch = Mth.clamp(state.pitch + Mth.clamp(tilt, -24, 24), -80, 80);
        float roll = Mth.clamp(state.roll + Mth.clamp(turn, -31, 31), -85, 85);
        if (!freeAttitude) {
            if (Math.abs(tilt) < .15F) pitch = Mth.approach(pitch, 0, 4.5F);
            if (Math.abs(turn) < .15F) roll = Mth.approach(roll, 0, 5.5F);
        }
        float yaw = Mth.wrapDegrees(state.yaw + yawStick * 10.5F);
        double throttle = Mth.clamp(state.throttle + throttleStick * .037, .12, 1.08);
        double thrust = Mth.clamp(throttle + lift * .32 + (boost ? .21 : 0), 0, 1.29);
        double pitchRad = pitch * Mth.DEG_TO_RAD;
        double rollRad = roll * Mth.DEG_TO_RAD;
        Vec3 acceleration = AirframeLayout.world(Vec3.ZERO, yaw, -Math.sin(rollRad), 0,
                Math.sin(pitchRad) * Math.cos(rollRad)).scale(thrust * .36);
        double liftEffect = thrust * Math.cos(pitchRad) * Math.cos(rollRad);
        double vy = Mth.clamp(state.velocity.y * .85 + (liftEffect - .61) * .50, -.94, 1.0);
        Vec3 velocity = state.velocity.multiply(.90, 0, .90).add(acceleration).add(0, vy, 0);
        double horizontal = velocity.horizontalDistance();
        double max = boost ? 2.30 : 1.65;
        if (horizontal > max) velocity = velocity.multiply(max / horizontal, 1, max / horizontal);
        return new State(yaw, pitch, roll, throttle, velocity);
    }

    public static Vec3 limitSignal(Vec3 at, Vec3 proposed, Vec3 pilot) {
        Vec3 radial = at.subtract(pilot);
        if (at.add(proposed).distanceToSqr(pilot) <= (double) RANGE * RANGE) return proposed;
        if (radial.lengthSqr() <= 1.0E-7) return proposed;
        Vec3 axis = radial.normalize();
        return proposed.subtract(axis.scale(Math.max(0, proposed.dot(axis)) + .07));
    }

    private static int axis(int keys, int positive, int negative) {
        return ((keys & positive) == 0 ? 0 : 1) - ((keys & negative) == 0 ? 0 : 1);
    }
}
