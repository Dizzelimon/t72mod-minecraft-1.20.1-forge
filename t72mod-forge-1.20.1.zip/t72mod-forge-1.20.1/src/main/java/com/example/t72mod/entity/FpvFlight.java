package com.example.t72mod.entity;

import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Original FPV feel for the Minecraft recon drone. Values are in game ticks and blocks. */
public final class FpvFlight {
    public static final int RANGE = 300;
    public static final int FORWARD = 1, BACK = 2, LEFT = 4, RIGHT = 8, UP = 16, DOWN = 32, BOOST = 64;

    private FpvFlight() {}

    public record State(float yaw, float pitch, float roll, double throttle, Vec3 velocity) {}

    public static State step(State state, int keys, float turn, float tilt) {
        return step(state, keys, turn, tilt, false);
    }

    public static State step(State state, int keys, float turn, float tilt, boolean freeAttitude) {
        int pitchStick = axis(keys, FORWARD, BACK);
        int rollStick = axis(keys, RIGHT, LEFT);
        int lift = axis(keys, UP, DOWN);
        boolean boost = (keys & BOOST) != 0;
        float pitch = Mth.clamp(state.pitch + Mth.clamp(tilt, -17, 17) + pitchStick * 4.2F, -74, 77);
        if (!freeAttitude && pitchStick == 0 && Math.abs(tilt) < .15F) pitch = Mth.approach(pitch, 0, 3.4F);
        float roll = freeAttitude ? Mth.clamp(state.roll + rollStick * 11, -80, 80)
                : Mth.lerp(.43F, state.roll, rollStick * 63F);
        float yaw = Mth.wrapDegrees(state.yaw + Mth.clamp(turn, -29, 29) + rollStick * 3.5F);
        double throttle = Mth.lerp(.35, state.throttle, boost ? 1.12 : .61 + lift * .36);
        double forward = Math.sin(pitch * Mth.DEG_TO_RAD);
        double sideways = Math.sin(roll * Mth.DEG_TO_RAD);
        Vec3 acceleration = AirframeLayout.world(Vec3.ZERO, yaw, -sideways, 0, forward)
                .scale(throttle * (boost ? .34 : .25));
        double liftEffect = throttle * (1 - Math.abs(forward) * .25 - Math.abs(sideways) * .22);
        double vy = Mth.clamp(state.velocity.y * .83 + (liftEffect - .61) * .55, -.82, 1.0);
        Vec3 velocity = state.velocity.multiply(.87, 0, .87).add(acceleration).add(0, vy, 0);
        double horizontal = velocity.horizontalDistance();
        double max = boost ? 2.0 : 1.40;
        if (horizontal > max) velocity = velocity.multiply(max / horizontal, 1, max / horizontal);
        return new State(yaw, pitch, roll, throttle, velocity);
    }

    public static Vec3 limitSignal(Vec3 at, Vec3 proposed, Vec3 pilot) {
        Vec3 radial = at.subtract(pilot);
        if (at.add(proposed).distanceToSqr(pilot) <= (double) RANGE * RANGE) return proposed;
        if (radial.lengthSqr() <= 1.0E-7) return proposed;
        Vec3 axis = radial.normalize();
        return proposed.subtract(axis.scale(Math.max(0, proposed.dot(axis)) + .07));
    }

    private static int axis(int keys, int positive, int negative) {
        return ((keys & positive) == 0 ? 0 : 1) - ((keys & negative) == 0 ? 0 : 1);
    }
}
