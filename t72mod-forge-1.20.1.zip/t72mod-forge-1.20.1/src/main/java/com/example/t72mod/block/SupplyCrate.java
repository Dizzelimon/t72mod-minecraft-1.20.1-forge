package com.example.t72mod.block;

import com.example.t72mod.T72Mod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public final class SupplyCrate extends BaseEntityBlock {
    public SupplyCrate(Properties properties) { super(properties); }

    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new Storage(pos, state); }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand,
                                 BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof Storage storage) player.openMenu(storage);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState next, boolean moving) {
        if (!next.is(state.getBlock()) && level.getBlockEntity(pos) instanceof Storage storage)
            Containers.dropContents(level, pos, storage);
        super.onRemove(state, level, pos, next, moving);
    }

    public static final class Storage extends RandomizableContainerBlockEntity {
        private NonNullList<ItemStack> items = NonNullList.withSize(27, ItemStack.EMPTY);

        public Storage(BlockPos pos, BlockState state) { super(T72Mod.SUPPLY_STORAGE.get(), pos, state); }

        @Override protected Component getDefaultName() {
            return Component.translatable("block.t72mod.supply_crate");
        }

        @Override public int getContainerSize() { return this.items.size(); }
        @Override protected NonNullList<ItemStack> getItems() { return this.items; }
        @Override protected void setItems(NonNullList<ItemStack> next) { this.items = next; }

        @Override protected AbstractContainerMenu createMenu(int id, Inventory inventory) {
            return ChestMenu.threeRows(id, inventory, this);
        }

        @Override public void load(CompoundTag tag) {
            super.load(tag);
            this.items = NonNullList.withSize(27, ItemStack.EMPTY);
            if (!this.tryLoadLootTable(tag)) ContainerHelper.loadAllItems(tag, this.items);
        }

        @Override protected void saveAdditional(CompoundTag tag) {
            super.saveAdditional(tag);
            if (!this.trySaveLootTable(tag)) ContainerHelper.saveAllItems(tag, this.items);
        }
    }
}
