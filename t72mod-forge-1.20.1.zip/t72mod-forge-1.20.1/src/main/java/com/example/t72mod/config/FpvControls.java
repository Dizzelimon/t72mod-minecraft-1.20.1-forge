package com.example.t72mod.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class FpvControls {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue ROLL, PITCH, DEAD_ZONE;
    public static final ForgeConfigSpec.BooleanValue GAMEPAD, INVERT;
    public static final ForgeConfigSpec.IntValue DEVICE;
    static {
        var config=new ForgeConfigSpec.Builder();
        config.push("fpv");
        ROLL=config.defineInRange("rollSensitivity",1.0,.1,3);
        PITCH=config.defineInRange("pitchSensitivity",1.0,.1,3);
        INVERT=config.define("invertPitch",false);
        GAMEPAD=config.define("enableGamepad",false);
        DEVICE=config.comment("GLFW gamepad number, starting at 1").defineInRange("gamepad",1,1,16);
        DEAD_ZONE=config.defineInRange("stickDeadZone",.12,0,.65);
        config.pop();
        SPEC=config.build();
    }
    private FpvControls() {}
    public static float stick(float raw,double deadZone) {
        if (!Float.isFinite(raw) || Math.abs(raw)<=deadZone) return 0;
        return (float)Math.copySign((Math.min(1,Math.abs(raw))-deadZone)/(1-deadZone),raw);
    }
}
