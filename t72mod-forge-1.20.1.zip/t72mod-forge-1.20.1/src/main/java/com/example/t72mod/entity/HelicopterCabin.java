package com.example.t72mod.entity;

import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Standing space, doorway and seat coordinates shared with the airframe model. */
public final class HelicopterCabin {
    private static final HelicopterCabin MI8 = new HelicopterCabin(1.35, 3.45, -3.61, 4.10, 1.56, 1.23, 1.76,
            new Vec3(-.67,1.67,3.47), new Vec3(.67,1.67,3.47), new Vec3(-1.10,1.68,-1.18),
            new Vec3(1.10,1.68,-1.18),new Vec3(-1.10,1.68,-2.14));
    private static final HelicopterCabin MI24 = new HelicopterCabin(1.10,3.31,.78,4.63,1.17,2.20,1.60,
            new Vec3(-.04,1.77,2.31),new Vec3(.04,1.49,3.70),new Vec3(-.46,1.48,1.05));
    private static final HelicopterCabin KA52 = new HelicopterCabin(1.16,3.25,1.14,4.04,1.23,2.05,1.61,
            new Vec3(-.56,1.52,2.86),new Vec3(.56,1.52,2.86));
    public final double floor, ceiling, rear, front, halfWidth, doorZ, doorWidth;
    private final Vec3[] seats;
    private final CabinSection[] shells;
    private static final EntityDimensions SEAT_HITBOX = EntityDimensions.fixed(.49F, .88F);

    private HelicopterCabin(double floor,double ceiling,double rear,double front,double halfWidth,
                            double doorZ,double doorWidth,Vec3... seats) {
        this.floor = floor;
        this.ceiling = ceiling;
        this.rear = rear;
        this.front = front;
        this.halfWidth = halfWidth;
        this.doorZ = doorZ;
        this.doorWidth = doorWidth;
        this.seats = seats;
        this.shells = this.buildShell();
    }

    public static HelicopterCabin forType(HelicopterType type) {
        return switch (type) { case MI8 -> MI8; case MI24 -> MI24; case KA52 -> KA52; };
    }

    private CabinSection[] buildShell() {
        List<CabinSection> parts = new ArrayList<>();
        int segments = (int) Math.ceil((this.front - this.rear) / .75);
        double length = (this.front - this.rear) / segments;
        for (int i = 0; i < segments; i++) {
            double z = this.rear + (i + .5) * length;
            parts.add(new CabinSection(0,this.floor-.13,z,2*this.halfWidth,.13,length+.015));
            parts.add(new CabinSection(0,this.ceiling,z,2*this.halfWidth-.15,.13,length+.015));
        }
        CabinSection.wall(parts,-this.halfWidth,this.floor,this.rear,this.front,this.ceiling-this.floor);
        CabinSection.wall(parts,this.halfWidth,this.floor,this.rear,this.doorZ-this.doorWidth/2,this.ceiling-this.floor);
        CabinSection.wall(parts,this.halfWidth,this.floor,this.doorZ+this.doorWidth/2,this.front,this.ceiling-this.floor);
        CabinSection.crossWall(parts,this.rear,this.floor,this.halfWidth,this.ceiling-this.floor);
        CabinSection.crossWall(parts,this.front,this.floor,this.halfWidth,this.ceiling-this.floor);
        parts.add(new CabinSection(this.halfWidth+.82,.25,this.doorZ,.78,.21,1.08));
        parts.add(new CabinSection(this.halfWidth+.49,.61,this.doorZ,.59,.21,1.08));
        parts.add(new CabinSection(this.halfWidth+.22,this.floor-.25,this.doorZ,.44,.18,1.08));
        return parts.toArray(CabinSection[]::new);
    }

    public boolean contains(Vec3 p) {
        return Math.abs(p.x) < this.halfWidth+.04 && p.z > this.rear-.03 && p.z < this.front+.03
                && p.y > this.floor-.15 && p.y < this.ceiling;
    }

    public boolean nearPilotSeat(Vec3 p) {
        Vec3 pilot = this.seats[0];
        return this.contains(p) && Math.abs(p.z - pilot.z) < 1.34
                && Math.abs(p.x - pilot.x) < 1.14;
    }

    public Vec3 seat(int index) { return this.seats[index]; }
    public int seatCount() { return this.seats.length; }

    public Vec3 seatHitCenter(int index) {
        Vec3 seat = this.seat(index);
        return new Vec3(seat.x, Math.max(this.floor+.06,seat.y-.21),seat.z);
    }

    public CabinSection shell(int index) { return this.shells[index - this.seats.length]; }

    public EntityDimensions[] partDimensions(EntityDimensions[] prefix) {
        var result = java.util.Arrays.copyOf(prefix,prefix.length+this.seats.length+this.shells.length);
        java.util.Arrays.fill(result,prefix.length,prefix.length+this.seats.length,SEAT_HITBOX);
        for (int i = 0; i < this.shells.length; i++) result[prefix.length+this.seats.length+i] = this.shells[i].dimensions();
        return result;
    }

    public CabinSection step(int index) { return this.shells[this.shells.length-3+index]; }
}
