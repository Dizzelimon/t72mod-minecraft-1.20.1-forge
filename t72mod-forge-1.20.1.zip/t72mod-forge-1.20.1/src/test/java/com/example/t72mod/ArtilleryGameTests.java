package com.example.t72mod;

import com.electronwill.nightconfig.core.CommentedConfig;
import com.example.t72mod.config.T72ServerConfig;
import com.example.t72mod.entity.ArtilleryBallistics;
import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.ArtilleryMarkerStore;
import com.example.t72mod.entity.VehiclePart;
import com.example.t72mod.network.ArtilleryMarkerPacket;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.fml.config.ConfigTracker;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@GameTestHolder(T72Mod.MODID)
public class ArtilleryGameTests {
    private static final TicketType<Integer> TEST_PATH = TicketType.create("t72mod_artillery_test", Integer::compare, 250);

    private static final class SpyOperator extends FakePlayer {
        Component lastClientMessage;

        SpyOperator(ServerLevel level, String name) {
            super(level, new GameProfile(UUID.randomUUID(), name));
        }

        @Override
        public void displayClientMessage(Component component, boolean actionBar) {
            this.lastClientMessage = component;
        }
    }

    private static ArtilleryEntity spawnArmedArtillery(GameTestHelper helper) {
        BlockPos localFloor = new BlockPos(1, 0, 1);
        helper.setBlock(localFloor, Blocks.STONE);
        ArtilleryEntity gun = helper.spawn(T72Mod.ARTILLERY.get(), new BlockPos(1, 1, 1));
        gun.loadStarterAmmo(); // 3 rounds
        gun.setOnGround(true);
        return gun;
    }

    private static List<ChunkPos> forceLine(ServerLevel level, ArtilleryEntity gun, int targetX, int targetZ) {
        List<ChunkPos> forced = new ArrayList<>();
        for (var point : ArtilleryBallistics.trajectorySamples(gun.getX(), gun.getZ(), targetX, targetZ)) {
            ChunkPos chunk = new ChunkPos(new BlockPos(point.blockX(), 0, point.blockZ()));
            if (forced.contains(chunk)) continue;
            level.getChunkSource().addRegionTicket(TEST_PATH, chunk, 4, gun.getId());
            level.getChunk(chunk.x, chunk.z);
            forced.add(chunk);
        }
        return forced;
    }

    private static void unforceAll(ServerLevel level, ArtilleryEntity gun, List<ChunkPos> chunks) {
        for (ChunkPos chunk : chunks) {
            level.getChunkSource().removeRegionTicket(TEST_PATH, chunk, 4, gun.getId());
        }
    }

    @PrefixGameTestTemplate(false)
    @GameTest(template = "empty", timeoutTicks = 80)
    public static void testOldRangeShotAndHitboxesAndAim(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        ArtilleryEntity gun = spawnArmedArtillery(helper);
        SpyOperator player = new SpyOperator(level, "OldRangeTester");
        player.setPos(gun.getX(), gun.getY(), gun.getZ());
        player.startRiding(gun, true);

        int tx = gun.getBlockX() + 48;
        int tz = gun.getBlockZ();
        List<ChunkPos> forced = forceLine(level, gun, tx, tz);
        try {
            gun.aimAt(player, tx, tz);
            float aimedYaw = gun.getYRot();
            int aimedElev = gun.elevation();
            helper.assertTrue(Math.abs(aimedYaw + 90.0F) < 5.0F, "Expected +X yaw ~ -90, got " + aimedYaw);
            helper.assertTrue(aimedElev > 20 && aimedElev < 80, "Expected valid elevation, got " + aimedElev);

            int beforeAmmo = gun.ammunition();
            boolean fired = gun.shootAt(player, tx, tz);
            helper.assertTrue(fired, "Shot at 48 blocks should succeed; msg=" + player.lastClientMessage);
            helper.assertTrue(gun.ammunition() == beforeAmmo - 1, "Exactly 1 shell must be consumed");
            helper.assertTrue(gun.reloadTicks() > 0, "Reload cooldown should start");
        } finally {
            unforceAll(level, gun, forced);
        }

        helper.runAfterDelay(5, () -> {
            VehiclePart[] parts=gun.getParts();
            helper.assertTrue(parts.length==10,"Expected 10 articulation shapes");
            helper.assertTrue(level.getEntityOrPart(parts[0].getId())==parts[0],
                    "Expected a Forge part reachable by interaction packet");
            helper.succeed();
        });
    }

    @PrefixGameTestTemplate(false)
    @GameTest(template = "empty", timeoutTicks = 220)
    public static void testBeyondOldLimitAndNearNewLimit(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        helper.assertTrue(ArtilleryEntity.maxRange() == 300,
                "Default server maxRange must be 300, got " + ArtilleryEntity.maxRange());

        ArtilleryEntity gun140 = spawnArmedArtillery(helper);
        SpyOperator p1 = new SpyOperator(level, "Tester140");
        p1.setPos(gun140.getX(), gun140.getY(), gun140.getZ());
        p1.startRiding(gun140, true);
        int tx140 = gun140.getBlockX() + 140;
        int tz140 = gun140.getBlockZ();
        List<ChunkPos> f140 = forceLine(level, gun140, tx140, tz140);

        ArtilleryEntity gun299 = spawnArmedArtillery(helper);
        SpyOperator p2 = new SpyOperator(level, "Tester299");
        p2.setPos(gun299.getX(), gun299.getY(), gun299.getZ());
        p2.startRiding(gun299, true);
        int tx299 = gun299.getBlockX();
        int tz299 = gun299.getBlockZ() + 299;
        List<ChunkPos> f299 = forceLine(level, gun299, tx299, tz299);
        helper.startSequence().thenWaitUntil(() -> {
            helper.assertTrue(ArtilleryEntity.canSimulatePath(level, gun140.getX(), gun140.getZ(), tx140, tz140)
                    && ArtilleryEntity.canSimulatePath(level, gun299.getX(), gun299.getZ(), tx299, tz299),
                    "Waiting for both artillery paths to enter entity simulation");
        }).thenExecute(() -> {
            try {
                int ammo140 = gun140.ammunition();
                helper.assertTrue(gun140.shootAt(p1, tx140, tz140),
                        "Shot at 140 blocks failed: " + p1.lastClientMessage);
                helper.assertTrue(gun140.ammunition() == ammo140 - 1, "Must consume 1 round at 140");

                int ammo299 = gun299.ammunition();
                helper.assertTrue(gun299.shootAt(p2, tx299, tz299),
                        "Shot at 299 blocks failed: " + p2.lastClientMessage);
                helper.assertTrue(gun299.ammunition() == ammo299 - 1, "Must consume 1 round at 299");
            } finally {
                unforceAll(level, gun140, f140);
                unforceAll(level, gun299, f299);
            }
        }).thenSucceed();
    }

    @PrefixGameTestTemplate(false)
    @GameTest(template = "empty", timeoutTicks = 80)
    public static void testOverLimitUnloadedAndConfigParity(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        ArtilleryEntity gun = spawnArmedArtillery(helper);
        SpyOperator player = new SpyOperator(level, "LimitTester");
        player.setPos(gun.getX(), gun.getY(), gun.getZ());
        player.startRiding(gun, true);
        int startAmmo = gun.ammunition();

        // 1. Beyond configured limit (301 > 300): rejected, ammo preserved
        boolean overLimit = gun.shootAt(player, gun.getBlockX() + 301, gun.getBlockZ());
        helper.assertFalse(overLimit, "Shot beyond 300 limit must be rejected");
        helper.assertTrue(gun.ammunition() == startAmmo, "Ammo must be preserved beyond limit");
        helper.assertTrue(player.lastClientMessage != null
                && player.lastClientMessage.getString().contains("300"),
                "Expected out-of-range message referencing 300, got " + player.lastClientMessage);

        // 2. Unloaded / non-simulating chunk within configured range (no permanent chunk force-loading!)
        var original = gun.position();
        gun.setPos(original.add(20_000, 0, 20_000));
        try {
            int txUnloaded = gun.getBlockX() - 185;
            int tzUnloaded = gun.getBlockZ() - 18;
            helper.assertFalse(ArtilleryEntity.canSimulatePath(level, gun.getX(), gun.getZ(), txUnloaded, tzUnloaded),
                    "Distant unforced chunk should not be entity-ticking");
            helper.assertFalse(gun.shootAt(player, txUnloaded, tzUnloaded),
                    "Shot to non-simulating chunk must be rejected");
            helper.assertTrue(gun.ammunition() == startAmmo, "Ammo must be preserved when simulation is unavailable");
        } finally {
            gun.setPos(original);
        }

        // 3. Server config override parity: lower config to 100 and check 120 fails cleanly without spending shell
        ModConfig loaded = ConfigTracker.INSTANCE.configSets().get(ModConfig.Type.SERVER).stream()
                .filter(config -> config.getModId().equals(T72Mod.MODID)).findFirst().orElseThrow();
        CommentedConfig override = CommentedConfig.inMemory();
        override.set("artillery.maxRange", 100);
        try {
            T72ServerConfig.SPEC.setConfig(override);
            helper.assertTrue(ArtilleryEntity.maxRange() == 100, "ArtilleryEntity.maxRange must reflect config");
            boolean denied = gun.shootAt(player, gun.getBlockX() + 120, gun.getBlockZ());
            helper.assertFalse(denied, "Shot at 120 when config is 100 must be rejected");
            helper.assertTrue(gun.ammunition() == startAmmo, "Ammo must be preserved when rejected by config");
        } finally {
            T72ServerConfig.SPEC.setConfig(loaded.getConfigData());
        }

        // 4. Quick marker limit per dimension on ServerPlayer
        ResourceLocation dim = Level.OVERWORLD.location();
        ArtilleryMarkerStore store = new ArtilleryMarkerStore();
        helper.assertTrue(store.addMarker(dim, 10, 10), "Marker 1 added");
        helper.assertTrue(store.addMarker(dim, 20, 20), "Marker 2 added");
        helper.assertTrue(store.addMarker(dim, 30, 30), "Marker 3 added");
        helper.assertFalse(store.addMarker(dim, 40, 40), "4th marker rejected");
        ArtilleryMarkerPacket.savePlayerStore(player, store);
        helper.assertTrue(ArtilleryMarkerPacket.loadPlayerStore(player).list(dim).size() == 3,
                "Player persistent NBT must store 3 markers");

        helper.succeed();
    }
}
