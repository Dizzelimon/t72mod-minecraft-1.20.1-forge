package com.example.t72mod;

import com.example.t72mod.entity.AirframeLayout;
import com.example.t72mod.entity.HelicopterCabin;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.TankGeometry;
import com.example.t72mod.entity.VehiclePart;
import com.example.t72mod.entity.VehiclePartEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

@GameTestHolder(T72Mod.MODID)
@PrefixGameTestTemplate(false)
public final class VehicleGameTests {
    private static final BlockPos CENTER=new BlockPos(17,2,11);

    private static void pad(GameTestHelper helper) {
        for (int x=5;x<=29;x++) for (int z=3;z<=20;z++) helper.setBlock(new BlockPos(x,1,z),Blocks.STONE);
    }

    private static Vec3 offset(Entity entity,double x,double y,double z) {
        return AirframeLayout.world(entity.position(),entity.getYRot(),x,y,z);
    }

    private static Vec3 local(Entity aircraft,Entity traveler) {
        return AirframeLayout.local(aircraft.position(),aircraft.getYRot(),traveler.position());
    }

    @GameTest(template="vehicle_pad",timeoutTicks=160)
    public static void cabinHoverAndIndependentSeat(GameTestHelper helper) {
        pad(helper);
        HelicopterEntity air=helper.spawn(T72Mod.MI8.get(),CENTER);
        air.setYRot(39);
        air.giveStarterFuel();
        FakePlayer pilot=new FakePlayer(helper.getLevel(),new GameProfile(UUID.randomUUID(),"Mi8TestPilot"));
        pilot.setPos(air.position());
        helper.getLevel().addNewPlayer(pilot);
        pilot.setGameMode(GameType.SURVIVAL);
        helper.runAtTickTime(18,()->{
            helper.assertTrue(air.isCabinOpen(),"Expected landed cabin");
            pilot.setPos(offset(air,0,1.37,2.70));
            air.handleCrewAction(pilot,HelicopterEntity.SELECT_SEAT);
            helper.assertTrue(air.isPilot(pilot),"Could not mount the specific pilot seat");
            air.handleAction(pilot,HelicopterEntity.TOGGLE_ENGINE);
            helper.assertTrue(air.engineOn(),"Engine failed to start");
        });
        for (int tick=62;tick<=92;tick++) helper.runAtTickTime(tick,
                ()->air.acceptInput(pilot,HelicopterEntity.ASCEND));
        double[] altitude={0};
        helper.runAtTickTime(93,()->{
            helper.assertTrue(air.getY()>helper.absolutePos(CENTER).getY()+5,"No takeoff");
            altitude[0]=air.getY();
            air.handleCrewAction(pilot, HelicopterEntity.TOGGLE_RAMP);
            helper.assertTrue(air.isRampOpen(), "Pilot could not open the rear ramp in flight");
            pilot.stopRiding();
            Vec3 foot=local(air,pilot);
            helper.assertTrue(!pilot.isPassenger() && HelicopterCabin.forType(air.model()).contains(foot),
                    "Dismount did not place pilot in cabin: "+foot);
        });
        helper.runAtTickTime(103,()->{
            helper.assertTrue(air.deckHold() && Math.abs(air.getY()-altitude[0])<.35,
                    "Empty pilot seat with cabin walker did not hold altitude");
            helper.assertTrue(air.isRampOpen(), "Airborne tick closed the rear ramp");
            // An off-centre route still fits through the widened bulkhead.
            Vec3 beforeBulkhead = new Vec3(.48, 1.37, 2.67);
            Vec3 throughBulkhead = new Vec3(.48, 1.37, 1.68);
            helper.assertTrue(air.constrainWalker(throughBulkhead, beforeBulkhead).distanceToSqr(throughBulkhead) < .001,
                    "Widened cabin doorway still blocks a valid path");
            var outside = helper.makeMockSurvivalPlayer();
            outside.setPos(offset(air, 0, 0, -5.9));
            air.handleCrewAction(outside, HelicopterEntity.TOGGLE_RAMP);
            helper.assertTrue(air.isRampOpen(), "A player outside the airborne Mi-8 closed the ramp");
            for (int step=0;step<32;step++)
                pilot.move(MoverType.SELF,AirframeLayout.world(Vec3.ZERO,air.getYRot(),0,0,-.13));
            Vec3 foot=local(air,pilot);
            helper.assertTrue(foot.z<-.76 && Math.abs(foot.y-1.35)<.10,"Could not walk rearward: "+foot);
            air.handleCrewAction(pilot, HelicopterEntity.TOGGLE_RAMP);
            helper.assertTrue(!air.isRampOpen(), "Standing crew member could not close the ramp in flight");
            air.handleCrewAction(pilot,HelicopterEntity.SELECT_SEAT+2);
            helper.assertTrue(pilot.getVehicle()==air && !air.isPilot(pilot),"Passenger seat picked up pilot role");
        });
        helper.runAtTickTime(115,()->{
            helper.assertTrue(Math.abs(air.getY()-altitude[0])<.6,"Craft fell with passenger and no pilot");
            Vec3 foot=local(air,pilot);
            helper.assertTrue(foot.x<-.85 && foot.z<-.85,"Passenger moved to the wrong seat: "+foot);
            pilot.discard();
            helper.succeed();
        });
    }

    @GameTest(template="vehicle_pad")
    public static void rearRampAndRocketMagazine(GameTestHelper helper) {
        pad(helper);
        HelicopterEntity air=helper.spawn(T72Mod.MI8.get(),CENTER);
        air.giveStarterFuel();
        air.setYRot(33);
        Player player=helper.makeMockSurvivalPlayer();
        helper.runAtTickTime(18,()->{
            player.setPos(offset(air,0,0,-5.9));
            air.handleCrewAction(player,HelicopterEntity.TOGGLE_RAMP);
            helper.assertTrue(air.isRampOpen(),"Rear switch did not work from ground");
            player.getInventory().setItem(0,new ItemStack(T72Mod.AIR_ROCKET.get(),16));
            air.handleCrewAction(player,HelicopterEntity.RELOAD_ROCKETS);
            helper.assertTrue(air.rockets()==12 && player.getInventory().getItem(0).getCount()==8,
                    "Reload did not leave excess rockets in inventory");
            air.handleCrewAction(player,HelicopterEntity.RELOAD_ROCKETS);
            helper.assertTrue(player.getInventory().getItem(0).getCount()==8,"Full rails consumed ammunition");
        });
        helper.runAtTickTime(37,()->{
            helper.assertTrue(air.rampProgress(1)==1,"Ramp did not deploy");
            var ramp=HelicopterCabin.forType(air.model()).rampStep(1);
            player.setPos(offset(air,0,ramp.y()+ramp.height()+.12,ramp.z()));
            player.move(MoverType.SELF,new Vec3(0,-.27,0));
            helper.assertTrue(Math.abs(local(air,player).y-ramp.y()-ramp.height())<.06,
                    "Ramp did not support standing player");
            air.handleCrewAction(player,HelicopterEntity.TOGGLE_RAMP);
            helper.assertTrue(!air.isRampOpen(),"Rear switch did not close");
            helper.succeed();
        });
    }

    @GameTest(template="vehicle_pad")
    public static void vehiclePartsStayWithParentAndSupportBarrel(GameTestHelper helper) {
        pad(helper);
        HelicopterEntity air=helper.spawn(T72Mod.MI8.get(),CENTER.offset(-6,0,0));
        T72TankEntity tank=helper.spawn(T72Mod.T90M_TANK.get(),CENTER.offset(5,0,0));
        tank.setTurretYaw(26);
        helper.runAtTickTime(18,()->{
            helper.assertTrue(air.getParts().length==21 && tank.getParts().length==15,"Multipart budgets changed");
            for (VehiclePart part : tank.getParts()) {
                helper.assertTrue(helper.getLevel().getEntity(part.getId())==null,"Part exists as tracked entity");
                helper.assertTrue(helper.getLevel().getEntityOrPart(part.getId())==part,"Part not reachable for hits");
            }
            helper.assertTrue(helper.getLevel().getEntitiesOfClass(VehiclePartEntity.class,
                    air.getBoundingBox().inflate(8)).isEmpty(),"Vehicles still spawn ticked collision entities");
            Player p=helper.makeMockSurvivalPlayer();
            Vec3 base=TankGeometry.barrelPivot(tank.position(),tank.getYRot(),tank.getTurretYaw(),tank.getTankType());
            Vec3 sample=base.add(Vec3.directionFromRotation(tank.getBarrelPitch(),tank.getTurretYaw()).scale(4.6));
            p.setPos(sample.add(0,.64,0));
            p.move(MoverType.SELF,new Vec3(0,-1.06,0));
            helper.assertTrue(Math.abs(p.getY()-sample.y)<.3,"No support on tank barrel");
            int oldId=tank.getParts()[0].getId();
            tank.discard();
            helper.assertTrue(helper.getLevel().getEntityOrPart(oldId)==null,"Parts leaked after removal");
            helper.succeed();
        });
    }
}
