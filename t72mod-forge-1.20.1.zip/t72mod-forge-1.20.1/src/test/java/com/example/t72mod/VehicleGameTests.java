package com.example.t72mod;

import com.example.t72mod.entity.AirframeLayout;
import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.BmpCabin;
import com.example.t72mod.entity.FieldVehicleEntity;
import com.example.t72mod.entity.FpvDroneEntity;
import com.example.t72mod.entity.FpvFlight;
import com.example.t72mod.entity.HelicopterCabin;
import com.example.t72mod.entity.HelicopterEntity;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.TankGeometry;
import com.example.t72mod.entity.VehiclePart;
import com.example.t72mod.entity.VehiclePartEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

@GameTestHolder(T72Mod.MODID)
@PrefixGameTestTemplate(false)
public final class VehicleGameTests {
    private static final BlockPos CENTER=new BlockPos(17,2,11);

    private static void pad(GameTestHelper helper) {
        for (int x=5;x<=29;x++) for (int z=3;z<=20;z++) helper.setBlock(new BlockPos(x,1,z),Blocks.STONE);
    }

    private static Vec3 offset(Entity entity,double x,double y,double z) {
        return AirframeLayout.world(entity.position(),entity.getYRot(),x,y,z);
    }

    private static Vec3 local(Entity aircraft,Entity traveler) {
        return AirframeLayout.local(aircraft.position(),aircraft.getYRot(),traveler.position());
    }

    @GameTest(template="vehicle_pad",timeoutTicks=160)
    public static void cabinHoverAndIndependentSeat(GameTestHelper helper) {
        pad(helper);
        HelicopterEntity air=helper.spawn(T72Mod.MI8.get(),CENTER);
        air.setYRot(39);
        air.giveStarterFuel();
        FakePlayer pilot=new FakePlayer(helper.getLevel(),new GameProfile(UUID.randomUUID(),"Mi8TestPilot"));
        pilot.setPos(air.position());
        helper.getLevel().addNewPlayer(pilot);
        pilot.setGameMode(GameType.SURVIVAL);
        helper.runAtTickTime(18,()->{
            helper.assertTrue(air.isCabinOpen(),"Expected landed cabin");
            pilot.setPos(offset(air,0,1.37,2.70));
            air.handleCrewAction(pilot,HelicopterEntity.SELECT_SEAT);
            helper.assertTrue(air.isPilot(pilot),"Could not mount the specific pilot seat");
            air.handleAction(pilot,HelicopterEntity.TOGGLE_ENGINE);
            helper.assertTrue(air.engineOn(),"Engine failed to start");
        });
        for (int tick=62;tick<=92;tick++) helper.runAtTickTime(tick,
                ()->air.acceptInput(pilot,HelicopterEntity.ASCEND));
        double[] altitude={0};
        helper.runAtTickTime(93,()->{
            helper.assertTrue(air.getY()>helper.absolutePos(CENTER).getY()+5,"No takeoff");
            altitude[0]=air.getY();
            air.handleCrewAction(pilot, HelicopterEntity.TOGGLE_RAMP);
            helper.assertTrue(air.isRampOpen(), "Pilot could not open the rear ramp in flight");
            pilot.stopRiding();
            Vec3 foot=local(air,pilot);
            helper.assertTrue(!pilot.isPassenger() && HelicopterCabin.forType(air.model()).contains(foot),
                    "Dismount did not place pilot in cabin: "+foot);
        });
        helper.runAtTickTime(103,()->{
            helper.assertTrue(air.deckHold() && Math.abs(air.getY()-altitude[0])<.35,
                    "Empty pilot seat with cabin walker did not hold altitude");
            helper.assertTrue(air.isRampOpen(), "Airborne tick closed the rear ramp");
            // An off-centre route still fits through the widened bulkhead.
            Vec3 beforeBulkhead = new Vec3(.48, 1.37, 2.67);
            Vec3 throughBulkhead = new Vec3(.48, 1.37, 1.68);
            helper.assertTrue(air.constrainWalker(throughBulkhead, beforeBulkhead).distanceToSqr(throughBulkhead) < .001,
                    "Widened cabin doorway still blocks a valid path");
            var outside = helper.makeMockSurvivalPlayer();
            outside.setPos(offset(air, 0, 0, -5.9));
            air.handleCrewAction(outside, HelicopterEntity.TOGGLE_RAMP);
            helper.assertTrue(air.isRampOpen(), "A player outside the airborne Mi-8 closed the ramp");
            for (int step=0;step<32;step++)
                pilot.move(MoverType.SELF,AirframeLayout.world(Vec3.ZERO,air.getYRot(),0,0,-.13));
            Vec3 foot=local(air,pilot);
            helper.assertTrue(foot.z<-.76 && Math.abs(foot.y-1.35)<.10,"Could not walk rearward: "+foot);
            air.handleCrewAction(pilot, HelicopterEntity.TOGGLE_RAMP);
            helper.assertTrue(!air.isRampOpen(), "Standing crew member could not close the ramp in flight");
            air.handleCrewAction(pilot,HelicopterEntity.SELECT_SEAT+2);
            helper.assertTrue(pilot.getVehicle()==air && !air.isPilot(pilot),"Passenger seat picked up pilot role");
        });
        helper.runAtTickTime(115,()->{
            helper.assertTrue(Math.abs(air.getY()-altitude[0])<.6,"Craft fell with passenger and no pilot");
            Vec3 foot=local(air,pilot);
            helper.assertTrue(foot.x<-.85 && foot.z<-.85,"Passenger moved to the wrong seat: "+foot);
            pilot.discard();
            helper.succeed();
        });
    }

    @GameTest(template="vehicle_pad")
    public static void rearRampAndRocketMagazine(GameTestHelper helper) {
        pad(helper);
        HelicopterEntity air=helper.spawn(T72Mod.MI8.get(),CENTER);
        air.giveStarterFuel();
        air.setYRot(33);
        Player player=helper.makeMockSurvivalPlayer();
        helper.runAtTickTime(18,()->{
            player.setPos(offset(air,0,0,-5.9));
            air.handleCrewAction(player,HelicopterEntity.TOGGLE_RAMP);
            helper.assertTrue(air.isRampOpen(),"Rear switch did not work from ground");
            player.getInventory().setItem(0,new ItemStack(T72Mod.AIR_ROCKET.get(),16));
            air.handleCrewAction(player,HelicopterEntity.RELOAD_ROCKETS);
            helper.assertTrue(air.rockets()==12 && player.getInventory().getItem(0).getCount()==8,
                    "Reload did not leave excess rockets in inventory");
            air.handleCrewAction(player,HelicopterEntity.RELOAD_ROCKETS);
            helper.assertTrue(player.getInventory().getItem(0).getCount()==8,"Full rails consumed ammunition");
        });
        helper.runAtTickTime(37,()->{
            helper.assertTrue(air.rampProgress(1)==1,"Ramp did not deploy");
            var ramp=HelicopterCabin.forType(air.model()).rampStep(1);
            player.setPos(offset(air,0,ramp.y()+ramp.height()+.12,ramp.z()));
            player.move(MoverType.SELF,new Vec3(0,-.27,0));
            helper.assertTrue(Math.abs(local(air,player).y-ramp.y()-ramp.height())<.06,
                    "Ramp did not support standing player");
            air.handleCrewAction(player,HelicopterEntity.TOGGLE_RAMP);
            helper.assertTrue(!air.isRampOpen(),"Rear switch did not close");
            helper.succeed();
        });
    }

    @GameTest(template="vehicle_pad")
    public static void vehiclePartsStayWithParentAndSupportBarrel(GameTestHelper helper) {
        pad(helper);
        HelicopterEntity air=helper.spawn(T72Mod.MI8.get(),CENTER.offset(-6,0,0));
        T72TankEntity tank=helper.spawn(T72Mod.T90M_TANK.get(),CENTER.offset(5,0,0));
        tank.setTurretYaw(26);
        helper.runAtTickTime(18,()->{
            helper.assertTrue(air.getParts().length==21 && tank.getParts().length==15,"Multipart budgets changed");
            for (VehiclePart part : tank.getParts()) {
                helper.assertTrue(helper.getLevel().getEntity(part.getId())==null,"Part exists as tracked entity");
                helper.assertTrue(helper.getLevel().getEntityOrPart(part.getId())==part,"Part not reachable for hits");
            }
            helper.assertTrue(helper.getLevel().getEntitiesOfClass(VehiclePartEntity.class,
                    air.getBoundingBox().inflate(8)).isEmpty(),"Vehicles still spawn ticked collision entities");
            Player p=helper.makeMockSurvivalPlayer();
            Vec3 base=TankGeometry.barrelPivot(tank.position(),tank.getYRot(),tank.getTurretYaw(),tank.getTankType());
            Vec3 sample=base.add(Vec3.directionFromRotation(tank.getBarrelPitch(),tank.getTurretYaw()).scale(4.6));
            p.setPos(sample.add(0,.64,0));
            p.move(MoverType.SELF,new Vec3(0,-1.06,0));
            helper.assertTrue(Math.abs(p.getY()-sample.y)<.3,"No support on tank barrel");
            int oldId=tank.getParts()[0].getId();
            tank.discard();
            helper.assertTrue(helper.getLevel().getEntityOrPart(oldId)==null,"Parts leaked after removal");
            helper.succeed();
        });
    }

    @GameTest(template="vehicle_pad", timeoutTicks=90)
    public static void bmpDismountKeepsEngineAndSeatRoles(GameTestHelper helper) {
        pad(helper);
        T72TankEntity bmp = helper.spawn(T72Mod.BMP3.get(), CENTER);
        bmp.setYRot(47);
        bmp.initStarterSupplies();
        FakePlayer driver = new FakePlayer(helper.getLevel(), new GameProfile(UUID.randomUUID(), "BmpDriver"));
        FakePlayer gunner = new FakePlayer(helper.getLevel(), new GameProfile(UUID.randomUUID(), "BmpGunner"));
        helper.runAtTickTime(15, () -> {
            driver.setPos(offset(bmp, -.25, BmpCabin.FLOOR + .02, 1.58));
            gunner.setPos(offset(bmp, .25, BmpCabin.FLOOR + .02, 1.30));
            helper.assertTrue(driver.startRiding(bmp, true), "Driver could not board");
            helper.assertTrue(gunner.startRiding(bmp, true), "Gunner could not board");
            bmp.toggleBmpRear(driver);
            bmp.toggleBmpBrake(driver);
            helper.assertTrue(!bmp.bmpParked() && !bmp.bmpCabinOpen(), "Could not release brake with closed doors");
            helper.assertTrue(bmp.getControllingPassenger() == driver && bmp.weaponOperator() == gunner,
                    "Driver and turret controls were not independent");
            driver.stopRiding();
            helper.assertTrue(!driver.isPassenger() && BmpCabin.contains(local(bmp, driver)),
                    "Driver dismounted outside the cabin");
            helper.assertTrue(bmp.bmpParked() && bmp.engineRunning() && !bmp.bmpCabinOpen(),
                    "Dismount changed the engine or door state, or failed to engage the brake");
            helper.assertTrue(bmp.getControllingPassenger() == null && bmp.weaponOperator() == gunner,
                    "The gunner jumped into the driver's seat");
            helper.assertTrue(driver.startRiding(bmp, true) && bmp.getControllingPassenger() == driver,
                    "Empty driver seat was not reusable");
            helper.succeed();
        });
    }

    @GameTest(template="vehicle_pad", timeoutTicks=90)
    public static void towMovesGunAndKeepsAmmunition(GameTestHelper helper) {
        pad(helper);
        FieldVehicleEntity truck = helper.spawn(T72Mod.WORKSHOP_TRUCK.get(), CENTER.offset(0, 0, 6));
        ArtilleryEntity gun = helper.spawn(T72Mod.ARTILLERY.get(), CENTER.offset(0, 0, -1));
        truck.setYRot(0);
        gun.setYRot(0);
        gun.loadStarterAmmo();
        double[] before = {0};
        helper.runAtTickTime(18, () -> {
            helper.assertTrue(truck.couple(gun), "Hitch did not attach: truck=" + truck.position() + " ground=" + truck.onGround()
                    + " yaw=" + truck.getYRot() + " speed=" + truck.getDeltaMovement() + " gun=" + gun.position()
                    + " gunGround=" + gun.hasGroundSupport() + " hitch=" + truck.rearHitch());
            helper.assertTrue(!truck.couple(gun), "Duplicate hitch was accepted");
            before[0] = gun.getZ();
            truck.move(MoverType.SELF, new Vec3(0, 0, 2.5));
        });
        helper.runAtTickTime(35, () -> {
            helper.assertTrue(gun.getZ() > before[0] + .8, "Artillery did not follow the hitch");
            helper.assertTrue(gun.ammunition() == 3, "Towing changed the ammunition");
            gun.unhitch();
            helper.assertTrue(gun.towVehicle().isEmpty() && truck.towedGun().isEmpty(), "Unhitch did not clear both ends");
            helper.succeed();
        });
    }

    @GameTest(template = "vehicle_pad", timeoutTicks = 120)
    public static void fpvSessionUsesBatteryAndLandsAfterRelease(GameTestHelper helper) {
        pad(helper);
        FpvDroneEntity drone = helper.spawn(T72Mod.FPV_DRONE.get(), CENTER);
        FakePlayer pilot = new FakePlayer(helper.getLevel(), new GameProfile(UUID.randomUUID(), "FpvPilot"));
        pilot.setPos(drone.position().add(2, 0, 0));
        pilot.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, new ItemStack(T72Mod.FPV_CONTROLLER.get()));
        helper.getLevel().addNewPlayer(pilot);
        drone.prepare(pilot, new ItemStack(T72Mod.FPV_KIT.get()));
        double[] starts = {drone.getY(), drone.getZ()};
        helper.runAtTickTime(18, () -> drone.toggle(pilot));
        for (int tick = 19; tick <= 60; tick++) helper.runAtTickTime(tick,
                () -> drone.accept(pilot, tickFlags(drone), 0, 0, 0));
        helper.runAtTickTime(60, () -> {
            helper.assertTrue(drone.controllerId() == pilot.getId(), "The controller session was not active");
            helper.assertTrue(drone.getY() > starts[0] + 2 && drone.getZ() > starts[1] + 1, "The drone did not fly");
            helper.assertTrue(drone.battery() < FpvDroneEntity.BATTERY_CAPACITY, "Flying did not discharge the battery");
            drone.accept(pilot, 0, 0, 0, 1);
            helper.assertTrue(drone.controllerId() < 0 && !pilot.getPersistentData().contains(FpvDroneEntity.ACTIVE),
                    "Release left the FPV camera session active");
            pilot.discard();
            helper.succeed();
        });
    }

    private static int tickFlags(FpvDroneEntity drone) {
        return FpvFlight.UP | (drone.yo < drone.getY() - .03 ? FpvFlight.FORWARD : 0);
    }

    @GameTest(template = "vehicle_pad", timeoutTicks = 100)
    public static void rotorDamageUsesBladeHeight(GameTestHelper helper) {
        pad(helper);
        HelicopterEntity heli = helper.spawn(T72Mod.MI8.get(), CENTER);
        heli.giveStarterFuel();
        FakePlayer pilot = new FakePlayer(helper.getLevel(), new GameProfile(UUID.randomUUID(), "RotorPilot"));
        pilot.setPos(heli.position());
        var blade = helper.spawn(EntityType.COW, CENTER.offset(5, 4, 0));
        var below = helper.spawn(EntityType.COW, CENTER.offset(6, 0, 0));
        blade.setNoAi(true);
        blade.setNoGravity(true);
        below.setNoAi(true);
        helper.runAtTickTime(17, () -> {
            helper.assertTrue(pilot.startRiding(heli, true), "Pilot could not mount helicopter");
            heli.handleAction(pilot, HelicopterEntity.TOGGLE_ENGINE);
            helper.assertTrue(heli.engineOn(), "Rotor could not start");
        });
        helper.runAtTickTime(57, () -> {
            helper.assertTrue(blade.getHealth() < blade.getMaxHealth() || !blade.isAlive(), "Rotor disk did not hit its target");
            helper.assertTrue(below.getHealth() == below.getMaxHealth(), "Rotor hit an entity below the blade disk");
            helper.succeed();
        });
    }

    @GameTest(template = "vehicle_pad", timeoutTicks = 100)
    public static void tankRunoverUsesHullFootprint(GameTestHelper helper) {
        pad(helper);
        T72TankEntity tank = helper.spawn(T72Mod.T90M_TANK.get(), CENTER);
        tank.setYRot(37);
        FakePlayer pilot = new FakePlayer(helper.getLevel(), new GameProfile(UUID.randomUUID(), "TrackPilot"));
        var target = helper.spawn(EntityType.COW, CENTER.offset(0, 0, 5));
        var outside = helper.spawn(EntityType.COW, CENTER.offset(5, 0, 5));
        target.setNoAi(true);
        outside.setNoAi(true);
        helper.runAtTickTime(18, () -> {
            helper.assertTrue(pilot.startRiding(tank, true), "Driver could not mount");
            double nose = TankGeometry.trackLength(tank.getTankType()) / 2;
            target.setPos(offset(tank, 0, 0, nose + .30));
            outside.setPos(offset(tank, 3.8, 0, nose));
            tank.setOnGround(true);
            tank.move(MoverType.SELF, AirframeLayout.world(Vec3.ZERO, tank.getYRot(), 0, 0, .37));
            helper.assertTrue(target.getHealth() < target.getMaxHealth(), "A moving tank did not damage a target in its footprint");
            helper.assertTrue(outside.getHealth() == outside.getMaxHealth(), "A tank damaged a target beyond its footprint");
            helper.succeed();
        });
    }
}
