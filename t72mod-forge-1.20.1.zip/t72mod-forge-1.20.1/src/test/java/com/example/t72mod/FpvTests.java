package com.example.t72mod;

import com.example.t72mod.entity.FpvFlight;
import net.minecraft.world.phys.Vec3;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

final class FpvTests {
    @Test void banksAcceleratesAndRecoversWhenControlsRelease() {
        var hover = new FpvFlight.State(0, 0, 0, .61, Vec3.ZERO);
        var state = hover;
        for (int tick = 0; tick < 15; tick++)
            state = FpvFlight.step(state, FpvFlight.FORWARD | FpvFlight.RIGHT | FpvFlight.UP | FpvFlight.BOOST, 5, 5);
        assertTrue(state.roll() > 55);
        assertTrue(state.yaw() > 100);
        assertTrue(state.velocity().horizontalDistance() > 1.3);
        assertTrue(state.velocity().horizontalDistance() <= 2.301);
        for (int tick = 0; tick < 50; tick++) state = FpvFlight.step(state, 0, 0, 0);
        assertEquals(0, state.pitch(), .1);
        assertEquals(0, state.roll(), .1);
        assertTrue(state.velocity().horizontalDistance() < .04);
        assertEquals(1.08, state.throttle(), .01);
        for (int tick = 0; tick < 13; tick++) state = FpvFlight.step(state, FpvFlight.BACK, 0, 0);
        assertEquals(.60, state.throttle(), .02);
    }

    @Test void freeAttitudeHoldsTheInclinationWithoutInput() {
        var state = new FpvFlight.State(30, 41, -34, .61, Vec3.ZERO);
        var next = FpvFlight.step(state, 0, 0, 0, true);
        assertEquals(41, next.pitch(), .01);
        assertEquals(-34, next.roll(), .01);
    }

    @Test void signalKeepsTheDroneNearThe300BlockBoundary() {
        var at = new Vec3(299.9, 0, 0);
        assertEquals(new Vec3(1, 0, 0), FpvFlight.limitSignal(new Vec3(100,0,0), new Vec3(1,0,0), Vec3.ZERO));
        var curtailed = FpvFlight.limitSignal(at, new Vec3(1.5, 0, .65), Vec3.ZERO);
        assertTrue(at.add(curtailed).length() < 300);
        assertEquals(.65, curtailed.z, .001);
    }
}
