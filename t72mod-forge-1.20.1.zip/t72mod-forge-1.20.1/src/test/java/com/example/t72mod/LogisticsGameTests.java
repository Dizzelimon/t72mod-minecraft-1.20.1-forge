package com.example.t72mod;

import com.example.t72mod.entity.*;
import com.example.t72mod.item.FlightBattery;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.nbt.Tag;
import com.example.t72mod.scenario.CrewRoutes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

@GameTestHolder(T72Mod.MODID)
@PrefixGameTestTemplate(false)
public final class LogisticsGameTests {
    private static final BlockPos CENTER=new BlockPos(16,2,11);
    private static FakePlayer player(GameTestHelper h,String name) {
        return new FakePlayer(h.getLevel(),new GameProfile(UUID.randomUUID(),name));
    }
    @GameTest(template="vehicle_pad")
    public static void twoTankSeatsAndSoloHandover(GameTestHelper h) {
        var tank=h.spawn(T72Mod.T90M_TANK.get(),CENTER);
        var driver=player(h,"Driver");var gunner=player(h,"Gunner");var other=player(h,"Spectator");
        h.assertTrue(driver.startRiding(tank,true) && gunner.startRiding(tank,true),"Both tank crew must fit");
        h.assertTrue(tank.getControllingPassenger()==driver && tank.weaponOperator()==gunner,"Incorrect roles");
        tank.setOnGround(true);tank.setDeltaMovement(Vec3.ZERO);tank.xo=tank.getX();tank.zo=tank.getZ();
        tank.changeCrewSeat(driver,1);tank.changeCrewSeat(other,0);
        h.assertTrue(tank.crewOccupant(1)==gunner && tank.crewOccupant(0)==driver,"Occupied seat stolen");
        gunner.stopRiding();h.assertTrue(tank.weaponOperator()==driver,"Driver did not regain turret");
        tank.changeCrewSeat(driver,1);
        h.assertTrue(tank.weaponOperator()==driver && tank.getControllingPassenger()==null,"Gunner became driver");
        var state=tank.saveWithoutId(new CompoundTag());
        h.assertTrue(state.getCompound("CrewSeats").getUUID("1").equals(driver.getUUID()),"Seat not persisted");
        h.succeed();
    }

    @GameTest(template="vehicle_pad")
    public static void recoverHullAndSalvageOnce(GameTestHelper h) {
        var tank=h.spawn(T72Mod.T72_TANK.get(),CENTER);
        var p=player(h,"Mechanic");
        tank.setEngineHealth(71);tank.die(tank.damageSources().generic());
        h.assertTrue(tank.isAlive() && tank.isWreck() && !tank.serviceFromTruck(),"Wreck state not enforced");
        p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(Items.SHEARS));
        for (int i=0;i<2;i++) tank.interactPart(TankGeometry.TRACK_PARTS,p,InteractionHand.MAIN_HAND);
        h.assertTrue(p.getInventory().countItem(T72Mod.ENGINE_MODULE.get())==1 && tank.getEngineHealth()==0,"Double salvage");
        var save=tank.saveWithoutId(new CompoundTag());tank.readAdditionalSaveData(save);
        h.assertTrue(tank.isWreck() && tank.getEngineHealth()==0,"Reload restored a salvaged engine");
        h.assertTrue(tank.overhaul() && !tank.isWreck() && tank.getHealth()>1,"Post failed to recover original hull");
        h.succeed();
    }

    @GameTest(template="vehicle_pad",timeoutTicks=100)
    public static void poweredDockKeepsPartialPack(GameTestHelper h) {
        var p=player(h,"Technician");
        var pos=h.absolutePos(CENTER);var level=h.getLevel();
        h.setBlock(CENTER,T72Mod.CHARGING_DOCK.get());h.setBlock(CENTER.east(),Blocks.REDSTONE_BLOCK);
        var hit=new BlockHitResult(Vec3.atCenterOf(pos),Direction.UP,pos,false);
        var pack=new ItemStack(T72Mod.FLIGHT_BATTERY.get());FlightBattery.charge(pack,410);
        p.setItemInHand(InteractionHand.MAIN_HAND,pack);
        level.getBlockState(pos).use(level,p,InteractionHand.MAIN_HAND,hit);
        h.assertTrue(p.getMainHandItem().isEmpty(),"Pack not docked");
        h.runAtTickTime(26,()->{
            var dock=level.getBlockEntity(pos);
            var data=dock.saveWithFullMetadata();dock.load(data);
            level.getBlockState(pos).use(level,p,InteractionHand.MAIN_HAND,hit);
            h.assertTrue(FlightBattery.charge(p.getMainHandItem())==475,"Charge lost or entirely refilled");
            var drone=h.spawn(T72Mod.FPV_DRONE.get(),CENTER.above(2));
            drone.prepare(p,new ItemStack(T72Mod.FPV_KIT.get()));drone.setOnGround(true);
            drone.interact(p,InteractionHand.MAIN_HAND);
            h.assertTrue(drone.battery()==475 && FlightBattery.charge(p.getMainHandItem())==2600,"Swap did not conserve charge");
            h.succeed();
        });
    }

    @GameTest(template="vehicle_pad")
    public static void softGroundWearSurvivesReload(GameTestHelper h) {
        var tank=h.spawn(T72Mod.T72_TANK.get(),CENTER);
        tank.setOnGround(true);
        var pos=GroundTraction.contact(tank,0,0);
        h.getLevel().setBlockAndUpdate(pos,Blocks.MUD.defaultBlockState());
        h.assertTrue(GroundTraction.sample(tank,pos)==1,"Mud block tag did not load");
        var terrain=new GroundTraction();
        terrain.restore(299.95);
        tank.xo=tank.getX();tank.zo=tank.getZ();
        h.assertTrue(!terrain.wear(tank),"Stationary vehicle wore down");
        tank.xo-=.6;
        h.assertTrue(terrain.wear(tank) && terrain.distance()<1,"Moving vehicle did not cross wear threshold");
        var saved=tank.saveWithoutId(new CompoundTag());
        saved.putDouble("SurfaceWear",107.5);tank.readAdditionalSaveData(saved);
        h.assertTrue(tank.saveWithoutId(new CompoundTag()).getDouble("SurfaceWear")==107.5,"Lost wear after loading");
        h.succeed();
    }

    @GameTest(template="vehicle_pad")
    public static void crewSupplyRouteFinishesOnlyAtDestination(GameTestHelper h) {
        var level=h.getLevel();
        var vehicle=h.spawn(T72Mod.WORKSHOP_TRUCK.get(),CENTER);
        var p=player(h,"Quartermaster");
        p.setPos(vehicle.position());
        var start=vehicle.blockPosition();
        var end=start.east(48);
        var day=level.getDayTime();
        try {
            level.setDayTime(18000);level.updateSkyBrightness();
            level.getServer().getCommands().performPrefixedCommand(p.createCommandSourceStack(),
                    "t72route supply "+end.getX()+" "+end.getZ());
        } finally { level.setDayTime(day);level.updateSkyBrightness(); }
        CrewRoutes.loaded(p,vehicle,0);
        var cargo=new CompoundTag();
        vehicle.freight().write(cargo);
        cargo.putLong("FreightRevision0",cargo.getLong("FreightRevision0")+1);
        vehicle.freight().read(cargo);
        CrewRoutes.moved(p,vehicle,0,null,0);
        CrewRoutes.loaded(p,vehicle,0);
        vehicle.setPos(end.getX(),end.getY(),end.getZ());
        cargo.putLong("FreightRevision0",cargo.getLong("FreightRevision0")+1);
        vehicle.freight().read(cargo);
        CrewRoutes.moved(p,vehicle,0,null,0);
        CrewRoutes.moved(p,vehicle,0,null,0);
        var store=level.getDataStorage().get(t -> { throw new AssertionError("Route store missing"); },"t72mod_crew_routes");
        var crew=store.save(new CompoundTag()).getCompound("Crews").getCompound("p:"+p.getUUID());
        h.assertTrue(!crew.contains("Active") && crew.getList("Journal",Tag.TAG_COMPOUND).size()==1,
                "Delivery journal missing or duplicated");
        h.succeed();
    }

    @GameTest(template="vehicle_pad")
    public static void crewChartReplacesPinAndIsolatesPlayers(GameTestHelper h) {
        var p=player(h,"Scout");var other=player(h,"Visitor");var position=h.absolutePos(CENTER);
        CrewRoutes.savePin(p,position,"road","dirt");
        CrewRoutes.savePin(p,position,"bridge","passable");
        CrewRoutes.savePin(other,position,"landing","level");
        var store=h.getLevel().getDataStorage().get(t->{throw new AssertionError("Missing chart");},"t72mod_crew_routes");
        var crews=store.save(new CompoundTag()).getCompound("Crews");
        var markers=crews.getCompound("p:"+p.getUUID()).getList("Pins",Tag.TAG_COMPOUND);
        var visitors=crews.getCompound("p:"+other.getUUID()).getList("Pins",Tag.TAG_COMPOUND);
        h.assertTrue(markers.size()==1 && markers.getCompound(0).getString("Kind").equals("bridge")
                && visitors.size()==1 && visitors.getCompound(0).getString("Kind").equals("landing"),"Wrong marker owner or duplicate");
        h.succeed();
    }

    @GameTest(template="vehicle_pad",timeoutTicks=90)
    public static void rampLoadsSealedCargoAndTransfersOnce(GameTestHelper h) {
        for (int x=7;x<26;x++) for (int z=4;z<18;z++) h.setBlock(new BlockPos(x,1,z),Blocks.STONE);
        var air=h.spawn(T72Mod.MI8.get(),CENTER.west(3));air.setYRot(0);
        var truck=h.spawn(T72Mod.WORKSHOP_TRUCK.get(),CENTER.east(3));truck.setYRot(0);
        var driver=player(h,"Trucker");var p=player(h,"Loader");
        h.runAtTickTime(15,()->{
            driver.startRiding(truck,true);truck.action(driver,2);
            p.setPos(air.position().add(-.6,.02,-5));air.handleCrewAction(p,HelicopterEntity.TOGGLE_RAMP);
        });
        h.runAtTickTime(35,()->{
            p.setPos(air.position().add(-.6,.02,-5));
            var box=new ItemStack(Items.BLUE_SHULKER_BOX);box.getOrCreateTag().putString("Seal","118");
            p.setItemInHand(InteractionHand.MAIN_HAND,box);air.freight().use(p,InteractionHand.MAIN_HAND);
            h.assertTrue(air.freight().count()==1 && p.getMainHandItem().isEmpty(),"Box did not leave hand");
            p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(T72Mod.FREIGHT_HOOK.get()));air.freight().use(p,InteractionHand.MAIN_HAND);
            var stale=p.getMainHandItem().copy();p.setPos(truck.position().add(-.6,.02,-4));
            truck.freight().use(p,InteractionHand.MAIN_HAND);
            p.setItemInHand(InteractionHand.MAIN_HAND,stale);truck.freight().use(p,InteractionHand.MAIN_HAND);
            var saved=truck.saveWithoutId(new CompoundTag());truck.readAdditionalSaveData(saved);
            h.assertTrue(air.freight().count()==0 && truck.freight().count()==1,"Transfer duplicated or lost cargo");
            h.assertTrue("118".equals(saved.getCompound("Freight0").getCompound("tag").getString("Seal")),"Box NBT changed");
            h.succeed();
        });
    }
}
