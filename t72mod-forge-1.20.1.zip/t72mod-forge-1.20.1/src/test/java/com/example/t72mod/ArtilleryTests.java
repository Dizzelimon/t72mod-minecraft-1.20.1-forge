package com.example.t72mod;

import com.example.t72mod.config.T72ServerConfig;
import com.example.t72mod.entity.ArtilleryBallistics;
import com.example.t72mod.entity.ArtilleryEntity;
import com.example.t72mod.entity.ArtilleryMarkerStore;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ArtilleryTests {

    @Test
    void defaultRangeIs300AndAlignedWithConfig() {
        assertEquals(16, ArtilleryBallistics.MIN_RANGE);
        assertEquals(300, T72ServerConfig.DEFAULT_ARTILLERY_MAX_RANGE);
        assertEquals(T72ServerConfig.DEFAULT_ARTILLERY_MAX_RANGE, T72ServerConfig.artilleryMaxRange());
    }

    @Test
    void rangeValidationRespectsMinimumAndConfiguredLimit() {
        assertFalse(ArtilleryBallistics.isRangeAllowed(15.9, 192));
        assertTrue(ArtilleryBallistics.isRangeAllowed(16.0, 192));
        assertTrue(ArtilleryBallistics.isRangeAllowed(96.0, 192));
        assertTrue(ArtilleryBallistics.isRangeAllowed(140.0, 192));
        assertTrue(ArtilleryBallistics.isRangeAllowed(192.0, 192));
        assertFalse(ArtilleryBallistics.isRangeAllowed(192.1, 192));

        // Custom config limits
        assertTrue(ArtilleryBallistics.isRangeAllowed(280.0, 320));
        assertFalse(ArtilleryBallistics.isRangeAllowed(100.0, 80));
    }

    @Test
    void discreteTrajectoryHitsTargetFromShortToExtendedRange() {
        Vec3 pivot = new Vec3(0.5, 65.35, 0.5);
        int[] ranges = {16, 48, 96, 128, 160, 192, 256, 300};
        int[] deltaYs = {0, 25, -20};

        for (int range : ranges) {
            for (int dy : deltaYs) {
                double targetX = 0.5 + range;
                double targetY = 64.0 + dy;
                double targetZ = 0.5;
                ArtilleryBallistics.Solution sol = ArtilleryBallistics.solve(pivot, targetX, targetY, targetZ);
                assertTrue(sol.valid(), "Solution should be valid at range=" + range + " dy=" + dy);

                int ticks = ArtilleryBallistics.flightTicks(range);
                Vec3 pos = pivot;
                Vec3 vel = sol.velocity();
                for (int t = 0; t < ticks; t++) {
                    pos = pos.add(vel);
                    vel = vel.scale(ArtilleryBallistics.AIR_DRAG).subtract(0.0, ArtilleryBallistics.GRAVITY, 0.0);
                }

                assertEquals(targetX, pos.x, 0.02, "X miss at range=" + range);
                assertEquals(targetY - 0.12, pos.y, 0.02, "Y miss at range=" + range + " dy=" + dy);
                assertEquals(targetZ, pos.z, 0.02, "Z miss at range=" + range);
            }
        }
    }

    @Test
    void dispersionIncreasesWithDistanceAndStaysInsideItsEnvelope() {
        var random = net.minecraft.util.RandomSource.create(87);
        assertEquals(0, ArtilleryBallistics.dispersionRadius(62));
        assertTrue(ArtilleryBallistics.dispersionRadius(135) < ArtilleryBallistics.dispersionRadius(220));
        assertTrue(ArtilleryBallistics.dispersionRadius(220) < ArtilleryBallistics.dispersionRadius(300));
        assertEquals(new ArtilleryBallistics.SamplePoint(20, -10), ArtilleryBallistics.dispersedTarget(20, -10, 70, random));
        boolean deviation = false;
        for (int n = 0; n < 50; n++) {
            var sample = ArtilleryBallistics.dispersedTarget(300, 0, 300, random);
            double error = Math.hypot(sample.blockX() - 300, sample.blockZ());
            assertTrue(error <= ArtilleryBallistics.dispersionRadius(300) + .75);
            deviation |= error > 8;
        }
        assertTrue(deviation);
    }

    @Test
    void trajectorySamplesCoverPathWithinSingleChunkStep() {
        List<ArtilleryBallistics.SamplePoint> samples =
                ArtilleryBallistics.trajectorySamples(0.5, 0.5, 192, 0);
        assertTrue(samples.size() >= 16);
        assertEquals(0, samples.get(0).blockX());
        assertEquals(192, samples.get(samples.size() - 1).blockX());
        for (int i = 1; i < samples.size(); i++) {
            int dx = samples.get(i).blockX() - samples.get(i - 1).blockX();
            int dz = samples.get(i).blockZ() - samples.get(i - 1).blockZ();
            assertTrue(Math.hypot(dx, dz) <= 13.0, "Sample gap exceeded 13 blocks");
        }
    }

    @Test
    void quickMarkersEnforceThreePerDimensionAndPersistNbt() {
        ResourceLocation overworld = new ResourceLocation("minecraft", "overworld");
        ResourceLocation nether = new ResourceLocation("minecraft", "the_nether");
        ArtilleryMarkerStore store = new ArtilleryMarkerStore();

        assertTrue(store.addMarker(overworld, 10, 20));
        assertTrue(store.addMarker(overworld, 120, -40));
        assertTrue(store.addMarker(overworld, 190, 15));
        assertFalse(store.addMarker(overworld, 50, 50)); // 4th in same dimension rejected
        assertEquals(3, store.list(overworld).size());

        // Separate dimension allows 3 of its own markers
        assertTrue(store.addMarker(nether, -30, 80));
        assertEquals(1, store.list(nether).size());
        assertEquals(3, store.list(overworld).size());

        // Deleting frees a slot
        assertTrue(store.deleteMarker(overworld, 1));
        assertFalse(store.deleteMarker(overworld, 5));
        assertEquals(2, store.list(overworld).size());
        assertTrue(store.addMarker(overworld, 180, -10));
        assertEquals(3, store.list(overworld).size());

        // NBT serialization roundtrip
        CompoundTag tag = store.writeNbt();
        ArtilleryMarkerStore reloaded = new ArtilleryMarkerStore();
        reloaded.readNbt(tag);
        assertEquals(store.list(overworld), reloaded.list(overworld));
        assertEquals(store.list(nether), reloaded.list(nether));
    }
}
