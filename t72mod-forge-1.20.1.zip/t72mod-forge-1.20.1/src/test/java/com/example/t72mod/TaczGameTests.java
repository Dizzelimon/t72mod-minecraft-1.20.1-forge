package com.example.t72mod;

import com.example.t72mod.entity.T72TankEntity;
import com.tacz.guns.api.event.common.EntityHurtByGunEvent;
import com.tacz.guns.api.event.common.GunFireEvent;
import com.tacz.guns.api.item.IGun;
import net.minecraft.world.InteractionHand;
import com.tacz.guns.api.item.IAmmo;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import net.minecraftforge.registries.ForgeRegistries;
import org.apache.commons.lang3.tuple.Pair;

@GameTestHolder(T72Mod.MODID)
@PrefixGameTestTemplate(false)
public final class TaczGameTests {
    @GameTest(template = "vehicle_pad")
    public static void optionalTaczVehicleIntegration(GameTestHelper helper) {
        if (ModList.get().isLoaded("tacz")) WithTacz.check(helper);
        else helper.succeed();
    }

    private static final class WithTacz {
        static void check(GameTestHelper helper) {
            var level = helper.getLevel();
            T72TankEntity tank = helper.spawn(T72Mod.T90M_TANK.get(), new BlockPos(17, 2, 11));
            var part = tank.getParts()[0];
            var bullet = new Snowball(level, tank.getX(), tank.getY() + 1.0, tank.getZ());
            var gunId = new ResourceLocation("tacz", "ak47");
            var damageType = level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                    .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("tacz", "bullet")));
            DamageSource source = new DamageSource(damageType, bullet);
            var event = new EntityHurtByGunEvent.Pre(bullet, part, null, gunId, gunId, 24,
                    Pair.of(source, source), false, 1, LogicalSide.SERVER);
            helper.assertTrue(MinecraftForge.EVENT_BUS.post(event), "TaCZ modular routing was not installed");
            int tracks = tank.getTracksHealth();
            helper.assertTrue(tracks < 100 && tank.getHealth() > 0, "Tank track did not take modular TaCZ damage");
            var duplicate = new EntityHurtByGunEvent.Pre(bullet, tank, null, gunId, gunId, 24,
                    Pair.of(source, source), false, 1, LogicalSide.SERVER);
            float hull = tank.getHealth();
            MinecraftForge.EVENT_BUS.post(duplicate);
            helper.assertTrue(tracks == tank.getTracksHealth() && hull == tank.getHealth(), "A single hit applied twice");
            ItemStack ammo = new ItemStack(ForgeRegistries.ITEMS.getValue(new ResourceLocation("tacz", "ammo")), 16);
            ((IAmmo) ammo.getItem()).setAmmoId(ammo, new ResourceLocation("tacz", "762x54"));
            helper.assertTrue(T72TankEntity.isMachineGunAmmo(ammo), "Compatible TaCZ stack rejected");
            int loaded = com.example.t72mod.compat.TaczCompat.loadMachineGunAmmo(ammo, 7);
            helper.assertTrue(loaded == 7 && ammo.getCount() == 9, "TaCZ ammo transfer lost or duplicated rounds");

            var stand = helper.spawn(T72Mod.GUN_STAND.get(), new BlockPos(23, 2, 11));
            var operator = helper.makeMockSurvivalPlayer();
            var mountedGun = new ItemStack(ForgeRegistries.ITEMS.getValue(new ResourceLocation("tacz", "modern_kinetic_gun")));
            ((IGun) mountedGun.getItem()).setGunId(mountedGun, gunId);
            operator.setItemInHand(InteractionHand.MAIN_HAND, mountedGun);
            stand.setYRot(0);
            operator.setPos(stand.position().add(0, 0, -1));
            operator.setYRot(0);
            operator.setXRot(0);
            helper.assertTrue(stand.interact(operator, InteractionHand.MAIN_HAND).consumesAction()
                    && operator.getVehicle() == stand, "TaCZ weapon did not mount on the stand");
            helper.assertFalse(MinecraftForge.EVENT_BUS.post(new GunFireEvent(operator, mountedGun, LogicalSide.SERVER)),
                    "A valid stand shot was blocked");
            operator.setYRot(110);
            helper.assertTrue(MinecraftForge.EVENT_BUS.post(new GunFireEvent(operator, mountedGun, LogicalSide.SERVER)),
                    "Weapon stand allowed shooting beyond its sector");
            operator.stopRiding();
            helper.succeed();
        }
    }
}
