package com.example.t72mod;

import com.example.t72mod.entity.T72TankEntity;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.entity.IGunOperator;
import com.tacz.guns.entity.EntityKineticBullet;
import com.tacz.guns.resource.modifier.AttachmentCacheProperty;
import com.tacz.guns.api.event.common.EntityHurtByGunEvent;
import com.tacz.guns.api.event.common.GunFireEvent;
import com.tacz.guns.api.item.IGun;
import net.minecraft.world.InteractionHand;
import com.tacz.guns.api.item.IAmmo;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import net.minecraftforge.registries.ForgeRegistries;
import org.apache.commons.lang3.tuple.Pair;

@GameTestHolder(T72Mod.MODID)
@PrefixGameTestTemplate(false)
public final class TaczGameTests {
    @GameTest(template = "vehicle_pad")
    public static void optionalTaczVehicleIntegration(GameTestHelper helper) {
        if (ModList.get().isLoaded("tacz")) WithTacz.check(helper);
        else helper.succeed();
    }

    public static final class ImpactObserver {
        private final EntityKineticBullet rocket;
        private Vec3 position;

        private ImpactObserver(EntityKineticBullet rocket) { this.rocket = rocket; }

        @SubscribeEvent(priority = EventPriority.LOWEST)
        public void observe(ExplosionEvent.Start event) {
            if (event.getExplosion().getExploder() == this.rocket) this.position = event.getExplosion().getPosition();
        }
    }

    private static final class WithTacz {
        static void check(GameTestHelper helper) {
            var level = helper.getLevel();
            T72TankEntity tank = helper.spawn(T72Mod.T90M_TANK.get(), new BlockPos(17, 2, 11));
            var part = tank.getParts()[0];
            var bullet = new Snowball(level, tank.getX(), tank.getY() + 1.0, tank.getZ());
            var gunId = new ResourceLocation("tacz", "ak47");
            var damageType = level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                    .getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("tacz", "bullet")));
            DamageSource source = new DamageSource(damageType, bullet);
            var event = new EntityHurtByGunEvent.Pre(bullet, part, null, gunId, gunId, 24,
                    Pair.of(source, source), false, 1, LogicalSide.SERVER);
            helper.assertFalse(MinecraftForge.EVENT_BUS.post(event), "TaCZ native impact was canceled");
            helper.assertTrue(event.getBaseAmount() == 0, "TaCZ direct damage was not routed to a module");
            int tracks = tank.getTracksHealth();
            helper.assertTrue(tracks < 100 && tank.getHealth() > 0, "Tank track did not take modular TaCZ damage");
            var duplicate = new EntityHurtByGunEvent.Pre(bullet, tank, null, gunId, gunId, 24,
                    Pair.of(source, source), false, 1, LogicalSide.SERVER);
            float hull = tank.getHealth();
            MinecraftForge.EVENT_BUS.post(duplicate);
            helper.assertTrue(tracks == tank.getTracksHealth() && hull == tank.getHealth(), "A single hit applied twice");
            ItemStack ammo = new ItemStack(ForgeRegistries.ITEMS.getValue(new ResourceLocation("tacz", "ammo")), 16);
            ((IAmmo) ammo.getItem()).setAmmoId(ammo, new ResourceLocation("tacz", "762x54"));
            helper.assertTrue(T72TankEntity.isMachineGunAmmo(ammo), "Compatible TaCZ stack rejected");
            int loaded = com.example.t72mod.compat.TaczCompat.loadMachineGunAmmo(ammo, 7);
            helper.assertTrue(loaded == 7 && ammo.getCount() == 9, "TaCZ ammo transfer lost or duplicated rounds");

            var stand = helper.spawn(T72Mod.GUN_STAND.get(), new BlockPos(23, 2, 11));
            var operator = helper.makeMockSurvivalPlayer();
            var mountedGun = new ItemStack(ForgeRegistries.ITEMS.getValue(new ResourceLocation("tacz", "modern_kinetic_gun")));
            ((IGun) mountedGun.getItem()).setGunId(mountedGun, gunId);
            stand.setYRot(0);
            operator.setPos(stand.position().add(0, 0, -1));
            operator.setYRot(0);
            operator.setXRot(0);
            helper.assertTrue(stand.interact(operator, InteractionHand.MAIN_HAND).consumesAction()
                    && operator.getVehicle() == stand, "Player could not mount the stand empty-handed");
            helper.assertFalse(stand.canAim(operator), "The stand allowed firing without a TaCZ gun");
            operator.setItemInHand(InteractionHand.MAIN_HAND, mountedGun);
            helper.assertFalse(MinecraftForge.EVENT_BUS.post(new GunFireEvent(operator, mountedGun, LogicalSide.SERVER)),
                    "A valid stand shot was blocked");
            operator.setYRot(110);
            helper.assertTrue(MinecraftForge.EVENT_BUS.post(new GunFireEvent(operator, mountedGun, LogicalSide.SERVER)),
                    "Weapon stand allowed shooting beyond its sector");
            operator.stopRiding();
            helper.assertTrue(stand.interact(operator, InteractionHand.MAIN_HAND).consumesAction()
                    && operator.getVehicle() == stand, "Player could not mount with a TaCZ gun already in hand");
            operator.stopRiding();
            tank.discard();
            checkRocket(helper, level, mountedGun);
        }

        private static void checkRocket(GameTestHelper helper, net.minecraft.server.level.ServerLevel level, ItemStack launcher) {
            var tank = helper.spawn(T72Mod.T90M_TANK.get(), new BlockPos(12, 2, 8));
            tank.setYRot(0);
            helper.runAfterDelay(10, () -> {
                var rpg = new ResourceLocation("tacz", "rpg7");
                var index = TimelessAPI.getCommonGunIndex(rpg).orElseThrow();
                var shooter = helper.makeMockSurvivalPlayer();
                Vec3 start = tank.position().add(7, .75, 0);
                shooter.setPos(start);
                ((IGun) launcher.getItem()).setGunId(launcher, rpg);
                shooter.setItemInHand(InteractionHand.MAIN_HAND, launcher);
                var cache = new AttachmentCacheProperty();
                cache.eval(launcher, index.getGunData());
                IGunOperator.fromLivingEntity(shooter).updateCacheProperty(cache);
                var rocket = new EntityKineticBullet(level, shooter, launcher, index.getGunData().getAmmoId(),
                        rpg, false, index.getGunData(), index.getBulletData());
                rocket.setPos(start);
                rocket.setDeltaMovement(-8, 0, 0);
                float previousHull = tank.getHealth();
                int beforeTracks = tank.getTracksHealth();
                ImpactObserver impacts = new ImpactObserver(rocket);
                MinecraftForge.EVENT_BUS.register(impacts);
                try {
                    rocket.tick();
                } finally {
                    MinecraftForge.EVENT_BUS.unregister(impacts);
                }
                helper.assertTrue(rocket.isRemoved(), "TaCZ RPG passed through the tank's side");
                helper.assertTrue(tank.getHealth() < previousHull || tank.getTracksHealth() < beforeTracks,
                        "TaCZ RPG did not damage the tank");
                helper.assertTrue(impacts.position != null && impacts.position.distanceTo(tank.position()) < 3,
                        "TaCZ RPG did not trigger its native explosion at the tank. Explosion: " + impacts.position);
                helper.succeed();
            });
        }
    }
}
