package com.example.t72mod;

import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.TankShellEntity;
import com.example.t72mod.network.ModMessages;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(T72Mod.MODID)
public class T72Mod {
    public static final String MODID = "t72mod";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final RegistryObject<EntityType<T72TankEntity>> T72_TANK = ENTITIES.register("t72_tank",
            () -> EntityType.Builder.<T72TankEntity>of(T72TankEntity::new, MobCategory.MISC)
                    .sized(3.2F, 1.55F)
                    .clientTrackingRange(12)
                    .updateInterval(1)
                    .fireImmune()
                    .build("t72_tank"));

    public static final RegistryObject<EntityType<TankShellEntity>> TANK_SHELL = ENTITIES.register("tank_shell",
            () -> EntityType.Builder.<TankShellEntity>of(TankShellEntity::new, MobCategory.MISC)
                    .sized(0.35F, 0.35F)
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build("tank_shell"));

    public static final RegistryObject<Item> T72_SPAWN_ITEM = ITEMS.register("t72_spawner",
            () -> new Item(new Item.Properties().stacksTo(1)) {
                @Override
                public InteractionResult useOn(UseOnContext ctx) {
                    Level level = ctx.getLevel();
                    if (!level.isClientSide) {
                        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
                        T72TankEntity tank = T72_TANK.get().create(level);
                        if (tank != null) {
                            tank.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ctx.getRotation(), 0.0F);
                            tank.setTurretYaw(ctx.getRotation());
                            level.addFreshEntity(tank);
                            if (ctx.getPlayer() != null && !ctx.getPlayer().getAbilities().instabuild) {
                                ctx.getItemInHand().shrink(1);
                            }
                        }
                    }
                    return InteractionResult.sidedSuccess(level.isClientSide);
                }
            });

    public static final RegistryObject<Item> SHELL_125MM = ITEMS.register("shell_125mm",
            () -> new Item(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<CreativeModeTab> TANK_TAB = TABS.register("tank_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.t72mod"))
                    .icon(() -> new ItemStack(T72_SPAWN_ITEM.get()))
                    .displayItems((params, output) -> {
                        output.accept(T72_SPAWN_ITEM.get());
                        output.accept(SHELL_125MM.get());
                    })
                    .build());

    public T72Mod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(modEventBus);
        ITEMS.register(modEventBus);
        TABS.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::registerAttributes);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModMessages::register);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(T72_TANK.get(), T72TankEntity.createAttributes().build());
    }
}
