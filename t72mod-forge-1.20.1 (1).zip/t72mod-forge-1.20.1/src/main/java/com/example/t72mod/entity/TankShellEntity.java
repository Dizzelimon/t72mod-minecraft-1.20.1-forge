package com.example.t72mod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class TankShellEntity extends ThrowableProjectile {

    public TankShellEntity(EntityType<? extends ThrowableProjectile> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {}

    @Override
    protected float getGravity() {
        return 0.012F;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            Vec3 pos = this.position();
            this.level().addParticle(ParticleTypes.SMOKE, pos.x, pos.y, pos.z, 0, 0, 0);
            this.level().addParticle(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 0, 0, 0);
        }
        if (this.tickCount > 200) {
            this.discard();
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide) {
            Vec3 hit = result.getLocation();

            double[][] offsets = {
                    { 1.2D, 0.0D,  0.0D},
                    {-1.2D, 0.0D,  0.0D},
                    { 0.0D, 0.0D,  1.2D},
                    { 0.0D, 0.0D, -1.2D}
            };

            for (double[] off : offsets) {
                this.level().explode(
                        this,
                        hit.x + off[0], hit.y + off[1], hit.z + off[2],
                        4.0F,
                        Level.ExplosionInteraction.TNT
                );
            }

            this.level().explode(
                    this,
                    hit.x, hit.y, hit.z,
                    8.0F,
                    Level.ExplosionInteraction.TNT
            );

            this.discard();
        }
    }
}
