package com.example.t72mod.client.renderer;

import com.example.t72mod.client.model.T72TankModel;
import com.example.t72mod.entity.T72TankEntity;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.Random;

public class T72TankRenderer extends EntityRenderer<T72TankEntity> {
    private static ResourceLocation GENERATED_CAMO_TEXTURE;
    private final T72TankModel model;

    public T72TankRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.model = new T72TankModel(ctx.bakeLayer(T72TankModel.LAYER_LOCATION));
        this.shadowRadius = 2.1F;
    }

    @Override
    public void render(T72TankEntity entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();

        float hullYaw = Mth.rotLerp(partialTicks, entity.yRotO, entity.getYRot());
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - hullYaw));

        this.model.setupAnim(entity, 0.0F, 0.0F, entity.tickCount + partialTicks, 0.0F, 0.0F);
        VertexConsumer vertexConsumer = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        this.model.renderToBuffer(poseStack, vertexConsumer, packedLight, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);

        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(T72TankEntity entity) {
        if (GENERATED_CAMO_TEXTURE == null) {
            GENERATED_CAMO_TEXTURE = createProceduralSovietTankTexture();
        }
        return GENERATED_CAMO_TEXTURE;
    }

    private static ResourceLocation createProceduralSovietTankTexture() {
        NativeImage img = new NativeImage(256, 256, false);
        Random rng = new Random(7272L);

        for (int y = 0; y < 256; y++) {
            for (int x = 0; x < 256; x++) {
                int noise = rng.nextInt(14) - 7;
                int r = 62 + noise;
                int g = 80 + noise;
                int b = 46 + noise;

                if (y >= 140) {
                    int trackStripe = (y % 4 == 0) ? -15 : 5;
                    r = 38 + trackStripe;
                    g = 38 + trackStripe;
                    b = 40 + trackStripe;
                } else if (y >= 80 && x < 80) {
                    r = 45 + noise / 2;
                    g = 52 + noise / 2;
                    b = 38 + noise / 2;
                } else if (x >= 120 && y >= 40) {
                    r = 50 + noise / 2;
                    g = 62 + noise / 2;
                    b = 42 + noise / 2;
                }

                r = Mth.clamp(r, 0, 255);
                g = Mth.clamp(g, 0, 255);
                b = Mth.clamp(b, 0, 255);

                int abgr = (255 << 24) | (b << 16) | (g << 8) | r;
                img.setPixelRGBA(x, y, abgr);
            }
        }

        DynamicTexture dyn = new DynamicTexture(img);
        return Minecraft.getInstance().getTextureManager().register("t72_procedural_camo", dyn);
    }
}
