package com.example.t72mod.network;

import com.example.t72mod.T72Mod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;

public class ModMessages {
    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(T72Mod.MODID, "messages"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    public static void register() {
        INSTANCE.registerMessage(0,
                TankActionPacket.class,
                TankActionPacket::encode,
                TankActionPacket::decode,
                TankActionPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }
}
