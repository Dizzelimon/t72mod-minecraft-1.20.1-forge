package com.example.t72mod.entity;

import com.example.t72mod.T72Mod;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class T72TankEntity extends PathfinderMob {
    private static final EntityDataAccessor<Float> DATA_TURRET_YAW =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_BARREL_PITCH =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> DATA_HATCH_OPEN =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_RELOAD_TICKS =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_RECOIL_TICKS =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SMOKE_COOLDOWN =
            SynchedEntityData.defineId(T72TankEntity.class, EntityDataSerializers.INT);

    public static final int MAX_RELOAD_TICKS = 80;
    public float prevTurretYaw;
    public float prevBarrelPitch;
    public float wheelRotation;

    public T72TankEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setMaxUpStep(1.5F);
        this.blocksBuilding = true;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.ARMOR, 24.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 16.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.35D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_TURRET_YAW, 0.0F);
        this.entityData.define(DATA_BARREL_PITCH, 0.0F);
        this.entityData.define(DATA_HATCH_OPEN, true);
        this.entityData.define(DATA_RELOAD_TICKS, 0);
        this.entityData.define(DATA_RECOIL_TICKS, 0);
        this.entityData.define(DATA_SMOKE_COOLDOWN, 0);
    }

    @Override
    protected void registerGoals() {
    }

    @Override
    public boolean canBeCollidedWith() {
        return this.isAlive();
    }

    @Override
    public boolean canCollideWith(Entity other) {
        return (other.canBeCollidedWith() || other.isPushable()) && !this.isPassengerOfSameVehicle(other);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public InteractionResult interactAt(Player player, Vec3 clickVec, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;

        ItemStack stack = player.getItemInHand(hand);

        if (this.getHealth() < this.getMaxHealth() && (stack.is(Items.IRON_BLOCK) || stack.is(Items.IRON_INGOT))) {
            if (!this.level().isClientSide) {
                float heal = stack.is(Items.IRON_BLOCK) ? 45.0F : 10.0F;
                this.heal(heal);
                if (!player.getAbilities().instabuild) stack.shrink(1);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 1.0F, 1.1F);
                player.displayClientMessage(Component.literal("Броня отремонтирована: " + (int) this.getHealth() + "/" + (int) this.getMaxHealth())
                        .withStyle(ChatFormatting.GREEN), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        double playerHeightAboveGround = player.getY() - this.getY();
        double horizontalDistToTurret = Math.hypot(player.getX() - this.getX(), player.getZ() - this.getZ());
        boolean isStandingOnTank = playerHeightAboveGround >= 1.15D && horizontalDistToTurret <= 2.3D;
        boolean clickedTopHatchArea = clickVec.y >= 1.35D && Math.hypot(clickVec.x, clickVec.z) <= 1.2D;

        if (player.isShiftKeyDown()) {
            if (isStandingOnTank || clickedTopHatchArea) {
                if (!this.level().isClientSide) {
                    boolean nextState = !this.isHatchOpen();
                    this.setHatchOpen(nextState);
                    this.level().playSound(null, this.blockPosition(),
                            nextState ? SoundEvents.IRON_TRAPDOOR_OPEN : SoundEvents.IRON_TRAPDOOR_CLOSE,
                            SoundSource.BLOCKS, 1.0F, 0.75F);
                    player.displayClientMessage(Component.literal(nextState ? "Люк башни открыт" : "Люк башни задраен")
                            .withStyle(ChatFormatting.YELLOW), true);
                }
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            } else {
                if (!this.level().isClientSide) {
                    player.displayClientMessage(Component.literal("Поднимитесь на крышу танка, чтобы дотянуться до люка!")
                            .withStyle(ChatFormatting.RED), true);
                }
                return InteractionResult.FAIL;
            }
        }

        if (!this.isVehicle()) {
            if (!isStandingOnTank) {
                if (!this.level().isClientSide) {
                    player.displayClientMessage(Component.literal("Нельзя сесть с земли! Запрыгните на корпус Т-72 и войдите через верхний люк башни.")
                            .withStyle(ChatFormatting.GOLD), true);
                }
                return InteractionResult.FAIL;
            }

            if (!this.isHatchOpen()) {
                if (!this.level().isClientSide) {
                    player.displayClientMessage(Component.literal("Люк башни закрыт! Нажмите Shift + ПКМ по люку, чтобы открыть его.")
                            .withStyle(ChatFormatting.RED), true);
                }
                return InteractionResult.FAIL;
            }

            if (!this.level().isClientSide) {
                player.startRiding(this);
                this.setHatchOpen(false);
                this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 1.0F, 0.7F);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        return InteractionResult.PASS;
    }

    @Override
    protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (!this.level().isClientSide && passenger instanceof Player) {
            this.setHatchOpen(true);
            this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.BLOCKS, 1.0F, 0.75F);
            passenger.setPos(this.getX(), this.getY() + 1.65D, this.getZ());
        }
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        return new Vec3(this.getX(), this.getY() + 1.65D, this.getZ());
    }

    @Override
    public double getPassengersRidingOffset() {
        return 0.85D;
    }

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        return this.getFirstPassenger() instanceof LivingEntity living ? living : null;
    }

    @Override
    public void tick() {
        this.prevTurretYaw = this.getTurretYaw();
        this.prevBarrelPitch = this.getBarrelPitch();

        super.tick();

        if (this.getReloadTicks() > 0) this.setReloadTicks(this.getReloadTicks() - 1);
        if (this.getRecoilTicks() > 0) this.setRecoilTicks(this.getRecoilTicks() - 1);
        if (this.getSmokeCooldown() > 0) this.setSmokeCooldown(this.getSmokeCooldown() - 1);

        if (!this.level().isClientSide && this.getReloadTicks() == 1) {
            this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_DOOR_CLOSE, SoundSource.PLAYERS, 1.2F, 1.4F);
        }

        LivingEntity driver = this.getControllingPassenger();
        if (driver != null) {
            float targetYaw = driver.getYHeadRot();
            float currentYaw = this.getTurretYaw();
            float diffYaw = Mth.wrapDegrees(targetYaw - currentYaw);
            float clampedYawStep = Mth.clamp(diffYaw, -3.8F, 3.8F);
            this.setTurretYaw(currentYaw + clampedYawStep);

            float targetPitch = Mth.clamp(driver.getXRot(), -15.0F, 6.0F);
            float currentPitch = this.getBarrelPitch();
            this.setBarrelPitch(Mth.lerp(0.35F, currentPitch, targetPitch));

            if (this.level().isClientSide && this.tickCount % 3 == 0) {
                double rad = Math.toRadians(this.getYRot());
                double backX = this.getX() + Math.sin(rad) * 1.9D - Math.cos(rad) * 1.1D;
                double backZ = this.getZ() - Math.cos(rad) * 1.9D - Math.sin(rad) * 1.1D;
                this.level().addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                        backX, this.getY() + 0.95D, backZ,
                        Math.sin(rad) * 0.04D, 0.03D, -Math.cos(rad) * 0.04D);
            }

            if (!this.level().isClientSide && this.tickCount % 25 == 0) {
                this.level().playSound(null, this.blockPosition(), SoundEvents.MINECART_RIDING, SoundSource.NEUTRAL, 0.8F, 0.55F);
            }
        }

        double speedSq = this.getDeltaMovement().horizontalDistanceSqr();
        if (speedSq > 0.001D) {
            this.wheelRotation += (float) Math.sqrt(speedSq) * 1.8F;
            if (!this.level().isClientSide && speedSq > 0.025D) {
                AABB ramBox = this.getBoundingBox().inflate(0.25D, 0.0D, 0.25D);
                List<Entity> hitEntities = this.level().getEntities(this, ramBox,
                        e -> e instanceof LivingEntity && !this.isPassengerOfSameVehicle(e));
                for (Entity victim : hitEntities) {
                    victim.hurt(this.damageSources().mobAttack(this), 10.0F);
                    Vec3 knock = this.getDeltaMovement().normalize().scale(1.2D);
                    victim.push(knock.x, 0.35D, knock.z);
                }
            }
        }
    }

    @Override
    public void travel(Vec3 travelVector) {
        if (this.isAlive() && this.isVehicle() && this.getControllingPassenger() instanceof Player player) {
            float turnInput = -player.xxa;
            this.setYRot(this.getYRot() + turnInput * 2.1F);
            this.yRotO = this.getYRot();
            this.yBodyRot = this.getYRot();
            this.yHeadRot = this.getTurretYaw();

            float forwardInput = player.zza;
            if (forwardInput < 0.0F) {
                forwardInput *= 0.35F;
            }

            this.setSpeed(0.24F);
            super.travel(new Vec3(0.0D, travelVector.y, forwardInput));
            return;
        }
        super.travel(travelVector);
    }

    public void fireMainCannon(Player shooter) {
        if (this.level().isClientSide || this.getReloadTicks() > 0) return;

        if (!shooter.getAbilities().instabuild) {
            ItemStack foundAmmo = ItemStack.EMPTY;
            for (int i = 0; i < shooter.getInventory().getContainerSize(); i++) {
                ItemStack s = shooter.getInventory().getItem(i);
                if (s.is(T72Mod.SHELL_125MM.get())) {
                    foundAmmo = s;
                    break;
                }
            }
            if (foundAmmo.isEmpty()) {
                shooter.displayClientMessage(Component.literal("Боеукладка пуста! Нужен 125-мм выстрел ЗОФ26.")
                        .withStyle(ChatFormatting.RED), true);
                this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 1.0F, 0.8F);
                return;
            }
            foundAmmo.shrink(1);
        }

        float yawRad = (float) Math.toRadians(this.getTurretYaw());
        float pitchRad = (float) Math.toRadians(this.getBarrelPitch());

        Vec3 barrelDir = new Vec3(
                -Mth.sin(yawRad) * Mth.cos(pitchRad),
                -Mth.sin(pitchRad),
                Mth.cos(yawRad) * Mth.cos(pitchRad)
        ).normalize();

        Vec3 muzzlePos = new Vec3(this.getX(), this.getY() + 1.38D, this.getZ()).add(barrelDir.scale(3.8D));

        TankShellEntity shell = new TankShellEntity(T72Mod.TANK_SHELL.get(), this.level());
        shell.setOwner(shooter);
        shell.setPos(muzzlePos.x, muzzlePos.y, muzzlePos.z);
        shell.shoot(barrelDir.x, barrelDir.y, barrelDir.z, 4.6F, 0.15F);
        this.level().addFreshEntity(shell);

        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.FLASH, muzzlePos.x, muzzlePos.y, muzzlePos.z, 2, 0, 0, 0, 0);
            serverLevel.sendParticles(ParticleTypes.EXPLOSION, muzzlePos.x, muzzlePos.y, muzzlePos.z, 4, 0.2, 0.2, 0.2, 0.05);
            serverLevel.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, muzzlePos.x, muzzlePos.y, muzzlePos.z, 18, 0.35, 0.35, 0.35, 0.04);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 3.0F, 0.65F);
        this.level().playSound(null, this.blockPosition(), SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 2.5F, 0.5F);

        this.push(-barrelDir.x * 0.35D, 0.05D, -barrelDir.z * 0.35D);

        this.setRecoilTicks(10);
        this.setReloadTicks(MAX_RELOAD_TICKS);
    }

    public void fireCoaxialMG(Player shooter) {
        if (this.level().isClientSide) return;

        float yawRad = (float) Math.toRadians(this.getTurretYaw());
        float pitchRad = (float) Math.toRadians(this.getBarrelPitch());
        Vec3 dir = new Vec3(
                -Mth.sin(yawRad) * Mth.cos(pitchRad),
                -Mth.sin(pitchRad),
                Mth.cos(yawRad) * Mth.cos(pitchRad)
        ).normalize();

        Vec3 start = new Vec3(this.getX(), this.getY() + 1.35D, this.getZ()).add(dir.scale(2.0D));
        Vec3 end = start.add(dir.scale(48.0D));

        if (this.level() instanceof ServerLevel serverLevel) {
            for (int i = 2; i < 40; i += 4) {
                Vec3 p = start.add(dir.scale(i));
                serverLevel.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            }
        }

        AABB rayBox = new AABB(start, end).inflate(1.0D);
        List<LivingEntity> targets = this.level().getEntitiesOfClass(LivingEntity.class, rayBox,
                e -> e != this && e != shooter && e.getBoundingBox().inflate(0.35D).clip(start, end).isPresent());

        for (LivingEntity target : targets) {
            target.invulnerableTime = 0;
            target.hurt(this.damageSources().mobProjectile(this, shooter), 6.0F);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.2F, 1.8F);
    }

    public void deploySmokeScreen() {
        if (this.level().isClientSide || this.getSmokeCooldown() > 0) return;

        float yawRad = (float) Math.toRadians(this.getTurretYaw());
        Vec3 forward = new Vec3(-Mth.sin(yawRad), 0.2D, Mth.cos(yawRad)).normalize();
        Vec3 smokeCenter = this.position().add(forward.scale(8.5D));

        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE,
                    smokeCenter.x, smokeCenter.y + 1.5D, smokeCenter.z,
                    120, 3.8D, 2.0D, 3.8D, 0.01D);
            serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE,
                    smokeCenter.x, smokeCenter.y + 1.0D, smokeCenter.z,
                    60, 3.0D, 1.5D, 3.0D, 0.02D);
        }

        List<Monster> monsters = this.level().getEntitiesOfClass(Monster.class, this.getBoundingBox().inflate(24.0D));
        for (Monster m : monsters) {
            m.setTarget(null);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.DISPENSER_LAUNCH, SoundSource.PLAYERS, 2.0F, 0.7F);
        this.setSmokeCooldown(300);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getDirectEntity() instanceof AbstractArrow
                || source.is(DamageTypeTags.IS_FIRE)
                || source.is(DamageTypeTags.IS_FALL)
                || source.is(DamageTypeTags.IS_DROWNING)) {
            this.level().playSound(null, this.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.NEUTRAL, 0.5F, 1.8F);
            return false;
        }

        if (!source.is(DamageTypeTags.IS_EXPLOSION) && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            amount *= 0.15F;
        }

        return super.hurt(source, amount);
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }

    public float getTurretYaw() { return this.entityData.get(DATA_TURRET_YAW); }
    public void setTurretYaw(float yaw) { this.entityData.set(DATA_TURRET_YAW, yaw); }

    public float getBarrelPitch() { return this.entityData.get(DATA_BARREL_PITCH); }
    public void setBarrelPitch(float pitch) { this.entityData.set(DATA_BARREL_PITCH, pitch); }

    public boolean isHatchOpen() { return this.entityData.get(DATA_HATCH_OPEN); }
    public void setHatchOpen(boolean open) { this.entityData.set(DATA_HATCH_OPEN, open); }

    public int getReloadTicks() { return this.entityData.get(DATA_RELOAD_TICKS); }
    public void setReloadTicks(int ticks) { this.entityData.set(DATA_RELOAD_TICKS, ticks); }

    public int getRecoilTicks() { return this.entityData.get(DATA_RECOIL_TICKS); }
    public void setRecoilTicks(int ticks) { this.entityData.set(DATA_RECOIL_TICKS, ticks); }

    public int getSmokeCooldown() { return this.entityData.get(DATA_SMOKE_COOLDOWN); }
    public void setSmokeCooldown(int ticks) { this.entityData.set(DATA_SMOKE_COOLDOWN, ticks); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("TurretYaw", getTurretYaw());
        tag.putBoolean("HatchOpen", isHatchOpen());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("TurretYaw")) setTurretYaw(tag.getFloat("TurretYaw"));
        if (tag.contains("HatchOpen")) setHatchOpen(tag.getBoolean("HatchOpen"));
    }
}
