package com.example.t72mod.client;

import com.example.t72mod.T72Mod;
import com.example.t72mod.client.model.T72TankModel;
import com.example.t72mod.client.renderer.T72TankRenderer;
import com.example.t72mod.client.renderer.TankShellRenderer;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.network.ModMessages;
import com.example.t72mod.network.TankActionPacket;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientTankEvents {

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(T72TankModel.LAYER_LOCATION, T72TankModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(T72Mod.T72_TANK.get(), T72TankRenderer::new);
        event.registerEntityRenderer(T72Mod.TANK_SHELL.get(), TankShellRenderer::new);
    }

    @SubscribeEvent
    public static void registerGuiOverlay(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "t72_sight_hud", (gui, graphics, partialTick, width, height) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.getVehicle() instanceof T72TankEntity tank) {
                renderTankPeriscopeOverlay(graphics, mc, tank, width, height);
            }
        });
    }

    private static void renderTankPeriscopeOverlay(GuiGraphics g, Minecraft mc, T72TankEntity tank, int w, int h) {
        boolean isZooming = GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;

        int maskColor = 0xF2080A08;
        int topBottomBorder = isZooming ? (int) (h * 0.22F) : (int) (h * 0.26F);
        int sideBorder = isZooming ? (int) (w * 0.26F) : (int) (w * 0.14F);

        g.fill(0, 0, w, topBottomBorder, maskColor);
        g.fill(0, h - topBottomBorder, w, h, maskColor);
        g.fill(0, topBottomBorder, sideBorder, h - topBottomBorder, maskColor);
        g.fill(w - sideBorder, topBottomBorder, w, h - topBottomBorder, maskColor);

        int borderColor = 0xAA2E5C32;
        g.renderOutline(sideBorder, topBottomBorder, w - sideBorder * 2, h - topBottomBorder * 2, borderColor);

        int cx = w / 2;
        int cy = h / 2;
        int reticleColor = tank.getReloadTicks() == 0 ? 0xCC22FF44 : 0xCCFF5522;

        g.fill(cx - 80, cy, cx - 8, cy + 1, reticleColor);
        g.fill(cx + 9, cy, cx + 81, cy + 1, reticleColor);
        g.fill(cx, cy + 4, cx + 1, cy + 55, reticleColor);

        for (int i = 1; i <= 3; i++) {
            int dropY = cy + i * 12;
            g.fill(cx - 10, dropY, cx + 11, dropY + 1, reticleColor);
        }

        int reload = tank.getReloadTicks();
        String statusText = reload == 0
                ? "[ АЗ: 125-мм ГОТОВ К БОЮ ]"
                : String.format("[ ЗАРЯЖАНИЕ АЗ: %.1f с ]", reload / 20.0F);
        int statusColor = reload == 0 ? 0x55FF55 : 0xFFAA00;
        g.drawCenteredString(mc.font, statusText, cx, h - topBottomBorder + 10, statusColor);

        float relAngle = Mth.wrapDegrees(tank.getTurretYaw() - tank.getYRot());
        String infoLine = String.format("Азимут башни: %+.0f°  |  УВН: %+.1f°  |  Броня: %d/%d  |  Дымы (G): %s",
                relAngle,
                -tank.getBarrelPitch(),
                (int) tank.getHealth(),
                (int) tank.getMaxHealth(),
                tank.getSmokeCooldown() == 0 ? "ГОТОВЫ" : (tank.getSmokeCooldown() / 20 + "с"));
        g.drawCenteredString(mc.font, infoLine, cx, topBottomBorder - 16, 0xA8E6A8);

        g.drawCenteredString(mc.font,
                "ЛКМ: Выстрел 125мм (4 ТНТ)  |  ПКМ: Прицел 3.5x  |  V: Пулемет ПКТ  |  G: Дымы «Туча»",
                cx, h - 18, 0x888888);
    }

    @Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeBusEvents {

        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || !(mc.player.getVehicle() instanceof T72TankEntity tank)) return;

            if (mc.options.getCameraType() != CameraType.FIRST_PERSON) {
                mc.options.setCameraType(CameraType.FIRST_PERSON);
            }

            mc.player.setXRot(Mth.clamp(mc.player.getXRot(), -15.0F, 6.0F));

            if (mc.screen == null) {
                long win = mc.getWindow().getWindow();
                if (InputConstants.isKeyDown(win, GLFW.GLFW_KEY_V) && tank.tickCount % 3 == 0) {
                    ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_FIRE_MG));
                }
            }
        }

        @SubscribeEvent
        public static void onMouseClick(InputEvent.InteractionKeyMappingTriggered event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.getVehicle() instanceof T72TankEntity) {
                if (event.isAttack()) {
                    ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_FIRE_MAIN));
                    event.setCanceled(true);
                    event.setSwingHand(false);
                }
            }
        }

        @SubscribeEvent
        public static void onKeyInput(InputEvent.Key event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.screen == null && mc.player != null && mc.player.getVehicle() instanceof T72TankEntity) {
                if (event.getKey() == GLFW.GLFW_KEY_G && event.getAction() == GLFW.GLFW_PRESS) {
                    ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_SMOKE));
                }
            }
        }

        @SubscribeEvent
        public static void onComputeFov(ViewportEvent.ComputeFov event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.getVehicle() instanceof T72TankEntity && mc.screen == null) {
                if (GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS) {
                    event.setFOV(event.getFOV() * 0.28D);
                }
            }
        }
    }
}
