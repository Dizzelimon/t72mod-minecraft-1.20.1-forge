package com.example.t72mod.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.entity.PartEntity;

public class TankPartEntity extends PartEntity<T72TankEntity> {
    public static final int MODULE_HULL_FRONT = 0;
    public static final int MODULE_TRACKS = 1;
    public static final int MODULE_TURRET = 2;
    public static final int MODULE_ENGINE = 3;

    public final String partName;
    public final int moduleType;
    private final EntityDimensions size;

    public TankPartEntity(T72TankEntity parent, String partName, int moduleType, float width, float height) {
        super(parent);
        this.partName = partName;
        this.moduleType = moduleType;
        this.size = EntityDimensions.scalable(width, height);
        this.refreshDimensions();
        this.blocksBuilding = true;
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public boolean isPickable() {
        return this.getParent().isAlive();
    }

    @Override
    public boolean canBeCollidedWith() {
        return this.getParent().isAlive();
    }

    @Override
    public boolean canCollideWith(Entity other) {
        return this.getParent().canCollideWith(other);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return !this.isInvulnerableTo(source) && this.getParent().hurtFromPart(this, source, amount);
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        return this.getParent().interactFromPart(this, player, hand);
    }

    @Override
    public InteractionResult interactAt(Player player, Vec3 vec, InteractionHand hand) {
        return this.getParent().interactFromPart(this, player, hand);
    }

    @Override
    public boolean is(Entity entity) {
        return this == entity || this.getParent() == entity;
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return this.size;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        throw new UnsupportedOperationException();
    }

    public void movePartTo(double x, double y, double z) {
        this.setPos(x, y, z);
        this.xo = x;
        this.yo = y;
        this.zo = z;
        this.xOld = x;
        this.yOld = y;
        this.zOld = z;
    }
}
