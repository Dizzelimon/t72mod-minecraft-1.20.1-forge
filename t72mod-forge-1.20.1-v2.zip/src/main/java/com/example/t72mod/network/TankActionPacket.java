package com.example.t72mod.network;

import com.example.t72mod.entity.T72TankEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class TankActionPacket {
    public static final int ACTION_FIRE_MAIN = 0;
    public static final int ACTION_FIRE_MG = 1;
    public static final int ACTION_SMOKE = 2;
    public static final int ACTION_OPEN_INVENTORY = 3;
    public static final int ACTION_REPAIR = 4;

    private final int action;

    public TankActionPacket(int action) {
        this.action = action;
    }

    public static void encode(TankActionPacket msg, FriendlyByteBuf buf) {
        buf.writeInt(msg.action);
    }

    public static TankActionPacket decode(FriendlyByteBuf buf) {
        return new TankActionPacket(buf.readInt());
    }

    public static void handle(TankActionPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;

            if (player.getVehicle() instanceof T72TankEntity tank) {
                switch (msg.action) {
                    case ACTION_FIRE_MAIN -> tank.fireMainCannon(player);
                    case ACTION_FIRE_MG -> tank.fireCoaxialMG(player);
                    case ACTION_SMOKE -> tank.deploySmokeScreen();
                    case ACTION_OPEN_INVENTORY -> tank.openTankInventory(player);
                    case ACTION_REPAIR -> tank.performFieldRepair(player);
                }
            } else if (msg.action == ACTION_REPAIR && player.containerMenu instanceof com.example.t72mod.inventory.TankInventoryMenu menu) {
                T72TankEntity menuTank = menu.getTank();
                if (menuTank != null && menuTank.isAlive() && player.distanceTo(menuTank) <= 8.0F) {
                    menuTank.performFieldRepair(player);
                }
            }
        });
        ctx.setPacketHandled(true);
    }
}
