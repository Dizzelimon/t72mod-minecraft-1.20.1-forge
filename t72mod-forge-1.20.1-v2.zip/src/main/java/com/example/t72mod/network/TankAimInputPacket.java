package com.example.t72mod.network;

import com.example.t72mod.entity.T72TankEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class TankAimInputPacket {
    private final float turretYaw;
    private final float barrelPitch;

    public TankAimInputPacket(float turretYaw, float barrelPitch) {
        this.turretYaw = turretYaw;
        this.barrelPitch = barrelPitch;
    }

    public static void encode(TankAimInputPacket msg, FriendlyByteBuf buf) {
        buf.writeFloat(msg.turretYaw);
        buf.writeFloat(msg.barrelPitch);
    }

    public static TankAimInputPacket decode(FriendlyByteBuf buf) {
        return new TankAimInputPacket(buf.readFloat(), buf.readFloat());
    }

    public static void handle(TankAimInputPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null && player.getVehicle() instanceof T72TankEntity tank) {
                tank.applyClientTurretAim(msg.turretYaw, msg.barrelPitch);
            }
        });
        ctx.setPacketHandled(true);
    }
}
