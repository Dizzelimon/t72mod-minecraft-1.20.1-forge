package com.example.t72mod.client.gui;

import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.inventory.TankInventoryMenu;
import com.example.t72mod.network.ModMessages;
import com.example.t72mod.network.TankActionPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

public class TankInventoryScreen extends AbstractContainerScreen<TankInventoryMenu> {

    public TankInventoryScreen(TankInventoryMenu menu, Inventory playerInv, Component title) {
        super(menu, playerInv, title);
        this.imageWidth = 176;
        this.imageHeight = 174;
        this.inventoryLabelY = 81;
    }

    @Override
    protected void init() {
        super.init();
        int btnX = this.leftPos + 110;
        int btnY = this.topPos + 57;
        this.addRenderableWidget(Button.builder(Component.literal("Ремонт (R)"), btn -> {
            ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_REPAIR));
        }).bounds(btnX, btnY, 60, 18).build());
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = this.leftPos;
        int y = this.topPos;

        // Main panel background
        g.fill(x, y, x + this.imageWidth, y + this.imageHeight, 0xEE1B221B);
        g.renderOutline(x, y, this.imageWidth, this.imageHeight, 0xFF4A6B4A);
        g.renderOutline(x + 2, y + 2, this.imageWidth - 4, this.imageHeight - 4, 0xFF283828);

        // Draw slot frames
        for (Slot slot : this.menu.slots) {
            int sx = x + slot.x - 1;
            int sy = y + slot.y - 1;
            int slotColor = 0xFF2D362D;
            if (slot.index < 4) slotColor = 0xFF3E3524;       // Cannon shells (amber tint)
            else if (slot.index < 6) slotColor = 0xFF283E2A;  // MG ammo (green tint)
            else if (slot.index < 8) slotColor = 0xFF3B2C1E;  // Fuel (brown/orange tint)
            else if (slot.index == 8) slotColor = 0xFF263844; // Repair slot (blue-steel tint)

            g.fill(sx, sy, sx + 18, sy + 18, slotColor);
            g.renderOutline(sx, sy, 18, 18, 0xFF687A68);
        }

        // Status readout panel on right side
        T72TankEntity tank = this.menu.getTank();
        if (tank != null) {
            int statX = x + 130;
            int statY = y + 16;
            String fuelStr = "Бак: " + tank.getFuel() + "/" + T72TankEntity.MAX_FUEL;
            String mgStr = "ПКТ: " + tank.getMgAmmo();
            g.drawString(this.font, fuelStr, statX - 2, statY, 0xFFD566, false);
            g.drawString(this.font, mgStr, statX - 2, statY + 11, 0x88FF88, false);

            String modStatus = (tank.isTurretBroken() || tank.isTracksBroken() || tank.isEngineBroken())
                    ? "КРИТ МОДУЛЯ!"
                    : "Все узлы ОК";
            int modColor = (tank.isTurretBroken() || tank.isTracksBroken() || tank.isEngineBroken())
                    ? 0xFF5555 : 0x66FF66;
            g.drawString(this.font, modStatus, statX - 2, statY + 22, modColor, false);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(this.font, this.title, 8, 5, 0xD0F0D0, false);
        g.drawString(this.font, "Снаряды", 8, 16, 0xFFCC66, false);
        g.drawString(this.font, "Ленты", 88, 16, 0x88EE88, false);
        g.drawString(this.font, "Топливо", 8, 48, 0xFFAA44, false);
        g.drawString(this.font, "ЗИП", 88, 48, 0x77CCFF, false);
        g.drawString(this.font, this.playerInventoryTitle, 8, this.inventoryLabelY, 0xB8C8B8, false);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        this.renderTooltip(g, mouseX, mouseY);
    }
}
