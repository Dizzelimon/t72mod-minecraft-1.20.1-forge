package com.example.t72mod.client;

import com.example.t72mod.T72Mod;
import com.example.t72mod.client.gui.TankInventoryScreen;
import com.example.t72mod.client.model.AbramsTankModel;
import com.example.t72mod.client.model.Leopard2TankModel;
import com.example.t72mod.client.model.T72TankModel;
import com.example.t72mod.client.renderer.T72TankRenderer;
import com.example.t72mod.client.renderer.TankShellRenderer;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.TankType;
import com.example.t72mod.network.ModMessages;
import com.example.t72mod.network.TankActionPacket;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientTankEvents {

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            MenuScreens.register(T72Mod.TANK_MENU.get(), TankInventoryScreen::new);
        });
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(T72TankModel.LAYER_LOCATION, T72TankModel::createBodyLayer);
        event.registerLayerDefinition(AbramsTankModel.LAYER_LOCATION, AbramsTankModel::createBodyLayer);
        event.registerLayerDefinition(Leopard2TankModel.LAYER_LOCATION, Leopard2TankModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(T72Mod.T72_TANK.get(), T72TankRenderer::new);
        event.registerEntityRenderer(T72Mod.ABRAMS_TANK.get(), T72TankRenderer::new);
        event.registerEntityRenderer(T72Mod.LEOPARD2_TANK.get(), T72TankRenderer::new);
        event.registerEntityRenderer(T72Mod.TANK_SHELL.get(), TankShellRenderer::new);
    }

    @SubscribeEvent
    public static void registerGuiOverlay(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "t72_sight_hud", (gui, graphics, partialTick, width, height) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.getVehicle() instanceof T72TankEntity tank && mc.screen == null) {
                renderTankPeriscopeOverlay(graphics, mc, tank, partialTick, width, height);
            }
        });
    }

    private static void renderTankPeriscopeOverlay(GuiGraphics g, Minecraft mc, T72TankEntity tank, float partialTick, int w, int h) {
        boolean isZooming = GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        TankType type = tank.getTankType();

        int maskColor = 0xF2080A08;
        int topBottomBorder = isZooming ? (int) (h * 0.20F) : (int) (h * 0.24F);
        int sideBorder = isZooming ? (int) (w * 0.24F) : (int) (w * 0.13F);

        g.fill(0, 0, w, topBottomBorder, maskColor);
        g.fill(0, h - topBottomBorder, w, h, maskColor);
        g.fill(0, topBottomBorder, sideBorder, h - topBottomBorder, maskColor);
        g.fill(w - sideBorder, topBottomBorder, w, h - topBottomBorder, maskColor);

        int borderColor = switch (type) {
            case ABRAMS -> 0xAA327A6D;
            case LEOPARD2 -> 0xAA4D7A32;
            default -> 0xAA2E5C32;
        };
        g.renderOutline(sideBorder, topBottomBorder, w - sideBorder * 2, h - topBottomBorder * 2, borderColor);

        int cx = w / 2;
        int cy = h / 2;
        int reticleColor = tank.getReloadTicks() == 0
                ? (type == TankType.ABRAMS ? 0xCC33FFCC : 0xCC22FF44)
                : 0xCCFF5522;

        // Main cursor reticle
        g.fill(cx - 80, cy, cx - 8, cy + 1, reticleColor);
        g.fill(cx + 9, cy, cx + 81, cy + 1, reticleColor);
        g.fill(cx, cy + 4, cx + 1, cy + 55, reticleColor);

        for (int i = 1; i <= 3; i++) {
            int dropY = cy + i * 12;
            g.fill(cx - 10, dropY, cx + 11, dropY + 1, reticleColor);
        }

        // Dynamic physical barrel marker showing exact turret/gun direction relative to cursor
        float interpTurretYaw = Mth.rotLerp(partialTick, tank.prevTurretYaw, tank.getTurretYaw());
        float interpBarrelPitch = Mth.lerp(partialTick, tank.prevBarrelPitch, tank.getBarrelPitch());
        float playerYaw = Mth.rotLerp(partialTick, mc.player.yRotO, mc.player.getYRot());
        float playerPitch = Mth.lerp(partialTick, mc.player.xRotO, mc.player.getXRot());

        float yawDiff = Mth.wrapDegrees(interpTurretYaw - playerYaw);
        float pitchDiff = interpBarrelPitch - playerPitch;
        float pixelsPerDeg = isZooming ? 8.5F : 3.2F;

        int barrelX = Mth.clamp(cx + Math.round(yawDiff * pixelsPerDeg), sideBorder + 12, w - sideBorder - 12);
        int barrelY = Mth.clamp(cy + Math.round(pitchDiff * pixelsPerDeg), topBottomBorder + 12, h - topBottomBorder - 12);
        int barrelMarkerColor = tank.isTurretBroken() ? 0xFFFF2222 : 0xDDFFFF44;
        g.renderOutline(barrelX - 5, barrelY - 5, 11, 11, barrelMarkerColor);

        // Reload status
        int reload = tank.getReloadTicks();
        String statusText = reload == 0
                ? String.format("[ %s: ГОТОВ | Снарядов в укладке: %d ]", type.cannonTitle, tank.getShellCount())
                : String.format("[ ПЕРЕЗАРЯДКА: %.1f с ]", reload / 20.0F);
        int statusColor = reload == 0 ? 0x55FF55 : 0xFFAA00;
        g.drawCenteredString(mc.font, statusText, cx, h - topBottomBorder + 6, statusColor);

        // Top line 1: Telemetry (Hull, Armor, Fuel, MG Ammo, Smoke)
        float relAngle = Mth.wrapDegrees(interpTurretYaw - Mth.rotLerp(partialTick, tank.yRotO, tank.getYRot()));
        String telemetryLine = String.format("%s | Броня: %d/%d | Топливо: %d/%d | Пулемёт: %d патр. | Азимут: %+.0f° | Дымы: %s",
                type.displayName,
                (int) tank.getHealth(),
                (int) tank.getMaxHealth(),
                tank.getFuel(),
                T72TankEntity.MAX_FUEL,
                tank.getMgAmmo(),
                relAngle,
                tank.getSmokeCooldown() == 0 ? "ОК" : (tank.getSmokeCooldown() / 20 + "с"));
        g.drawCenteredString(mc.font, telemetryLine, cx, topBottomBorder - 26, 0xA8E6A8);

        // Top line 2: Module status (Turret, Tracks, Engine)
        String turretStat = tank.isTurretBroken() ? "§cБАШНЯ: КЛИН!" : ("§aБашня: " + tank.getTurretHealth() + "%");
        String tracksStat = tank.isTracksBroken() ? "§cГУСЕНИЦЫ: СБИТЫ!" : ("§aГусеницы: " + tank.getTracksHealth() + "%");
        String engineStat = tank.isEngineBroken() ? "§cДВИГАТЕЛЬ: КРИТ!" : ("§aДвигатель: " + tank.getEngineHealth() + "%");
        String moduleLine = "Узлы танка:  " + turretStat + "  |  " + tracksStat + "  |  " + engineStat;
        g.drawCenteredString(mc.font, moduleLine, cx, topBottomBorder - 13, 0xFFFFFF);

        // Bottom controls hint
        g.drawCenteredString(mc.font,
                "ЛКМ: Выстрел | ПКМ: Прицел | V: Пулемёт | G: Дымы | I: Слоты и топливо | R: Полевой ремонт",
                cx, h - 15, 0x999999);
    }

    @Mod.EventBusSubscriber(modid = T72Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeBusEvents {

        @SubscribeEvent
        public static void onComputeCameraAngles(ViewportEvent.ComputeCameraAngles event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.getVehicle() instanceof T72TankEntity tank) {
                TankType type = tank.getTankType();
                // Clamp pitch every single render frame to prevent 20Hz tick snapping jitter
                float clampedPitch = Mth.clamp(mc.player.getXRot(), type.minBarrelPitch, type.maxBarrelPitch);
                if (mc.player.getXRot() != clampedPitch) {
                    mc.player.setXRot(clampedPitch);
                    mc.player.xRotO = clampedPitch;
                }
                event.setPitch(clampedPitch);
            }
        }

        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || !(mc.player.getVehicle() instanceof T72TankEntity tank)) return;

            if (mc.options.getCameraType() != CameraType.FIRST_PERSON) {
                mc.options.setCameraType(CameraType.FIRST_PERSON);
            }

            TankType type = tank.getTankType();
            float clampedPitch = Mth.clamp(mc.player.getXRot(), type.minBarrelPitch, type.maxBarrelPitch);
            if (mc.player.getXRot() != clampedPitch) {
                mc.player.setXRot(clampedPitch);
                mc.player.xRotO = clampedPitch;
            }

            if (mc.screen == null) {
                long win = mc.getWindow().getWindow();
                if (InputConstants.isKeyDown(win, GLFW.GLFW_KEY_V) && tank.tickCount % 3 == 0) {
                    ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_FIRE_MG));
                }
            }
        }

        @SubscribeEvent
        public static void onMouseClick(InputEvent.InteractionKeyMappingTriggered event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.getVehicle() instanceof T72TankEntity) {
                if (event.isAttack()) {
                    ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_FIRE_MAIN));
                    event.setCanceled(true);
                    event.setSwingHand(false);
                }
            }
        }

        @SubscribeEvent
        public static void onKeyInput(InputEvent.Key event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.screen == null && mc.player != null && mc.player.getVehicle() instanceof T72TankEntity) {
                if (event.getAction() == GLFW.GLFW_PRESS) {
                    if (event.getKey() == GLFW.GLFW_KEY_G) {
                        ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_SMOKE));
                    } else if (event.getKey() == GLFW.GLFW_KEY_I || event.getKey() == GLFW.GLFW_KEY_B) {
                        ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_OPEN_INVENTORY));
                    } else if (event.getKey() == GLFW.GLFW_KEY_R) {
                        ModMessages.INSTANCE.sendToServer(new TankActionPacket(TankActionPacket.ACTION_REPAIR));
                    }
                }
            }
        }

        @SubscribeEvent
        public static void onComputeFov(ViewportEvent.ComputeFov event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.player.getVehicle() instanceof T72TankEntity tank && mc.screen == null) {
                if (GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS) {
                    event.setFOV(event.getFOV() * tank.getTankType().zoomFovMultiplier);
                }
            }
        }
    }
}
