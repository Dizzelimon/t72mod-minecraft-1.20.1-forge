package com.example.t72mod.client.model;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.T72TankEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class T72TankModel extends EntityModel<T72TankEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(T72Mod.MODID, "t72_tank"), "main");

    private final ModelPart root;
    private final ModelPart hull;
    private final ModelPart turret;
    private final ModelPart barrel;
    private final ModelPart hatch;

    public T72TankModel(ModelPart root) {
        this.root = root;
        this.hull = root.getChild("hull");
        this.turret = root.getChild("turret");
        this.barrel = this.turret.getChild("barrel");
        this.hatch = this.turret.getChild("hatch");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-18.0F, 6.0F, -34.0F, 36.0F, 10.0F, 68.0F)
                .texOffs(0, 0).addBox(-17.0F, 14.0F, -36.0F, 34.0F, 4.0F, 16.0F)
                .texOffs(0, 0).addBox(-17.0F, 15.0F, 12.0F, 34.0F, 3.0F, 22.0F)
                .texOffs(0, 80).addBox(-24.0F, 9.0F, -35.0F, 2.0F, 7.0F, 70.0F)
                .texOffs(0, 80).addBox(22.0F, 9.0F, -35.0F, 2.0F, 7.0F, 70.0F)
                .texOffs(0, 140).addBox(-23.0F, 0.0F, -34.0F, 6.0F, 10.0F, 68.0F)
                .texOffs(0, 140).addBox(17.0F, 0.0F, -34.0F, 6.0F, 10.0F, 68.0F)
                // Rear external fuel drums (characteristic of T-72B)
                .texOffs(120, 0).addBox(-15.0F, 12.0F, 34.0F, 12.0F, 8.0F, 8.0F)
                .texOffs(120, 0).addBox(3.0F, 12.0F, 34.0F, 12.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        for (int i = 0; i < 6; i++) {
            float zOffset = -25.0F + i * 10.0F;
            hull.addOrReplaceChild("wheel_l_" + i, CubeListBuilder.create()
                    .texOffs(160, 0).addBox(-23.5F, 1.0F, zOffset - 3.5F, 2.0F, 7.0F, 7.0F),
                    PartPose.ZERO);
            hull.addOrReplaceChild("wheel_r_" + i, CubeListBuilder.create()
                    .texOffs(160, 0).addBox(21.5F, 1.0F, zOffset - 3.5F, 2.0F, 7.0F, 7.0F),
                    PartPose.ZERO);
        }

        PartDefinition turret = root.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-15.0F, 16.0F, -18.0F, 30.0F, 9.0F, 32.0F)
                .texOffs(80, 80).addBox(-13.0F, 17.0F, -23.0F, 26.0F, 7.0F, 6.0F)
                .texOffs(120, 20).addBox(-11.0F, 17.0F, 14.0F, 22.0F, 7.0F, 6.0F)
                .texOffs(160, 20).addBox(-16.5F, 19.0F, -12.0F, 2.0F, 4.0F, 6.0F),
                PartPose.offset(0.0F, 0.0F, -2.0F));

        turret.addOrReplaceChild("barrel", CubeListBuilder.create()
                .texOffs(120, 40).addBox(-4.0F, -3.0F, -6.0F, 8.0F, 6.0F, 6.0F)
                .texOffs(120, 60).addBox(-1.5F, -1.5F, -62.0F, 3.0F, 3.0F, 58.0F)
                .texOffs(120, 40).addBox(-2.5F, -2.5F, -36.0F, 5.0F, 5.0F, 10.0F),
                PartPose.offset(0.0F, 20.5F, -21.0F));

        turret.addOrReplaceChild("hatch", CubeListBuilder.create()
                .texOffs(80, 100).addBox(-6.0F, -1.5F, -10.0F, 12.0F, 2.0F, 12.0F),
                PartPose.offset(4.0F, 25.0F, 2.0F));

        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(T72TankEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        float partialTick = ageInTicks - entity.tickCount;

        float hullYaw = Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot());
        float turretYaw = Mth.rotLerp(partialTick, entity.prevTurretYaw, entity.getTurretYaw());
        float relativeTurretYaw = Mth.wrapDegrees(turretYaw - hullYaw);

        // Negated because renderer applies 180.0F - hullYaw around +Y
        this.turret.yRot = (float) Math.toRadians(-relativeTurretYaw);

        float pitch = Mth.lerp(partialTick, entity.prevBarrelPitch, entity.getBarrelPitch());
        // Negated so negative pitch (looking UP) raises the barrel (+Y)
        this.barrel.xRot = (float) Math.toRadians(-pitch);

        float recoilOffset = entity.getRecoilTicks() > 0
                ? Mth.sin((entity.getRecoilTicks() - partialTick) * 0.3F) * 6.5F
                : 0.0F;
        this.barrel.z = -21.0F + recoilOffset;

        this.hatch.xRot = entity.isHatchOpen() ? -1.35F : 0.0F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
