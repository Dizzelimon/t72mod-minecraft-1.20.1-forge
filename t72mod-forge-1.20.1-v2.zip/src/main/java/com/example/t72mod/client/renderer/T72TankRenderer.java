package com.example.t72mod.client.renderer;

import com.example.t72mod.client.model.AbramsTankModel;
import com.example.t72mod.client.model.Leopard2TankModel;
import com.example.t72mod.client.model.T72TankModel;
import com.example.t72mod.entity.T72TankEntity;
import com.example.t72mod.entity.TankType;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.Random;

public class T72TankRenderer extends EntityRenderer<T72TankEntity> {
    private static ResourceLocation SOVIET_CAMO_TEXTURE;
    private static ResourceLocation ABRAMS_DESERT_TEXTURE;
    private static ResourceLocation LEOPARD_NATO_TEXTURE;

    private final T72TankModel t72Model;
    private final AbramsTankModel abramsModel;
    private final Leopard2TankModel leopard2Model;

    public T72TankRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.t72Model = new T72TankModel(ctx.bakeLayer(T72TankModel.LAYER_LOCATION));
        this.abramsModel = new AbramsTankModel(ctx.bakeLayer(AbramsTankModel.LAYER_LOCATION));
        this.leopard2Model = new Leopard2TankModel(ctx.bakeLayer(Leopard2TankModel.LAYER_LOCATION));
        this.shadowRadius = 2.2F;
    }

    @Override
    public void render(T72TankEntity entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();

        float hullYaw = Mth.rotLerp(partialTicks, entity.yRotO, entity.getYRot());
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - hullYaw));

        EntityModel<T72TankEntity> activeModel = switch (entity.getTankType()) {
            case ABRAMS -> this.abramsModel;
            case LEOPARD2 -> this.leopard2Model;
            default -> this.t72Model;
        };

        activeModel.setupAnim(entity, 0.0F, 0.0F, entity.tickCount + partialTicks, 0.0F, 0.0F);
        VertexConsumer vertexConsumer = buffer.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        activeModel.renderToBuffer(poseStack, vertexConsumer, packedLight, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);

        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(T72TankEntity entity) {
        return switch (entity.getTankType()) {
            case ABRAMS -> {
                if (ABRAMS_DESERT_TEXTURE == null) {
                    ABRAMS_DESERT_TEXTURE = createProceduralAbramsTexture();
                }
                yield ABRAMS_DESERT_TEXTURE;
            }
            case LEOPARD2 -> {
                if (LEOPARD_NATO_TEXTURE == null) {
                    LEOPARD_NATO_TEXTURE = createProceduralLeopardTexture();
                }
                yield LEOPARD_NATO_TEXTURE;
            }
            default -> {
                if (SOVIET_CAMO_TEXTURE == null) {
                    SOVIET_CAMO_TEXTURE = createProceduralSovietTankTexture();
                }
                yield SOVIET_CAMO_TEXTURE;
            }
        };
    }

    private static ResourceLocation createProceduralSovietTankTexture() {
        NativeImage img = new NativeImage(256, 256, false);
        Random rng = new Random(7272L);

        for (int y = 0; y < 256; y++) {
            for (int x = 0; x < 256; x++) {
                int noise = rng.nextInt(14) - 7;
                int r = 62 + noise;
                int g = 80 + noise;
                int b = 46 + noise;

                if (y >= 140) {
                    int trackStripe = (y % 4 == 0) ? -15 : 5;
                    r = 38 + trackStripe;
                    g = 38 + trackStripe;
                    b = 40 + trackStripe;
                } else if (y >= 80 && x < 80) {
                    r = 45 + noise / 2;
                    g = 52 + noise / 2;
                    b = 38 + noise / 2;
                } else if (x >= 120 && y >= 40) {
                    r = 50 + noise / 2;
                    g = 62 + noise / 2;
                    b = 42 + noise / 2;
                }

                r = Mth.clamp(r, 0, 255);
                g = Mth.clamp(g, 0, 255);
                b = Mth.clamp(b, 0, 255);

                int abgr = (255 << 24) | (b << 16) | (g << 8) | r;
                img.setPixelRGBA(x, y, abgr);
            }
        }

        DynamicTexture dyn = new DynamicTexture(img);
        return Minecraft.getInstance().getTextureManager().register("t72_procedural_camo", dyn);
    }

    private static ResourceLocation createProceduralAbramsTexture() {
        NativeImage img = new NativeImage(256, 256, false);
        Random rng = new Random(1991L);

        for (int y = 0; y < 256; y++) {
            for (int x = 0; x < 256; x++) {
                int noise = rng.nextInt(12) - 6;
                // Desert Tan CARC camouflage (US M1A2 SEP)
                int r = 194 + noise;
                int g = 172 + noise;
                int b = 128 + noise;

                if (y >= 140) {
                    int trackStripe = (y % 4 == 0) ? -16 : 6;
                    r = 44 + trackStripe;
                    g = 42 + trackStripe;
                    b = 40 + trackStripe;
                } else if (y >= 80 && x < 80) {
                    r = 175 + noise / 2;
                    g = 154 + noise / 2;
                    b = 112 + noise / 2;
                } else if (x >= 120 && y >= 40) {
                    r = 162 + noise / 2;
                    g = 142 + noise / 2;
                    b = 104 + noise / 2;
                }

                r = Mth.clamp(r, 0, 255);
                g = Mth.clamp(g, 0, 255);
                b = Mth.clamp(b, 0, 255);

                int abgr = (255 << 24) | (b << 16) | (g << 8) | r;
                img.setPixelRGBA(x, y, abgr);
            }
        }

        DynamicTexture dyn = new DynamicTexture(img);
        return Minecraft.getInstance().getTextureManager().register("abrams_desert_camo", dyn);
    }

    private static ResourceLocation createProceduralLeopardTexture() {
        NativeImage img = new NativeImage(256, 256, false);
        Random rng = new Random(2006L);

        for (int y = 0; y < 256; y++) {
            for (int x = 0; x < 256; x++) {
                int noise = rng.nextInt(12) - 6;
                // NATO Three-Tone Camo (Bronze Green / Leather Brown / Tar Black)
                double wave = Math.sin(x * 0.075D) + Math.cos(y * 0.075D);
                int r, g, b;
                if (wave > 0.65D) {
                    // Leather Brown
                    r = 98 + noise;
                    g = 68 + noise;
                    b = 48 + noise;
                } else if (wave < -0.75D) {
                    // Tar Black
                    r = 38 + noise / 2;
                    g = 40 + noise / 2;
                    b = 38 + noise / 2;
                } else {
                    // Bronze Green
                    r = 68 + noise;
                    g = 84 + noise;
                    b = 58 + noise;
                }

                if (y >= 140) {
                    int trackStripe = (y % 4 == 0) ? -15 : 5;
                    r = 36 + trackStripe;
                    g = 36 + trackStripe;
                    b = 38 + trackStripe;
                }

                r = Mth.clamp(r, 0, 255);
                g = Mth.clamp(g, 0, 255);
                b = Mth.clamp(b, 0, 255);

                int abgr = (255 << 24) | (b << 16) | (g << 8) | r;
                img.setPixelRGBA(x, y, abgr);
            }
        }

        DynamicTexture dyn = new DynamicTexture(img);
        return Minecraft.getInstance().getTextureManager().register("leopard2_nato_camo", dyn);
    }
}
