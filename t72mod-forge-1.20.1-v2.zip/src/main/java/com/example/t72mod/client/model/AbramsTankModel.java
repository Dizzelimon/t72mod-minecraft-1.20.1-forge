package com.example.t72mod.client.model;

import com.example.t72mod.T72Mod;
import com.example.t72mod.entity.T72TankEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class AbramsTankModel extends EntityModel<T72TankEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(T72Mod.MODID, "abrams_tank"), "main");

    private final ModelPart root;
    private final ModelPart hull;
    private final ModelPart turret;
    private final ModelPart barrel;
    private final ModelPart hatch;

    public AbramsTankModel(ModelPart root) {
        this.root = root;
        this.hull = root.getChild("hull");
        this.turret = root.getChild("turret");
        this.barrel = this.turret.getChild("barrel");
        this.hatch = this.turret.getChild("hatch");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // Wide, low-slung M1A2 Abrams hull with Chobham frontal glacis and heavy ballistic side skirts
        PartDefinition hull = root.addOrReplaceChild("hull", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-20.0F, 6.0F, -37.0F, 40.0F, 10.0F, 74.0F)
                .texOffs(0, 0).addBox(-19.0F, 13.0F, -40.0F, 38.0F, 4.0F, 18.0F)
                .texOffs(0, 80).addBox(-26.0F, 8.0F, -38.0F, 2.0F, 9.0F, 76.0F)
                .texOffs(0, 80).addBox(24.0F, 8.0F, -38.0F, 2.0F, 9.0F, 76.0F)
                .texOffs(0, 140).addBox(-25.0F, 0.0F, -36.0F, 7.0F, 10.0F, 72.0F)
                .texOffs(0, 140).addBox(18.0F, 0.0F, -36.0F, 7.0F, 10.0F, 72.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        // 7 Roadwheels per side (characteristic of M1A2 Abrams)
        for (int i = 0; i < 7; i++) {
            float zOffset = -27.0F + i * 9.0F;
            hull.addOrReplaceChild("wheel_l_" + i, CubeListBuilder.create()
                    .texOffs(160, 0).addBox(-25.5F, 1.0F, zOffset - 3.5F, 2.0F, 7.0F, 7.0F),
                    PartPose.ZERO);
            hull.addOrReplaceChild("wheel_r_" + i, CubeListBuilder.create()
                    .texOffs(160, 0).addBox(23.5F, 1.0F, zOffset - 3.5F, 2.0F, 7.0F, 7.0F),
                    PartPose.ZERO);
        }

        // Large angular flat-sloped M1A2 turret with long rear bustle & blowout panels + CITV optic
        PartDefinition turret = root.addOrReplaceChild("turret", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-18.0F, 16.0F, -20.0F, 36.0F, 10.0F, 44.0F)
                .texOffs(80, 80).addBox(-17.0F, 17.0F, -27.0F, 34.0F, 8.0F, 8.0F)
                .texOffs(120, 20).addBox(-16.0F, 17.0F, 24.0F, 32.0F, 8.0F, 10.0F)
                // CITV Independent Thermal Viewer & Commander .50 cal mount
                .texOffs(160, 20).addBox(-12.0F, 26.0F, -10.0F, 7.0F, 5.0F, 7.0F)
                .texOffs(160, 20).addBox(6.0F, 26.0F, -6.0F, 6.0F, 5.0F, 14.0F),
                PartPose.offset(0.0F, 0.0F, -1.0F));

        // 120mm M256 Smoothbore Cannon with central thermal sleeve & bore evacuator
        turret.addOrReplaceChild("barrel", CubeListBuilder.create()
                .texOffs(120, 40).addBox(-5.0F, -3.5F, -7.0F, 10.0F, 7.0F, 8.0F)
                .texOffs(120, 60).addBox(-2.0F, -2.0F, -64.0F, 4.0F, 4.0F, 58.0F)
                .texOffs(120, 40).addBox(-3.0F, -3.0F, -35.0F, 6.0F, 6.0F, 12.0F),
                PartPose.offset(0.0F, 21.0F, -26.0F));

        turret.addOrReplaceChild("hatch", CubeListBuilder.create()
                .texOffs(80, 100).addBox(-6.0F, -1.5F, -10.0F, 12.0F, 2.0F, 12.0F),
                PartPose.offset(6.0F, 26.0F, 5.0F));

        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(T72TankEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        float partialTick = ageInTicks - entity.tickCount;

        float hullYaw = Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot());
        float turretYaw = Mth.rotLerp(partialTick, entity.prevTurretYaw, entity.getTurretYaw());
        float relativeTurretYaw = Mth.wrapDegrees(turretYaw - hullYaw);

        this.turret.yRot = (float) Math.toRadians(-relativeTurretYaw);

        float pitch = Mth.lerp(partialTick, entity.prevBarrelPitch, entity.getBarrelPitch());
        this.barrel.xRot = (float) Math.toRadians(-pitch);

        float recoilOffset = entity.getRecoilTicks() > 0
                ? Mth.sin((entity.getRecoilTicks() - partialTick) * 0.3F) * 6.0F
                : 0.0F;
        this.barrel.z = -26.0F + recoilOffset;

        this.hatch.xRot = entity.isHatchOpen() ? -1.35F : 0.0F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
